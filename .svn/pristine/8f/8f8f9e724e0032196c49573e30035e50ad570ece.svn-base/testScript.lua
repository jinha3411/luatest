--require "Libraries"
package.path = package.path .. ";C:/HHIAutomation/OpenBlockWeldingRobot_Server/LuaLibs/?.lua"
require "WeldInformation"
require "RobotPoseData"
require "WeldMainCondition"

pose_1_start = RobotPoseData:createFromIndividual(1, 1, 1, 1, 1, 1, 1, 1)
pose_1_mid = RobotPoseData:createFromIndividual(2, 2, 2, 2, 2, 2, 2, 2)
pose_1_end = RobotPoseData:createFromIndividual(3, 3, 3, 3, 3, 3, 3, 3)

main_1 = WeldMainCondition:new()
main_1:SetStartPose(pose_1_start)
main_1:SetMidPose(pose_1_mid)
main_1:SetEndPose(pose_1_end)

pose_2_start = RobotPoseData:createFromIndividual(10, 10, 10, 10, 10, 10, 10, 10)
pose_2_mid = RobotPoseData:createFromIndividual(20, 20, 20, 20, 20, 20, 20, 20)
pose_2_end = RobotPoseData:createFromIndividual(30, 30, 30, 30, 30, 30, 30, 30)

main_2 = WeldMainCondition:new()
main_2:SetStartPose(pose_2_start)
main_2:SetMidPose(pose_2_mid)
main_2:SetEndPose(pose_2_end)

weldInfo = WeldInformation:new()
weldInfo:AddMainCondition(main_1)
weldInfo:AddMainCondition(main_2)

weldInfo:ApplyOffset(10, 10, 10, 10, 10, 10, 10)
test = RobotPoseData:createFromIndividual(30, 30, 30, 30, 30, 30, 30, 30)
Helper:ClassToLua_RobotPoseData(10)
pose_test = Helper:MOVE(pose_2_mid, 40, 0)
Helper:MOVE(pose_test, 20)