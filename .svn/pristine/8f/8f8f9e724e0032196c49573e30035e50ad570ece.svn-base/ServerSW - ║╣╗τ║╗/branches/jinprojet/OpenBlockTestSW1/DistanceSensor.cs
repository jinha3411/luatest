﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.IO;
using System.IO.Ports;

namespace OpenBlockWeldingRobot
{

    class DataEX_DistanceSensor
    {
        public int test;

        //여기에 데이터교환 필요한 변수 정의

        //상태변수
        public byte DistanceSensorState;    //센서 상태. 정의필요


        public DateTime[] DistanceSensorCommTime = new DateTime[3];      //마지막 통신 성공 시간

        //센서 입력 변수. 스레드에서 통신으로 받아온 값을 여기에 씀. 메인스레드에서 읽어감

        //DistanceSensorValue[0]:첫번째 센서 측정값
        //DistanceSensorValue[1]:두번째 센서 측정값
        //DistanceSensorValue[2]:세번째 센서 측정값
        public double[] DistanceSensorValue = new double[3];

    }




    class ThreadClass_DistanceSensor
    {
        public DataEX_DistanceSensor DistanceSensorData;
        public Thread DistanceSensorthread;
        private bool threadContinue;

        //시퀸스 상태변수
        public string DistanceCommunicationSeq = "시작대기";
        //초기화 로그
        public StringBuilder DistanceInitLog = new StringBuilder();

        SerialPort DistanceSensorSerialPort = new SerialPort();

        List<char> DistanceSensorRxDataList = new List<char>();

        DateTime TxTime = DateTime.Now;



        ////생성자 1
        //public ThreadClass_DistanceSensor()
        //{

        //}

        //생성자 2
        public ThreadClass_DistanceSensor(DataEX_DistanceSensor atemp)
        {
            DistanceSensorData = atemp;

            //스래드클래스의 함수를 스래드로 돌림
            DistanceSensorthread = new Thread(new ThreadStart(threadfunc));
            DistanceSensorthread.Start();
            DistanceCommunicationSeq = "초기화-시작";
        }


        //스레드 함수
        public void threadfunc()
        {
            threadContinue = true;
            DateTime InitStartTime = DateTime.Now;
            char[] txdata, rxdata, tempchar;
            int tempi;
            string tempstr="";
            double tempd = 0;


            while (threadContinue)
            {

                switch (DistanceCommunicationSeq)
                {
                    case "시작대기":
                        //초기상태. 아무것도 안함
                        break;

                    case "초기화-시작":
                        //외부에서 "접속시작-0" 단계로 바꾸면 접속절차 시작함
                        DistanceInitLog.Clear();
                        DistanceInitLog.AppendLine("거리센서-초기화 시작");
                        DistanceInitLog.AppendLine("거리센서-통신포트 생성 시작");

                        DistanceSensorSerialPort.PortName = "COM2";
                        DistanceSensorSerialPort.BaudRate = 38400;
                        DistanceSensorSerialPort.Parity = Parity.None;
                        DistanceSensorSerialPort.StopBits = StopBits.One;
                        DistanceSensorSerialPort.DataBits = 8;
                        DistanceSensorSerialPort.Handshake = Handshake.None;
                        DistanceSensorSerialPort.RtsEnable = true;
                        DistanceSensorSerialPort.DtrEnable = true;


                        try
                        {
                            DistanceSensorSerialPort.Open();
                            DistanceInitLog.AppendLine("거리센서-통신포트 생성 성공");
                            DistanceInitLog.AppendLine("거리센서-통신 수신대기 시작");
                            InitStartTime = DateTime.Now;
                            DistanceCommunicationSeq = "초기화-통신 수신대기";
                        }
                        catch
                        {
                            DistanceInitLog.AppendLine("거리센서-통신포트 생성 실패");
                            DistanceCommunicationSeq = "초기화-실패";
                        }


                        break;

                    case "초기화-통신 수신대기":
                        //센서에서 제대로 된 패킷이 날라오는지 확인함. 0.5초 이상 정상패킷이 수신되지 않으면 에러처리

                        //시간 체크함. 500ms 이상 경과하면 실패처리
                        tempi = (int)(DateTime.Now - InitStartTime).Ticks / 10000;
                        if (tempi > 1000)
                        {
                            DistanceInitLog.AppendLine("거리센서-센서 통신 수신실패");
                            DistanceCommunicationSeq = "초기화-실패";
                        }


                        //데이터 요청패킷 전송
                        txdata = new char[] { (char)0x02, 'M', 'E', 'A', 'S', 'U', 'R', 'E', (char)0x03 };
                        DistanceSensorSerialPort.Write(txdata, 0, 9);


                        //수신데이터 처리함
                        rxdata = DistanceSensorSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length != 0)
                        {
                            if ((rxdata[0] == (char)0x02) && (rxdata[rxdata.Length - 1] == (char)0x03))
                            {
                                try
                                {
                                    tempstr = new string(rxdata, 1, rxdata.Length - 2);
                                    tempd = Convert.ToDouble(tempstr);
                                    DistanceInitLog.AppendLine("거리센서-센서 통신 수신성공");
                                    DistanceCommunicationSeq = "메인반복-시작";
                                }
                                catch
                                {


                                }
                            }
                        }
                        
                        break;

                    case "초기화-실패":



                        break;

                    case "메인반복-시작":

                        //수신데이터 처리함
                        rxdata = DistanceSensorSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length != 0)
                        {
                            if ((rxdata[0] == (char)0x02) && (rxdata[rxdata.Length - 1] == (char)0x03))
                            {
                                try
                                {
                                    tempstr = new string(rxdata, 1, rxdata.Length - 2);
                                    tempd = Convert.ToDouble(tempstr);
                                    DistanceSensorData.DistanceSensorCommTime[0] = DateTime.Now;
                                    DistanceSensorData.DistanceSensorValue[0] = tempd;
                                }
                                catch
                                {


                                }
                            }
                        }



                        //데이터 요청패킷 전송
                        txdata = new char[] { (char)0x02, 'M', 'E', 'A', 'S', 'U', 'R', 'E', (char)0x03 };
                        DistanceSensorSerialPort.Write(txdata, 0, 9);


                        break;

                    default:
                        break;

                }





                //40m 대기
                Thread.Sleep(40);
            }
        }

        //스레드 종료 호출
        public void threadStop()
        {
            threadContinue = false;
        }


    }
}
