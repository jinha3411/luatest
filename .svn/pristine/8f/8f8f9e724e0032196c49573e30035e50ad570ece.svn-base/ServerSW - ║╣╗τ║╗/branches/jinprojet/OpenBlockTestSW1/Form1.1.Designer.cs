﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//추가된 네임스페이스
using System.Threading;
using System.IO;

namespace OpenBlockWeldingRobot
{
    //메인 Form1 클래스의 파샬클래스
    //메인클래스 공동작업이 필요 한 경우 동시에 동일한 파일 수정하는것을 막기위해 만들었음.
    //여기에는 주로 설정파일을 만들고 설정값을 핸들링하는 코드 위주로 작성
    
    public partial class Form1
    {


        //초기설정 파일 불러오기. 없으면 기본설정으로 파일 생성
        /// <summary>
        /// 초기설정 파일 불러오기. 없으면 기본설정으로 파일 생성
        /// </summary>
        /// <param name="InitFilePath">초기설정 파일 경로</param>
        /// <returns>1:문제없이 로드 성공, 2:설정파일 없음, 3:설정파일은 있지만 설정값이 없음</returns>
        private int LoadInitSetting(string InitFilePath)
        {
            FileInfo fi = new FileInfo(InitFilePath);

            if(fi.Exists)
            {
                //파일이 있으면 로드
                InitSetting = new DataSet();
                InitSetting.Clear();
                InitSetting.ReadXml(InitFilePath);
                InitSetting_Backup = InitSetting.Copy();
            }
            else
            {
                //없으면 새로 만들고 2 리턴
                CreateInitFile(InitFilePath);
                InitSetting_Backup = InitSetting.Copy();
                SettingDisplay();
                return 2;
            }

            //설정화면에 표시
            if(SettingDisplay() == false)
            {
                //불러온 설정 데이터셋에서 값을 읽을 때 문제가 있었으면 3 리턴
                return 3;
            }

            //문제없이 전부 수행되면 1 리턴
            return 1;

        }


        //초기 설정파일 생성
        private void CreateInitFile(string InitFilePath)
        {
            //데이터셋 객체 생성
            InitSetting = new DataSet();

            //키-값 테이블 생성 후 데이터셋에 추가
            DataTable KeyValueSetting = new DataTable("Key_Value");
            DataColumn col;
            col = new DataColumn("Key", typeof(String), "", MappingType.Attribute);
            KeyValueSetting.Columns.Add(col);
            col = new DataColumn("Value", typeof(String), "", MappingType.Attribute);
            KeyValueSetting.Columns.Add(col);
            InitSetting.Tables.Add(KeyValueSetting);

            //키-값 테이블에 기본 설정행 추가
            DataRow row;
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ServerSW_ID";
            row["Value"] = "OBWR_S_001";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "IOComPort";
            row["Value"] = "COM1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "IOComSpeed";
            row["Value"] = "115200";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "IMUComPort";
            row["Value"] = "COM2";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "IMUComSpeed";
            row["Value"] = "115200";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "DistanceSensor1ComPort";
            row["Value"] = "COM3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "DistanceSensor1ComSpeed";
            row["Value"] = "115200";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "DistanceSensor2ComPort";
            row["Value"] = "COM4";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "DistanceSensor2ComSpeed";
            row["Value"] = "115200";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "VolMinIn";
            row["Value"] = "2";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "VolMaxIn";
            row["Value"] = "8";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "VolMinOut";
            row["Value"] = "15";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "VolMaxOut";
            row["Value"] = "40";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "AmpMinIn";
            row["Value"] = "2";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "AmpMaxIn";
            row["Value"] = "8";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "AmpMinOut";
            row["Value"] = "150";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "AmpMaxOut";
            row["Value"] = "400";
            InitSetting.Tables["Key_Value"].Rows.Add(row);


            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCP_X";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCP_Y";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCP_Z";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCP_Rx";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCP_Ry";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCP_Rz";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCPMass";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCPMassCenterX";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCPMassCenterY";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotTCPMassCenterZ";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);


            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionThreshold1";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionThreshold2";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionThreshold3";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionThreshold4";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionThreshold5";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionThreshold6";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionDetectOnOff";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotCollisionMitigationOnOff";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotMountType";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotMountRx";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotMountRy";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotMountAngleAutoSet";
            row["Value"] = "0";
            InitSetting.Tables["Key_Value"].Rows.Add(row);


            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_6mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_7mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_8mm";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_9mm";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_10mm";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_11mm";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_12mm";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_2F_13mm";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_6mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_7mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_8mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_9mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_10mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_11mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_12mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PathNum_3F_13mm";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenHFactor_2F";
            row["Value"] = "0.5";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenVFactor_2F";
            row["Value"] = "0.25";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenHMaxdL_2F";
            row["Value"] = "100";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenVMaxdL_2F";
            row["Value"] = "100";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenHOncedL_2F";
            row["Value"] = "0.5";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenVOncedL_2F";
            row["Value"] = "0.5";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenTimeShift_2F";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenHFactor_3F";
            row["Value"] = "0.5";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenVFactor_3F";
            row["Value"] = "0.25";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenHMaxdL_3F";
            row["Value"] = "100";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenVMaxdL_3F";
            row["Value"] = "100";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenHOncedL_3F";
            row["Value"] = "0.5";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenVOncedL_3F";
            row["Value"] = "0.5";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "ArcSenTimeShift_3F";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "StartGasTime";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "StartArcTime";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "StartArcVol";
            row["Value"] = "24";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "StartArcAmp";
            row["Value"] = "200";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "EndGasTime";
            row["Value"] = "3";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "EndArcTime";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "EndArcVol";
            row["Value"] = "24";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "EndArcAmp";
            row["Value"] = "200";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "EndBackLength";
            row["Value"] = "10";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "OffsetH";
            row["Value"] = "10";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "OffsetV";
            row["Value"] = "10";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadyX";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadyY";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadyZ";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadyRx";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadyRy";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadyRz";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutReadySpeed";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutX";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutY";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutZ";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutRx";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutRy";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutRz";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseCutSpeed";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPX";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPY";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPZ";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPRx";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPRy";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPRz";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "PoseTCPSpeed";
            row["Value"] = "55";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "WeldingOrder";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "HWeldingDir";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);
            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "WeldingAutoManualStart";
            row["Value"] = "2";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            row = InitSetting.Tables["Key_Value"].NewRow();
            row["Key"] = "RobotRebootAndConnect";
            row["Value"] = "1";
            InitSetting.Tables["Key_Value"].Rows.Add(row);

            InitSetting.Tables["Key_Value"].AcceptChanges();


            //통신IP 포트설정 테이블 생성 후 데이터셋에 추가
            DataTable Communication_IPPortSetting = new DataTable("Communication_IPPortSetting");
            col = new DataColumn("IP", typeof(String), "", MappingType.Attribute);
            Communication_IPPortSetting.Columns.Add(col);
            col = new DataColumn("Port", typeof(String), "", MappingType.Attribute);
            Communication_IPPortSetting.Columns.Add(col);
            InitSetting.Tables.Add(Communication_IPPortSetting);

            //샘플 데이터 입력
            row = InitSetting.Tables["Communication_IPPortSetting"].NewRow();
            row["IP"] = "000.000.000.000";
            row["Port"] = "00000";
            InitSetting.Tables["Communication_IPPortSetting"].Rows.Add(row);
            InitSetting.Tables["Communication_IPPortSetting"].AcceptChanges();


            //통신대상 및 제어권한 테이블 생성 후 데이터셋에 추가
            DataTable Communication_Permission = new DataTable("Communication_Permission");
            col = new DataColumn("IP", typeof(String), "", MappingType.Attribute);
            Communication_Permission.Columns.Add(col);
            col = new DataColumn("Port", typeof(String), "", MappingType.Attribute);
            Communication_Permission.Columns.Add(col);
            col = new DataColumn("Permission", typeof(String), "", MappingType.Attribute);
            Communication_Permission.Columns.Add(col);
            InitSetting.Tables.Add(Communication_Permission);

            //샘플 데이터 입력
            row = InitSetting.Tables["Communication_Permission"].NewRow();
            row["IP"] = "000.000.000.000";
            row["Port"] = "00000";
            row["Permission"] = "0";
            InitSetting.Tables["Communication_Permission"].Rows.Add(row);
            InitSetting.Tables["Communication_Permission"].AcceptChanges();

            //설정데이터셋 파일로 저장
            InitSetting.WriteXml(InitFilePath);
        }

        //InitSetting_Backup 설정값을 설정화면에 표시해줌
        private bool SettingDisplay()
        {
            bool readOK = true;

            string value = "";

            //데이터테이블 바인딩
            dataGridView_SettingControlAndMonitor.DataSource = InitSetting_Backup.Tables["Communication_IPPortSetting"];
            dataGridView_SettingPermission.DataSource = InitSetting_Backup.Tables["Communication_Permission"];

            //데이터테이블 폭 지정
            dataGridView_SettingControlAndMonitor.Columns["IP"].Width = 110;
            dataGridView_SettingControlAndMonitor.Columns["Port"].Width = 50;
            dataGridView_SettingPermission.Columns["IP"].Width = 110;
            dataGridView_SettingPermission.Columns["Port"].Width = 50;
            dataGridView_SettingPermission.Columns["Permission"].HeaderText = "권한";
            dataGridView_SettingPermission.Columns["Permission"].Width = 40;

            //데이터그리드뷰 정렬 못하게 막음
            foreach (DataGridViewColumn c in dataGridView_SettingControlAndMonitor.Columns)
            {
                c.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn c in dataGridView_SettingPermission.Columns)
            {
                c.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            //키-값 테이블에서 프로그램ID 읽어옴
            if (Read_InitSettingBackup_KeyValue("ServerSW_ID", ref value)) { textBox_ProgramID.Text = value; } else { readOK = false; }

            //키-값 테이블에서 시리얼 통신정보 가져옴
            if (Read_InitSettingBackup_KeyValue("IOComPort", ref value)) { textBox_IOCOM.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("IOComSpeed", ref value)) { textBox_IOSpeed.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("IMUComPort", ref value)) { textBox_IMUCOM.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("IMUComSpeed", ref value)) { textBox_IMUSpeed.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("DistanceSensor1ComPort", ref value)) { textBox_IMUSpeed.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("DistanceSensor1ComSpeed", ref value)) { textBox_IMUSpeed.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("DistanceSensor2ComPort", ref value)) { textBox_Distance2COM.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("DistanceSensor2ComSpeed", ref value)) { textBox_Distance2Speed.Text = value; } else { readOK = false; }

            //키-값 테이블에서 용접기선형화 데이터 가져옴
            if (Read_InitSettingBackup_KeyValue("VolMinIn", ref value)) { textBox_VolMinIn.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("VolMaxIn", ref value)) { textBox_VolMaxIn.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("VolMinOut", ref value)) { textBox_VolMinOut.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("VolMaxOut", ref value)) { textBox_VolMaxOut.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("AmpMinIn", ref value)) { textBox_AmpMinIn.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("AmpMaxIn", ref value)) { textBox_AmpMaxIn.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("AmpMinOut", ref value)) { textBox_AmpMinOut.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("AmpMaxOut", ref value)) { textBox_AmpMaxOut.Text = value; } else { readOK = false; }

            //키-값 테이블에서 TCP 포즈 읽어옴
            if (Read_InitSettingBackup_KeyValue("RobotTCP_X", ref value)) { textBox_SettingRobotTCP_X.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCP_Y", ref value)) { textBox_SettingRobotTCP_Y.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCP_Z", ref value)) { textBox_SettingRobotTCP_Z.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCP_Rx", ref value)) { textBox_SettingRobotTCP_Rx.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCP_Ry", ref value)) { textBox_SettingRobotTCP_Ry.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCP_Rz", ref value)) { textBox_SettingRobotTCP_Rz.Text = value; } else { readOK = false; }

            //키-값 테이블에서 툴 무게 읽어옴
            if (Read_InitSettingBackup_KeyValue("RobotTCPMass", ref value)) { textBox_SettingRobotTCPMass.Text = value; } else { readOK = false; }

            //키-값 테이블에서 툴 무게중심좌표 읽어옴
            if (Read_InitSettingBackup_KeyValue("RobotTCPMassCenterX", ref value)) { textBox_SettingRobotTCPMassCenterX.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCPMassCenterY", ref value)) { textBox_SettingRobotTCPMassCenterY.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotTCPMassCenterZ", ref value)) { textBox_SettingRobotTCPMassCenterZ.Text = value; } else { readOK = false; }

            //키-값 테이블에서 충돌감지 임계치 읽어옴
            if (Read_InitSettingBackup_KeyValue("RobotCollisionThreshold1", ref value)) { textBox_SettingRobotCollisionThreshold1.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotCollisionThreshold2", ref value)) { textBox_SettingRobotCollisionThreshold2.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotCollisionThreshold3", ref value)) { textBox_SettingRobotCollisionThreshold3.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotCollisionThreshold4", ref value)) { textBox_SettingRobotCollisionThreshold4.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotCollisionThreshold5", ref value)) { textBox_SettingRobotCollisionThreshold5.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotCollisionThreshold6", ref value)) { textBox_SettingRobotCollisionThreshold6.Text = value; } else { readOK = false; }

            //키-값 테이블에서 충돌감지기능 사용여부 가져옴
            if (Read_InitSettingBackup_KeyValue("RobotCollisionDetectOnOff", ref value)) { textBox_SettingRobotCollisionDetectOnOff.Text = value; } else { readOK = false; }

            //키-값 테이블에서 충돌감지 완화기능 사용여부 읽어옴
            if (Read_InitSettingBackup_KeyValue("RobotCollisionMitigationOnOff", ref value)) { textBox_SettingRobotCollisionMitigationOnOff.Text = value; } else { readOK = false; }

            //키-값 테이블에서 설치정보 읽어옴 RobotMountAngleAutoSet
            if (Read_InitSettingBackup_KeyValue("RobotMountType", ref value)) { textBox_SettingRobotMountType.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotMountRx", ref value)) { textBox_SettingRobotMountRx.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotMountRy", ref value)) { textBox_SettingRobotMountRy.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("RobotMountAngleAutoSet", ref value))
            {
                if (value == "1")
                {
                    radioButton_SettingMountAngleAutoSet0.Checked = false;
                    radioButton_SettingMountAngleAutoSet1.Checked = true;
                    radioButton_SettingMountAngleAutoSet2.Checked = false;
                }
                else if (value == "2")
                {
                    radioButton_SettingMountAngleAutoSet0.Checked = false;
                    radioButton_SettingMountAngleAutoSet1.Checked = false;
                    radioButton_SettingMountAngleAutoSet2.Checked = true;
                }
                else
                {
                    radioButton_SettingMountAngleAutoSet0.Checked = true;
                    radioButton_SettingMountAngleAutoSet1.Checked = false;
                    radioButton_SettingMountAngleAutoSet2.Checked = false;
                }
            }
            else { readOK = false; }

            //키-값 테이블에서 자세별 각장에 대한 전체패스수 가져옴
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_6mm", ref value)) { textBox_Setting2F6.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_7mm", ref value)) { textBox_Setting2F7.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_8mm", ref value)) { textBox_Setting2F8.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_9mm", ref value)) { textBox_Setting2F9.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_10mm", ref value)) { textBox_Setting2F10.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_11mm", ref value)) { textBox_Setting2F11.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_12mm", ref value)) { textBox_Setting2F12.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_2F_13mm", ref value)) { textBox_Setting2F13.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_6mm", ref value)) { textBox_Setting3F6.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_7mm", ref value)) { textBox_Setting3F7.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_8mm", ref value)) { textBox_Setting3F8.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_9mm", ref value)) { textBox_Setting3F9.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_10mm", ref value)) { textBox_Setting3F10.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_11mm", ref value)) { textBox_Setting3F11.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_12mm", ref value)) { textBox_Setting3F12.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PathNum_3F_13mm", ref value)) { textBox_Setting3F13.Text = value; } else { readOK = false; }

            //키-값 테이블에서 아크센싱 관련 설정 가져옴
            if (Read_InitSettingBackup_KeyValue("ArcSenHFactor_2F", ref value)) { textBox_SettingArcSenH_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenVFactor_2F", ref value)) { textBox_SettingArcSenV_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenHMaxdL_2F", ref value)) { textBox_SettingMaxdLH_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenVMaxdL_2F", ref value)) { textBox_SettingMaxdLV_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenHOncedL_2F", ref value)) { textBox_SettingOncedLH_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenVOncedL_2F", ref value)) { textBox_SettingOncedLV_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenTimeShift_2F", ref value)) { textBox_SettingDelayTime_2F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenHFactor_3F", ref value)) { textBox_SettingArcSenH_3F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenVFactor_3F", ref value)) { textBox_SettingArcSenV_3F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenHMaxdL_3F", ref value)) { textBox_SettingMaxdLH_3F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenVMaxdL_3F", ref value)) { textBox_SettingMaxdLV_3F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenHOncedL_3F", ref value)) { textBox_SettingOncedLH_3F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenVOncedL_3F", ref value)) { textBox_SettingOncedLV_3F.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("ArcSenTimeShift_3F", ref value)) { textBox_SettingDelayTime_3F.Text = value; } else { readOK = false; }

            //키-값 테이블에서 용접 시작,종료, 오프셋조건 가져옴
            if (Read_InitSettingBackup_KeyValue("StartGasTime", ref value)) { textBox_SettingStartGasTime.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("StartArcTime", ref value)) { textBox_SettingStartArcTime.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("StartArcVol", ref value)) { textBox_SettingStartArcVol.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("StartArcAmp", ref value)) { textBox_SettingStartArcAmp.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("EndGasTime", ref value)) { textBox_SettingEndGasTime.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("EndArcTime", ref value)) { textBox_SettingEndArcTime.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("EndArcVol", ref value)) { textBox_SettingEndArcVol.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("EndArcAmp", ref value)) { textBox_SettingEndArcAmp.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("EndBackLength", ref value)) { textBox_SettingEndBackLength.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("OffsetH", ref value)) { textBox_SettingOffsetH.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("OffsetV", ref value)) { textBox_SettingOffsetV.Text = value; } else { readOK = false; }

            //로봇 기본자세 읽어옴
            if (Read_InitSettingBackup_KeyValue("PoseCutReadyX", ref value)) { textBox_SettingPoseCutReadyX.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutReadyY", ref value)) { textBox_SettingPoseCutReadyY.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutReadyZ", ref value)) { textBox_SettingPoseCutReadyZ.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutReadyRx", ref value)) { textBox_SettingPoseCutReadyRx.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutReadyRy", ref value)) { textBox_SettingPoseCutReadyRy.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutReadyRz", ref value)) { textBox_SettingPoseCutReadyRz.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutReadySpeed", ref value)) { textBox_SettingPoseCutReadySpeed.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutX", ref value)) { textBox_SettingPoseCutX.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutY", ref value)) { textBox_SettingPoseCutY.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutZ", ref value)) { textBox_SettingPoseCutZ.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutRx", ref value)) { textBox_SettingPoseCutRx.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutRy", ref value)) { textBox_SettingPoseCutRy.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutRz", ref value)) { textBox_SettingPoseCutRz.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseCutSpeed", ref value)) { textBox_SettingPoseCutSpeed.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPX", ref value)) { textBox_SettingPoseTCPX.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPY", ref value)) { textBox_SettingPoseTCPY.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPZ", ref value)) { textBox_SettingPoseTCPZ.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPRx", ref value)) { textBox_SettingPoseTCPRx.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPRy", ref value)) { textBox_SettingPoseTCPRy.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPRz", ref value)) { textBox_SettingPoseTCPRz.Text = value; } else { readOK = false; }
            if (Read_InitSettingBackup_KeyValue("PoseTCPSpeed", ref value)) { textBox_SettingPoseTCPSpeed.Text = value; } else { readOK = false; }

            if (Read_InitSettingBackup_KeyValue("WeldingOrder", ref value))
            {
                if (value == "0")
                {
                    radioButton_WeldingOrder0.Checked = true;
                    radioButton_WeldingOrder1.Checked = false;
                }
                else
                {
                    radioButton_WeldingOrder0.Checked = false;
                    radioButton_WeldingOrder1.Checked = true;
                }
            }
            else { readOK = false; }

            if (Read_InitSettingBackup_KeyValue("HWeldingDir", ref value))
            {
                if (value == "0")
                {
                    radioButton_HWeldingDir0.Checked = true;
                    radioButton_HWeldingDir1.Checked = false;
                    radioButton_HWeldingDir2.Checked = false;
                } else if (value == "1")
                {
                    radioButton_HWeldingDir0.Checked = false;
                    radioButton_HWeldingDir1.Checked = true;
                    radioButton_HWeldingDir2.Checked = false;
                }
                else
                {
                    radioButton_HWeldingDir0.Checked = false;
                    radioButton_HWeldingDir1.Checked = false;
                    radioButton_HWeldingDir2.Checked = true;
                }

            }
            else { readOK = false; }


            if (Read_InitSettingBackup_KeyValue("WeldingAutoManualStart", ref value))
            {
                if (value == "0")
                {
                    radioButton_AutoManualStart0.Checked = true;
                    radioButton_AutoManualStart1.Checked = false;
                    radioButton_AutoManualStart2.Checked = false;
                }
                else if (value == "1")
                {
                    radioButton_AutoManualStart0.Checked = false;
                    radioButton_AutoManualStart1.Checked = true;
                    radioButton_AutoManualStart2.Checked = false;
                }
                else
                {
                    radioButton_AutoManualStart0.Checked = false;
                    radioButton_AutoManualStart1.Checked = false;
                    radioButton_AutoManualStart2.Checked = true;
                }
            }
            else { readOK = false; }

            if (Read_InitSettingBackup_KeyValue("RobotRebootAndConnect", ref value))
            {
                if (value == "0")
                {
                    radioButton_SettingRobotRebootAndConnect0.Checked = true;
                    radioButton_SettingRobotRebootAndConnect1.Checked = false;
                    radioButton_SettingRobotRebootAndConnect2.Checked = false;
                }
                else if (value == "1")
                {
                    radioButton_SettingRobotRebootAndConnect0.Checked = false;
                    radioButton_SettingRobotRebootAndConnect1.Checked = true;
                    radioButton_SettingRobotRebootAndConnect2.Checked = false;
                }
                else
                {
                    radioButton_SettingRobotRebootAndConnect0.Checked = false;
                    radioButton_SettingRobotRebootAndConnect1.Checked = false;
                    radioButton_SettingRobotRebootAndConnect2.Checked = true;
                }
            }
            else { readOK = false; }


            return readOK;
        }


        
        /// <summary>
        /// InitSetting 의 키-값 테이블에서 키로 값 읽어오는 함수
        /// </summary>
        /// <param name="key">검색하고자 하는 키</param>
        /// <param name="value">입력한 키에 대해 검색된 값</param>
        /// <returns>검색이 되었으면 true, 검색이 되지 않으면 false 반환</returns>
        private bool Read_InitSetting_KeyValue(string key, ref string value)
        {
            foreach (DataRow dr in InitSetting.Tables["Key_Value"].Rows)
            {
                if (Convert.ToString(dr["Key"]) == key)
                {
                    value = Convert.ToString(dr["Value"]);
                    return true;
                }
            }

            value = "";
            return false;
        }
        
        /// <summary>
        /// InitSetting 의 키-값 테이블에서 해당 키의 값을 입력하는 함수
        /// </summary>
        /// <param name="key">입력하고자 하는 설정키</param>
        /// <param name="value">입력하고자 하는 설정값</param>
        /// <returns>해당 키 설정이 있으면 true, 없으면 false</returns>
        private bool Write_InitSetting_KeyValue(string key, string value)
        {
            foreach (DataRow dr in InitSetting.Tables["Key_Value"].Rows)
            {
                if (Convert.ToString(dr["Key"]) == key)
                {
                    dr["Value"] = value;
                    return true;
                }
            }

            return false;
        }


        
        /// <summary>
        /// InitSetting_Backup 의 키-값 테이블에서 키로 값 읽어오는 함수
        /// </summary>
        /// <param name="key">검색하고자 하는 키</param>
        /// <param name="value">입력한 키에 대해 검색된 값</param>
        /// <returns>검색이 되었으면 true, 검색이 되지 않으면 false 반환</returns>
        private bool Read_InitSettingBackup_KeyValue(string key, ref string value)
        {
            foreach (DataRow dr in InitSetting_Backup.Tables["Key_Value"].Rows)
            {
                if(Convert.ToString(dr["Key"]) == key)
                {
                    value = Convert.ToString( dr["Value"] );
                    return true;
                }
            }

            value = "";
            return false;
        }
        
        /// <summary>
        /// InitSetting_Backup 의 키-값 테이블에서 해당 키의 값을 입력하는 함수
        /// </summary>
        /// <param name="key">입력하고자 하는 설정키</param>
        /// <param name="value">입력하고자 하는 설정값</param>
        /// <returns>해당 키 설정이 있으면 true, 없으면 false</returns>
        private bool Write_InitSettingBackup_KeyValue(string key, string value)
        {
            foreach (DataRow dr in InitSetting_Backup.Tables["Key_Value"].Rows)
            {
                if (Convert.ToString(dr["Key"]) == key)
                {
                    dr["Value"] = value;
                    return true;
                }
            }

            return false;
        }

        //설정창에서 취소버튼 누르면 수행하는 내용.
        private void SettingCancel()
        {
            if (MessageBox.Show("변경한 내용을 전부 취소 합니다.\r계속 하시겠습니까?", "입력 취소", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                //설정 편집한 내용 삭제하고 원래 설정으로 원복
                InitSetting_Backup.Clear();
                InitSetting_Backup = InitSetting.Copy();

                //다시 디스플레이
                SettingDisplay();
            }
        }

        //설정창에서 저장버튼 누르면 수행하는 내용
        private void SettingSave(string initpath)
        {
            if (MessageBox.Show("변경한 내용을 저장 합니다.\r프로그램설정과 용접설정은 바로 반영되고\r로봇설정은 다음번 서보 ON할때,\r통신설정은 프로그램을 재시작 해야 반영됩니다.\r계속 하시겠습니까?", "입력 저장", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                //텍스트박스 설정값 저장
                Write_InitSettingBackup_KeyValue("ServerSW_ID", textBox_ProgramID.Text.Trim());
                Write_InitSettingBackup_KeyValue("IOComPort", textBox_IOCOM.Text.Trim());
                Write_InitSettingBackup_KeyValue("IOComSpeed", textBox_IOSpeed.Text.Trim());
                Write_InitSettingBackup_KeyValue("IMUComPort", textBox_IMUCOM.Text.Trim());
                Write_InitSettingBackup_KeyValue("IMUComSpeed", textBox_IMUSpeed.Text.Trim());
                Write_InitSettingBackup_KeyValue("DistanceSensor1ComPort", textBox_Distance1COM.Text.Trim());
                Write_InitSettingBackup_KeyValue("DistanceSensor1ComSpeed", textBox_Distance1Speed.Text.Trim());
                Write_InitSettingBackup_KeyValue("DistanceSensor2ComPort", textBox_Distance2COM.Text.Trim());
                Write_InitSettingBackup_KeyValue("DistanceSensor2ComSpeed", textBox_Distance2Speed.Text.Trim());
                Write_InitSettingBackup_KeyValue("VolMinIn", textBox_VolMinIn.Text.Trim());
                Write_InitSettingBackup_KeyValue("VolMaxIn", textBox_VolMaxIn.Text.Trim());
                Write_InitSettingBackup_KeyValue("VolMinOut", textBox_VolMinOut.Text.Trim());
                Write_InitSettingBackup_KeyValue("VolMaxOut", textBox_VolMaxOut.Text.Trim());
                Write_InitSettingBackup_KeyValue("AmpMinIn", textBox_AmpMinIn.Text.Trim());
                Write_InitSettingBackup_KeyValue("AmpMaxIn", textBox_AmpMaxIn.Text.Trim());
                Write_InitSettingBackup_KeyValue("AmpMinOut", textBox_AmpMinOut.Text.Trim());
                Write_InitSettingBackup_KeyValue("AmpMaxOut", textBox_AmpMaxOut.Text.Trim());

                Write_InitSettingBackup_KeyValue("RobotTCP_X", textBox_SettingRobotTCP_X.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCP_Y", textBox_SettingRobotTCP_Y.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCP_Z", textBox_SettingRobotTCP_Z.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCP_Rx", textBox_SettingRobotTCP_Rx.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCP_Ry", textBox_SettingRobotTCP_Ry.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCP_Rz", textBox_SettingRobotTCP_Rz.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCPMass", textBox_SettingRobotTCPMass.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCPMassCenterX", textBox_SettingRobotTCPMassCenterX.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCPMassCenterY", textBox_SettingRobotTCPMassCenterY.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotTCPMassCenterZ", textBox_SettingRobotTCPMassCenterZ.Text.Trim());

                Write_InitSettingBackup_KeyValue("RobotCollisionThreshold1", textBox_SettingRobotCollisionThreshold1.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionThreshold2", textBox_SettingRobotCollisionThreshold2.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionThreshold3", textBox_SettingRobotCollisionThreshold3.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionThreshold4", textBox_SettingRobotCollisionThreshold4.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionThreshold5", textBox_SettingRobotCollisionThreshold5.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionThreshold6", textBox_SettingRobotCollisionThreshold6.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionDetectOnOff", textBox_SettingRobotCollisionDetectOnOff.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotCollisionMitigationOnOff", textBox_SettingRobotCollisionMitigationOnOff.Text.Trim());

                Write_InitSettingBackup_KeyValue("RobotMountType", textBox_SettingRobotMountType.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotMountRx", textBox_SettingRobotMountRx.Text.Trim());
                Write_InitSettingBackup_KeyValue("RobotMountRy", textBox_SettingRobotMountRy.Text.Trim());
                if (radioButton_SettingMountAngleAutoSet1.Checked == true)
                { Write_InitSettingBackup_KeyValue("RobotMountAngleAutoSet", "1"); }
                else if (radioButton_SettingMountAngleAutoSet2.Checked == true)
                { Write_InitSettingBackup_KeyValue("RobotMountAngleAutoSet", "2"); }
                else { Write_InitSettingBackup_KeyValue("RobotMountAngleAutoSet", "0"); }

                Write_InitSettingBackup_KeyValue("PathNum_2F_6mm", textBox_Setting2F6.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_7mm", textBox_Setting2F7.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_8mm", textBox_Setting2F8.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_9mm", textBox_Setting2F9.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_10mm", textBox_Setting2F10.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_11mm", textBox_Setting2F11.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_12mm", textBox_Setting2F12.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_2F_13mm", textBox_Setting2F13.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_6mm", textBox_Setting3F6.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_7mm", textBox_Setting3F7.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_8mm", textBox_Setting3F8.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_9mm", textBox_Setting3F9.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_10mm", textBox_Setting3F10.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_11mm", textBox_Setting3F11.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_12mm", textBox_Setting3F12.Text.Trim());
                Write_InitSettingBackup_KeyValue("PathNum_3F_13mm", textBox_Setting3F13.Text.Trim());

                Write_InitSettingBackup_KeyValue("ArcSenHFactor_2F", textBox_SettingArcSenH_2F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenVFactor_2F", textBox_SettingArcSenV_2F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenHMaxdL_2F", textBox_SettingMaxdLH_2F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenVMaxdL_2F", textBox_SettingMaxdLV_2F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenHOncedL_2F", textBox_SettingOncedLH_2F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenVOncedL_2F", textBox_SettingOncedLV_2F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenTimeShift_2F", textBox_SettingDelayTime_2F.Text.Trim());

                Write_InitSettingBackup_KeyValue("ArcSenHFactor_3F", textBox_SettingArcSenH_3F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenVFactor_3F", textBox_SettingArcSenV_3F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenHMaxdL_3F", textBox_SettingMaxdLH_3F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenVMaxdL_3F", textBox_SettingMaxdLV_3F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenHOncedL_3F", textBox_SettingOncedLH_3F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenVOncedL_3F", textBox_SettingOncedLV_3F.Text.Trim());
                Write_InitSettingBackup_KeyValue("ArcSenTimeShift_3F", textBox_SettingDelayTime_3F.Text.Trim());

                Write_InitSettingBackup_KeyValue("StartGasTime", textBox_SettingStartGasTime.Text.Trim());
                Write_InitSettingBackup_KeyValue("StartArcTime", textBox_SettingStartArcTime.Text.Trim());
                Write_InitSettingBackup_KeyValue("StartArcVol", textBox_SettingStartArcVol.Text.Trim());
                Write_InitSettingBackup_KeyValue("StartArcAmp", textBox_SettingStartArcAmp.Text.Trim());
                Write_InitSettingBackup_KeyValue("EndGasTime", textBox_SettingEndGasTime.Text.Trim());
                Write_InitSettingBackup_KeyValue("EndArcTime", textBox_SettingEndArcTime.Text.Trim());
                Write_InitSettingBackup_KeyValue("EndArcVol", textBox_SettingEndArcVol.Text.Trim());
                Write_InitSettingBackup_KeyValue("EndArcAmp", textBox_SettingEndArcAmp.Text.Trim());
                Write_InitSettingBackup_KeyValue("EndBackLength", textBox_SettingEndBackLength.Text.Trim());
                Write_InitSettingBackup_KeyValue("OffsetH", textBox_SettingOffsetH.Text.Trim());
                Write_InitSettingBackup_KeyValue("OffsetV", textBox_SettingOffsetV.Text.Trim());

                Write_InitSettingBackup_KeyValue("PoseCutReadyX", textBox_SettingPoseCutReadyX.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutReadyY", textBox_SettingPoseCutReadyY.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutReadyZ", textBox_SettingPoseCutReadyZ.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutReadyRx", textBox_SettingPoseCutReadyRx.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutReadyRy", textBox_SettingPoseCutReadyRy.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutReadyRz", textBox_SettingPoseCutReadyRz.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutReadySpeed", textBox_SettingPoseCutReadySpeed.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutX", textBox_SettingPoseCutX.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutY", textBox_SettingPoseCutY.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutZ", textBox_SettingPoseCutZ.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutRx", textBox_SettingPoseCutRx.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutRy", textBox_SettingPoseCutRy.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutRz", textBox_SettingPoseCutRz.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseCutSpeed", textBox_SettingPoseCutSpeed.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPX", textBox_SettingPoseTCPX.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPY", textBox_SettingPoseTCPY.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPZ", textBox_SettingPoseTCPZ.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPRx", textBox_SettingPoseTCPRx.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPRy", textBox_SettingPoseTCPRy.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPRz", textBox_SettingPoseTCPRz.Text.Trim());
                Write_InitSettingBackup_KeyValue("PoseTCPSpeed", textBox_SettingPoseTCPSpeed.Text.Trim());

                if (radioButton_WeldingOrder0.Checked == true)
                { Write_InitSettingBackup_KeyValue("WeldingOrder", "0"); }
                else
                { Write_InitSettingBackup_KeyValue("WeldingOrder", "1"); }

                if (radioButton_HWeldingDir0.Checked == true)
                { Write_InitSettingBackup_KeyValue("HWeldingDir", "0"); }
                else if (radioButton_HWeldingDir1.Checked == true)
                { Write_InitSettingBackup_KeyValue("HWeldingDir", "1"); }
                else { Write_InitSettingBackup_KeyValue("HWeldingDir", "2"); }

                if (radioButton_AutoManualStart0.Checked == true)
                { Write_InitSettingBackup_KeyValue("WeldingAutoManualStart", "0"); }
                else if (radioButton_AutoManualStart1.Checked == true)
                { Write_InitSettingBackup_KeyValue("WeldingAutoManualStart", "1"); }
                else { Write_InitSettingBackup_KeyValue("WeldingAutoManualStart", "2"); }

                if (radioButton_SettingRobotRebootAndConnect0.Checked == true)
                { Write_InitSettingBackup_KeyValue("RobotRebootAndConnect", "0"); }
                else if (radioButton_SettingRobotRebootAndConnect1.Checked == true)
                { Write_InitSettingBackup_KeyValue("RobotRebootAndConnect", "1"); }
                else { Write_InitSettingBackup_KeyValue("RobotRebootAndConnect", "2"); }


                //데이터그리드뷰에서 컬럼이 삭제되는것을 막기 위해 널값이라도 지정해줌
                for (int i = InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows.Count - 1; i >= 0; i--)
                {
                    if (InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i]["IP"].ToString() == "")
                    {
                        InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i]["IP"] = "";
                    }

                    if (InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i]["PORT"].ToString() == "")
                    {
                        InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i]["PORT"] = "";
                    }
                }

                //데이터가 없는 행은 행 자체를 삭제함
                for (int i = InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows.Count - 1; i >= 0; i--)
                {
                    if ((InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i]["IP"].ToString() == "") && (InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i]["PORT"].ToString() == ""))
                    {
                        InitSetting_Backup.Tables["Communication_IPPortSetting"].Rows[i].Delete();
                    }
                }



                //데이터그리드뷰에서 컬럼이 삭제되는것을 막기 위해 널값이라도 지정해줌
                for (int i = InitSetting_Backup.Tables["Communication_Permission"].Rows.Count - 1; i >= 0; i--)
                {
                    if (InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["IP"].ToString() == "")
                    {
                        InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["IP"] = "";
                    }

                    if (InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["PORT"].ToString() == "")
                    {
                        InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["PORT"] = "";
                    }

                    if (InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["Permission"].ToString() == "")
                    {
                        InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["Permission"] = "";
                    }
                }

                //데이터가 없는 행은 행 자체를 삭제함
                for (int i = InitSetting_Backup.Tables["Communication_Permission"].Rows.Count - 1; i >= 0; i--)
                {
                    if ((InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["IP"].ToString() == "") && (InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["PORT"].ToString() == "") && (InitSetting_Backup.Tables["Communication_Permission"].Rows[i]["Permission"].ToString() == ""))
                    {
                        InitSetting_Backup.Tables["Communication_Permission"].Rows[i].Delete();
                    }
                }


                //설정 내용 덮어씀
                InitSetting.Clear();
                InitSetting = InitSetting_Backup.Copy();

                //다시 디스플레이
                SettingDisplay();


                //설정데이터셋 파일로 저장
                InitSetting.WriteXml(initpath);

                //로봇 데이터에 반영
                SendSettingDataToRobot();
            }

        }

        private void SendSettingDataToRobot()
        {
            string tempstr = "";
            float mass = 0;
            float massx = 0;
            float massy = 0;
            float massz = 0;
            float tcpx = 0;
            float tcpy = 0;
            float tcpz = 0;
            float tcprx = 0;
            float tcpry = 0;
            float tcprz = 0;
            int mountposi = 0;
            float mountrx = 0;
            float mountry = 0;

            float inVol1 = 0;
            float outVol1 = 0;
            float inAmp1 = 0;
            float outAmp1 = 0;
            float inVol2 = 0;
            float outVol2 = 0;
            float inAmp2 = 0;
            float outAmp2 = 0;

            try
            {
                Read_InitSetting_KeyValue("RobotTCPMass", ref tempstr);
                mass = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCPMassCenterX", ref tempstr);
                massx = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCPMassCenterY", ref tempstr);
                massy = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCPMassCenterZ", ref tempstr);
                massz = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCP_X", ref tempstr);
                tcpx = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCP_Y", ref tempstr);
                tcpy = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCP_Z", ref tempstr);
                tcpz = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCP_Rx", ref tempstr);
                tcprx = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCP_Ry", ref tempstr);
                tcpry = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotTCP_Rz", ref tempstr);
                tcprz = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotMountType", ref tempstr);
                mountposi = Convert.ToInt32(tempstr);
                Read_InitSetting_KeyValue("RobotMountRx", ref tempstr);
                mountrx = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("RobotMountRy", ref tempstr);
                mountry = Convert.ToSingle(tempstr);

                Read_InitSetting_KeyValue("VolMinIn", ref tempstr);
                inVol1 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("VolMinOut", ref tempstr);
                outVol1 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("AmpMinIn", ref tempstr);
                inAmp1 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("AmpMinOut", ref tempstr);
                outAmp1 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("VolMaxIn", ref tempstr);
                inVol2 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("VolMaxOut", ref tempstr);
                outVol2 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("AmpMaxIn", ref tempstr);
                inAmp2 = Convert.ToSingle(tempstr);
                Read_InitSetting_KeyValue("AmpMaxOut", ref tempstr);
                outAmp2 = Convert.ToSingle(tempstr);
                
            }
            catch
            {
                return;
            }

            RobotCommclass.RobotControlParameter_ToolWeight = mass;
            RobotCommclass.RobotControlParameter_ToolMassCenterX = massx;
            RobotCommclass.RobotControlParameter_ToolMassCenterY = massy;
            RobotCommclass.RobotControlParameter_ToolMassCenterZ = massz;
            RobotCommclass.RobotControlParameter_TCP[0] = tcpx;
            RobotCommclass.RobotControlParameter_TCP[1] = tcpy;
            RobotCommclass.RobotControlParameter_TCP[2] = tcpz;
            RobotCommclass.RobotControlParameter_TCP[3] = tcprx;
            RobotCommclass.RobotControlParameter_TCP[4] = tcpry;
            RobotCommclass.RobotControlParameter_TCP[5] = tcprz;
            RobotCommclass.RobotControlParameter_MountType = mountposi;
            RobotCommclass.RobotControlParameter_MountAngleRx = mountrx;
            RobotCommclass.RobotControlParameter_MountAngleRy = mountry;

            RobotCommclass.RefVoltIO_1 = inVol1;
            RobotCommclass.WeldVolt_1 = outVol1;
            RobotCommclass.RefAmpIO_1 = inAmp1;
            RobotCommclass.WeldAmp_1 = outAmp1;
            RobotCommclass.RefVoltIO_2 = inVol2;
            RobotCommclass.WeldVolt_2 = outVol2;
            RobotCommclass.RefAmpIO_2 = inAmp2;
            RobotCommclass.WeldAmp_2 = outAmp2;
        }




        /// <summary>
        /// 설정값에서 아크센싱 관련 설정들 읽어오는 함수
        /// </summary>
        /// <param name="PathType">불러올 아크센싱 종류 지정. 0:2F조건 불러옴, 1:3F조건 불러옴</param>
        /// <param name="HFactor">좌우 아크센싱계수</param>
        /// <param name="VFactor">상하 아크센싱계수</param>
        /// <param name="HMaxdL">좌우 최대보정량 한계값</param>
        /// <param name="VMaxdL">상하 최대보정량 한계값</param>
        /// <param name="HOncedL">좌우 1회보정량 한계값</param>
        /// <param name="VOncedL">상하 1회보정량 한계값</param>
        /// <param name="TimeShift">센서 지연시간</param>
        /// <returns>1:성공, 0:실패</returns>
        int SettingLoadArcSen(int PathType, out double HFactor, out double VFactor, out double HMaxdL, out double VMaxdL, out double HOncedL, out double VOncedL, out double TimeShift)
        {
            HFactor = 0;
            VFactor = 0;
            HMaxdL = 0;
            VMaxdL = 0;
            HOncedL = 0;
            VOncedL = 0;
            TimeShift = 0;

            double d1, d2, d3, d4, d5, d6, d7;
            string s1 = "", s2 = "", s3 = "", s4 = "", s5 = "", s6 = "", s7 = "";
            string value = "";
            bool readOK = true;

            if (PathType == 0)
            {
                if (Read_InitSetting_KeyValue("ArcSenHFactor_2F", ref value)) { s1 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenVFactor_2F", ref value)) { s2 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenHMaxdL_2F", ref value)) { s3 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenVMaxdL_2F", ref value)) { s4 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenHOncedL_2F", ref value)) { s5 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenVOncedL_2F", ref value)) { s6 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenTimeShift_2F", ref value)) { s7 = value; } else { readOK = false; }
                if (readOK == false) return 0;
            }else if(PathType == 1)
            {
                if (Read_InitSetting_KeyValue("ArcSenHFactor_3F", ref value)) { s1 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenVFactor_3F", ref value)) { s2 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenHMaxdL_3F", ref value)) { s3 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenVMaxdL_3F", ref value)) { s4 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenHOncedL_3F", ref value)) { s5 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenVOncedL_3F", ref value)) { s6 = value; } else { readOK = false; }
                if (Read_InitSetting_KeyValue("ArcSenTimeShift_3F", ref value)) { s7 = value; } else { readOK = false; }
                if (readOK == false) return 0;
            }

            try
            {
                d1 = Convert.ToDouble(s1);
                d2 = Convert.ToDouble(s2);
                d3 = Convert.ToDouble(s3);
                d4 = Convert.ToDouble(s4);
                d5 = Convert.ToDouble(s5);
                d6 = Convert.ToDouble(s6);
                d7 = ((double)(Convert.ToInt32(s7)))/1000;
            }
            catch
            {
                return 0;
            }

            HFactor = d1;
            VFactor = d2;
            HMaxdL = d3;
            VMaxdL = d4;
            HOncedL = d5;
            VOncedL = d6;
            TimeShift = d7;

            return 1;
        }


        /// <summary>
        /// 설정값에서 시작 종료데이터 읽어오는 함수
        /// </summary>
        /// <param name="SGasTime">초기가스 토출시간</param>
        /// <param name="SArcTime">초기아크타임</param>
        /// <param name="SArcVol">초기아크 전압</param>
        /// <param name="SArcAmp">초기아크 전류</param>
        /// <param name="EGasTime">가스 후출시간</param>
        /// <param name="EArcTime">크레이터 용접시간</param>
        /// <param name="EArcVol">크레이터 전압</param>
        /// <param name="EArcAmp">크레이터 전류</param>
        /// <param name="EBackLength">용접종료후 후진거리</param>
        /// <returns>0:읽기 실패, 1:성공</returns>
        int SettingLoadStartEndData(out double SGasTime, out double SArcTime, out double SArcVol, out double SArcAmp, out double EGasTime, out double EArcTime, out double EArcVol, out double EArcAmp, out double EBackLength)
        {
            SGasTime = 0;
            SArcTime = 0;
            SArcVol = 0;
            SArcAmp = 0;
            EGasTime = 0;
            EArcTime = 0;
            EArcVol = 0;
            EArcAmp = 0;
            EBackLength = 0;

            double d1, d2, d3, d4, d5, d6, d7, d8, d9;
            string s1 = "", s2 = "", s3 = "", s4 = "", s5 = "", s6 = "", s7 = "", s8 = "", s9 = "";
            string value = "";
            bool readOK = true;
            
            if (Read_InitSetting_KeyValue("StartGasTime", ref value)) { s1 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("StartArcTime", ref value)) { s2 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("StartArcVol", ref value)) { s3 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("StartArcAmp", ref value)) { s4 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("EndGasTime", ref value)) { s5 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("EndArcTime", ref value)) { s6 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("EndArcVol", ref value)) { s7 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("EndArcAmp", ref value)) { s8 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("EndBackLength", ref value)) { s9 = value; } else { readOK = false; }
            if (readOK == false) return 0;

            try
            {
                d1 = Convert.ToDouble(s1);
                d2 = Convert.ToDouble(s2);
                d3 = Convert.ToDouble(s3);
                d4 = Convert.ToDouble(s4);
                d5 = Convert.ToDouble(s5);
                d6 = Convert.ToDouble(s6);
                d7 = Convert.ToDouble(s7);
                d8 = Convert.ToDouble(s8);
                d9 = Convert.ToDouble(s9);
            }
            catch
            {
                return 0;
            }
            
            SGasTime = d1;
            SArcTime = d2;
            SArcVol = d3;
            SArcAmp = d4;
            EGasTime = d5;
            EArcTime = d6;
            EArcVol = d7;
            EArcAmp = d8;
            EBackLength = d9;

            return 1;
        }


        /// <summary>
        /// 로봇의 컷팅준비자세, 컷팅자세, TCP홈자세를 설정값에 저장되어 있는 값으로 갱신하는 함수
        /// </summary>
        /// <returns>0:실패, 1:성공</returns>
        int SettingLoadRobotPose()
        {
            double d11, d12, d13, d14, d15, d16, d17;
            double d21, d22, d23, d24, d25, d26, d27;
            double d31, d32, d33, d34, d35, d36, d37;
            string s11 = "", s12 = "", s13 = "", s14 = "", s15 = "", s16 = "", s17 = "";
            string s21 = "", s22 = "", s23 = "", s24 = "", s25 = "", s26 = "", s27 = "";
            string s31 = "", s32 = "", s33 = "", s34 = "", s35 = "", s36 = "", s37 = "";


            string value = "";
            bool readOK = true;

            if (Read_InitSetting_KeyValue("PoseCutReadyX", ref value)) { s11 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutReadyY", ref value)) { s12 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutReadyZ", ref value)) { s13 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutReadyRx", ref value)) { s14 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutReadyRy", ref value)) { s15 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutReadyRz", ref value)) { s16 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutReadySpeed", ref value)) { s17 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutX", ref value)) { s21 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutY", ref value)) { s22 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutZ", ref value)) { s23 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutRx", ref value)) { s24 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutRy", ref value)) { s25 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutRz", ref value)) { s26 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseCutSpeed", ref value)) { s27 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPX", ref value)) { s31 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPY", ref value)) { s32 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPZ", ref value)) { s33 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPRx", ref value)) { s34 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPRy", ref value)) { s35 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPRz", ref value)) { s36 = value; } else { readOK = false; }
            if (Read_InitSetting_KeyValue("PoseTCPSpeed", ref value)) { s37 = value; } else { readOK = false; }
            if (readOK == false) return 0;

            try
            {
                d11 = Convert.ToDouble(s11);
                d12 = Convert.ToDouble(s12);
                d13 = Convert.ToDouble(s13);
                d14 = Convert.ToDouble(s14);
                d15 = Convert.ToDouble(s15);
                d16 = Convert.ToDouble(s16);
                d17 = Convert.ToDouble(s17);
                d21 = Convert.ToDouble(s21);
                d22 = Convert.ToDouble(s22);
                d23 = Convert.ToDouble(s23);
                d24 = Convert.ToDouble(s24);
                d25 = Convert.ToDouble(s25);
                d26 = Convert.ToDouble(s26);
                d27 = Convert.ToDouble(s27);
                d31 = Convert.ToDouble(s31);
                d32 = Convert.ToDouble(s32);
                d33 = Convert.ToDouble(s33);
                d34 = Convert.ToDouble(s34);
                d35 = Convert.ToDouble(s35);
                d36 = Convert.ToDouble(s36);
                d37 = Convert.ToDouble(s37);
            }
            catch
            {
                return 0;
            }

            RDP_TCP_WireCut2 = new RobotPoseData(2, d17, d11, d12, d13, d14, d15, d16);
            RDP_TCP_WireCut3 = new RobotPoseData(2, d27, d21, d22, d23, d24, d25, d26);
            RDP_TCP_Home2 = new RobotPoseData(2, d37, d31, d32, d33, d34, d35, d36);


            return 1;
        }
        

    }
}
