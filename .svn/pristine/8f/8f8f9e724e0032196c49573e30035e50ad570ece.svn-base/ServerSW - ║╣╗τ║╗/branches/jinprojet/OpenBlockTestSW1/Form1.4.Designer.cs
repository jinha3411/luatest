﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBlockWeldingRobot
{
    public partial class Form1
    {

        string SampleTypeName = "";
        double[] SampleWeldLineWidth = new double[8];
        double[] SampleWeldLineGap = new double[8];
        double[] SampleWeldCellPara = new double[20];
        double[] SampleWeldCon_Vol = new double[4];
        double[] SampleWeldCon_Amp = new double[4];
        double[] SampleWeldCon_Spd = new double[4];


        RobotPoseData[] SampleWeld_DTPoint_JointPose = new RobotPoseData[16];    //단독용접 직접교시 좌표 축좌표로 기록하는 변수
        RobotPoseData[] SampleWeld_DTPoint_TCPPose = new RobotPoseData[16];      //단독용접 직접교시 좌표 직교좌표로 기록하는 변수
        bool[] SampleWeldDTPointOK = new bool[16];

        //터치센싱위치 저장 변수
        RobotPoseData[] SampleWeld_TSPoint_JointPose = new RobotPoseData[16];
        RobotPoseData[] SampleWeld_TSPoint_TCPPose = new RobotPoseData[16];

        //계산된 용접점 저장 변수
        RobotPoseData[] SampleWeld_WedlPoint = new RobotPoseData[16];


        //계산된 연속용접 리스트
        List<WeldInformation> SampleWeld_WeldInformationList = new List<WeldInformation>();

        
        string SampleSequenceState = "개별용접-대기";
        string SampleDTSubSeq = "대기";
        string SampleDTSubSeq_Buffer = "대기";
        string SampleTSSubSeq = "대기";

        bool SampleDTPoseRecordFlag = false;
        bool SampleDTPoseNextFlag = false;
        bool SampleDTPoseMoveFlag = false;
        bool SampleDTEndFlag = false;
        bool SampleTSStartFlag = false;
        bool SampleTouchAndWeldFlag = false;
        bool SampleWeldStartFlag = false;

        int SampleWeldCount = 0;
        string SampleWeldingSubState = "대기";

        //용접실행 시퀀스에서 사용하는 플래그
        bool SampleWeldSubNextWeldingStopFlag = false;
        bool SampleWeldSubNextWeldingStartFlag = false;

        List<List<ActualWeldingPathRecord>> SampleWeldingPathRecord_ALL = new List<List<ActualWeldingPathRecord>>();
        List<ActualWeldingPathRecord> SampleWeldingPathRecord_Single = new List<ActualWeldingPathRecord>();

        int SampleWeldSub_TotalLineCount = 0;
        double SampleWeldSub_TotalLineLength = 0;
        double SampleWeldSub_TotalWeldTime = 0;
        int SampleWeldSub_NowLineCount = 0;
        double SampleWeldSub_LeftNowLineLength = 0;
        double SampleWeldSub_LeftNowWeldTime = 0;
        double SampleWeldSub_LeftTotalLineLength = 0;
        double SampleWeldSub_LeftTotalWeldTime = 0;


        //셀타입별 변수
        Dictionary<string, int> SampleTypeData = new Dictionary<string, int>();
        Dictionary<string, int> SampleTypePose = new Dictionary<string, int>();


        //샘플시편정보 기록하는 함수. 일단 시편 종류별 직접교시점 개수 저장
        void SampleDataRecord()
        {

            //셀 타입별로 용접라인 개수 저장. 나중에 꺼내쓰기 위해
            //검색키는 "[샘플ID]_ WeldLine"
            SampleTypeData.Add("Fillet2F_WeldLine", 1);
            SampleTypeData.Add("Fillet3F.Left_WeldLine", 1);
            SampleTypeData.Add("Fillet3F.Right_WeldLine", 1);
            //SampleTypeData.Add("Fillet4F_WeldLine", 1);

            //셀 타입별로 교시포인트 개수 저장. 나중에 꺼내쓰기 위해
            //검색키는 "[샘플ID]_DTPoint"
            SampleTypeData.Add("Fillet2F_DTPoint", 2);
            SampleTypeData.Add("Fillet3F.Left_DTPoint", 2);
            SampleTypeData.Add("Fillet3F.Right_DTPoint", 2);
            //SampleTypeData.Add("Fillet4F_DTPoint", 2);

            //셀 타입의 직접교시번호에 해당하는 준비자세 미리 저장해놓음
            //검색키 "[샘플ID]_[종류번호]_[직접교시번호]"
            //ST1
            SampleTypePose.Add("Fillet2F_DT0", 11);
            SampleTypePose.Add("Fillet2F_DT1", 11);
            SampleTypePose.Add("Fillet3F.Left_DT0", 6);
            SampleTypePose.Add("Fillet3F.Left_DT1", 6);
            SampleTypePose.Add("Fillet3F.Right_DT0", 16);
            SampleTypePose.Add("Fillet3F.Right_DT1", 16);
            //SampleTypePose.Add("Fillet4F_DT0", 11);
            //SampleTypePose.Add("Fillet4F_DT1", 11);

        }


        void SampleSequence()
        {


            int tempi = 0;
            switch (SampleSequenceState)
            {
                case "개별용접-대기":

                    break;
                case "개별용접-시작":
                    SampleSequenceState = "개별용접-직접교시 시작";

                    //직접교시 기록내역 초기화
                    for (int i = 0; i < 16; i++){ SampleWeldDTPointOK[i] = false; }

                    break;
                case "개별용접-정보 입력대기":

                    break;
                case "개별용접-직접교시 시작":
                    MainLog_Add("개별용접-직접교시 시작.");
                    SampleDTSubSeq = "시작";
                    SampleSequenceState = "개별용접-직접교시 완료대기";
                    break;
                case "개별용접-직접교시 완료대기":

                    SampleWeldDTSeq();

                    if (SampleDTSubSeq == "직접교시 완료")
                    {
                        SampleTSStartFlag = false;
                        SampleSequenceState = "개별용접-터치센싱 시작대기";
                    }
                    else if (SampleDTSubSeq == "직접교시 실패")
                    {
                        //직접교시 실패처리. 직접교시 시작상태로 돌아감
                        SampleSequenceState = "개별용접-직접교시 시작";
                        SampleDTSubSeq = "대기";
                    }

                    break;
                case "개별용접-터치센싱 시작대기":

                    if (SampleTSStartFlag == true)
                    {
                        SampleSequenceState = "개별용접-터치센싱 와이어컷팅 시작";
                        SampleTSStartFlag = false;
                    }

                    if (SampleTouchAndWeldFlag == true)
                    {
                        SampleSequenceState = "개별용접-터치센싱 와이어컷팅 시작";
                    }

                    break;
                case "개별용접-터치센싱 와이어컷팅 시작":

                    WirecutState = "와이어컷-이동";
                    SampleSequenceState = "개별용접-터치센싱 와이어컷팅 완료대기";
                    break;
                case "개별용접-터치센싱 와이어컷팅 완료대기":

                    Wirecutting();

                    if (WirecutState == "와이어컷-완료")
                    {
                        SampleSequenceState = "개별용접-터치센싱 시작";
                    }
                    else if (WirecutState == "와이어컷-실패")
                    {
                        SampleSequenceState = "개별용접-터치센싱 시작대기";
                        SampleTouchAndWeldFlag = false;
                    }

                    break;
                case "개별용접-터치센싱 시작":
                    
                    SampleSequenceState = "개별용접-" + SampleTypeName + " 터치센싱 중";
                    SampleTSSubSeq = "시작";
                    
                    break;
                case "개별용접-Fillet2F 터치센싱 중":
                    TouchSeq_Fillet2F();
                    if (SampleTSSubSeq == "터치시퀀스 성공")
                    {
                        SampleSequenceState = "개별용접-터치센싱 완료";
                    }
                    else if (SampleTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        SampleSequenceState = "개별용접-터치센싱 실패";
                    }
                    break;
                case "개별용접-Fillet3F.Left 터치센싱 중":
                    TouchSeq_Fillet3F_Left();
                    if (SampleTSSubSeq == "터치시퀀스 성공")
                    {
                        SampleSequenceState = "개별용접-터치센싱 완료";
                    }
                    else if (SampleTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        SampleSequenceState = "개별용접-터치센싱 실패";
                    }
                    break;
                case "개별용접-Fillet3F.Right 터치센싱 중":
                    TouchSeq_Fillet3F_Right();
                    if (SampleTSSubSeq == "터치시퀀스 성공")
                    {
                        SampleSequenceState = "개별용접-터치센싱 완료";
                    }
                    else if (SampleTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        SampleSequenceState = "개별용접-터치센싱 실패";
                    }
                    break;
                case "개별용접-Fillet4F 터치센싱 중":
                    //TouchSeq_Fillet4F();
                    if (SampleTSSubSeq == "터치시퀀스 성공")
                    {
                        SampleSequenceState = "개별용접-터치센싱 완료";
                    }
                    else if (SampleTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        SampleSequenceState = "개별용접-터치센싱 실패";
                    }
                    break;
                case "개별용접-터치센싱 실패":

                    //지정된 시간 이상 터치센싱 시작 대기상태로 넘어감
                    SampleTSStartFlag = false;
                    SampleTSSubSeq = "대기";
                    SampleSequenceState = "개별용접-터치센싱 시작대기";
                    

                    break;
                case "개별용접-터치센싱 완료":

                    //용접시작 플래그 초기화 후 용접시작대기 전환
                    SampleTSStartFlag = false;
                    SampleSequenceState = "개별용접-용접시작대기";
                    SampleTSSubSeq = "대기";

                    break;
                case "개별용접-용접시작대기":

                    if (SampleWeldStartFlag == true)
                    {
                        SampleSequenceState = "개별용접-용접시작";
                        SampleWeldStartFlag = false;
                    }

                    if (SampleTouchAndWeldFlag == true)
                    {
                        SampleSequenceState = "개별용접-용접시작";
                        SampleTouchAndWeldFlag = false;
                    }

                    break;
                case "개별용접-용접시작":

                    if (MakeSampleWeldInformation() == 1)
                    {
                        SampleWeldCalcInfo_Total();

                        SampleSequenceState = "개별용접-용접완료대기";
                        SampleWeldingSubState = "시작";
                        SampleWeldCount = 0;
                    }
                    else
                    {
                        SampleSequenceState = "개별용접-용접실패";
                    }
                    break;
                case "개별용접-용접완료대기":

                    SampleWeldingSubSeq();

                    SampleWeldCalcInfo_Left(); //용접 수행 중 남아있는 용접정보(용접선 개수, 용접길이, 용접시간) 계산

                    if (SampleWeldingSubState == "연속용접 성공")
                    {
                        SampleSequenceState = "개별용접-용접완료";
                    }
                    else if (SampleWeldingSubState == "연속용접 실패")
                    {
                        SampleSequenceState = "개별용접-용접실패";
                        ErrorOccurTime = DateTime.Now;
                    }



                    break;
                case "개별용접-용접완료":

                    break;
                case "개별용접-용접실패":

                    //일정시간 대기
                    tempi = (int)(DateTime.Now - ErrorOccurTime).Ticks / 10000;
                    if (tempi > 3000)
                    {   //지정된 시간 이상 개별용접 시작 대기상태로 넘어감
                        SampleSequenceState = "개별용접-용접시작대기";
                    }
                    break;
                default:
                    break;
            }

            

        }

        
        //개별용접 직접교시 시퀀스에서 단계일때 하는일
        void DTSampleCheck(int count)
        {
            //선택된 형상에 대한 티칭포인트 개수 가져옴
            int DTSampleCount;
            string tempstr = SampleTypeName + "_DTPoint";
            DTSampleCount = SampleTypeData[tempstr];
            

            //기록 요청이 들어올 경우 현재위치 기록
            if (SampleDTPoseRecordFlag == true)
            {
                //현재위치 기록
                SampleWeld_DTPoint_JointPose[count].PoseType = 1;
                SampleWeld_DTPoint_JointPose[count].Speed = 10;
                SampleWeld_DTPoint_JointPose[count].f1 = RobotDataEX.moni_RobotJointActualAngle[0];
                SampleWeld_DTPoint_JointPose[count].f2 = RobotDataEX.moni_RobotJointActualAngle[1];
                SampleWeld_DTPoint_JointPose[count].f3 = RobotDataEX.moni_RobotJointActualAngle[2];
                SampleWeld_DTPoint_JointPose[count].f4 = RobotDataEX.moni_RobotJointActualAngle[3];
                SampleWeld_DTPoint_JointPose[count].f5 = RobotDataEX.moni_RobotJointActualAngle[4];
                SampleWeld_DTPoint_JointPose[count].f6 = RobotDataEX.moni_RobotJointActualAngle[5];

                SampleWeld_DTPoint_TCPPose[count].PoseType = 2;
                SampleWeld_DTPoint_TCPPose[count].Speed = 100;
                SampleWeld_DTPoint_TCPPose[count].f1 = RobotDataEX.moni_RobotTCPActualPose[0];
                SampleWeld_DTPoint_TCPPose[count].f2 = RobotDataEX.moni_RobotTCPActualPose[1];
                SampleWeld_DTPoint_TCPPose[count].f3 = RobotDataEX.moni_RobotTCPActualPose[2];
                SampleWeld_DTPoint_TCPPose[count].f4 = RobotDataEX.moni_RobotTCPActualPose[3];
                SampleWeld_DTPoint_TCPPose[count].f5 = RobotDataEX.moni_RobotTCPActualPose[4];
                SampleWeld_DTPoint_TCPPose[count].f6 = RobotDataEX.moni_RobotTCPActualPose[5];
                
                SampleWeldDTPointOK[count] = true;
                SampleDTPoseRecordFlag = false;
            }

            //다음번호 요청이 들어올 경우 다음번호로 변경
            if (SampleDTPoseNextFlag == true)
            {
                //티칭개수 비교
                if (DTSampleCount - 1 > count)
                {
                    SampleDTSubSeq = "DT" + (count + 1).ToString() + " 티칭대기";
                }
                SampleDTPoseNextFlag = false;
            }

            //현재위치 기본자세로 이동 요청이 들어올 경우 현재 시퀀스 상태를 버퍼에 저장한 다음 기본자세 이동시퀀스로 변경함. 이동 완료하고 원복 위해
            if (SampleDTPoseMoveFlag == true)
            {
                SampleDTSubSeq_Buffer = SampleDTSubSeq;
                SampleDTSubSeq = "기본자세이동 시작";

                SampleDTPoseMoveFlag = false;
            }

            //직접교시 완료요청이 들어올 경우 기록점이 빠진곳 없는지 체크하고 완료처리
            if (SampleDTEndFlag == true)
            {
                RobotCommclass.RobotDirectTeachingOff();
                bool temp = true;
                for (int i = 0; i < DTSampleCount; i++) { if (SampleWeldDTPointOK[i] == false) temp = false; }
                if (temp == true) SampleDTSubSeq = "직접교시 완료";

                SampleDTEndFlag = false;
            }

            if (SampleTouchAndWeldFlag == true)
            {
                RobotCommclass.RobotDirectTeachingOff();
                bool temp = true;
                for (int i = 0; i < DTSampleCount; i++) { if (SampleWeldDTPointOK[i] == false) temp = false; }
                if (temp == true) SampleDTSubSeq = "직접교시 완료";
            }
        }

        void SampleWeldDTSeq()
        {
            string tempstr = "";
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            int tempi = 0;
            int InitPoseIndex = 0;
            int TargetPoseIndex = 0;

            switch (SampleDTSubSeq)
            {
                case "대기":

                    break;
                case "시작":
                    SampleDTSubSeq = "DT0 티칭대기";
                    break;

                case "DT0 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(0);
                    break;

                case "DT1 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(1);
                    break;

                case "DT2 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(2);
                    break;

                case "DT3 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(3);
                    break;

                case "DT4 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(4);
                    break;

                case "DT5 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(5);
                    break;

                case "DT6 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(6);
                    break;

                case "DT7 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(7);
                    break;

                case "DT8 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(8);
                    break;

                case "DT9 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(9);
                    break;

                case "DT10 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(10);
                    break;

                case "DT11 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(11);
                    break;

                case "DT12 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(12);
                    break;

                case "DT13 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(13);
                    break;

                case "DT14 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(14);
                    break;

                case "DT15 티칭대기":
                    //위치기록 플래그 체크
                    DTSampleCheck(15);
                    break;

                case "직접교시 완료":

                    break;
                case "직접교시 실패":

                    break;
                case "기본자세이동 시작":

                    //직접교시 끄기
                    RobotCommclass.RobotDirectTeachingOff();
                    DTOffTime = DateTime.Now;
                    SampleDTSubSeq = "기본자세이동 직접교시종료대기";

                    break;
                case "기본자세이동 직접교시종료대기":

                    //일정시간 대기
                    tempi = (int)(DateTime.Now - DTOffTime).Ticks / 10000;
                    if (tempi > 500)
                    {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                        SampleDTSubSeq = "기본자세이동 모션명령";
                    }

                    break;
                case "기본자세이동 모션명령":

                    tempstr = "";
                    tempstr = SampleTypeName + "_" + (Convert.ToInt32(SampleWeldCellPara[0]+0.1)).ToString() + "_" + SampleDTSubSeq_Buffer.Split(' ')[0];
                    TargetPoseIndex = SampleTypePose[tempstr];
                    InitPoseIndex = FindCloseRDPIndex(RobotDataEX.moni_RobotTCPActualPose[0], RobotDataEX.moni_RobotTCPActualPose[1], RobotDataEX.moni_RobotTCPActualPose[2], RobotDataEX.moni_RobotTCPActualPose[3], RobotDataEX.moni_RobotTCPActualPose[4], RobotDataEX.moni_RobotTCPActualPose[5]);
                    tempRobotPoseArr.Add(TCP_BACK());
                    if (TargetPoseIndex > InitPoseIndex)
                    {
                        for (int i = InitPoseIndex; i <= TargetPoseIndex; i++) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                    }
                    else if (TargetPoseIndex < InitPoseIndex)
                    {
                        for (int i = InitPoseIndex; i >= TargetPoseIndex; i--) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add(SampleDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 시작.");
                        SampleDTSubSeq = "기본자세이동 완료대기";

                    }
                    else
                    {
                        MainLog_Add(SampleDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 시작실패.");
                        SampleDTSubSeq = "기본자세이동 실패";
                    }
                    break;
                case "기본자세이동 완료대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add(SampleDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 성공.");
                        SampleDTSubSeq = "기본자세이동 성공";
                    }
                    else if (RobotCommclass.RobotControlThreadSeq == 310)
                    {//연속이동 시퀀스 실패
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add(SampleDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 실패.");
                        SampleDTSubSeq = "기본자세이동 실패";
                    }

                    break;
                case "기본자세이동 성공":

                    //직접교시 켜기
                    RobotCommclass.RobotDirectTeachingOn();
                    SampleDTSubSeq = SampleDTSubSeq_Buffer;
                    break;
                case "기본자세이동 실패":

                    SampleDTSubSeq = SampleDTSubSeq_Buffer;
                    break;
                default:
                    break;
            }


        }
        


        int MakeSampleWeldInformation()
        {
            //기존 용접정보 삭제
            SampleWeld_WeldInformationList.Clear();

            switch (SampleTypeName)
            {
                case "Fillet2F":
                    if (MakeWeldInfo_Fillet2F() != 1) return 0;
                    break;
                case "Fillet3F.Left":
                    if (MakeWeldInfo_Fillet3F_Left() != 1) return 0;
                    break;
                case "Fillet3F.Right":
                    if (MakeWeldInfo_Fillet3F_Right() != 1) return 0;
                    break;
                case "Fillet4F":
                    if (MakeWeldInfo_Fillet4F() != 1) return 0;
                    break;
                default:
                    break;
            }

            return 1;

        }



        void SampleWeldingSubSeq()
        {
            bool NextWeldFlag = true;
            string tempstr1 = "";

            switch (SampleWeldingSubState)
            {
                case "시작":

                    //기존용접경로 삭제
                    SampleWeldingPathRecord_ALL.Clear();
                    SampleWeldingPathRecord_Single.Clear();

                    SampleWeldCount = 0;
                    if (SampleWeld_WeldInformationList.Count > 0)
                    {
                        SampleWeldingSubState = "연속용접 대기";
                    }
                    else
                    {
                        SampleWeldingSubState = "연속용접 실패";
                    }

                    break;

                case "연속용접 대기":
                    //용접 라인이 남아있는 경우 용접을 자동으로 시작하는 설정인지 체크한 후 용접 진행함
                    if (SampleWeld_WeldInformationList.Count > SampleWeldCount)
                    {
                        //설정값 가져옴
                        Read_InitSetting_KeyValue("WeldingAutoManualStart", ref tempstr1);

                        //자동진행 설정 중 하나라도 진행안함이 있으면 자동진행 안함
                        NextWeldFlag = true;
                        if (tempstr1 == "1") NextWeldFlag = false; //설정이 수동진행인 경우
                        if ((SampleWeld_WeldInformationList[SampleWeldCount].MultipathNumber > 1) && (tempstr1 == "2")) NextWeldFlag = false; //다층용접이며 설정이 다층용접일때 수동진행인 경우
                        if (SampleWeld_WeldInformationList[SampleWeldCount].ContinueFlag == false) NextWeldFlag = false; //용접패스설정
                        if (SampleWeldSubNextWeldingStopFlag == true) NextWeldFlag = false; //상위에서 다음 용접 진행안함 눌렀을 경우

                        if (NextWeldFlag == false)
                        {
                            //자동진행 설정으로 용접 안할때 상위에서 수동으로 진행하는 플래그
                            if (SampleWeldSubNextWeldingStartFlag == true)
                            {
                                SampleWeldSubNextWeldingStartFlag = false;
                                SampleWeldSubNextWeldingStopFlag = false;
                                SampleWeldingSubState = "연속용접";
                            }
                        }
                        else
                        {
                            //진행인 경우 다음 용접 진행
                            SampleWeldingSubState = "연속용접";
                        }
                    }
                    else
                    {
                        SampleWeldingSubState = "연속용접 성공";
                    }

                    break;

                case "연속용접":

                    if (MultipathAndArcSensingCheck(SampleWeld_WeldInformationList, SampleWeldCount) == true)
                    {
                        //멀티패스(2,3패스) 이며 초층을 아크센싱 적용한 경우 초층 실제 용접경로에 쉬프트 적용하여 다층용접경로 생성 후 용접
                        RobotCommclass.WeldStart(MakeArcSensingMultiPath(SampleWeld_WeldInformationList,SampleWeldingPathRecord_ALL, SampleWeldCount));
                    }
                    else
                    {
                        //멀티패스가 아니거나 초층에 아크센싱을 사용하지 않은 경우 정해진 경로대로 용접
                        RobotCommclass.WeldStart(SampleWeld_WeldInformationList[SampleWeldCount]);
                    }

                    SampleWeldCount++;
                    SampleWeldingSubState = "연속용접 완료대기";

                    break;

                case "연속용접 완료대기":

                    if (RobotCommclass.RobotControlThreadSeq == 124)
                    {
                        RobotCommclass.RobotControlThreadSeq = 15;
                        SampleWeldingSubState = "연속용접 대기";

                        //용접경로 저장
                        if (SampleWeldingPathRecord_ALL.Count > SampleWeldCount - 1) SampleWeldingPathRecord_ALL.RemoveAt(SampleWeldingPathRecord_ALL.Count-1);
                        SampleWeldingPathRecord_Single = RobotCommclass.GetLastWeldingPath();
                        SampleWeldingPathRecord_ALL.Add(SampleWeldingPathRecord_Single);
                    }
                    else if (RobotCommclass.RobotControlThreadSeq == 199)
                    {
                        RobotCommclass.RobotControlThreadSeq = 15;
                        SampleWeldingSubState = "연속용접 실패";
                    }

                    break;

                case "연속용접 실패":
                    break;

                case "연속용접 성공":
                    break;

                default:
                    break;
            }

        }



        void TouchSeq_Fillet2F()
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            int para1 = Convert.ToInt32(SampleWeldCellPara[0] + 0.1);
            int para2 = Convert.ToInt32(SampleWeldCellPara[1] + 0.1);

            switch (SampleTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (((para1==0)|| (para1 == 1)|| (para1 == 2)) && ((para2 == 0) || (para2 == 1) || (para2 == 2)))
                    {
                        MainLog_Add("일반 수평필렛 터치센싱 시작.");
                        SampleTSSubSeq = "터치센싱 위치 계산";
                    }
                    else
                    {
                        MainLog_Add("수평필렛 세부 형상정보 잘못됨.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }
                    break;
                case "터치센싱 위치 계산":

                    MainLog_Add("터치센싱 위치 계산.");
                    SampleWeld_TSPoint_JointPose[0].Copy(SampleWeld_DTPoint_JointPose[0]);
                    SampleWeld_TSPoint_JointPose[1].Copy(SampleWeld_DTPoint_JointPose[1]);
                    SampleWeld_TSPoint_TCPPose[0].Copy(SampleWeld_DTPoint_TCPPose[0]);
                    SampleWeld_TSPoint_TCPPose[1].Copy(SampleWeld_DTPoint_TCPPose[1]);

                    SampleTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (para1 == 0)
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_B()));       //첫번째 터치위치
                    }
                    else if(para1 == 1)
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_B_L()));     //첫번째 터치위치
                    }
                    else
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_B_RR()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        SampleTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        SampleTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 0, -1, 20, 20, 1, 0, 0, 1));
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 50, 20, 1, -1, 0, 0));

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        SampleTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        SampleWeld_WedlPoint[0] = RobotCommclass.GetTouchPose_2th(0, 0, -20);

                        SampleTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (para2 == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_B()));
                    }
                    else if (para2 == 1)
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_B_L()));
                    }
                    else
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_B_RR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        SampleTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        SampleTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 0, -1, 20, 20, 1, 0, 0, 1));
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 50, 20, 1, -1, 0, 0));

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        SampleTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        SampleWeld_WedlPoint[1] = RobotCommclass.GetTouchPose_2th(0, 0, -20);

                        SampleTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    tempRobotPoseArr.Add(TCP_BACK());
                    tempRobotPoseArr.Add(TCP_Middle2());

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        SampleTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("수평필렛 터치센싱 완료.");
                        SampleTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
        }

        void TouchSeq_Fillet3F_Left()
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            int para1 = Convert.ToInt32(SampleWeldCellPara[0] + 0.1);
            int para2 = Convert.ToInt32(SampleWeldCellPara[1] + 0.1);

            switch (SampleTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":

                    if (((para1 == 0) || (para1 == 1)) && ((para2 == 0) || (para2 == 1) || (para2 == 2) || (para2 == 3)))
                    {
                        MainLog_Add("왼쪽 수직필렛 터치센싱 시작.");
                        SampleTSSubSeq = "터치센싱 위치 계산";
                    }
                    else
                    {
                        MainLog_Add("왼쪽 수직필렛 세부 형상정보 잘못됨.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }
                    break;
                case "터치센싱 위치 계산":

                    MainLog_Add("터치센싱 위치 계산.");
                    SampleWeld_TSPoint_JointPose[0].Copy(SampleWeld_DTPoint_JointPose[0]);
                    SampleWeld_TSPoint_JointPose[1].Copy(SampleWeld_DTPoint_JointPose[1]);
                    SampleWeld_TSPoint_TCPPose[0].Copy(SampleWeld_DTPoint_TCPPose[0]);
                    SampleWeld_TSPoint_TCPPose[1].Copy(SampleWeld_DTPoint_TCPPose[1]);

                    SampleTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (para1 == 0)
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(TCP_BL());
                        tempRobotPoseArr.Add(TCP_L());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_L()));       //첫번째 터치위치
                    }
                    else
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(TCP_BL());
                        tempRobotPoseArr.Add(TCP_L_BB());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_L_BB()));       //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        SampleTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        SampleTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        SampleTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        SampleWeld_WedlPoint[0] = RobotCommclass.GetTouchPose_2th(20, 0, 0);

                        SampleTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (para2 == 0)
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_L()));       //두번째 터치위치 TCP_L
                    }
                    else if (para2 == 1)
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_L_B()));       //두번째 터치위치 TCP_L_B
                    }
                    else if (para2 == 2)
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_L_U()));       //두번째 터치위치 TCP_L_U
                    }
                    else
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_LCP_L()));       //두번째 터치위치 TCP_LCP_L
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        SampleTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        SampleTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    
                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        SampleTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        SampleWeld_WedlPoint[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);

                        SampleTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    tempRobotPoseArr.Add(TCP_BL());
                    tempRobotPoseArr.Add(TCP_Middle2());
                    
                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        SampleTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("수평필렛 터치센싱 완료.");
                        SampleTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":

                    break;
                case "터치시퀀스 실패":

                    break;
                default:
                    break;
            }

        }


        void TouchSeq_Fillet3F_Right()
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            int para1 = Convert.ToInt32(SampleWeldCellPara[0] + 0.1);
            int para2 = Convert.ToInt32(SampleWeldCellPara[1] + 0.1);

            switch (SampleTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":

                    if (((para1 == 0) || (para1 == 1)) && ((para2 == 0) || (para2 == 1) || (para2 == 2) || (para2 == 3)))
                    {
                        MainLog_Add("오른쪽 수직필렛 터치센싱 시작.");
                        SampleTSSubSeq = "터치센싱 위치 계산";
                    }
                    else
                    {
                        MainLog_Add("오른쪽 수직필렛 세부 형상정보 잘못됨.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }
                    break;
                case "터치센싱 위치 계산":

                    MainLog_Add("터치센싱 위치 계산.");
                    SampleWeld_TSPoint_JointPose[0].Copy(SampleWeld_DTPoint_JointPose[0]);
                    SampleWeld_TSPoint_JointPose[1].Copy(SampleWeld_DTPoint_JointPose[1]);
                    SampleWeld_TSPoint_TCPPose[0].Copy(SampleWeld_DTPoint_TCPPose[0]);
                    SampleWeld_TSPoint_TCPPose[1].Copy(SampleWeld_DTPoint_TCPPose[1]);

                    SampleTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (para1 == 0)
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(TCP_BL());
                        tempRobotPoseArr.Add(TCP_L());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_R()));       //첫번째 터치위치
                    }
                    else 
                    {
                        tempRobotPoseArr.Add(Joint_B());
                        tempRobotPoseArr.Add(TCP_BL());
                        tempRobotPoseArr.Add(TCP_L_BB());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[0], TCP_R_BB()));       //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        SampleTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        SampleTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        SampleTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        SampleWeld_WedlPoint[0] = RobotCommclass.GetTouchPose_2th(20, 0, 0);

                        SampleTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (para2 == 0)
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_R()));       //두번째 터치위치 TCP_R
                    }
                    else if (para2 == 1)
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_R_B()));       //두번째 터치위치 TCP_R_B
                    }
                    else if (para2 == 2)
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_R_U()));       //두번째 터치위치 TCP_R_U
                    }
                    else
                    {
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, SampleWeld_TSPoint_TCPPose[1], TCP_RCP_R()));       //두번째 터치위치 TCP_RCP_R
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        SampleTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        SampleTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    
                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        SampleTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        SampleWeld_WedlPoint[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);

                        SampleTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    tempRobotPoseArr.Add(TCP_BR());
                    tempRobotPoseArr.Add(TCP_Middle2());
                    

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        SampleTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        SampleTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("수평필렛 터치센싱 완료.");
                        SampleTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":

                    break;
                case "터치시퀀스 실패":

                    break;
                default:
                    break;
            }

        }

        void TouchSeq_Fillet4F()
        {




        }






        int MakeWeldInfo_Fillet2F()
        {
            int para1 = Convert.ToInt32(SampleWeldCellPara[0] + 0.1);
            int para2 = Convert.ToInt32(SampleWeldCellPara[1] + 0.1);

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation0 = new WeldInformation();
            RobotPoseData tempRobotPose;
            
            //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
            Read_InitSetting_KeyValue("PathNum_2F_" + ((int)SampleWeldLineWidth[0]).ToString() + "mm", ref tempstr1);
            pathnum = Convert.ToInt32(tempstr1);

            //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
            DefaultWeldInformation = new WeldInformation();
            tempmaincon = new WeldMainCondition();
            tempmaincon.SetPath(1, SampleWeld_WedlPoint[1], SampleWeld_WedlPoint[1], SampleWeld_WedlPoint[0]);
            DefaultWeldInformation.AddMainCondition(tempmaincon);

            //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
            for (int i = 0; i < pathnum; i++)
            {
                ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation0, "2F", SampleWeldLineWidth[0], SampleWeldLineGap[0], pathnum, i, "1", "P", false, i * 5, i * 5);
                tempweldinformation0.ArcOnFlag = ArcFlag;
                tempweldinformation0.ContinueFlag = true;

                //접근경로
                if (para1 == 1)
                {
                    tempweldinformation0.InitCondition.AddStartPosition(Joint_Middle2());
                    tempweldinformation0.InitCondition.AddStartPosition(TCP_B_L());
                }
                else if(para1 == 2)
                {
                    tempweldinformation0.InitCondition.AddStartPosition(Joint_Middle2());
                    tempweldinformation0.InitCondition.AddStartPosition(TCP_B_RR());
                }
                else
                {
                    tempweldinformation0.InitCondition.AddStartPosition(Joint_Middle2());
                    tempweldinformation0.InitCondition.AddStartPosition(TCP_B());
                }

                //복귀경로
                if (para2 == 1)
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_B_L());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }
                else if (para2 == 2)
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_B_RR());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }
                else
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_B());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }
               

                //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                string tempstr = "";
                Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                if (tempstr == "1")
                {
                    SampleWeld_WeldInformationList.Add((WeldInformation)tempweldinformation0.Clone());
                }
                else if (tempstr == "0")
                {
                    SampleWeld_WeldInformationList.Add(tempweldinformation0.ReverseInfo());
                }
                else
                {
                    if (IMUclass.RobotRx < -5)
                    {
                        SampleWeld_WeldInformationList.Add(tempweldinformation0.ReverseInfo());
                    }
                    else
                    {
                        SampleWeld_WeldInformationList.Add((WeldInformation)tempweldinformation0.Clone());
                    }
                }


            }


            return 1;
        }

        int MakeWeldInfo_Fillet3F_Left()
        {
            int para1 = Convert.ToInt32(SampleWeldCellPara[0] + 0.1);
            int para2 = Convert.ToInt32(SampleWeldCellPara[1] + 0.1);

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation0 = new WeldInformation();
            RobotPoseData tempRobotPose;

            //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
            Read_InitSetting_KeyValue("PathNum_3F_" + ((int)SampleWeldLineWidth[0]).ToString() + "mm", ref tempstr1);
            pathnum = Convert.ToInt32(tempstr1);

            //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
            DefaultWeldInformation = new WeldInformation();
            tempmaincon = new WeldMainCondition();
            tempmaincon.SetPath(1, SampleWeld_WedlPoint[0], SampleWeld_WedlPoint[0], SampleWeld_WedlPoint[1]);
            DefaultWeldInformation.AddMainCondition(tempmaincon);

            //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
            for (int i = 0; i < pathnum; i++)
            {
                ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation0, "3F", SampleWeldLineWidth[0], SampleWeldLineGap[0], pathnum, i, "1", "P", false, i * 5, i * 5);
                tempweldinformation0.ArcOnFlag = ArcFlag;
                tempweldinformation0.ContinueFlag = true;

                //접근경로
                tempweldinformation0.InitCondition.AddStartPosition(Joint_Middle2());
                tempweldinformation0.InitCondition.AddStartPosition(TCP_L_B());

                //복귀경로
                if (para2 == 3)
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_LCP_L());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_L());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }
                else
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_L());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }

                
                SampleWeld_WeldInformationList.Add((WeldInformation)tempweldinformation0.Clone());
            }
            

            return 1;
        }


        int MakeWeldInfo_Fillet3F_Right()
        {
            int para1 = Convert.ToInt32(SampleWeldCellPara[0] + 0.1);
            int para2 = Convert.ToInt32(SampleWeldCellPara[1] + 0.1);

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation0 = new WeldInformation();
            RobotPoseData tempRobotPose;

            //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
            Read_InitSetting_KeyValue("PathNum_3F_" + ((int)SampleWeldLineWidth[0]).ToString() + "mm", ref tempstr1);
            pathnum = Convert.ToInt32(tempstr1);

            //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
            DefaultWeldInformation = new WeldInformation();
            tempmaincon = new WeldMainCondition();
            tempmaincon.SetPath(1, SampleWeld_WedlPoint[0], SampleWeld_WedlPoint[0], SampleWeld_WedlPoint[1]);
            DefaultWeldInformation.AddMainCondition(tempmaincon);

            //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
            for (int i = 0; i < pathnum; i++)
            {
                ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation0, "3F", SampleWeldLineWidth[0], SampleWeldLineGap[0], pathnum, i, "1", "P", false, i * 5, i * 5);
                tempweldinformation0.ArcOnFlag = ArcFlag;
                tempweldinformation0.ContinueFlag = true;

                //접근경로
                tempweldinformation0.InitCondition.AddStartPosition(Joint_Middle2());
                tempweldinformation0.InitCondition.AddStartPosition(TCP_R_B());

                //복귀경로
                if (para2 == 3)
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_RCP_R());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_R());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }
                else
                {
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_BACK());
                    tempweldinformation0.EndCondition.AddEndPosition(TCP_R());
                    tempweldinformation0.EndCondition.AddEndPosition(Joint_Middle2());
                }


                SampleWeld_WeldInformationList.Add((WeldInformation)tempweldinformation0.Clone());
            }


            return 1;
        }

        int MakeWeldInfo_Fillet4F()
        {



            return 1;
        }





        void SampleWeldCalcInfo_Total()
        {
            double temp1 = 0, temp2 = 0;

            SampleWeldSub_TotalLineCount = SampleWeld_WeldInformationList.Count;

            foreach (WeldInformation wi in SampleWeld_WeldInformationList)
            {
                temp1 = temp1 + wi.CalcWeldLength();
                temp2 = temp2 + wi.CalcWeldTime();
            }

            SampleWeldSub_TotalLineLength = temp1;
            SampleWeldSub_TotalWeldTime = temp2;
        }


        void SampleWeldCalcInfo_Left()
        {
            if (SampleWeldCount - 1 >= 0)
            {
                SampleWeldSub_NowLineCount = SampleWeldCount;

                double temp1 = 0, temp2 = 0, temp3 = 0, temp4 = 0;

                for (int i = SampleWeldCount; i < SampleWeld_WeldInformationList.Count; i++)
                {
                    temp1 = temp1 + SampleWeld_WeldInformationList[i].CalcWeldLength();
                    temp2 = temp2 + SampleWeld_WeldInformationList[i].CalcWeldTime();
                }

                temp3 = SampleWeld_WeldInformationList[SampleWeldCount - 1].CalcWeldLength();
                temp4 = SampleWeld_WeldInformationList[SampleWeldCount - 1].CalcWeldTime();


                if (RobotCommclass.RobotControlThreadSeq < 112)
                {
                    SampleWeldSub_LeftNowLineLength = temp3;
                    SampleWeldSub_LeftNowWeldTime = temp4;
                    SampleWeldSub_LeftTotalLineLength = temp1 + temp3;
                    SampleWeldSub_LeftTotalWeldTime = temp2 + temp4;
                }
                else if (RobotCommclass.RobotControlThreadSeq < 115)
                {
                    int nowweldcount = SampleWeld_WeldInformationList[SampleWeldCount - 1].GetMainConditionCount();

                    double d1 = SampleWeld_WeldInformationList[SampleWeldCount - 1].GetMainCondition(nowweldcount - 1).GetEndPose().f1 - RobotDataEX.moni_RobotTCPActualPose[0];
                    double d2 = SampleWeld_WeldInformationList[SampleWeldCount - 1].GetMainCondition(nowweldcount - 1).GetEndPose().f2 - RobotDataEX.moni_RobotTCPActualPose[1];
                    double d3 = SampleWeld_WeldInformationList[SampleWeldCount - 1].GetMainCondition(nowweldcount - 1).GetEndPose().f3 - RobotDataEX.moni_RobotTCPActualPose[2];
                    double d4 = Math.Sqrt(d1 * d1 + d2 * d2 + d3 * d3);

                    temp4 = temp4 * (d4 / temp3);
                    temp3 = d4;

                    SampleWeldSub_LeftNowLineLength = temp3;
                    SampleWeldSub_LeftNowWeldTime = temp4;
                    SampleWeldSub_LeftTotalLineLength = temp1 + temp3;
                    SampleWeldSub_LeftTotalWeldTime = temp2 + temp4;
                }
                else
                {
                    SampleWeldSub_LeftNowLineLength = 0;
                    SampleWeldSub_LeftNowWeldTime = 0;
                    SampleWeldSub_LeftTotalLineLength = temp1;
                    SampleWeldSub_LeftTotalWeldTime = temp2;
                }
            }
            else
            {
                SampleWeldSub_NowLineCount = 0;
                SampleWeldSub_LeftNowLineLength = 0;
                SampleWeldSub_LeftNowWeldTime = 0;
                SampleWeldSub_LeftTotalLineLength = 0;
                SampleWeldSub_LeftTotalWeldTime = 0;
            }

        }



    }
}
