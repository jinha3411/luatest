﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

//뮤텍스 사용하기 위해
using System.Threading;

namespace OpenBlockWeldingRobot
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string mtxName = "DF39FED8-E791-41DB-88BE-8E86617A6818";
            bool createdNew;

            using (Mutex mtx = new Mutex(true, mtxName, out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show("프로그램이 이미 실행중입니다");
                    Application.Exit();
                }
                else
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new Form1());
                }
            }
        }
    }
}
