﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBlockWeldingRobot
{
    //메인 Form1 클래스의 파샬클래스
    //메인클래스 공동작업이 필요 한 경우 동시에 동일한 파일 수정하는것을 막기위해 만들었음.
    //여기에는 주로 수동시퀀스 관련해서 작성

    public partial class Form1
    {
        //시퀀스 상태변수
        string ManualSequenceState = "수동조작-대기";
        string TestWeldingState = "시편 테스트 용접-대기";
        string WirecutState = "와이어컷-대기";
        string TCPCheckMotionState = "TCP확인모션-대기";

        //인칭, 가스체크 통신지령 시간기록변수, 상태플래그
        DateTime UDPGasTime = DateTime.Now;
        DateTime UDPInchingTime = DateTime.Now;
        DateTime UDPInvInchingTime = DateTime.Now;
        bool UDPGasFlag = false;
        bool UDPInchingFlag = false;
        bool UDPInvInchingFlag = false;


        void ManualSequence()
        {

            switch (ManualSequenceState)
            {
                case "수동조작-대기":
                    
                    break;

                case "수동조작-시편테스트용접":
                    MainLog_Add("시편테스트 용접 시작");
                    ManualSequenceState = "수동조작-시편테스트용접 수행중";
                    TestWeldingState = "시편 테스트 용접-시작";

                    break;

                case "수동조작-시편테스트용접 수행중":
                    
                    TestWeldingSequence();

                    if (TestWeldingState == "시편 테스트 용접-용접완료")
                    {
                        TestWeldingState = "시편 테스트 용접-대기";
                        ManualSequenceState = "수동조작-종료";
                    }
                    else if (TestWeldingState == "시편 테스트 용접-용접실패")
                    {
                        TestWeldingState = "시편 테스트 용접-대기";
                        ManualSequenceState = "수동조작-실패";
                    }

                    break;

                case "수동조작-와이어컷팅":
                    MainLog_Add("와이어 컷팅 시작");
                    ManualSequenceState = "수동조작-와이어컷팅 수행중";
                    WirecutState = "와이어컷-이동";
                    break;

                case "수동조작-와이어컷팅 수행중":

                    Wirecutting();

                    if (WirecutState == "와이어컷-완료")
                    {
                        WirecutState = "와이어컷-대기";
                        ManualSequenceState = "수동조작-종료";
                    }
                    else if (WirecutState == "와이어컷-실패")
                    {
                        WirecutState = "와이어컷-대기";
                        ManualSequenceState = "수동조작-실패";
                    }

                    break;

                case "수동조작-TCP확인":
                    MainLog_Add("TCP 확인모션 시작");
                    ManualSequenceState = "수동조작-TCP확인 수행중";
                    TCPCheckMotionState = "TCP확인모션-이동";
                    break;

                case "수동조작-TCP확인 수행중":

                    TCPCheckMotion();

                    if (TCPCheckMotionState == "TCP확인모션-완료")
                    {
                        TCPCheckMotionState = "TCP확인모션-대기";
                        ManualSequenceState = "수동조작-종료";
                    }
                    else if (TCPCheckMotionState == "TCP확인모션-실패")
                    {
                        TCPCheckMotionState = "TCP확인모션-대기";
                        ManualSequenceState = "수동조작-실패";
                    }

                    break;

                case "수동조작-종료":



                    break;

                case "수동조작-실패":



                    break;

                default:
                    break;



            }


        }




        void TestWeldingSequence()
        {
            switch (TestWeldingState)
            {
                case "시편 테스트 용접-대기":

                    break;
                case "시편 테스트 용접-시작":
                    TestWeldingState = "시편 테스트 용접-직접교시 입력대기";
                    break;
                case "시편 테스트 용접-직접교시 입력대기":
                    break;
                case "시편 테스트 용접-1번티칭":
                    break;
                case "시편 테스트 용접-2번티칭":
                    break;
                case "시편 테스트 용접-티칭종료":
                    AutoTSSubSeq = "시작";
                    break;
                case "시편 테스트 용접-터치센싱 시작":

                    if (direction > 3) TouchSeq();
                    else TouchSeq(direction);


                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        TestWeldingState = "시편 테스트 용접-용접시작 대기";
                        MainLog_Add("용접시작 대기");
                        AutoWeldStartFlag = false;
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        TestWeldingState = "시편 테스트 용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;


                case "시편 테스트 용접-용접시작 대기":

                    if (AutoWeldStartFlag == true)
                    {
                        TestWeldingState = "시편 테스트 용접-용접시작";
                        AutoWeldStartFlag = false;
                    }
                    break;


                case "시편 테스트 용접-용접시작":
                    if (direction > 3) ManualWeldInfo();
                    else ManualWeldInfo(direction);

                    TestWeldingState = "시편 테스트 용접-용접완료대기";
                    AutoWeldingSubState = "시작";
                    AutoWeldCount = 0;
                    break;

                case "시편 테스트 용접-용접완료대기":

                    AutoWeldingSubSeq();

                    if (AutoWeldingSubState == "연속용접 성공")
                    {
                        TestWeldingState = "시편 테스트 용접-용접완료";

                    }
                    else if (AutoWeldingSubState == "연속용접 실패")
                    {
                        TestWeldingState = "시편 테스트 용접-용접실패";
                        ErrorOccurTime = DateTime.Now;
                    }



                    break;
                case "시편 테스트 용접-용접완료":

                    break;
                case "시편 테스트 용접-용접실패":
                    
                    break;

                default:
                    break;


            }

        }
        void ManualWeldInfo(int dir)
        {
            double tempd1;
            double tempd2;
            double tempd3;
            double WeldLength;

            WeldInformation tempweldinformation;

            AutoWeld_WeldInformationList.Clear();

            double WeldStartAmp = Convert.ToDouble(textBox_HFInitAmp.Text);
            double WeldStartTime = Convert.ToDouble(textBox_HFInitTime.Text);
            double WeldStartVol = Convert.ToDouble(textBox_HFInitVol.Text);

            double tVol = Convert.ToDouble(textBox_HFVol.Text);
            double tAmp = Convert.ToDouble(textBox_HFAmp.Text);
            double tSpd = Convert.ToDouble(textBox_HFSpeed.Text);

            int Weavingflag = comboBox_HFWeav.SelectedIndex;
            double tHz = Convert.ToDouble(textBox_HFHz.Text);
            double tHzWidth = Convert.ToDouble(textBox_HFWidth.Text);
            double WeavLeftStopTime = Convert.ToDouble(textBox_HFLStopTime.Text);
            double WeavRightStopTime = Convert.ToDouble(textBox_HFRStopTime.Text);
            int ArcSen = comboBox_HFArc.SelectedIndex;
            double ArcSenTimeShift = Convert.ToDouble(textBox_HFTimeShift.Text);
            double ArcSenHFactor = Convert.ToDouble(textBox_HFHFactor.Text);
            double ArcSenVFactor = Convert.ToDouble(textBox_HFVFactor.Text);
            double ArcSenMaxdL = Convert.ToDouble(textBox_HFLimit.Text);

            //메인조건 입력
            tempd1 = AutoWeld_WedlPoint_Left[0].f1 - AutoWeld_WedlPoint_Right[0].f1;
            tempd2 = AutoWeld_WedlPoint_Left[0].f2 - AutoWeld_WedlPoint_Right[0].f2;
            tempd3 = AutoWeld_WedlPoint_Left[0].f3 - AutoWeld_WedlPoint_Right[0].f3;
            WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));

            float temp1X, temp1Y, temp1Z, temp2X, temp2Y, temp2Z;
            temp1X = (float)(AutoWeld_WedlPoint_Left[0].f1 - 50 * (tempd1 / WeldLength));
            temp1Y = (float)(AutoWeld_WedlPoint_Left[0].f2 - 50 * (tempd2 / WeldLength));
            temp1Z = (float)(AutoWeld_WedlPoint_Left[0].f3 - 50 * (tempd3 / WeldLength));

            temp2X = (float)(AutoWeld_WedlPoint_Right[0].f1 + 100 * (tempd1 / WeldLength));
            temp2Y = (float)(AutoWeld_WedlPoint_Right[0].f2 + 100 * (tempd2 / WeldLength));
            temp2Z = (float)(AutoWeld_WedlPoint_Right[0].f3 + 100 * (tempd3 / WeldLength));

            //시작조건 입력
            tempweldinformation = new WeldInformation();
            tempweldinformation.InitCondition = new WeldStartCondition(3, WeldStartTime, WeldStartVol, WeldStartAmp);
            if (dir == 1 || dir == 2) { tempweldinformation.InitCondition.AddStartPosition((RobotPoseData)RDP_TCP_B.Clone()); }
            //else if (dir == 3) { tempweldinformation.InitCondition.AddStartPosition((RobotPoseData)RobotMiddlePose2.Clone()); }


            // tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone());


            double tVol1 = Convert.ToDouble(textBox2.Text);
            double tAmp1 = Convert.ToDouble(textBox3.Text);
            double tSpd1 = Convert.ToDouble(textBox4.Text);

            double tHz1 = Convert.ToDouble(textBox5.Text);
            double tHzWidth1 = Convert.ToDouble(textBox6.Text);
            double WeavLeftStopTime1 = Convert.ToDouble(textBox12.Text);
            double WeavRightStopTime1 = Convert.ToDouble(textBox13.Text);
            if (dir == 2 || dir == 3)
            {
                //메인조건 입력
                WeldMainCondition tempmaincon1 = new WeldMainCondition();
                tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon1.WeavingSetting(Weavingflag, tHz, tHzWidth, WeavLeftStopTime, WeavRightStopTime);//위빙설정입력
                tempmaincon1.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon1.SetStartPose(AutoWeld_WedlPoint_Right[0]);
                tempmaincon1.SetMidPose(AutoWeld_WedlPoint_Left[0]);
                tempmaincon1.SetEndPose(AutoWeld_WedlPoint_Left[0]);
                tempweldinformation.AddMainCondition(tempmaincon1);
            }

            if (dir == 1)
            {
                //메인조건 입력
                WeldMainCondition tempmaincon2 = new WeldMainCondition();
                tempmaincon2.WeldSetting(1, tVol1, tAmp1, tSpd1);//보간방식, 전압 전류 스피드 입력
                tempmaincon2.WeavingSetting(Weavingflag, tHz1, tHzWidth1, WeavLeftStopTime1, WeavRightStopTime1);//위빙설정입력
                tempmaincon2.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon2.SetStartPose(AutoWeld_WedlPoint_Left[0]);
                tempmaincon2.SetMidPose(AutoWeld_WedlPoint_Left[0]);
                //tempmaincon2.SetEndPose(new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, RDP_TCP_R_B_10.f4, RDP_TCP_R_B_10.f5, RDP_TCP_R_B_10.f6));
                //tempmaincon2.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone();
                tempweldinformation.AddMainCondition(tempmaincon2);


                WeldMainCondition tempmaincon3 = new WeldMainCondition();
                tempmaincon3.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon3.WeavingSetting(Weavingflag, tHz, tHzWidth, WeavLeftStopTime, WeavRightStopTime);//위빙설정입력
                tempmaincon3.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                //tempmaincon3.SetStartPose(new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, RDP_TCP_R_B_10.f4, RDP_TCP_R_B_10.f5, RDP_TCP_R_B_10.f6));
                tempmaincon3.SetMidPose(AutoWeld_WedlPoint_Right[0]);
                tempmaincon3.SetEndPose(AutoWeld_WedlPoint_Right[0]);
                tempweldinformation.AddMainCondition(tempmaincon3);
            }

            /*
          //메인조건 입력
          WeldMainCondition tempmaincon1 = new WeldMainCondition();
          tempmaincon1.WeldSetting(1, tVol1, tAmp1, tSpd1);//보간방식, 전압 전류 스피드 입력
          tempmaincon1.WeavingSetting(Weavingflag, tHz1, tHzWidth1, WeavLeftStopTime, WeavRightStopTime);//위빙설정입력
          tempmaincon1.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
          tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[0].Clone();
          tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[0].Clone();
          tempmaincon1.PathEndPosition =  new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, -135.0, 0.0, -90.0);
          tempweldinformation.MainCondition.Add(tempmaincon1);


          WeldMainCondition tempmaincon2 = new WeldMainCondition();
          tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
          tempmaincon2.WeavingSetting(Weavingflag, tHz, tHzWidth, WeavLeftStopTime, WeavRightStopTime);//위빙설정입력
          tempmaincon2.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
          tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, -135.0, 0.0, -90.0);
          tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, -135.0, 0.0, -90.0);
          tempmaincon2.PathEndPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, -135.0, 0.0, -90.0);
          tempweldinformation.MainCondition.Add(tempmaincon2);

          double tVol2 = Convert.ToDouble(textBox9.Text);
          double tAmp2 = Convert.ToDouble(textBox10.Text);
          double tSpd2 = Convert.ToDouble(textBox11.Text);

          double tHz2 = Convert.ToDouble(textBox7.Text);
          double tHzWidth2 = Convert.ToDouble(textBox8.Text);

          WeldMainCondition tempmaincon3 = new WeldMainCondition();
          tempmaincon3.WeldSetting(1, tVol2, tAmp2, tSpd2);//보간방식, 전압 전류 스피드 입력
          tempmaincon3.WeavingSetting(Weavingflag, tHz2, tHzWidth2, WeavLeftStopTime, WeavRightStopTime);//위빙설정입력
          tempmaincon3.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
          tempmaincon3.PathStartPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, -135.0, 0.0, -90.0);
          tempmaincon3.PathMidPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, -135.0, 0.0, -90.0);
          tempmaincon3.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone();
          tempweldinformation.MainCondition.Add(tempmaincon3);
          */



            //종료조건 입력
            tempweldinformation.EndCondition = new WeldEndCondition(3, WeldStartTime, WeldStartVol, WeldStartAmp, 10);

            if (dir == 1 || dir == 2) { tempweldinformation.EndCondition.AddEndPosition((RobotPoseData)RDP_TCP_B.Clone()); }
            //else if (dir == 3) { tempweldinformation.EndCondition.AddEndPosition((RobotPoseData)RobotMiddlePose2.Clone()); }


            tempweldinformation.ArcOnFlag = ArcFlag;

            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());



        }
        void ManualWeldInfo()
        {
            double tempd1;
            double tempd2;
            double tempd3;
            double WeldLength;

            WeldInformation tempweldinformation;

            AutoWeld_WeldInformationList.Clear();

            double WeldStartAmp = Convert.ToDouble(textBox31.Text);
            double WeldStartTime = Convert.ToDouble(textBox54.Text);
            double WeldStartVol = Convert.ToDouble(textBox53.Text);

            double tVol = Convert.ToDouble(textBox21.Text);
            double tAmp = Convert.ToDouble(textBox22.Text);
            double tSpd = Convert.ToDouble(textBox24.Text);

            int Weavingflag = comboBox4.SelectedIndex;
            double tHz = Convert.ToDouble(textBox23.Text);
            double tHzWidth = Convert.ToDouble(textBox26.Text);
            double WeavLeftStopTime = Convert.ToDouble(textBox29.Text);
            double WeavRightStopTime = Convert.ToDouble(textBox30.Text);
            int ArcSen = comboBox5.SelectedIndex;
            double ArcSenTimeShift = Convert.ToDouble(textBox20.Text);
            double ArcSenHFactor = Convert.ToDouble(textBox27.Text);
            double ArcSenVFactor = Convert.ToDouble(textBox25.Text);
            double ArcSenMaxdL = Convert.ToDouble(textBox19.Text);

            double tVol1 = Convert.ToDouble(textBox33.Text);
            double tAmp1 = Convert.ToDouble(textBox34.Text);
            double tSpd1 = Convert.ToDouble(textBox36.Text);

            int Weavingflag1 = comboBox6.SelectedIndex;
            double tHz1 = Convert.ToDouble(textBox35.Text);
            double tHzWidth1 = Convert.ToDouble(textBox38.Text);
            double WeavLeftStopTime1 = Convert.ToDouble(textBox40.Text);
            double WeavRightStopTime1 = Convert.ToDouble(textBox41.Text);
            int ArcSen1 = comboBox7.SelectedIndex;
            double ArcSenTimeShift1 = Convert.ToDouble(textBox32.Text);
            double ArcSenHFactor1 = Convert.ToDouble(textBox39.Text);
            double ArcSenVFactor1 = Convert.ToDouble(textBox37.Text);
            double ArcSenMaxdL1 = Convert.ToDouble(textBox28.Text);

            double tVol2 = Convert.ToDouble(textBox44.Text);
            double tAmp2 = Convert.ToDouble(textBox45.Text);
            double tSpd2 = Convert.ToDouble(textBox47.Text);

            int Weavingflag2 = comboBox8.SelectedIndex;
            double tHz2 = Convert.ToDouble(textBox46.Text);
            double tHzWidth2 = Convert.ToDouble(textBox49.Text);
            double WeavLeftStopTime2 = Convert.ToDouble(textBox51.Text);
            double WeavRightStopTime2 = Convert.ToDouble(textBox52.Text);
            int ArcSen2 = comboBox9.SelectedIndex;
            double ArcSenTimeShift2 = Convert.ToDouble(textBox43.Text);
            double ArcSenHFactor2 = Convert.ToDouble(textBox50.Text);
            double ArcSenVFactor2 = Convert.ToDouble(textBox48.Text);
            double ArcSenMaxdL2 = Convert.ToDouble(textBox42.Text);



            //시작조건 입력
            tempweldinformation = new WeldInformation();
            tempweldinformation.InitCondition = new WeldStartCondition(3, WeldStartTime, WeldStartVol, WeldStartAmp);
            //tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RDP_TCP_B.Clone());
            //tempweldinformation.InitCondition.AddStartPosition((RobotPoseData)RobotMiddlePose1.Clone());

            //메인조건 입력
            WeldMainCondition tempmaincon1 = new WeldMainCondition();
            tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
            tempmaincon1.WeavingSetting(Weavingflag, tHz, tHzWidth, WeavLeftStopTime, WeavRightStopTime);//위빙설정입력
            tempmaincon1.ArcSenSetting(ArcSen, ArcSenTimeShift, ArcSenHFactor, ArcSenVFactor, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
            tempmaincon1.SetStartPose(AutoWeld_WedlPoint_Right[0]);
            tempmaincon1.SetMidPose(AutoWeld_WedlPoint_Right[0]);
            tempmaincon1.SetEndPose(AutoWeld_WedlPoint_Right[1]);
            tempweldinformation.AddMainCondition(tempmaincon1);

            WeldMainCondition tempmaincon2 = new WeldMainCondition();
            tempmaincon2.WeldSetting(2, tVol1, tAmp1, tSpd1);//보간방식, 전압 전류 스피드 입력
            tempmaincon2.WeavingSetting(Weavingflag1, tHz1, tHzWidth1, WeavLeftStopTime1, WeavRightStopTime1);//위빙설정입력
            tempmaincon2.ArcSenSetting(ArcSen1, ArcSenTimeShift1, ArcSenHFactor1, ArcSenVFactor1, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
            tempmaincon2.SetStartPose(AutoWeld_WedlPoint_Right[1]);
            tempmaincon2.SetMidPose(AutoWeld_WedlPoint_Right[2]);
            tempmaincon2.SetEndPose(AutoWeld_WedlPoint_Right[3]);
            tempweldinformation.AddMainCondition(tempmaincon2);

            WeldMainCondition tempmaincon3 = new WeldMainCondition();
            tempmaincon3.WeldSetting(1, tVol2, tAmp2, tSpd2);//보간방식, 전압 전류 스피드 입력
            tempmaincon3.WeavingSetting(Weavingflag2, tHz2, tHzWidth2, WeavLeftStopTime2, WeavRightStopTime2);//위빙설정입력
            tempmaincon3.ArcSenSetting(ArcSen2, ArcSenTimeShift2, ArcSenHFactor2, ArcSenVFactor2, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
            tempmaincon3.SetStartPose(AutoWeld_WedlPoint_Right[3]);
            tempmaincon3.SetMidPose(AutoWeld_WedlPoint_Right[3]);
            tempmaincon3.SetEndPose(AutoWeld_WedlPoint_Right[4]);
            tempweldinformation.AddMainCondition(tempmaincon3);


            //종료조건 입력
            tempweldinformation.EndCondition = new WeldEndCondition(3, WeldStartTime, WeldStartVol, WeldStartAmp, 10);


            //tempweldinformation.EndCondition.AddEndPosition((RobotPoseData)Robot_BACK.Clone());

            tempweldinformation.ArcOnFlag = ArcFlag;

            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());



        }




        void Wirecutting()
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            double tempw1, tempw2;

            //와이어 절단포즈 갱신
            SettingLoadRobotPose();

            switch (WirecutState)
            {
                case "와이어컷-대기":
                    //대기 상태
                    break;
                case "와이어컷-이동":
                    //컷팅기로 이동
                    tempRobotPoseArr.Clear();
                    tempRobotPoseArr.Add(Joint_Middle2());
                    tempRobotPoseArr.Add(Joint_WireCut0());
                    tempRobotPoseArr.Add(Joint_WireCut1());
                    tempRobotPoseArr.Add(TCP_WireCut2());

                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("와이어컷 준비 위치 이동 시작");
                        WirecutState = "와이어컷-이동대기";
                    }
                    else
                    {
                        MainLog_Add("와이어컷 준비 위치 이동  실패.");
                        WirecutState = "와이어컷-실패";
                    }

                    break;

                case "와이어컷-이동대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("와이어컷 준비 위치 이동 완료.");
                        WirecutState = "와이어컷-인칭시작";
                        finchingTime = DateTime.Now;
                    }

                    break;
                case "와이어컷-인칭시작":
                    RobotCommclass.Wire_FInching_On();
                    tempw1 = (int)(DateTime.Now - finchingTime).Ticks / 10000;
                    IODataEX.IOModuleOutputData[6] = 1;

                    if (tempw1 > 2000)
                    {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                        RobotCommclass.Wire_FInching_Off();
                        IODataEX.IOModuleOutputData[6] = 0;
                        WirecutState = "와이어컷-역인칭시작";
                        finchingTime = DateTime.Now;
                    }
                    break;
                    break;
                case "와이어컷-역인칭시작":
                    RobotCommclass.Wire_IInching_On();
                    tempw1 = (int)(DateTime.Now - finchingTime).Ticks / 10000;
                    IODataEX.IOModuleOutputData[6] = 1;

                    if (tempw1 > 500)
                    {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                        RobotCommclass.Wire_IInching_Off();
                        IODataEX.IOModuleOutputData[6] = 0;
                        WirecutState = "와이어컷-커팅기로 이동";
                    }
                    break;


                case "와이어컷-커팅기로 이동":
                    //와이어 컷팅기로 이동

                    tempRobotPoseArr.Clear();
                    tempRobotPoseArr.Add(TCP_WireCut3());

                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("와이어컷 실행 위치 이동 시작");
                        WirecutState = "와이어컷-커팅기로 이동대기";
                    }
                    else
                    {
                        MainLog_Add("와이어컷 실행 위치 이동  실패.");
                        WirecutState = "와이어컷-실패";
                    }
                    break;
                case "와이어컷-커팅기로 이동대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("와이어컷 실행 위치 이동 완료.");
                        cut1 = DateTime.Now;

                        WirecutState = "와이어컷-커팅1";
                    }
                    break;

                case "와이어컷-커팅1":

                    tempw1 = (int)(DateTime.Now - cut1).Ticks / 10000;
                    IODataEX.IOModuleOutputData[5] = 1;

                    if (tempw1 > 2000)
                    {
                        IODataEX.IOModuleOutputData[5] = 0;
                        WirecutState = "와이어컷-커팅2";
                        cut1 = DateTime.Now;

                    }


                    break;
                case "와이어컷-커팅2":

                    tempw1 = (int)(DateTime.Now - cut1).Ticks / 10000;
                    IODataEX.IOModuleOutputData[6] = 1;


                    if (tempw1 > 1000)
                    {
                        IODataEX.IOModuleOutputData[6] = 0;

                        cut2 = DateTime.Now;
                        WirecutState = "와이어컷-커팅3";
                    }
                    break;
                case "와이어컷-커팅3":
                    tempw2 = (int)(DateTime.Now - cut2).Ticks / 10000;

                    if (tempw2 > 500)
                    {
                        WirecutState = "와이어컷-복귀";
                    }

                    break;

                case "와이어컷-복귀":
                    tempRobotPoseArr.Clear();
                    tempRobotPoseArr.Add(TCP_WireCut2());
                    tempRobotPoseArr.Add(Joint_WireCut1());
                    tempRobotPoseArr.Add(Joint_WireCut0());
                    tempRobotPoseArr.Add(Joint_Middle2());
                    IODataEX.IOModuleOutputData[5] = 1;
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {

                        IODataEX.IOModuleOutputData[5] = 0;
                        MainLog_Add("와이어컷 복귀 이동시작");
                        WirecutState = "와이어컷-복귀대기";
                    }
                    else
                    {
                        MainLog_Add("와이어컷 복귀 이동실패.");
                        WirecutState = "와이어컷-실패";
                    }

                    break;

                case "와이어컷-복귀대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("와이어컷 복귀대기");
                        WirecutState = "와이어컷-완료";
                    }
                    break;
                case "와이어컷-완료":
                    break;
                case "와이어컷-실패":

                    break;


            }


        }
        

        void TCPCheckMotion()
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            RobotPoseData tempRobotPose = new RobotPoseData();

            //TCP 체크포즈 갱신
            SettingLoadRobotPose();

            switch (TCPCheckMotionState)
            {
                case "TCP확인모션-대기":
                    //대기 상태
                    break;
                case "TCP확인모션-이동":
                    //컷팅기로 이동
                    tempRobotPoseArr.Clear();
                    tempRobotPoseArr.Add(Joint_Middle2());
                    tempRobotPoseArr.Add(Joint_Home0());
                    tempRobotPoseArr.Add(Joint_Home1());
                    tempRobotPoseArr.Add(TCP_Home2());

                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("TCP 확인위치 이동 시작");
                        TCPCheckMotionState = "TCP확인모션-이동대기";
                    }
                    else
                    {
                        MainLog_Add("TCP 확인위치 이동시작 실패");
                        TCPCheckMotionState = "TCP확인모션-실패";
                    }

                    break;

                case "TCP확인모션-이동대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("TCP 확인위치 이동 완료.");
                        TCPCheckMotionState = "TCP확인모션-완료";
                    }

                    break;
                case "TCP확인모션-완료":
                    break;
                case "TCP확인모션-실패":
                    break;


            }


        }



        void TouchSeq(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            double tempd1, tempd2;
            /*

                        switch (AutoTSSubSeq)
                        {
                            case "대기":
                                //대기상태
                                break;
                            case "시작":
                                if (dir == 1) MainLog_Add("수직 터치센싱 시작.");
                                else if (dir == 2) MainLog_Add("수평 터치센싱 시작.");
                                else if (dir == 3) MainLog_Add("위보기 터치센싱 시작");
                                TouchSensingSubSeq = "터치센싱 위치 계산";
                                break;
                            case "터치센싱 위치 계산":

                                AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                                AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                                AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                                AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);

                                TouchSensingSubSeq = "0번 터치점 위치이동 시작";
                                break;
                            case "0번 터치점 위치이동 시작":
                                //이동경로 초기화
                                tempRobotPoseArr.Clear();

                                if (dir == 1)
                                {
                                    int PoseID = CellTypePose["ST1_L0"];
                                    //tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());                                          //첫번째 경유점
                                    //tempRobotPoseArr.Add((RobotPoseData)RDP_Joint[PoseID].Clone());                         //22                //두번째 경유점
                                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], RDP_TCP[12]));     //첫번째 터치위치
                                }
                                else if (dir == 2)
                                {
                                    int PoseID = CellTypePose["ST1_L0"];
                                    //tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());                                          //첫번째 경유점
                                    tempRobotPoseArr.Add((RobotPoseData)RDP_Joint[PoseID].Clone());                                         //두번째 경유점
                                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], RDP_TCP[8]));     //첫번째 터치위치
                                }

                                else if (dir == 3)
                                {
                                    int PoseID = CellTypePose["ST1_L0"];
                                    // tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());                                          //첫번째 경유점

                                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], RDP_TCP[16]));     //첫번째 터치위치
                                }

                                //로봇 연속이동 실행
                                if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                                {
                                    MainLog_Add("0번 터치점 위치이동 시작.");
                                    TouchSensingSubSeq = "0번 터치점 위치이동 완료 대기";
                                }
                                else
                                {
                                    MainLog_Add("0번 터치점 위치이동 실패.");
                                    TouchSensingSubSeq = "터치시퀀스 실패";
                                }

                                break;

                            case "0번 터치점 위치이동 완료 대기":
                                if (RobotCommclass.RobotControlThreadSeq == 311)
                                {//연속이동 시퀀스 성공
                                    RobotCommclass.RobotControlThreadSeq = 15;
                                    MainLog_Add("0번 터치점 위치이동 완료.");
                                    TouchSensingSubSeq = "0번위치 터치센싱 시작";
                                }

                                break;

                            case "0번위치 터치센싱 시작":
                                TempTouchDataArr.Clear();

                                //터치경로 저장
                                //터치경로 저장
                                if (dir == 1)
                                {//수직
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, -1, 0, 10, 20, 1, 0, 1, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[2]에 저장

                                }
                                else if (dir == 2)
                                {//수평
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 10, 20, 1, 0, 0, 1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                                }
                                else if (dir == 3)
                                {
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 10, 20, 1, 0, 0, -1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                                }

                                //로봇 연속터치시퀀스 실행
                                if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                                {
                                    MainLog_Add("0번 위치 터치센싱 시작.");
                                    TouchSensingSubSeq = "0번위치 터치센싱 완료 대기";
                                }
                                else
                                {
                                    MainLog_Add("0번 위치 터치센싱 시작 실패.");
                                    TouchSensingSubSeq = "터치시퀀스 실패";
                                }
                                break;

                            case "0번위치 터치센싱 완료 대기":

                                if (RobotCommclass.RobotControlThreadSeq == 280)
                                {//연속터치 시퀀스 성공
                                    RobotCommclass.RobotControlThreadSeq = 15;
                                    MainLog_Add("0번 위치 터치센싱 완료.");

                                    //0번 계산점 계산
                                    tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                                    tempRobotPose.f1 = tempRobotPose.f1 + 10;
                                    AutoWeld_WedlPoint_Left[0] = (RobotPoseData)tempRobotPose.Clone();

                                    TouchSensingSubSeq = "1번 터치점 위치이동 시작";
                                }

                                break;
                            case "1번 터치점 위치이동 시작":
                                //이동경로 초기화
                                tempRobotPoseArr.Clear();

                                //이동경로 저장
                                if (dir == 1)
                                {//수직
                                    int PoseID = CellTypePose["ST1_R0"];//21
                                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], RDP_TCP[14]));
                                }
                                else if (dir == 2)
                                {//수평
                                    int PoseID = CellTypePose["ST1_R0"];
                                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], RDP_TCP[10]));
                                }
                                else if (dir == 3)
                                {//위보기
                                    int PoseID = CellTypePose["ST1_R0"];
                                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], RDP_TCP[16]));
                                }


                                //로봇 연속이동 실행
                                if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                                {
                                    MainLog_Add("1번 터치점 위치이동 시작.");
                                    TouchSensingSubSeq = "1번 터치점 위치이동 완료 대기";

                                }
                                else
                                {
                                    MainLog_Add("1번 터치점 위치이동 실패.");
                                    TouchSensingSubSeq = "터치시퀀스 실패";

                                }


                                break;
                            case "1번 터치점 위치이동 완료 대기":

                                if (RobotCommclass.RobotControlThreadSeq == 311)
                                {//연속이동 시퀀스 성공
                                    RobotCommclass.RobotControlThreadSeq = 15;
                                    MainLog_Add("1번 터치점 위치이동 완료.");
                                    TouchSensingSubSeq = "1번위치 터치센싱 시작";
                                }

                                break;
                            case "1번위치 터치센싱 시작":
                                TempTouchDataArr.Clear();

                                //터치경로 저장
                                if (dir == 1)
                                {//수직
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, -1, 0, 10, 20, 1, 0, 1, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장

                                }
                                else if (dir == 2)
                                {//수평
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 10, 20, 1, 0, 0, 1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                                }
                                else if (dir == 3)
                                {
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 10, 20, 1, 0, 0, -1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                                }

                                //로봇 연속터치시퀀스 실행
                                if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                                {
                                    MainLog_Add("1번 위치 터치센싱 시작.");
                                    TouchSensingSubSeq = "1번위치 터치센싱 완료 대기";
                                }
                                else
                                {
                                    MainLog_Add("1번 위치 터치센싱 시작 실패.");
                                    TouchSensingSubSeq = "터치시퀀스 실패";
                                }


                                break;
                            case "1번위치 터치센싱 완료 대기":

                                if (RobotCommclass.RobotControlThreadSeq == 280)
                                {//연속터치 시퀀스 성공
                                    RobotCommclass.RobotControlThreadSeq = 15;
                                    MainLog_Add("1번 위치 터치센싱 완료.");

                                    //1번 계산점 계산

                                    //오른쪽
                                    tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                                    tempRobotPose.f1 = tempRobotPose.f1 + 10;
                                    AutoWeld_WedlPoint_Right[0] = (RobotPoseData)tempRobotPose.Clone();

                                    TouchSensingSubSeq = "종료위치 이동 시작";
                                }

                                break;
                            case "종료위치 이동 시작":
                                //이동경로 초기화
                                tempRobotPoseArr.Clear();


                                tempRobotPoseArr.Add((RobotPoseData)RDP_TCP_B.Clone());

                                //로봇 연속이동 실행
                                if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                                {
                                    MainLog_Add("로봇 터치종료위치로 이동 시작");
                                    TouchSensingSubSeq = "종료위치 이동 완료 대기";
                                }
                                else
                                {
                                    MainLog_Add("로봇 터치종료위치로 이동 실패.");
                                    TouchSensingSubSeq = "터치시퀀스 실패";
                                }

                                break;
                            case "종료위치 이동 완료 대기":

                                if (RobotCommclass.RobotControlThreadSeq == 311)
                                {//연속이동 시퀀스 성공
                                    RobotCommclass.RobotControlThreadSeq = 15;
                                    if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                                    TouchSensingSubSeq = "터치시퀀스 성공";
                                }

                                break;
                            case "터치시퀀스 성공":


                                break;
                            case "터치시퀀스 실패":


                                break;

                            default:
                                break;
                        }

                        */
        }
        void TouchSeq()
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            double tempd1, tempd2;

            /*
            switch (TouchSensingSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    MainLog_Add("수직 칼라플레이트 시작.");
                    TouchSensingSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":

 
                    AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                    AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                    AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                    AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                    AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                    AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                    AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                    AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                    AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                    AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                    TouchSensingSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose1.Clone());

                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], RDP_TCP[15]));     //첫번째 터치위치


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장

                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 10, 20, 1, 0, 0, -1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                        tempRobotPose.f1 = tempRobotPose.f1 + 10;
                        AutoWeld_WedlPoint_Right[0] = (RobotPoseData)tempRobotPose.Clone();

                        TouchSensingSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장

                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], RDP_TCP[16]));



                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "1번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 10, 20, 1, 0, 0, -1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장


                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산

                        //오른쪽
                        tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                        tempRobotPose.f1 = tempRobotPose.f1 + 10;
                        AutoWeld_WedlPoint_Right[1] = (RobotPoseData)tempRobotPose.Clone();

                        TouchSensingSubSeq = "2번 터치점 위치이동 시작";
                    }

                    break;

                case "2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    tempRobotPoseArr.Add(new RobotPoseData(2,100, AutoWeld_TSPoint_Right_TCPPose[1].f1, AutoWeld_TSPoint_Right_TCPPose[2].f2, AutoWeld_TSPoint_Right_TCPPose[1].f3, AutoWeld_TSPoint_Right_TCPPose[1].f4, AutoWeld_TSPoint_Right_TCPPose[1].f5, AutoWeld_TSPoint_Right_TCPPose[1].f6));
                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RDP_TCP[17]));



                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "2번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "2번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;
                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, -1, 0, 10, 20, 1, 0, 1, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장


                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");

                        //1번 계산점 계산

                        //오른쪽
                        tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                        tempRobotPose.f1 = tempRobotPose.f1 + 10;
                        AutoWeld_WedlPoint_Right[2] = (RobotPoseData)tempRobotPose.Clone();

                        TouchSensingSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2].f1 , AutoWeld_TSPoint_Right_TCPPose[2].f2, AutoWeld_TSPoint_Right_TCPPose[3].f3, AutoWeld_WedlPoint_Right[2].f4, AutoWeld_WedlPoint_Right[2].f5, AutoWeld_WedlPoint_Right[2].f6));
                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[3], RDP_TCP[17]));



                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "3번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;
                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 10, 20, 1, 0, 0, 1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장


                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //1번 계산점 계산

                        //오른쪽
                        tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                        tempRobotPose.f1 = tempRobotPose.f1 + 10;
                        AutoWeld_WedlPoint_Right[3] = (RobotPoseData)tempRobotPose.Clone();

                        TouchSensingSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장

                    tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[4], RDP_TCP[17]));



                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "4번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 10, 20, 1, 0, 0, 1));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장


                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //1번 계산점 계산

                        //오른쪽
                        tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                        tempRobotPose.f1 = tempRobotPose.f1 + 10;
                        AutoWeld_WedlPoint_Right[4] = (RobotPoseData)tempRobotPose.Clone();

                        TouchSensingSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());

                    tempRobotPoseArr.Add((RobotPoseData)Robot_BACK.Clone());

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        TouchSensingSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add(" 터치센싱 완료.");
                        TouchSensingSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
*/

        }


    }
}
