﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBlockWeldingRobot
{
    class WeldStartCondition : ICloneable
    {
        public double GasPreTime = 0;
        public double WeldStartTime = 0;
        public double WeldStartVol = 0;
        public double WeldStartAmp = 0;
        List<RobotPoseData> StartPosition = new List<RobotPoseData>();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldStartCondition()
        {

        }
        /// <summary>
        /// 초기가스시간, 초기아크시간, 초기아크전압, 초기아크전류 설정해주는 생성자
        /// </summary>
        /// <param name="gas">초기가스시간</param>
        /// <param name="startt">초기아크시간</param>
        /// <param name="startv">초기아크전압</param>
        /// <param name="starta">초기아크전류</param>
        public WeldStartCondition(double gas, double startt, double startv, double starta)
        {
            GasPreTime = gas;
            WeldStartTime = startt;
            WeldStartVol = startv;
            WeldStartAmp = starta;
            StartPosition = new List<RobotPoseData>();
        }


        /// <summary>
        /// 시작경로 리스트에 경로 추가하는 함수
        /// </summary>
        /// <param name="RobotPose">추가할 로봇 포즈</param>
        public void AddStartPosition(RobotPoseData RobotPose)
        {
            StartPosition.Add((RobotPoseData)RobotPose.Clone());
        }

        /// <summary>
        /// 시작경로 리스트에서 index번째 객체 복사해오는 함수
        /// </summary>
        /// <param name="index">복사해올 객체 인덱스</param>
        /// <returns>인덱스가 유효하면 로봇포즈 복사본 리턴, 유효하지 않으면 NULL 리턴</returns>
        public RobotPoseData GetStartPosition(int index)
        {
            if ((index >= 0) && (index < StartPosition.Count))
            {
                return (RobotPoseData)(StartPosition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 시작경로 리스트 개수 반환
        /// </summary>
        /// <returns>시작경로 리스트 개수</returns>
        public int GetStartPositionCount()
        {
            return StartPosition.Count;
        }

        /// <summary>
        /// 시작경로 리스트 초기화하는 함수
        /// </summary>
        public void ClearStartPosition()
        {
            StartPosition = new List<RobotPoseData>();
        }

        public object Clone()
        {
            WeldStartCondition tempdata = new WeldStartCondition();

            tempdata.GasPreTime = this.GasPreTime;
            tempdata.WeldStartTime = this.WeldStartTime;
            tempdata.WeldStartVol = this.WeldStartVol;
            tempdata.WeldStartAmp = this.WeldStartAmp;

            for (int i = 0; i < this.StartPosition.Count; i++)
            {
                tempdata.StartPosition.Add(this.StartPosition[i]);
            }

            return tempdata;
        }
    }

    class WeldMainCondition : ICloneable
    {
        public int PathType = 1; //1:선형 2:원호
        RobotPoseData PathStartPosition = new RobotPoseData();
        RobotPoseData PathMidPosition = new RobotPoseData();
        RobotPoseData PathEndPosition = new RobotPoseData();

        public double WelVol = 0;
        public double WeldAmp = 0;
        public double WeldSpd = 0;

        public int Weaving = 0; //0:위빙안함 1:지그재그 2:사인파
        public double WeavHz = 0;
        public double WeavLength = 0;
        public double WeavLeftStopTime = 0;
        public double WeavRightStopTime = 0;

        public int ArcSen = 0; //0:아크센싱안함 1:좌우센싱만함 2:상하센싱만함 3:둘다함
        public double ArcSenTimeShift = 0;
        public double ArcSenHFactor = 0;
        public double ArcSenVFactor = 0;
        public double ArcSenHMaxdL = 0;
        public double ArcSenVMaxdL = 0;
        public double ArcSenHOncedL = 0;
        public double ArcSenVOncedL = 0;
        public double ArcSenWeightedFactorRight = 0;
        public double ArcSenWeightedFactorLeft = 0;


        /// <summary>
        /// 로봇 모션 시작점 지정하는 함수
        /// </summary>
        /// <param name="temppose">시작점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetStartPose(RobotPoseData temppose) { PathStartPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 중간점 지정하는 함수
        /// </summary>
        /// <param name="temppose">중간점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetMidPose(RobotPoseData temppose) { PathMidPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 종료점 지정하는 함수
        /// </summary>
        /// <param name="temppose">종료점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetEndPose(RobotPoseData temppose) { PathEndPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 시작포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 시작포즈객체 복사본</returns>
        public RobotPoseData GetStartPose() { return (RobotPoseData)(this.PathStartPosition.Clone()); }
        /// <summary>
        /// 로봇 모션 중간포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 중간포즈객체 복사본</returns>
        public RobotPoseData GetMidPose() { return (RobotPoseData)(this.PathMidPosition.Clone()); }
        /// <summary>
        /// 로봇 모션 종료포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 종료포즈객체 복사본</returns>
        public RobotPoseData GetEndPose() { return (RobotPoseData)(this.PathEndPosition.Clone()); }

        /// <summary>
        /// 보간방식, 시작, 중간, 종료점 동시에 설정하는 함수
        /// </summary>
        /// <param name="type">보간방식 1:선형, 2:원호</param>
        /// <param name="Start">시작점</param>
        /// <param name="Mid">중간점</param>
        /// <param name="End">종료점</param>
        public void SetPath(int type, RobotPoseData Start, RobotPoseData Mid, RobotPoseData End)
        {
            PathType = type;
            SetStartPose(Start);
            SetMidPose(Mid);
            SetEndPose(End);
        }


        /// <summary>
        /// 보간방식, 전압, 전류, 속도 동시에 설정하는 함수
        /// </summary>
        /// <param name="type">보간방식 1:선형, 2:원호</param>
        /// <param name="vol">용접전압</param>
        /// <param name="amp">용접전류</param>
        /// <param name="speed">속도</param>
        public void WeldSetting(int type, double vol, double amp, double speed)
        {
            PathType = type;
            WelVol = vol;
            WeldAmp = amp;
            WeldSpd = speed;
        }

        /// <summary>
        /// 위빙관련 데이터 동시에 설정하는 함수
        /// </summary>
        /// <param name="onoff">위빙여부, 0:위빙안함, 1:지그재그위빙, 2:사인파위빙</param>
        /// <param name="Hz">위빙 주파수</param>
        /// <param name="Length">위빙 폭</param>
        /// <param name="LeftStopTime">좌멈춤시간</param>
        /// <param name="RightStopTime">우멈춤시간</param>
        public void WeavingSetting(int onoff, double Hz, double Length, double LeftStopTime, double RightStopTime)
        {
            Weaving = onoff;
            WeavHz = Hz;
            WeavLength = Length;
            WeavLeftStopTime = LeftStopTime;
            WeavRightStopTime = RightStopTime;
        }

        /// <summary>
        /// 아크센싱 관련 데이터 동시에 설정하는 함수
        /// </summary>
        /// <param name="onoff">0:아크센싱안함 1:좌우센싱만함 2:상하센싱만함 3:좌우,상하 전부함</param>
        /// <param name="TimeShift">센서 지연시간</param>
        /// <param name="HFactor">좌우센싱계수</param>
        /// <param name="VFactor">상하센싱계수</param>
        /// <param name="HMaxdL">좌우 최대보정량 한계값</param>
        /// <param name="VMaxdL">상하 최대보정량 한계값</param>
        /// <param name="HOncedL">좌우 1회보정량 한계값</param>
        /// <param name="VOncedL">상하 1회보정량 한계값</param>
        /// <param name="WeightedFactorRight">우외빙 센서값 가중치</param>
        /// <param name="WeightedFactorLeft">좌위빙 센서값 가중치</param>
        public void ArcSenSetting(int onoff, double TimeShift, double HFactor, double VFactor, double HMaxdL, double VMaxdL, double HOncedL, double VOncedL, double WeightedFactorRight, double WeightedFactorLeft)
        {
            ArcSen = onoff;
            ArcSenTimeShift = TimeShift;
            ArcSenHFactor = HFactor;
            ArcSenVFactor = VFactor;
            ArcSenHMaxdL = HMaxdL;
            ArcSenVMaxdL = VMaxdL;
            ArcSenHOncedL = HOncedL;
            ArcSenVOncedL = VOncedL;
            ArcSenWeightedFactorRight = WeightedFactorRight;
            ArcSenWeightedFactorLeft = WeightedFactorLeft;
        }
        public object Clone()
        {
            WeldMainCondition tempclone = new WeldMainCondition();

            tempclone.PathStartPosition = (RobotPoseData)(this.PathStartPosition.Clone());
            tempclone.PathMidPosition = (RobotPoseData)(this.PathMidPosition.Clone());
            tempclone.PathEndPosition = (RobotPoseData)(this.PathEndPosition.Clone());

            tempclone.PathType = this.PathType;
            tempclone.WelVol = this.WelVol;
            tempclone.WeldAmp = this.WeldAmp;
            tempclone.WeldSpd = this.WeldSpd;

            tempclone.Weaving = this.Weaving;
            tempclone.WeavHz = this.WeavHz;
            tempclone.WeavLength = this.WeavLength;
            tempclone.WeavLeftStopTime = this.WeavLeftStopTime;
            tempclone.WeavRightStopTime = this.WeavRightStopTime;

            tempclone.ArcSen = this.ArcSen;
            tempclone.ArcSenTimeShift = this.ArcSenTimeShift;
            tempclone.ArcSenHFactor = this.ArcSenHFactor;
            tempclone.ArcSenVFactor = this.ArcSenVFactor;
            tempclone.ArcSenHMaxdL = this.ArcSenHMaxdL;
            tempclone.ArcSenVMaxdL = this.ArcSenVMaxdL;
            tempclone.ArcSenHOncedL = this.ArcSenHOncedL;
            tempclone.ArcSenVOncedL = this.ArcSenVOncedL;
            tempclone.ArcSenWeightedFactorRight = this.ArcSenWeightedFactorRight;
            tempclone.ArcSenWeightedFactorLeft = this.ArcSenWeightedFactorLeft;

            return tempclone;
        }
    }

    class WeldEndCondition : ICloneable
    {
        public double GasPostTime = 0;
        public double WeldEndTime = 0;
        public double WeldEndVol = 0;
        public double WeldEndAmp = 0;
        public double WeldEndLength = 0;
        List<RobotPoseData> EndPosition = new List<RobotPoseData>();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldEndCondition()
        {

        }

        /// <summary>
        /// 종료 아크조건 설정해주는 생성자
        /// </summary>
        /// <param name="gas">아크 종료후 후기가스시간</param>
        /// <param name="endt">크레이터 아크시간</param>
        /// <param name="endv">크레이터 아크전압</param>
        /// <param name="enda">크레이터 아크전류</param>
        /// <param name="endl">아크 종료후 후진거리</param>
        public WeldEndCondition(double gas, double endt, double endv, double enda, double endl)
        {
            GasPostTime = gas;
            WeldEndTime = endt;
            WeldEndVol = endv;
            WeldEndAmp = enda;
            WeldEndLength = endl;
            EndPosition = new List<RobotPoseData>();
        }



        /// <summary>
        /// 종료경로 리스트에 경로 추가하는 함수
        /// </summary>
        /// <param name="RobotPose">추가할 로봇 포즈</param>
        public void AddEndPosition(RobotPoseData RobotPose)
        {
            EndPosition.Add((RobotPoseData)RobotPose.Clone());
        }

        /// <summary>
        /// 종료경로 리스트에서 index번째 객체 복사해오는 함수
        /// </summary>
        /// <param name="index">복사해올 객체 인덱스</param>
        /// <returns>인덱스가 유효하면 로봇포즈 복사본 리턴, 유효하지 않으면 NULL 리턴</returns>
        public RobotPoseData GetEndPosition(int index)
        {
            if ((index >= 0) && (index < EndPosition.Count))
            {
                return (RobotPoseData)(EndPosition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 종료경로 리스트 개수 반환
        /// </summary>
        /// <returns>종료경로 리스트 개수</returns>
        public int GetEndPositionCount()
        {
            return EndPosition.Count;
        }

        /// <summary>
        /// 종료경로 리스트 초기화하는 함수
        /// </summary>
        public void ClearEndPosition()
        {
            EndPosition = new List<RobotPoseData>();
        }


        public object Clone()
        {
            WeldEndCondition tempdata = new WeldEndCondition();

            tempdata.GasPostTime = this.GasPostTime;
            tempdata.WeldEndTime = this.WeldEndTime;
            tempdata.WeldEndVol = this.WeldEndVol;
            tempdata.WeldEndAmp = this.WeldEndAmp;
            tempdata.WeldEndLength = this.WeldEndLength;

            for (int i = 0; i < this.EndPosition.Count; i++)
            {
                tempdata.EndPosition.Add(this.EndPosition[i]);
            }

            return tempdata;
        }

    }

    class WeldInformation : ICloneable
    {
        public bool ArcOnFlag; //용접을 할지 모션만 할지 선택
        public bool ContinueFlag = true; //용접 종료 후 멈추고자 할때 false 지정
        public bool MultipathFlag = false; // 해당 용접이 다층용접(초층제외)일경우 true 지정. 슬래그 털기 설정이 되어 있는 경우 이게 트루이면 용접 진행 안하고 대기함
        public int MultipathNumber = 1; // 다층용접인 경우 몇번째 용접인지 입력. 초층=1.
        public double OffsetX = 0;  //다층용접일 때 초층대비 쉬프트량 입력. 초층 아크센싱 후 다층용접 할 때 초층대비 경로보정을 위해
        public double OffsetY = 0;  //다층용접일 때 초층대비 쉬프트량 입력. 초층 아크센싱 후 다층용접 할 때 초층대비 경로보정을 위해
        public double OffsetZ = 0;  //다층용접일 때 초층대비 쉬프트량 입력. 초층 아크센싱 후 다층용접 할 때 초층대비 경로보정을 위해
        public double OffsetWorkAngle = 0;  //다층용접일 때 초층대비 쉬프트량 입력. 초층 아크센싱 후 다층용접 할 때 초층대비 경로보정을 위해
        public double OffsetTravelAngle = 0;  //다층용접일 때 초층대비 쉬프트량 입력. 초층 아크센싱 후 다층용접 할 때 초층대비 경로보정을 위해

        public WeldStartCondition InitCondition = new WeldStartCondition();
        List<WeldMainCondition> MainCondition = new List<WeldMainCondition>();
        public WeldEndCondition EndCondition = new WeldEndCondition();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldInformation()
        {

        }

        /// <summary>
        /// 메인 용접정보 리스트에 객체 추가하는 함수
        /// </summary>
        /// <param name="tempWMC">메인컨디션 객체</param>
        public void AddMainCondition(WeldMainCondition tempWMC)
        {
            MainCondition.Add((WeldMainCondition)(tempWMC.Clone()));
        }

        /// <summary>
        /// 메인컨디션 리스트에서 index번째 객체 반환(복사본으로)
        /// </summary>
        /// <param name="index"></param>
        /// <returns>해당 인덱스번째 객체가 있으면 객체 복사본 반환. 그렇지 않으면 Null 반환</returns>
        public WeldMainCondition GetMainCondition(int index)
        {
            if ((index >= 0) && (index < MainCondition.Count))
            {
                return (WeldMainCondition)(MainCondition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 메인컨디션리스트의 객체 개수 반환
        /// </summary>
        /// <returns>리스트 객체 개수</returns>
        public int GetMainConditionCount()
        {
            return MainCondition.Count;
        }


        public void ClearMainCondition()
        {
            MainCondition = new List<WeldMainCondition>();
        }


        public object Clone()
        {
            WeldInformation tempclone = new WeldInformation();

            tempclone.ArcOnFlag = this.ArcOnFlag;
            tempclone.ContinueFlag = this.ContinueFlag;
            tempclone.MultipathFlag = this.MultipathFlag;
            tempclone.MultipathNumber = this.MultipathNumber;
            tempclone.OffsetX = this.OffsetX;
            tempclone.OffsetY = this.OffsetY;
            tempclone.OffsetZ = this.OffsetZ;
            tempclone.OffsetWorkAngle = this.OffsetWorkAngle;
            tempclone.OffsetTravelAngle = this.OffsetTravelAngle;

            tempclone.InitCondition = (WeldStartCondition)this.InitCondition.Clone();
            tempclone.EndCondition = (WeldEndCondition)this.EndCondition.Clone();

            tempclone.MainCondition = new List<WeldMainCondition>();
            for (int i = 0; i < this.MainCondition.Count; i++)
            {
                tempclone.MainCondition.Add((WeldMainCondition)this.MainCondition[i].Clone());
            }

            return tempclone;
        }



        public WeldInformation ReverseInfo()
        {
            WeldInformation ResultInfo = (WeldInformation)this.Clone();

            //시작경로,종료경로 뒤집어 넣기
            ResultInfo.InitCondition.ClearStartPosition();
            int endposecount = this.EndCondition.GetEndPositionCount();
            for (int i = endposecount - 1; i >= 0; i--)
            {
                RobotPoseData temppose = this.EndCondition.GetEndPosition(i);
                if ((temppose.PoseType == 3) || (temppose.PoseType == 4)) continue;
                ResultInfo.InitCondition.AddStartPosition(temppose);
            }

            ResultInfo.EndCondition.ClearEndPosition();
            ResultInfo.EndCondition.AddEndPosition(new RobotPoseData(3, 50, -1, 0, 0, 0, 0, 0));
            int initposecount = this.InitCondition.GetStartPositionCount();
            for (int i = initposecount - 1; i >= 0; i--)
            {
                RobotPoseData temppose = this.InitCondition.GetStartPosition(i);
                if ((temppose.PoseType == 3) || (temppose.PoseType == 4)) continue;
                ResultInfo.EndCondition.AddEndPosition(temppose);
            }

            //메인경로 시작점 종료점 뒤바꿈
            int mainweldcount = this.MainCondition.Count;
            for (int i = 0; i < mainweldcount; i++)
            {
                ResultInfo.MainCondition[i].SetStartPose(this.MainCondition[i].GetEndPose());
                ResultInfo.MainCondition[i].SetEndPose(this.MainCondition[i].GetStartPose());
            }
            ResultInfo.MainCondition.Reverse();

            return ResultInfo;
        }

        //오프셋 적용하는 함수
        public void ApplyOffset(double OffsetStart, double OffsetEnd, double OffsetX, double OffsetY, double OffsetZ, double OffsetWorkAngle, double OffsetTravelAngle)
        {
            HCRRobotCommunication calcRobotFuc = new HCRRobotCommunication();

            //용접경로가 라인 몇개로 구성되있는지 체크
            int count = this.GetMainConditionCount();

            //첫번째라인 시작점과 마지막라인 종료점으로 대략적인 용접방향 단위벡터 계산. 수평용접인지 수직용접인지 판단하기 위해
            RobotPoseData SPose = this.GetMainCondition(0).GetStartPose();
            RobotPoseData EPose = this.GetMainCondition(count - 1).GetEndPose();
            double Vx, Vy, Vz, length;

            calcRobotFuc.RobotStartEndToDirCal(SPose, EPose, out Vx, out Vy, out Vz, out length);


            //첫번째라인 시작점 토치방향 단위벡터 계산
            double ToolX, ToolY, ToolZ;
            calcRobotFuc.RobotPoseToTooldirCal(SPose, out ToolX, out ToolY, out ToolZ);


            //용접방향, 토치자세 등을 따져 바닥쪽이 좌방향인지 우방향인지 판단하는 부분. FloorDir에 바닥이 왼쪽이면 1 오른쪽이면 2 넣음. 칼라플레이트는 일단 고려 안함
            int FloorDir = 0;
            if (Math.Abs(Vy) > Math.Abs(Vz))
            {//수평용접
                if (Vy > 0)
                {//진행방향 왼쪽
                    FloorDir = 1;
                }
                else
                {//진행방향 오른쪽
                    FloorDir = 2;
                }
            }
            else
            {//수직용접
                if (ToolY > 0)
                {//왼쪽 수직용접
                    FloorDir = 1;
                }
                else
                {//오른쪽 수직용접
                    FloorDir = 2;
                }
            }

            //메인용접라인 리스트에 순서대로 오프셋 적용
            for (int i = 0; i < count; i++)
            {
                //현재 용접라인 방향벡터와 다음 용접라인 방향벡터 구함. 현재 용접라인이 마지막라인인 경우 다음 용접라인 데이터를 현재 값으로 넣음
                WeldMainCondition maincon = this.GetMainCondition(i);
                WeldMainCondition maincon_Next;

                if ((i + 1) < count)
                {
                    maincon_Next = this.GetMainCondition(i + 1);
                }
                else
                {
                    maincon_Next = this.GetMainCondition(i);
                }
                RobotPoseData mainSPose = maincon.GetStartPose();
                RobotPoseData mainEPose = maincon.GetEndPose();
                RobotPoseData nextSPose = maincon_Next.GetStartPose();
                RobotPoseData nextEPose = maincon_Next.GetEndPose();

                //용접 진행방향벡터 계산 (작업각 회전축)
                double nowX, nowY, nowZ, nowL, nextX, nextY, nextZ, nextL;
                calcRobotFuc.RobotStartEndToDirCal(mainSPose, mainEPose, out nowX, out nowY, out nowZ, out nowL);
                calcRobotFuc.RobotStartEndToDirCal(nextSPose, nextEPose, out nextX, out nextY, out nextZ, out nextL);

                //툴 방향벡터 계산 (회전할 벡터)
                double nowToolX, nowToolY, nowToolZ, nextToolX, nextToolY, nextToolZ;
                calcRobotFuc.RobotPoseToTooldirCal(mainSPose, out nowToolX, out nowToolY, out nowToolZ);
                calcRobotFuc.RobotPoseToTooldirCal(nextSPose, out nextToolX, out nextToolY, out nextToolZ);

                //용접방향과 툴방향 외적 결과 (진행각 회전축)
                double nowCrossX, nowCrossY, nowCrossZ, nextCrossX, nextCrossY, nextCrossZ;
                calcRobotFuc.VectorCrossProduct(nowToolX, nowToolY, nowToolZ, nowX, nowY, nowZ, out nowCrossX, out nowCrossY, out nowCrossZ);
                calcRobotFuc.VectorCrossProduct(nextToolX, nextToolY, nextToolZ, nextX, nextY, nextZ, out nextCrossX, out nextCrossY, out nextCrossZ);

                //첫번째 라인인 경우 시작오프셋 적용
                if (i == 0)
                {
                    RobotPoseData temppose = MainCondition[i].GetStartPose();
                    temppose.f1 = (float)(temppose.f1 + nowX * OffsetStart);
                    temppose.f2 = (float)(temppose.f2 + nowY * OffsetStart);
                    temppose.f3 = (float)(temppose.f3 + nowZ * OffsetStart);
                    MainCondition[i].SetStartPose(temppose);
                }

                //마지막 라인인 경우 종료오프셋 적용
                if (i == count - 1)
                {
                    RobotPoseData temppose = MainCondition[i].GetEndPose();
                    temppose.f1 = (float)(temppose.f1 - nowX * OffsetEnd);
                    temppose.f2 = (float)(temppose.f2 - nowY * OffsetEnd);
                    temppose.f3 = (float)(temppose.f3 - nowZ * OffsetEnd);
                    MainCondition[i].SetEndPose(temppose);
                }

                //작업각, 진행각, XYZ오프셋 적용
                //xyz 오프셋 반영
                RobotPoseData tempposeS = MainCondition[i].GetStartPose();
                RobotPoseData tempposeM = MainCondition[i].GetMidPose();
                RobotPoseData tempposeE = MainCondition[i].GetEndPose();
                tempposeS.f1 = (float)(tempposeS.f1 + OffsetX);
                tempposeS.f2 = (float)(tempposeS.f2 + OffsetY);
                tempposeS.f3 = (float)(tempposeS.f3 + OffsetZ);
                tempposeM.f1 = (float)(tempposeM.f1 + OffsetX);
                tempposeM.f2 = (float)(tempposeM.f2 + OffsetY);
                tempposeM.f3 = (float)(tempposeM.f3 + OffsetZ);
                tempposeE.f1 = (float)(tempposeE.f1 + OffsetX);
                tempposeE.f2 = (float)(tempposeE.f2 + OffsetY);
                tempposeE.f3 = (float)(tempposeE.f3 + OffsetZ);

                //작업각 반영
                float ORx, ORy, ORz, RRx, RRy, RRz;

                ORx = tempposeS.f4;
                ORy = tempposeS.f5;
                ORz = tempposeS.f6;
                if (FloorDir == 1)
                {
                    calcRobotFuc.RobotBaseRotation(ORx, ORy, ORz, (float)nowX, (float)nowY, (float)nowZ, (float)OffsetWorkAngle, out RRx, out RRy, out RRz);
                }
                else
                {
                    calcRobotFuc.RobotBaseRotation(ORx, ORy, ORz, (float)nowX, (float)nowY, (float)nowZ, -(float)OffsetWorkAngle, out RRx, out RRy, out RRz);
                }
                tempposeS.f4 = RRx;
                tempposeS.f5 = RRy;
                tempposeS.f6 = RRz;

                ORx = tempposeE.f4;
                ORy = tempposeE.f5;
                ORz = tempposeE.f6;
                if (FloorDir == 1)
                {
                    calcRobotFuc.RobotBaseRotation(ORx, ORy, ORz, (float)nextX, (float)nextY, (float)nextZ, (float)OffsetWorkAngle, out RRx, out RRy, out RRz);
                }
                else
                {
                    calcRobotFuc.RobotBaseRotation(ORx, ORy, ORz, (float)nextX, (float)nextY, (float)nextZ, -(float)OffsetWorkAngle, out RRx, out RRy, out RRz);
                }
                tempposeE.f4 = RRx;
                tempposeE.f5 = RRy;
                tempposeE.f6 = RRz;


                //진행각 반영
                ORx = tempposeS.f4;
                ORy = tempposeS.f5;
                ORz = tempposeS.f6;
                calcRobotFuc.RobotBaseRotation(ORx, ORy, ORz, (float)nowCrossX, (float)nowCrossY, (float)nowCrossZ, (float)OffsetTravelAngle, out RRx, out RRy, out RRz);
                tempposeS.f4 = RRx;
                tempposeS.f5 = RRy;
                tempposeS.f6 = RRz;

                ORx = tempposeE.f4;
                ORy = tempposeE.f5;
                ORz = tempposeE.f6;
                calcRobotFuc.RobotBaseRotation(ORx, ORy, ORz, (float)nextCrossX, (float)nextCrossY, (float)nextCrossZ, (float)OffsetTravelAngle, out RRx, out RRy, out RRz);
                tempposeE.f4 = RRx;
                tempposeE.f5 = RRy;
                tempposeE.f6 = RRz;

                MainCondition[i].SetStartPose(tempposeS);
                MainCondition[i].SetMidPose(tempposeM);
                MainCondition[i].SetEndPose(tempposeE);

            }
        }


        //용접선 길이 리턴하는 함수 단위 밀리미터
        public double CalcWeldLength()
        {
            double length = 0;

            HCRRobotCommunication calcRobotFuc = new HCRRobotCommunication();

            //용접경로가 라인 몇개로 구성되있는지 체크
            int count = this.GetMainConditionCount();

            for (int i = 0; i < count; i++)
            {
                double Vx, Vy, Vz, SingleL;
                calcRobotFuc.RobotStartEndToDirCal(MainCondition[i].GetStartPose(), MainCondition[i].GetEndPose(), out Vx, out Vy, out Vz, out SingleL);
                length = length + SingleL;
            }

                return length;
        }


        //추정 용접시간 리턴하는 함수. 단위 초
        public double CalcWeldTime()
        {
            double time = 0;

            HCRRobotCommunication calcRobotFuc = new HCRRobotCommunication();

            //용접경로가 라인 몇개로 구성되있는지 체크
            int count = this.GetMainConditionCount();

            for (int i = 0; i < count; i++)
            {
                double Vx, Vy, Vz, SingleL;
                calcRobotFuc.RobotStartEndToDirCal(MainCondition[i].GetStartPose(), MainCondition[i].GetEndPose(), out Vx, out Vy, out Vz, out SingleL);

                double Speed = (MainCondition[i].WeldSpd / ((MainCondition[i].WeavLeftStopTime + MainCondition[i].WeavRightStopTime) * MainCondition[i].WeavHz + 1))/6;

                time = time + SingleL / Speed;

            }

            return time;
        }


    }

    class TouchSensingData : ICloneable
    {
        //터치센싱 진입데이터
        public int In_coord; //방향벡터의 기준좌표계 1:베이스, 2:툴,
        public float In_X; //방향벡터 성분 중 x
        public float In_Y; //방향벡터 성분 중 y
        public float In_Z; //방향벡터 성분 중 z
        public float In_Length; //벡터 방향으로 진행하는 거리
        public float In_Speed; //진행 속도

        //터치센싱 완료 후 복귀데이터
        public int Out_coord; //방향벡터의 기준좌표계 1:베이스, 2:툴,
        public float Out_X; //방향벡터 성분 중 x
        public float Out_Y; //방향벡터 성분 중 y
        public float Out_Z; //방향벡터 성분 중 z
        public float Out_Length; //벡터 방향으로 진행하는 거리
        public float Out_Speed; //진행 속도

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public TouchSensingData()
        {

        }

        /// <summary>
        /// 터치관련 인자 바로 넣는 생성자
        /// </summary>
        /// <param name="iLength">서칭거리(mm)</param>
        /// <param name="iSpeed">서칭속도(mm/s)</param>
        /// <param name="iCoord">방향벡터 좌표계, 1:베이스좌표계, 2:툴좌표계</param>
        /// <param name="iX">방향벡터 X성분</param>
        /// <param name="iY">방향벡터 Y성분</param>
        /// <param name="iZ">방향벡터 Z성분</param>
        /// <param name="oLength">복귀거리(mm)</param>
        /// <param name="oSpeed">복귀속도(mm/s)</param>
        /// <param name="oCoord">방향벡터 좌표계, 1:베이스좌표계, 2:툴좌표계</param>
        /// <param name="oX">방향벡터 X성분</param>
        /// <param name="oY">방향벡터 Y성분</param>
        /// <param name="oZ">방향벡터 Z성분</param>
        public TouchSensingData(double iLength, double iSpeed, int iCoord, double iX, double iY, double iZ, double oLength, double oSpeed, int oCoord, double oX, double oY, double oZ)
        {
            In_Length = (float)iLength;
            In_Speed = (float)iSpeed;
            In_coord = iCoord;
            In_X = (float)iX;
            In_Y = (float)iY;
            In_Z = (float)iZ;

            Out_Length = (float)oLength;
            Out_Speed = (float)oSpeed;
            Out_coord = oCoord;
            Out_X = (float)oX;
            Out_Y = (float)oY;
            Out_Z = (float)oZ;
        }

        public object Clone()
        {
            TouchSensingData temp = new TouchSensingData();

            temp.In_coord = this.In_coord;
            temp.In_X = this.In_X;
            temp.In_Y = this.In_Y;
            temp.In_Z = this.In_Z;
            temp.In_Length = this.In_Length;
            temp.In_Speed = this.In_Speed;

            temp.Out_coord = this.Out_coord;
            temp.Out_X = this.Out_X;
            temp.Out_Y = this.Out_Y;
            temp.Out_Z = this.Out_Z;
            temp.Out_Length = this.Out_Length;
            temp.Out_Speed = this.Out_Speed;

            return temp;
        }


    }

    class WeldingCondition : ICloneable
    {
        public double Vol;
        public double Amp;
        public double Spd;
        public double Offset_WorkAngle;
        public double Offset_TravelAngle;
        public double Offset_X;
        public double Offset_Y;
        public double Offset_Z;
        public double WeavingHz;
        public double WeavingWidth;
        public double WeavingFloorStop;
        public double WeavingWallStop;
        public int ArcSen;
        public double BeadBias;


        public object Clone()
        {
            WeldingCondition temp = new WeldingCondition();

            temp.Vol = this.Vol;
            temp.Amp = this.Amp;
            temp.Spd = this.Spd;
            temp.Offset_WorkAngle = this.Offset_WorkAngle;
            temp.Offset_TravelAngle = this.Offset_TravelAngle;
            temp.Offset_X = this.Offset_X;
            temp.Offset_Y = this.Offset_Y;
            temp.Offset_Z = this.Offset_Z;
            temp.WeavingHz = this.WeavingHz;
            temp.WeavingWidth = this.WeavingWidth;
            temp.WeavingFloorStop = this.WeavingFloorStop;
            temp.WeavingWallStop = this.WeavingWallStop;
            temp.ArcSen = this.ArcSen;
            temp.BeadBias = this.BeadBias;

            return temp;
        }

    }


}
