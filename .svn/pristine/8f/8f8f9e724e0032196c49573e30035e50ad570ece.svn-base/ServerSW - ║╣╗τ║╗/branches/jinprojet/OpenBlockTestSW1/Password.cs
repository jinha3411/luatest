﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenBlockWeldingRobot
{
    public partial class Password : Form
    {
        public Password()
        {
            InitializeComponent();
        }

        //확인버튼 눌렀을 때 314를 입력했으면 ok반환 아니면 cancel반환
        private void button_OK_Click(object sender, EventArgs e)
        {
            if (textBox_Password.Text == "314")
            {
                MessageBox.Show("로그인 성공");
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("로그인 실패");
                this.DialogResult = DialogResult.Cancel;
            }
        }

        //취소버튼 눌렀을 때 cancel반환
        private void button_Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        //비밀번호 입력 박스에서 엔터 눌렀을 때 확인버튼 눌러줌
        private void textBox_Password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button_OK.PerformClick();
            }
        }




    }
}
