﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBlockWeldingRobot
{
    class SystemState
    {

        //서버 프로그램 관련 모니터링 값
        public byte SWState;                                                //서버 프로그램 상태 0:정상, 1:비정상
        public byte ControlState;                                           //서버 프로그램 제어권 상태 0:비어있음, 1:점유됨
        public byte[] ControlClientIP = new byte[4];                        //서버 제어권 점유중인 클라이언트 IP
        public ushort ControlClientPort;                                    //서버 제어권 점유중인 클라이언트 포트
        public string ControlClientID;                                      //서버 제어권 점유중인 클라이언트 ID
        public string ControlClientUserID;                                  //서버 제어권 점유중인 클라이언트에 접속한 유저 ID

        //작업시퀀스 상태
        public string MainSeqState;                                         //메인시퀸스 상태문자열
        public string AutoSeqState;                                         //자동작업시퀸스 상태문자열
        public string DTSeqState;                                           //직접교시시퀸스 상태문자열
        public string TouchSeqState;                                        //터치센싱시퀸스 상태문자열
        public string WeldSeqState;                                         //용접시퀸스 상태문자열
        public string ManualSeqState;                                       //수동조작시퀸스 상태문자열
        public string SettingSeqState;                                      //설정시퀸스 상태문자열
        public byte[] ServerWorkClientIP = new byte[4];                     //현재 작업지령 내린 클라이언트 IP
        public ushort ServerWorkClientPort;                                 //현재 작업지령 내린 클라이언트 포트
        public string ServerWorkClientID;                                   //현재 작업지령 내린 클라이언트 ID

        public string AutoWeldCellType;                                     //자동작업 셀타입 문자열
        public bool[] DTPointCompleteFlagLeft = new bool[33];               //왼쪽 교시점 저장완료 플래그
        public bool[] DTPointCompleteFlagRight = new bool[33];              //오른쪽 교시점 저장완료 플래그

        public double CellWeldProgress;                                     //자동용접 진행률
        public double ArcTimeTotal;                                         //자동용접 아크타임 추정시간(초)
        public double ArcTimeLeft;                                          //남은 아크타임 추정시간
        

        public SystemState()
        {

        }




    }
}
