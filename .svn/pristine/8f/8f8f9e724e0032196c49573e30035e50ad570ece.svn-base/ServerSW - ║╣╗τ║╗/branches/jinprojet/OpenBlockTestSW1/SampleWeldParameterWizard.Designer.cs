﻿namespace OpenBlockWeldingRobot
{
    partial class SampleWeldParameterWizard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SampleWeldParameterWizard));
            this.button_Cancel = new System.Windows.Forms.Button();
            this.button_OK = new System.Windows.Forms.Button();
            this.panel_Fillet2F = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label_ParaWizFillet2F = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel_Fillet3F_Left = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel_Fillet3F_Right = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button_Fillet2F_R1 = new System.Windows.Forms.Button();
            this.button_Fillet2F_R2 = new System.Windows.Forms.Button();
            this.button_Fillet2F_R0 = new System.Windows.Forms.Button();
            this.button_Fillet2F_L1 = new System.Windows.Forms.Button();
            this.button_Fillet2F_L2 = new System.Windows.Forms.Button();
            this.button_Fillet2F_L0 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button_Fillet3F_Right_U3 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Right_U1 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Right_U0 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Right_U2 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Right_B0 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Right_B1 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button_Fillet3F_Left_U3 = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.button_Fillet3F_Left_U1 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Left_U2 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Left_U0 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Left_B1 = new System.Windows.Forms.Button();
            this.button_Fillet3F_Left_B0 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel_Fillet2F.SuspendLayout();
            this.panel_Fillet3F_Left.SuspendLayout();
            this.panel_Fillet3F_Right.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Cancel
            // 
            this.button_Cancel.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_Cancel.Location = new System.Drawing.Point(388, 289);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(92, 34);
            this.button_Cancel.TabIndex = 5;
            this.button_Cancel.Text = "취소";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // button_OK
            // 
            this.button_OK.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_OK.Location = new System.Drawing.Point(268, 289);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(92, 34);
            this.button_OK.TabIndex = 4;
            this.button_OK.Text = "입력";
            this.button_OK.UseVisualStyleBackColor = true;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // panel_Fillet2F
            // 
            this.panel_Fillet2F.Controls.Add(this.pictureBox9);
            this.panel_Fillet2F.Controls.Add(this.pictureBox8);
            this.panel_Fillet2F.Controls.Add(this.label2);
            this.panel_Fillet2F.Controls.Add(this.label1);
            this.panel_Fillet2F.Controls.Add(this.button_Fillet2F_R1);
            this.panel_Fillet2F.Controls.Add(this.button_Fillet2F_R2);
            this.panel_Fillet2F.Controls.Add(this.button_Fillet2F_R0);
            this.panel_Fillet2F.Controls.Add(this.button_Fillet2F_L1);
            this.panel_Fillet2F.Controls.Add(this.button_Fillet2F_L2);
            this.panel_Fillet2F.Controls.Add(this.button_Fillet2F_L0);
            this.panel_Fillet2F.Controls.Add(this.pictureBox1);
            this.panel_Fillet2F.Controls.Add(this.label_ParaWizFillet2F);
            this.panel_Fillet2F.Location = new System.Drawing.Point(3, 3);
            this.panel_Fillet2F.Name = "panel_Fillet2F";
            this.panel_Fillet2F.Size = new System.Drawing.Size(479, 280);
            this.panel_Fillet2F.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "수평용접 오른쪽 토치방향 선택";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "수평용접 왼쪽 토치방향 선택";
            // 
            // label_ParaWizFillet2F
            // 
            this.label_ParaWizFillet2F.AutoSize = true;
            this.label_ParaWizFillet2F.Location = new System.Drawing.Point(9, 6);
            this.label_ParaWizFillet2F.Name = "label_ParaWizFillet2F";
            this.label_ParaWizFillet2F.Size = new System.Drawing.Size(44, 12);
            this.label_ParaWizFillet2F.TabIndex = 0;
            this.label_ParaWizFillet2F.Text = "Fillet2F";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Dir0_0.png");
            this.imageList1.Images.SetKeyName(1, "Dir0_1.png");
            this.imageList1.Images.SetKeyName(2, "Dir0_2.png");
            this.imageList1.Images.SetKeyName(3, "Dir1_0.png");
            this.imageList1.Images.SetKeyName(4, "Dir1_1.png");
            this.imageList1.Images.SetKeyName(5, "Dir1_2.png");
            this.imageList1.Images.SetKeyName(6, "Dir2_0.png");
            this.imageList1.Images.SetKeyName(7, "Dir2_1.png");
            this.imageList1.Images.SetKeyName(8, "Dir2_2.png");
            this.imageList1.Images.SetKeyName(9, "WeldLine0.png");
            this.imageList1.Images.SetKeyName(10, "WeldLine1.png");
            this.imageList1.Images.SetKeyName(11, "WeldLine2.png");
            // 
            // panel_Fillet3F_Left
            // 
            this.panel_Fillet3F_Left.Controls.Add(this.button_Fillet3F_Left_U3);
            this.panel_Fillet3F_Left.Controls.Add(this.pictureBox6);
            this.panel_Fillet3F_Left.Controls.Add(this.pictureBox7);
            this.panel_Fillet3F_Left.Controls.Add(this.label3);
            this.panel_Fillet3F_Left.Controls.Add(this.label4);
            this.panel_Fillet3F_Left.Controls.Add(this.button_Fillet3F_Left_U1);
            this.panel_Fillet3F_Left.Controls.Add(this.button_Fillet3F_Left_U2);
            this.panel_Fillet3F_Left.Controls.Add(this.button_Fillet3F_Left_U0);
            this.panel_Fillet3F_Left.Controls.Add(this.button_Fillet3F_Left_B1);
            this.panel_Fillet3F_Left.Controls.Add(this.button_Fillet3F_Left_B0);
            this.panel_Fillet3F_Left.Controls.Add(this.pictureBox2);
            this.panel_Fillet3F_Left.Controls.Add(this.label5);
            this.panel_Fillet3F_Left.Location = new System.Drawing.Point(3, 3);
            this.panel_Fillet3F_Left.Name = "panel_Fillet3F_Left";
            this.panel_Fillet3F_Left.Size = new System.Drawing.Size(479, 280);
            this.panel_Fillet3F_Left.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(146, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "왼쪽 수직용접 위쪽 토치방향 선택";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(146, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "왼쪽 수직용접 아래쪽 토치방향 선택";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Fillet3F.Left";
            // 
            // panel_Fillet3F_Right
            // 
            this.panel_Fillet3F_Right.Controls.Add(this.pictureBox5);
            this.panel_Fillet3F_Right.Controls.Add(this.pictureBox4);
            this.panel_Fillet3F_Right.Controls.Add(this.button_Fillet3F_Right_U3);
            this.panel_Fillet3F_Right.Controls.Add(this.label6);
            this.panel_Fillet3F_Right.Controls.Add(this.label7);
            this.panel_Fillet3F_Right.Controls.Add(this.button_Fillet3F_Right_U1);
            this.panel_Fillet3F_Right.Controls.Add(this.button_Fillet3F_Right_U0);
            this.panel_Fillet3F_Right.Controls.Add(this.button_Fillet3F_Right_U2);
            this.panel_Fillet3F_Right.Controls.Add(this.button_Fillet3F_Right_B0);
            this.panel_Fillet3F_Right.Controls.Add(this.button_Fillet3F_Right_B1);
            this.panel_Fillet3F_Right.Controls.Add(this.pictureBox3);
            this.panel_Fillet3F_Right.Controls.Add(this.label8);
            this.panel_Fillet3F_Right.Location = new System.Drawing.Point(3, 3);
            this.panel_Fillet3F_Right.Name = "panel_Fillet3F_Right";
            this.panel_Fillet3F_Right.Size = new System.Drawing.Size(479, 280);
            this.panel_Fillet3F_Right.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(116, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(189, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "왼쪽 수직용접 위쪽 토치방향 선택";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(106, 166);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "왼쪽 수직용접 아래쪽 토치방향 선택";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "Fillet3F.Right";
            // 
            // button_Fillet2F_R1
            // 
            this.button_Fillet2F_R1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_2;
            this.button_Fillet2F_R1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet2F_R1.Location = new System.Drawing.Point(313, 89);
            this.button_Fillet2F_R1.Name = "button_Fillet2F_R1";
            this.button_Fillet2F_R1.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet2F_R1.TabIndex = 7;
            this.button_Fillet2F_R1.UseVisualStyleBackColor = true;
            this.button_Fillet2F_R1.Click += new System.EventHandler(this.button_Fillet2F_R1_Click);
            // 
            // button_Fillet2F_R2
            // 
            this.button_Fillet2F_R2.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_1;
            this.button_Fillet2F_R2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet2F_R2.Location = new System.Drawing.Point(313, 37);
            this.button_Fillet2F_R2.Name = "button_Fillet2F_R2";
            this.button_Fillet2F_R2.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet2F_R2.TabIndex = 6;
            this.button_Fillet2F_R2.UseVisualStyleBackColor = true;
            this.button_Fillet2F_R2.Click += new System.EventHandler(this.button_Fillet2F_R2_Click);
            // 
            // button_Fillet2F_R0
            // 
            this.button_Fillet2F_R0.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_0;
            this.button_Fillet2F_R0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet2F_R0.Location = new System.Drawing.Point(313, 141);
            this.button_Fillet2F_R0.Name = "button_Fillet2F_R0";
            this.button_Fillet2F_R0.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet2F_R0.TabIndex = 5;
            this.button_Fillet2F_R0.UseVisualStyleBackColor = true;
            this.button_Fillet2F_R0.Click += new System.EventHandler(this.button_Fillet2F_R0_Click);
            // 
            // button_Fillet2F_L1
            // 
            this.button_Fillet2F_L1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_2;
            this.button_Fillet2F_L1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet2F_L1.Location = new System.Drawing.Point(89, 89);
            this.button_Fillet2F_L1.Name = "button_Fillet2F_L1";
            this.button_Fillet2F_L1.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet2F_L1.TabIndex = 4;
            this.button_Fillet2F_L1.UseVisualStyleBackColor = true;
            this.button_Fillet2F_L1.Click += new System.EventHandler(this.button_Fillet2F_L1_Click);
            // 
            // button_Fillet2F_L2
            // 
            this.button_Fillet2F_L2.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_1;
            this.button_Fillet2F_L2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet2F_L2.Location = new System.Drawing.Point(89, 37);
            this.button_Fillet2F_L2.Name = "button_Fillet2F_L2";
            this.button_Fillet2F_L2.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet2F_L2.TabIndex = 3;
            this.button_Fillet2F_L2.UseVisualStyleBackColor = true;
            this.button_Fillet2F_L2.Click += new System.EventHandler(this.button_Fillet2F_L2_Click);
            // 
            // button_Fillet2F_L0
            // 
            this.button_Fillet2F_L0.BackColor = System.Drawing.SystemColors.Control;
            this.button_Fillet2F_L0.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_0;
            this.button_Fillet2F_L0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet2F_L0.Location = new System.Drawing.Point(89, 141);
            this.button_Fillet2F_L0.Name = "button_Fillet2F_L0";
            this.button_Fillet2F_L0.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet2F_L0.TabIndex = 2;
            this.button_Fillet2F_L0.UseVisualStyleBackColor = true;
            this.button_Fillet2F_L0.Click += new System.EventHandler(this.button_Fillet2F_L0_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.WeldLine0;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(108, 233);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(239, 40);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_0;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(341, 193);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(45, 19);
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_0;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(341, 82);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(43, 19);
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // button_Fillet3F_Right_U3
            // 
            this.button_Fillet3F_Right_U3.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_3;
            this.button_Fillet3F_Right_U3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Right_U3.Location = new System.Drawing.Point(53, 69);
            this.button_Fillet3F_Right_U3.Name = "button_Fillet3F_Right_U3";
            this.button_Fillet3F_Right_U3.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Right_U3.TabIndex = 10;
            this.button_Fillet3F_Right_U3.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Right_U3.Click += new System.EventHandler(this.button_Fillet3F_Right_U3_Click);
            // 
            // button_Fillet3F_Right_U1
            // 
            this.button_Fillet3F_Right_U1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_2;
            this.button_Fillet3F_Right_U1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Right_U1.Location = new System.Drawing.Point(183, 69);
            this.button_Fillet3F_Right_U1.Name = "button_Fillet3F_Right_U1";
            this.button_Fillet3F_Right_U1.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Right_U1.TabIndex = 7;
            this.button_Fillet3F_Right_U1.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Right_U1.Click += new System.EventHandler(this.button_Fillet3F_Right_U1_Click);
            // 
            // button_Fillet3F_Right_U0
            // 
            this.button_Fillet3F_Right_U0.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_0;
            this.button_Fillet3F_Right_U0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Right_U0.Location = new System.Drawing.Point(248, 69);
            this.button_Fillet3F_Right_U0.Name = "button_Fillet3F_Right_U0";
            this.button_Fillet3F_Right_U0.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Right_U0.TabIndex = 6;
            this.button_Fillet3F_Right_U0.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Right_U0.Click += new System.EventHandler(this.button_Fillet3F_Right_U0_Click);
            // 
            // button_Fillet3F_Right_U2
            // 
            this.button_Fillet3F_Right_U2.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_1;
            this.button_Fillet3F_Right_U2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Right_U2.Location = new System.Drawing.Point(118, 69);
            this.button_Fillet3F_Right_U2.Name = "button_Fillet3F_Right_U2";
            this.button_Fillet3F_Right_U2.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Right_U2.TabIndex = 5;
            this.button_Fillet3F_Right_U2.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Right_U2.Click += new System.EventHandler(this.button_Fillet3F_Right_U2_Click);
            // 
            // button_Fillet3F_Right_B0
            // 
            this.button_Fillet3F_Right_B0.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_0;
            this.button_Fillet3F_Right_B0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Right_B0.Location = new System.Drawing.Point(248, 181);
            this.button_Fillet3F_Right_B0.Name = "button_Fillet3F_Right_B0";
            this.button_Fillet3F_Right_B0.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Right_B0.TabIndex = 4;
            this.button_Fillet3F_Right_B0.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Right_B0.Click += new System.EventHandler(this.button_Fillet3F_Right_B0_Click);
            // 
            // button_Fillet3F_Right_B1
            // 
            this.button_Fillet3F_Right_B1.BackColor = System.Drawing.SystemColors.Control;
            this.button_Fillet3F_Right_B1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir2_2;
            this.button_Fillet3F_Right_B1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Right_B1.Location = new System.Drawing.Point(183, 181);
            this.button_Fillet3F_Right_B1.Name = "button_Fillet3F_Right_B1";
            this.button_Fillet3F_Right_B1.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Right_B1.TabIndex = 2;
            this.button_Fillet3F_Right_B1.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Right_B1.Click += new System.EventHandler(this.button_Fillet3F_Right_B1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.WeldLine1;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(376, 86);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(41, 123);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // button_Fillet3F_Left_U3
            // 
            this.button_Fillet3F_Left_U3.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_3;
            this.button_Fillet3F_Left_U3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Left_U3.Location = new System.Drawing.Point(343, 69);
            this.button_Fillet3F_Left_U3.Name = "button_Fillet3F_Left_U3";
            this.button_Fillet3F_Left_U3.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Left_U3.TabIndex = 15;
            this.button_Fillet3F_Left_U3.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Left_U3.Click += new System.EventHandler(this.button_Fillet3F_Left_U3_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_0;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(89, 196);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(45, 19);
            this.pictureBox6.TabIndex = 14;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_0;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(89, 81);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(43, 19);
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            // 
            // button_Fillet3F_Left_U1
            // 
            this.button_Fillet3F_Left_U1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_2;
            this.button_Fillet3F_Left_U1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Left_U1.Location = new System.Drawing.Point(213, 69);
            this.button_Fillet3F_Left_U1.Name = "button_Fillet3F_Left_U1";
            this.button_Fillet3F_Left_U1.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Left_U1.TabIndex = 7;
            this.button_Fillet3F_Left_U1.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Left_U1.Click += new System.EventHandler(this.button_Fillet3F_Left_U1_Click);
            // 
            // button_Fillet3F_Left_U2
            // 
            this.button_Fillet3F_Left_U2.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_1;
            this.button_Fillet3F_Left_U2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Left_U2.Location = new System.Drawing.Point(278, 69);
            this.button_Fillet3F_Left_U2.Name = "button_Fillet3F_Left_U2";
            this.button_Fillet3F_Left_U2.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Left_U2.TabIndex = 6;
            this.button_Fillet3F_Left_U2.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Left_U2.Click += new System.EventHandler(this.button_Fillet3F_Left_U2_Click);
            // 
            // button_Fillet3F_Left_U0
            // 
            this.button_Fillet3F_Left_U0.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_0;
            this.button_Fillet3F_Left_U0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Left_U0.Location = new System.Drawing.Point(148, 69);
            this.button_Fillet3F_Left_U0.Name = "button_Fillet3F_Left_U0";
            this.button_Fillet3F_Left_U0.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Left_U0.TabIndex = 5;
            this.button_Fillet3F_Left_U0.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Left_U0.Click += new System.EventHandler(this.button_Fillet3F_Left_U0_Click);
            // 
            // button_Fillet3F_Left_B1
            // 
            this.button_Fillet3F_Left_B1.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_2;
            this.button_Fillet3F_Left_B1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Left_B1.Location = new System.Drawing.Point(213, 184);
            this.button_Fillet3F_Left_B1.Name = "button_Fillet3F_Left_B1";
            this.button_Fillet3F_Left_B1.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Left_B1.TabIndex = 4;
            this.button_Fillet3F_Left_B1.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Left_B1.Click += new System.EventHandler(this.button_Fillet3F_Left_B1_Click);
            // 
            // button_Fillet3F_Left_B0
            // 
            this.button_Fillet3F_Left_B0.BackColor = System.Drawing.SystemColors.Control;
            this.button_Fillet3F_Left_B0.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir1_0;
            this.button_Fillet3F_Left_B0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_Fillet3F_Left_B0.Location = new System.Drawing.Point(148, 184);
            this.button_Fillet3F_Left_B0.Name = "button_Fillet3F_Left_B0";
            this.button_Fillet3F_Left_B0.Size = new System.Drawing.Size(59, 46);
            this.button_Fillet3F_Left_B0.TabIndex = 2;
            this.button_Fillet3F_Left_B0.UseVisualStyleBackColor = true;
            this.button_Fillet3F_Left_B0.Click += new System.EventHandler(this.button_Fillet3F_Left_B0_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.WeldLine1;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(59, 86);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(41, 124);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_0;
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Location = new System.Drawing.Point(99, 199);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(31, 44);
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = global::OpenBlockWeldingRobot.Properties.Resources.Dir3_0;
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(326, 199);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(31, 44);
            this.pictureBox9.TabIndex = 11;
            this.pictureBox9.TabStop = false;
            // 
            // SampleWeldParameterWizard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 328);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.panel_Fillet2F);
            this.Controls.Add(this.panel_Fillet3F_Right);
            this.Controls.Add(this.panel_Fillet3F_Left);
            this.Name = "SampleWeldParameterWizard";
            this.Text = "SampleWeldParameterWizard";
            this.panel_Fillet2F.ResumeLayout(false);
            this.panel_Fillet2F.PerformLayout();
            this.panel_Fillet3F_Left.ResumeLayout(false);
            this.panel_Fillet3F_Left.PerformLayout();
            this.panel_Fillet3F_Right.ResumeLayout(false);
            this.panel_Fillet3F_Right.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.Panel panel_Fillet2F;
        private System.Windows.Forms.Label label_ParaWizFillet2F;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button_Fillet2F_L0;
        private System.Windows.Forms.Button button_Fillet2F_L1;
        private System.Windows.Forms.Button button_Fillet2F_L2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Fillet2F_R1;
        private System.Windows.Forms.Button button_Fillet2F_R2;
        private System.Windows.Forms.Button button_Fillet2F_R0;
        private System.Windows.Forms.Panel panel_Fillet3F_Left;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_Fillet3F_Left_U1;
        private System.Windows.Forms.Button button_Fillet3F_Left_U2;
        private System.Windows.Forms.Button button_Fillet3F_Left_U0;
        private System.Windows.Forms.Button button_Fillet3F_Left_B1;
        private System.Windows.Forms.Button button_Fillet3F_Left_B0;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel_Fillet3F_Right;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_Fillet3F_Right_U1;
        private System.Windows.Forms.Button button_Fillet3F_Right_U0;
        private System.Windows.Forms.Button button_Fillet3F_Right_U2;
        private System.Windows.Forms.Button button_Fillet3F_Right_B0;
        private System.Windows.Forms.Button button_Fillet3F_Right_B1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_Fillet3F_Right_U3;
        private System.Windows.Forms.Button button_Fillet3F_Left_U3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
    }
}