﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenBlockWeldingRobot
{
    public partial class SampleWeldParameterWizard : Form
    {
        public double[] para = new double[15] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


        public SampleWeldParameterWizard(string name)
        {
            InitializeComponent();


            switch(name)
            {
                case "Fillet2F":
                    panel_Fillet2F.BringToFront();

                    button_Fillet2F_L0.BackColor = Color.Chartreuse;
                    button_Fillet2F_R0.BackColor = Color.Chartreuse;
                    para[0] = 0;
                    para[1] = 0;
                    
                    break;
                case "Fillet3F.Left":
                    panel_Fillet3F_Left.BringToFront();

                    button_Fillet3F_Left_B0.BackColor = Color.Chartreuse;
                    button_Fillet3F_Left_U0.BackColor = Color.Chartreuse;
                    para[0] = 0;
                    para[1] = 0;

                    break;
                case "Fillet3F.Right":
                    panel_Fillet3F_Right.BringToFront();

                    button_Fillet3F_Right_B0.BackColor = Color.Chartreuse;
                    button_Fillet3F_Right_U0.BackColor = Color.Chartreuse;
                    para[0] = 0;
                    para[1] = 0;

                    break;
                default:
                    break;
            }


        }




        private void button_OK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }


        //Fillet2F 패널 버튼이벤트
        private void button_Fillet2F_L0_Click(object sender, EventArgs e)
        {
            para[0] = 0;

            button_Fillet2F_L0.BackColor = Color.Chartreuse;

            button_Fillet2F_L1.BackColor = SystemColors.Control;
            button_Fillet2F_L1.UseVisualStyleBackColor = true;
            button_Fillet2F_L2.BackColor = SystemColors.Control;
            button_Fillet2F_L2.UseVisualStyleBackColor = true;
        }
        private void button_Fillet2F_L1_Click(object sender, EventArgs e)
        {
            para[0] = 1;

            button_Fillet2F_L1.BackColor = Color.Chartreuse;

            button_Fillet2F_L0.BackColor = SystemColors.Control;
            button_Fillet2F_L0.UseVisualStyleBackColor = true;
            button_Fillet2F_L2.BackColor = SystemColors.Control;
            button_Fillet2F_L2.UseVisualStyleBackColor = true;
        }
        private void button_Fillet2F_L2_Click(object sender, EventArgs e)
        {
            para[0] = 2;

            button_Fillet2F_L2.BackColor = Color.Chartreuse;

            button_Fillet2F_L0.BackColor = SystemColors.Control;
            button_Fillet2F_L0.UseVisualStyleBackColor = true;
            button_Fillet2F_L1.BackColor = SystemColors.Control;
            button_Fillet2F_L1.UseVisualStyleBackColor = true;
        }
        private void button_Fillet2F_R0_Click(object sender, EventArgs e)
        {
            para[1] = 0;

            button_Fillet2F_R0.BackColor = Color.Chartreuse;

            button_Fillet2F_R1.BackColor = SystemColors.Control;
            button_Fillet2F_R1.UseVisualStyleBackColor = true;
            button_Fillet2F_R2.BackColor = SystemColors.Control;
            button_Fillet2F_R2.UseVisualStyleBackColor = true;
        }
        private void button_Fillet2F_R1_Click(object sender, EventArgs e)
        {
            para[1] = 1;

            button_Fillet2F_R1.BackColor = Color.Chartreuse;

            button_Fillet2F_R0.BackColor = SystemColors.Control;
            button_Fillet2F_R0.UseVisualStyleBackColor = true;
            button_Fillet2F_R2.BackColor = SystemColors.Control;
            button_Fillet2F_R2.UseVisualStyleBackColor = true;
        }
        private void button_Fillet2F_R2_Click(object sender, EventArgs e)
        {
            para[1] = 2;

            button_Fillet2F_R2.BackColor = Color.Chartreuse;

            button_Fillet2F_R0.BackColor = SystemColors.Control;
            button_Fillet2F_R0.UseVisualStyleBackColor = true;
            button_Fillet2F_R1.BackColor = SystemColors.Control;
            button_Fillet2F_R1.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Left_B0_Click(object sender, EventArgs e)
        {
            para[0] = 0;

            button_Fillet3F_Left_B0.BackColor = Color.Chartreuse;

            button_Fillet3F_Left_B1.BackColor = SystemColors.Control;
            button_Fillet3F_Left_B1.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Left_B1_Click(object sender, EventArgs e)
        {
            para[0] = 1;

            button_Fillet3F_Left_B1.BackColor = Color.Chartreuse;

            button_Fillet3F_Left_B0.BackColor = SystemColors.Control;
            button_Fillet3F_Left_B0.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Left_U0_Click(object sender, EventArgs e)
        {
            para[1] = 0;

            button_Fillet3F_Left_U0.BackColor = Color.Chartreuse;

            button_Fillet3F_Left_U1.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U1.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U2.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U2.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U3.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U3.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Left_U1_Click(object sender, EventArgs e)
        {
            para[1] = 1;

            button_Fillet3F_Left_U1.BackColor = Color.Chartreuse;

            button_Fillet3F_Left_U0.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U0.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U2.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U2.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U3.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U3.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Left_U2_Click(object sender, EventArgs e)
        {
            para[1] = 2;

            button_Fillet3F_Left_U2.BackColor = Color.Chartreuse;

            button_Fillet3F_Left_U0.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U0.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U1.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U1.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U3.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U3.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Left_U3_Click(object sender, EventArgs e)
        {
            para[1] = 3;

            button_Fillet3F_Left_U3.BackColor = Color.Chartreuse;

            button_Fillet3F_Left_U0.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U0.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U1.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U1.UseVisualStyleBackColor = true;
            button_Fillet3F_Left_U2.BackColor = SystemColors.Control;
            button_Fillet3F_Left_U2.UseVisualStyleBackColor = true;
        }


        private void button_Fillet3F_Right_B0_Click(object sender, EventArgs e)
        {
            para[0] = 0;

            button_Fillet3F_Right_B0.BackColor = Color.Chartreuse;

            button_Fillet3F_Right_B1.BackColor = SystemColors.Control;
            button_Fillet3F_Right_B1.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Right_B1_Click(object sender, EventArgs e)
        {
            para[0] = 1;

            button_Fillet3F_Right_B1.BackColor = Color.Chartreuse;

            button_Fillet3F_Right_B0.BackColor = SystemColors.Control;
            button_Fillet3F_Right_B0.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Right_U0_Click(object sender, EventArgs e)
        {
            para[1] = 0;

            button_Fillet3F_Right_U0.BackColor = Color.Chartreuse;

            button_Fillet3F_Right_U1.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U1.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U2.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U2.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U3.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U3.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Right_U1_Click(object sender, EventArgs e)
        {
            para[1] = 1;

            button_Fillet3F_Right_U1.BackColor = Color.Chartreuse;

            button_Fillet3F_Right_U0.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U0.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U2.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U2.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U3.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U3.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Right_U2_Click(object sender, EventArgs e)
        {
            para[1] = 2;

            button_Fillet3F_Right_U2.BackColor = Color.Chartreuse;

            button_Fillet3F_Right_U0.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U0.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U1.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U1.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U3.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U3.UseVisualStyleBackColor = true;
        }

        private void button_Fillet3F_Right_U3_Click(object sender, EventArgs e)
        {
            para[1] = 3;

            button_Fillet3F_Right_U3.BackColor = Color.Chartreuse;

            button_Fillet3F_Right_U0.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U0.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U1.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U1.UseVisualStyleBackColor = true;
            button_Fillet3F_Right_U2.BackColor = SystemColors.Control;
            button_Fillet3F_Right_U2.UseVisualStyleBackColor = true;
        }

    }
}
