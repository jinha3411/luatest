﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBlockWeldingRobot
{
    class WeldStartCondition
    {
        public double GasPreTime = 0;
        public double WeldStartTime = 0;
        public double WeldStartVol = 0;
        public double WeldStartAmp = 0;
        List<RobotPoseData> StartPosition = new List<RobotPoseData>();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldStartCondition()
        {

        }
        /// <summary>
        /// 초기가스시간, 초기아크시간, 초기아크전압, 초기아크전류 설정해주는 생성자
        /// </summary>
        /// <param name="gas">초기가스시간</param>
        /// <param name="startt">초기아크시간</param>
        /// <param name="startv">초기아크전압</param>
        /// <param name="starta">초기아크전류</param>
        public WeldStartCondition(double gas, double startt, double startv, double starta)
        {
            GasPreTime = gas;
            WeldStartTime = startt;
            WeldStartVol = startv;
            WeldStartAmp = starta;
            StartPosition = new List<RobotPoseData>();
        }


        /// <summary>
        /// 시작경로 리스트에 경로 추가하는 함수
        /// </summary>
        /// <param name="RobotPose">추가할 로봇 포즈</param>
        public void AddStartPosition(RobotPoseData RobotPose)
        {
            StartPosition.Add((RobotPoseData)RobotPose.Clone());
        }

        /// <summary>
        /// 시작경로 리스트에서 index번째 객체 복사해오는 함수
        /// </summary>
        /// <param name="index">복사해올 객체 인덱스</param>
        /// <returns>인덱스가 유효하면 로봇포즈 복사본 리턴, 유효하지 않으면 NULL 리턴</returns>
        public RobotPoseData GetStartPosition(int index)
        {
            if ((index >= 0) && (index < StartPosition.Count))
            {
                return (RobotPoseData)(StartPosition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 시작경로 리스트 개수 반환
        /// </summary>
        /// <returns>시작경로 리스트 개수</returns>
        public int GetStartPositionCount()
        {
            return StartPosition.Count;
        }

        /// <summary>
        /// 시작경로 리스트 초기화하는 함수
        /// </summary>
        public void ClearStartPosition()
        {
            StartPosition = new List<RobotPoseData>();
        }

    }

    class WeldMainCondition : ICloneable
    {
        public int PathType = 1; //1:선형 2:원호
        RobotPoseData PathStartPosition = new RobotPoseData();
        RobotPoseData PathMidPosition = new RobotPoseData();
        RobotPoseData PathEndPosition = new RobotPoseData();

        public double WelVol = 0;
        public double WeldAmp = 0;
        public double WeldSpd = 0;

        public int Weaving = 0; //0:위빙안함 1:지그재그 2:사인파
        public double WeavHz = 0;
        public double WeavLength = 0;
        public double WeavLeftStopTime = 0;
        public double WeavRightStopTime = 0;

        public int ArcSen = 0; //0:아크센싱안함 1:좌우센싱만함 2:상하센싱만함 3:둘다함
        public double ArcSenTimeShift = 0;
        public double ArcSenHFactor = 0;
        public double ArcSenVFactor = 0;
        public double ArcSenHMaxdL = 0;
        public double ArcSenVMaxdL = 0;
        public double ArcSenHOncedL = 0;
        public double ArcSenVOncedL = 0;
        public double ArcSenWeightedFactorRight = 0;
        public double ArcSenWeightedFactorLeft = 0;


        /// <summary>
        /// 로봇 모션 시작점 지정하는 함수
        /// </summary>
        /// <param name="temppose">시작점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetStartPose(RobotPoseData temppose){ PathStartPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 중간점 지정하는 함수
        /// </summary>
        /// <param name="temppose">중간점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetMidPose(RobotPoseData temppose) { PathMidPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 종료점 지정하는 함수
        /// </summary>
        /// <param name="temppose">종료점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetEndPose(RobotPoseData temppose) { PathEndPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 시작포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 시작포즈객체 복사본</returns>
        public RobotPoseData GetStartPose() { return (RobotPoseData)(this.PathStartPosition.Clone()); }
        /// <summary>
        /// 로봇 모션 중간포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 중간포즈객체 복사본</returns>
        public RobotPoseData GetMidPose() { return (RobotPoseData)(this.PathMidPosition.Clone()); }
        /// <summary>
        /// 로봇 모션 종료포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 종료포즈객체 복사본</returns>
        public RobotPoseData GetEndPose() { return (RobotPoseData)(this.PathEndPosition.Clone()); }

        /// <summary>
        /// 보간방식, 시작, 중간, 종료점 동시에 설정하는 함수
        /// </summary>
        /// <param name="type">보간방식 1:선형, 2:원호</param>
        /// <param name="Start">시작점</param>
        /// <param name="Mid">중간점</param>
        /// <param name="End">종료점</param>
        public void SetPath(int type, RobotPoseData Start, RobotPoseData Mid, RobotPoseData End)
        {
            PathType = type;
            SetStartPose(Start);
            SetMidPose(Mid);
            SetEndPose(End);
        }

        
        /// <summary>
        /// 보간방식, 전압, 전류, 속도 동시에 설정하는 함수
        /// </summary>
        /// <param name="type">보간방식 1:선형, 2:원호</param>
        /// <param name="vol">용접전압</param>
        /// <param name="amp">용접전류</param>
        /// <param name="speed">속도</param>
        public void WeldSetting(int type, double vol, double amp, double speed)
        {
            PathType = type;
            WelVol = vol;
            WeldAmp = amp;
            WeldSpd = speed;
        }

        /// <summary>
        /// 위빙관련 데이터 동시에 설정하는 함수
        /// </summary>
        /// <param name="onoff">위빙여부, 0:위빙안함, 1:지그재그위빙, 2:사인파위빙</param>
        /// <param name="Hz">위빙 주파수</param>
        /// <param name="Length">위빙 폭</param>
        /// <param name="LeftStopTime">좌멈춤시간</param>
        /// <param name="RightStopTime">우멈춤시간</param>
        public void WeavingSetting(int onoff, double Hz, double Length, double LeftStopTime, double RightStopTime)
        {
            Weaving = onoff;
            WeavHz = Hz;
            WeavLength = Length;
            WeavLeftStopTime = LeftStopTime;
            WeavRightStopTime = RightStopTime;
        }

        /// <summary>
        /// 아크센싱 관련 데이터 동시에 설정하는 함수
        /// </summary>
        /// <param name="onoff">0:아크센싱안함 1:좌우센싱만함 2:상하센싱만함 3:좌우,상하 전부함</param>
        /// <param name="TimeShift">센서 지연시간</param>
        /// <param name="HFactor">좌우센싱계수</param>
        /// <param name="VFactor">상하센싱계수</param>
        /// <param name="HMaxdL">좌우 최대보정량 한계값</param>
        /// <param name="VMaxdL">상하 최대보정량 한계값</param>
        /// <param name="HOncedL">좌우 1회보정량 한계값</param>
        /// <param name="VOncedL">상하 1회보정량 한계값</param>
        /// <param name="WeightedFactorRight">우외빙 센서값 가중치</param>
        /// <param name="WeightedFactorLeft">좌위빙 센서값 가중치</param>
        public void ArcSenSetting(int onoff, double TimeShift, double HFactor, double VFactor, double HMaxdL, double VMaxdL, double HOncedL, double VOncedL, double WeightedFactorRight, double WeightedFactorLeft)
        {
            ArcSen = onoff;
            ArcSenTimeShift = TimeShift;
            ArcSenHFactor = HFactor;
            ArcSenVFactor = VFactor;
            ArcSenHMaxdL = HMaxdL;
            ArcSenVMaxdL = VMaxdL;
            ArcSenHOncedL = HOncedL;
            ArcSenVOncedL = VOncedL;
            ArcSenWeightedFactorRight = WeightedFactorRight;
            ArcSenWeightedFactorLeft = WeightedFactorLeft;
        }
        public object Clone()
        {
            WeldMainCondition tempclone = new WeldMainCondition();

            tempclone.PathStartPosition = (RobotPoseData)(this.PathStartPosition.Clone());
            tempclone.PathMidPosition = (RobotPoseData)(this.PathMidPosition.Clone());
            tempclone.PathEndPosition = (RobotPoseData)(this.PathEndPosition.Clone());

            tempclone.PathType = this.PathType;
            tempclone.WelVol = this.WelVol;
            tempclone.WeldAmp = this.WeldAmp;
            tempclone.WeldSpd = this.WeldSpd;

            tempclone.Weaving = this.Weaving;
            tempclone.WeavHz = this.WeavHz;
            tempclone.WeavLength = this.WeavLength;
            tempclone.WeavLeftStopTime = this.WeavLeftStopTime;
            tempclone.WeavRightStopTime = this.WeavRightStopTime;

            tempclone.ArcSen = this.ArcSen;
            tempclone.ArcSenTimeShift = this.ArcSenTimeShift;
            tempclone.ArcSenHFactor = this.ArcSenHFactor;
            tempclone.ArcSenVFactor = this.ArcSenVFactor;
            tempclone.ArcSenHMaxdL = this.ArcSenHMaxdL;
            tempclone.ArcSenVMaxdL = this.ArcSenVMaxdL;
            tempclone.ArcSenHOncedL = this.ArcSenHOncedL;
            tempclone.ArcSenVOncedL = this.ArcSenVOncedL;
            tempclone.ArcSenWeightedFactorRight = this.ArcSenWeightedFactorRight;
            tempclone.ArcSenWeightedFactorLeft = this.ArcSenWeightedFactorLeft;

            return tempclone;
        }
    }

    class WeldEndCondition
    {
        public double GasPostTime = 0;
        public double WeldEndTime = 0;
        public double WeldEndVol = 0;
        public double WeldEndAmp = 0;
        public double WeldEndLength = 0;
        List<RobotPoseData> EndPosition = new List<RobotPoseData>();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldEndCondition()
        {

        }

        /// <summary>
        /// 종료 아크조건 설정해주는 생성자
        /// </summary>
        /// <param name="gas">아크 종료후 후기가스시간</param>
        /// <param name="endt">크레이터 아크시간</param>
        /// <param name="endv">크레이터 아크전압</param>
        /// <param name="enda">크레이터 아크전류</param>
        /// <param name="endl">아크 종료후 후진거리</param>
        public WeldEndCondition(double gas, double endt, double endv, double enda, double endl)
        {
            GasPostTime = gas;
            WeldEndTime = endt;
            WeldEndVol = endv;
            WeldEndAmp = enda;
            WeldEndLength = endl;
            EndPosition = new List<RobotPoseData>();
        }



        /// <summary>
        /// 종료경로 리스트에 경로 추가하는 함수
        /// </summary>
        /// <param name="RobotPose">추가할 로봇 포즈</param>
        public void AddEndPosition(RobotPoseData RobotPose)
        {
            EndPosition.Add((RobotPoseData)RobotPose.Clone());
        }

        /// <summary>
        /// 종료경로 리스트에서 index번째 객체 복사해오는 함수
        /// </summary>
        /// <param name="index">복사해올 객체 인덱스</param>
        /// <returns>인덱스가 유효하면 로봇포즈 복사본 리턴, 유효하지 않으면 NULL 리턴</returns>
        public RobotPoseData GetEndPosition(int index)
        {
            if ((index >= 0) && (index < EndPosition.Count))
            {
                return (RobotPoseData)(EndPosition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 종료경로 리스트 개수 반환
        /// </summary>
        /// <returns>종료경로 리스트 개수</returns>
        public int GetEndPositionCount()
        {
            return EndPosition.Count;
        }

        /// <summary>
        /// 종료경로 리스트 초기화하는 함수
        /// </summary>
        public void ClearEndPosition()
        {
            EndPosition = new List<RobotPoseData>();
        }
    }

    class WeldInformation : ICloneable
    {
        public bool ArcOnFlag; //용접을 할지 모션만 할지 선택
        public bool ContinueFlag = true; //용접 종료 후 멈추고자 할때 false 지정
        public bool MultipathFlag = false; // 해당 용접이 다층용접(초층제외)일경우 true 지정. 슬래그 털기 설정이 되어 있는 경우 이게 트루이면 용접 진행 안하고 대기함
        public WeldStartCondition InitCondition = new WeldStartCondition();
        List<WeldMainCondition> MainCondition = new List<WeldMainCondition>();
        public WeldEndCondition EndCondition = new WeldEndCondition();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldInformation()
        {

        }

        /// <summary>
        /// 메인 용접정보 리스트에 객체 추가하는 함수
        /// </summary>
        /// <param name="tempWMC">메인컨디션 객체</param>
        public void AddMainCondition(WeldMainCondition tempWMC)
        {
            MainCondition.Add((WeldMainCondition)(tempWMC.Clone()));
        }

        /// <summary>
        /// 메인컨디션 리스트에서 index번째 객체 반환(복사본으로)
        /// </summary>
        /// <param name="index"></param>
        /// <returns>해당 인덱스번째 객체가 있으면 객체 복사본 반환. 그렇지 않으면 Null 반환</returns>
        public WeldMainCondition GetMainCondition(int index)
        {
            if ((index >= 0) && (index < MainCondition.Count))
            {
                return (WeldMainCondition)(MainCondition[index].Clone());
            }else
            {
                return null;
            }
        }

        /// <summary>
        /// 메인컨디션리스트의 객체 개수 반환
        /// </summary>
        /// <returns>리스트 객체 개수</returns>
        public int GetMainConditionCount()
        {
            return MainCondition.Count;
        }


        public object Clone()
        {
            WeldInformation tempclone = new WeldInformation();
            tempclone.ArcOnFlag = this.ArcOnFlag;
            tempclone.ContinueFlag = this.ContinueFlag;
            tempclone.MultipathFlag = this.MultipathFlag;
            tempclone.InitCondition = new WeldStartCondition();
            tempclone.InitCondition.GasPreTime = this.InitCondition.GasPreTime;
            tempclone.InitCondition.WeldStartTime = this.InitCondition.WeldStartTime;
            tempclone.InitCondition.WeldStartVol = this.InitCondition.WeldStartVol;
            tempclone.InitCondition.WeldStartAmp = this.InitCondition.WeldStartAmp;
            for (int i = 0; i < this.InitCondition.GetStartPositionCount(); i++)
            {
                RobotPoseData temptcpdata = new RobotPoseData();
                temptcpdata.PoseType = this.InitCondition.GetStartPosition(i).PoseType;
                temptcpdata.f1 = this.InitCondition.GetStartPosition(i).f1;
                temptcpdata.f2 = this.InitCondition.GetStartPosition(i).f2;
                temptcpdata.f3 = this.InitCondition.GetStartPosition(i).f3;
                temptcpdata.f4 = this.InitCondition.GetStartPosition(i).f4;
                temptcpdata.f5 = this.InitCondition.GetStartPosition(i).f5;
                temptcpdata.f6 = this.InitCondition.GetStartPosition(i).f6;
                tempclone.InitCondition.AddStartPosition(temptcpdata);
            }
            tempclone.EndCondition = new WeldEndCondition();
            tempclone.EndCondition.GasPostTime = this.EndCondition.GasPostTime;
            tempclone.EndCondition.WeldEndTime = this.EndCondition.WeldEndTime;
            tempclone.EndCondition.WeldEndVol = this.EndCondition.WeldEndVol;
            tempclone.EndCondition.WeldEndAmp = this.EndCondition.WeldEndAmp;
            tempclone.EndCondition.WeldEndLength = this.EndCondition.WeldEndLength;
            for (int i = 0; i < this.EndCondition.GetEndPositionCount(); i++)
            {
                RobotPoseData temptcpdata = new RobotPoseData();
                temptcpdata.PoseType = this.EndCondition.GetEndPosition(i).PoseType;
                temptcpdata.f1 = this.EndCondition.GetEndPosition(i).f1;
                temptcpdata.f2 = this.EndCondition.GetEndPosition(i).f2;
                temptcpdata.f3 = this.EndCondition.GetEndPosition(i).f3;
                temptcpdata.f4 = this.EndCondition.GetEndPosition(i).f4;
                temptcpdata.f5 = this.EndCondition.GetEndPosition(i).f5;
                temptcpdata.f6 = this.EndCondition.GetEndPosition(i).f6;
                tempclone.EndCondition.AddEndPosition(temptcpdata);
            }

            tempclone.MainCondition = new List<WeldMainCondition>();
            for (int i = 0; i < this.MainCondition.Count; i++)
            {
                WeldMainCondition tempmaincon = new WeldMainCondition();

                tempmaincon.SetStartPose(this.MainCondition[i].GetStartPose());
                tempmaincon.SetMidPose(this.MainCondition[i].GetMidPose());
                tempmaincon.SetEndPose(this.MainCondition[i].GetEndPose());

                tempmaincon.PathType = this.MainCondition[i].PathType;
                tempmaincon.WelVol = this.MainCondition[i].WelVol;
                tempmaincon.WeldAmp = this.MainCondition[i].WeldAmp;
                tempmaincon.WeldSpd = this.MainCondition[i].WeldSpd;
                tempmaincon.Weaving = this.MainCondition[i].Weaving;
                tempmaincon.WeavHz = this.MainCondition[i].WeavHz;
                tempmaincon.WeavLength = this.MainCondition[i].WeavLength;
                tempmaincon.WeavLeftStopTime = this.MainCondition[i].WeavLeftStopTime;
                tempmaincon.WeavRightStopTime = this.MainCondition[i].WeavRightStopTime;
                tempmaincon.ArcSen = this.MainCondition[i].ArcSen;
                tempmaincon.ArcSenTimeShift = this.MainCondition[i].ArcSenTimeShift;
                tempmaincon.ArcSenHFactor = this.MainCondition[i].ArcSenHFactor;
                tempmaincon.ArcSenVFactor = this.MainCondition[i].ArcSenVFactor;
                tempmaincon.ArcSenHMaxdL = this.MainCondition[i].ArcSenHMaxdL;
                tempmaincon.ArcSenVMaxdL = this.MainCondition[i].ArcSenVMaxdL;
                tempmaincon.ArcSenHOncedL = this.MainCondition[i].ArcSenHOncedL;
                tempmaincon.ArcSenVOncedL = this.MainCondition[i].ArcSenVOncedL;
                tempmaincon.ArcSenWeightedFactorLeft = this.MainCondition[i].ArcSenWeightedFactorLeft;
                tempmaincon.ArcSenWeightedFactorRight = this.MainCondition[i].ArcSenWeightedFactorRight;

                tempclone.MainCondition.Add(tempmaincon);
            }


            return tempclone;
        }



        public WeldInformation ReverseInfo()
        {
            WeldInformation ResultInfo = (WeldInformation)this.Clone();

            //시작경로,종료경로 뒤집어 넣기
            ResultInfo.InitCondition.ClearStartPosition();
            int endposecount = this.EndCondition.GetEndPositionCount();
            for (int i = endposecount - 1; i >= 0; i--)
            {
                RobotPoseData temppose = this.EndCondition.GetEndPosition(i);
                if ((temppose.PoseType == 3) || (temppose.PoseType == 4)) continue;
                ResultInfo.InitCondition.AddStartPosition(temppose);
            }

            ResultInfo.EndCondition.ClearEndPosition();
            ResultInfo.EndCondition.AddEndPosition(new RobotPoseData(3, 50, -1, 0, 0, 0, 0, 0));
            int initposecount = this.InitCondition.GetStartPositionCount();
            for (int i = initposecount - 1; i >= 0; i--)
            {
                RobotPoseData temppose = this.InitCondition.GetStartPosition(i);
                if ((temppose.PoseType == 3) || (temppose.PoseType == 4)) continue;
                ResultInfo.EndCondition.AddEndPosition(temppose);
            }

            //메인경로 시작점 종료점 뒤바꿈
            int mainweldcount = this.MainCondition.Count;
            for(int i=0; i< mainweldcount; i++)
            {
                ResultInfo.MainCondition[i].SetStartPose(this.MainCondition[i].GetEndPose());
                ResultInfo.MainCondition[i].SetEndPose(this.MainCondition[i].GetStartPose());
            }
            ResultInfo.MainCondition.Reverse();
            
            return ResultInfo;
        }


    }

    class TouchSensingData : ICloneable
    {
        //터치센싱 진입데이터
        public int In_coord; //방향벡터의 기준좌표계 1:베이스, 2:툴,
        public float In_X; //방향벡터 성분 중 x
        public float In_Y; //방향벡터 성분 중 y
        public float In_Z; //방향벡터 성분 중 z
        public float In_Length; //벡터 방향으로 진행하는 거리
        public float In_Speed; //진행 속도

        //터치센싱 완료 후 복귀데이터
        public int Out_coord; //방향벡터의 기준좌표계 1:베이스, 2:툴,
        public float Out_X; //방향벡터 성분 중 x
        public float Out_Y; //방향벡터 성분 중 y
        public float Out_Z; //방향벡터 성분 중 z
        public float Out_Length; //벡터 방향으로 진행하는 거리
        public float Out_Speed; //진행 속도

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public TouchSensingData()
        {

        }

        /// <summary>
        /// 터치관련 인자 바로 넣는 생성자
        /// </summary>
        /// <param name="iLength">서칭거리(mm)</param>
        /// <param name="iSpeed">서칭속도(mm/s)</param>
        /// <param name="iCoord">방향벡터 좌표계, 1:베이스좌표계, 2:툴좌표계</param>
        /// <param name="iX">방향벡터 X성분</param>
        /// <param name="iY">방향벡터 Y성분</param>
        /// <param name="iZ">방향벡터 Z성분</param>
        /// <param name="oLength">복귀거리(mm)</param>
        /// <param name="oSpeed">복귀속도(mm/s)</param>
        /// <param name="oCoord">방향벡터 좌표계, 1:베이스좌표계, 2:툴좌표계</param>
        /// <param name="oX">방향벡터 X성분</param>
        /// <param name="oY">방향벡터 Y성분</param>
        /// <param name="oZ">방향벡터 Z성분</param>
        public TouchSensingData(double iLength, double iSpeed, int iCoord, double iX, double iY, double iZ, double oLength, double oSpeed, int oCoord, double oX, double oY, double oZ)
        {
            In_Length = (float)iLength;
            In_Speed = (float)iSpeed;
            In_coord = iCoord;
            In_X = (float)iX;
            In_Y = (float)iY;
            In_Z = (float)iZ;

            Out_Length = (float)oLength;
            Out_Speed = (float)oSpeed;
            Out_coord = oCoord;
            Out_X = (float)oX;
            Out_Y = (float)oY;
            Out_Z = (float)oZ;
        }

        public object Clone()
        {
            TouchSensingData temp = new TouchSensingData();

            temp.In_coord = this.In_coord;
            temp.In_X = this.In_X;
            temp.In_Y = this.In_Y;
            temp.In_Z = this.In_Z;
            temp.In_Length = this.In_Length;
            temp.In_Speed = this.In_Speed;

            temp.Out_coord = this.Out_coord;
            temp.Out_X = this.Out_X;
            temp.Out_Y = this.Out_Y;
            temp.Out_Z = this.Out_Z;
            temp.Out_Length = this.Out_Length;
            temp.Out_Speed = this.Out_Speed;

            return temp;
        }


    }

    class WeldingCondition : ICloneable
    {
        public double Vol;
        public double Amp;
        public double Spd;
        public double Offset_WorkAngle;
        public double Offset_TravelAngle;
        public double Offset_X;
        public double Offset_Y;
        public double Offset_Z;
        public double WeavingHz;
        public double WeavingWidth;
        public double WeavingFloorStop;
        public double WeavingWallStop;
        public int ArcSen;
        public double BeadBias;


        public object Clone()
        {
            WeldingCondition temp = new WeldingCondition();

            temp.Vol = this.Vol;
            temp.Amp = this.Amp;
            temp.Spd = this.Spd;
            temp.Offset_WorkAngle = this.Offset_WorkAngle;
            temp.Offset_TravelAngle = this.Offset_TravelAngle;
            temp.Offset_X = this.Offset_X;
            temp.Offset_Y = this.Offset_Y;
            temp.Offset_Z = this.Offset_Z;
            temp.WeavingHz = this.WeavingHz;
            temp.WeavingWidth = this.WeavingWidth;
            temp.WeavingFloorStop = this.WeavingFloorStop;
            temp.WeavingWallStop = this.WeavingWallStop;
            temp.ArcSen = this.ArcSen;
            temp.BeadBias = this.BeadBias;

            return temp;
        }

    }


}
