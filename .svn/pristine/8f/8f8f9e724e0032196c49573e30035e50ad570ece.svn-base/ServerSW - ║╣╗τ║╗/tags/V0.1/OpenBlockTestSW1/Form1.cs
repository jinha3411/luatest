﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//추가된 네임스페이스
using System.Threading;
using System.IO;


namespace OpenBlockWeldingRobot
{

    public partial class Form1 : Form
    {
        //파일 경로 설정. 고정값임
        const string ProgramPath =  @"C:\HHIAutomation\OpenBlockWeldingRobot_Server";
        const string ProgramInitFileFullPath = @ProgramPath + @"\Init\init.xml";

        //만약 로봇접속 시퀀스를 넘어가고 싶다면 1(로봇이 없는 테스트 환경일 때)
        int TestEnvFlag = 0;


        int direction;
        SystemState SystemStateValue;
        WeldInformation tempWeldInfo;


        //어드밴텍 IO 관련 클래스, 스레드
        DataEX_AdvantechIO IODataEX;
        ThreadClass_AdvantechIO IOclass;

        //IMU 관련 클래스, 스레드
        DataEX_NTARSv2 IMUDataEX;
        ThreadClass_NTARSv2 IMUclass;

        //거리센서 관련 클래스, 스레드
        DataEX_DistanceSensor DistanceSensorDataEX;
        ThreadClass_DistanceSensor DistanceSensorclass;

        //UDP통신관련 클래스, 스레드
        DataEX_UDPCommunication UDPCommDataEX;
        ThreadClass_UDPCommunication_Server UDPCommclass;


        //로봇 통신관련 클래스
        DataEX_HCRRobot RobotDataEX;
        HCRRobotCommunication RobotCommclass;

        //기본 설정 데이터셋
        DataSet InitSetting; //프로그램에서 사용되는 설정
        DataSet InitSetting_Backup; //설정화면에 표시되는 값. 설정화면의 데이터그리드뷰와 테이블을 바인딩 할 때 테이블 값 수정이 바로 설정파일에 반영되는것을 막기위해 사용 


        //프로그램 시퀀스 상태변수
        string MainSequence = "초기화-시작";
        //프로그램 초기화 로그
        public StringBuilder ServerInitLog = new StringBuilder();

        //메인 프로그램 로그
        public List<string> MainLog = new List<string>();
        private object lockObject_MainLog = new object();

        //0.5초마다 온오프 전환하는 출력 내보내기 위해
        DateTime WatchDocTime = DateTime.Now;

        //램프 깜박이는 타이머
        DateTime LampTime = DateTime.Now;

        //툴 버튼 눌렸는지 체크하기 위한 이전값 저장변수
        int[] ToolDIBuff = new int[4] { 0, 0, 0, 0 };

        public Form1()
        {
            InitializeComponent();

            
            //셀정보 기록 함수
            CellDataRecord();
            SampleDataRecord();

            //용접DB파일 로드
            WeldDatabaseLoad();


            //메인 시퀀스 타이머 시작
            timer_Main.Enabled = true;

            //1번 패널 보여줌
            DisplayPanalChange("Main");

            //시스템 상태변수 선언
            SystemStateValue = new SystemState();


            RobotDataEX = new DataEX_HCRRobot();
            RobotCommclass = new HCRRobotCommunication(RobotDataEX);

            comboBox_WeldTypeLeft.SelectedIndex = 0;
            comboBox_WeldTypeRight.SelectedIndex = 0;
            comboBox_WeldSample.SelectedIndex = 0;

            for (int i=0; i<32; i++)
            {
                AutoWeld_DTPoint_Left_JointPose[i] = new RobotPoseData();
                AutoWeld_DTPoint_Right_JointPose[i] = new RobotPoseData();
                AutoWeld_TSPoint_Left_JointPose[i] = new RobotPoseData();
                AutoWeld_TSPoint_Right_JointPose[i] = new RobotPoseData();
                AutoWeld_DTPoint_Left_TCPPose[i] = new RobotPoseData();
                AutoWeld_DTPoint_Right_TCPPose[i] = new RobotPoseData();
                AutoWeld_TSPoint_Left_TCPPose[i] = new RobotPoseData();
                AutoWeld_TSPoint_Right_TCPPose[i] = new RobotPoseData();
                AutoWeld_WedlPoint_Left[i] = new RobotPoseData();
                AutoWeld_WedlPoint_Right[i] = new RobotPoseData();
                DTPointLeftOK[i] = false;
                DTPointRightOK[i] = false;
            }

            for (int i = 0; i < 16; i++ )
            {
                SampleWeld_DTPoint_JointPose[i] = new RobotPoseData();
                SampleWeld_DTPoint_TCPPose[i] = new RobotPoseData();
                SampleWeld_TSPoint_JointPose[i] = new RobotPoseData();
                SampleWeld_TSPoint_TCPPose[i] = new RobotPoseData();
                SampleWeld_WedlPoint[i] = new RobotPoseData();
                SampleWeldDTPointOK[i] = false;
            }

            //DTDataSave();
            //DTDataLoad();
            //TouchDataSave();
            //TouchDataLoad();


        }

        private void MainLog_Add(string tempstr)
        {
            lock (lockObject_MainLog)
            {
                MainLog.Add(DateTime.Now.ToString("HH:mm:ss.fff-") + tempstr);

                if (MainLog.Count > 1000)
                {
                    MainLog.RemoveAt(0);
                }
            }
        }

        public string[] MainLog_ReadBlock(int count)
        {
            string[] tempdata;

            lock (lockObject_MainLog)
            {
                if (MainLog.Count < count)
                {
                    tempdata = new string[MainLog.Count];
                    MainLog.CopyTo(0, tempdata, 0, MainLog.Count);
                }
                else
                {
                    tempdata = new string[count];
                    MainLog.CopyTo(MainLog.Count - count, tempdata, 0, count);
                }
            }

            return tempdata;
        }



        //어드밴텍 IO관련 객체 만들고 스레드 실행
        private void IOinit()
        {
            //데이터교환 객체 생성
            IODataEX = new DataEX_AdvantechIO();

            //스레드클래스 객체 생성하고 데이터교환 객체 등록. 자동으로 통신스레드 시작
            IOclass = new ThreadClass_AdvantechIO(IODataEX);

        }
        //IMU 관련 객체 만들고 스레드 실행
        private void IMUinit()
        {
            //데이터교환 객체 생성
            IMUDataEX = new DataEX_NTARSv2();

            //스레드클래스 객체 생성하고 데이터교환 객체 등록
            IMUclass = new ThreadClass_NTARSv2(IMUDataEX);
            
        }
        //거리센서 관련 객체 만들고 스레드 실행
        private void DistanceSensorinit()
        {
            //데이터교환 객체 생성
            DistanceSensorDataEX = new DataEX_DistanceSensor();

            //스레드클래스 객체 생성하고 데이터교환 객체 등록
            DistanceSensorclass = new ThreadClass_DistanceSensor(DistanceSensorDataEX);
        }
        //통신객체 만들고 스레드 실행
        private void UDPCommunicationinit()
        {
            //데이터교환 객체 생성
            UDPCommDataEX = new DataEX_UDPCommunication();

            List<string> tempUDPdata = new List<string>();
            foreach (DataRow dr in InitSetting.Tables["Communication_IPPortSetting"].Rows)
            {
                tempUDPdata.Add(dr["IP"].ToString() + "/" + dr["PORT"].ToString());
            }

            List<string> tempPermissiondata = new List<string>();
            foreach (DataRow dr in InitSetting.Tables["Communication_Permission"].Rows)
            {
                tempPermissiondata.Add(dr["IP"].ToString() + "/" + dr["PORT"].ToString() + "/" + dr["Permission"].ToString());
            }

            //스레드클래스 객체 생성하고 데이터교환 객체 등록. 스레드 시작
            UDPCommclass = new ThreadClass_UDPCommunication_Server(UDPCommDataEX);
            UDPCommclass.SetIPPortAndPermision(tempUDPdata, tempPermissiondata);
            UDPCommclass.UDPCommunicationStart();

        }

        //로봇 스레드 실행
        private void RobotCommunicationInit()
        {
            RobotDataEX = new DataEX_HCRRobot();
            RobotCommclass = new HCRRobotCommunication(RobotDataEX);
            SendSettingDataToRobot();
            RobotCommclass.RobotConnect();
        }

        //패널 전환 함수
        private void DisplayPanalChange(string panalName)
        {
            switch (panalName)
            {
                case "Main": //메인페널
                    button_Display_Main.BackColor = Color.Chartreuse;

                    button_Display_RobotState.BackColor = SystemColors.Control;
                    button_Display_RobotState.UseVisualStyleBackColor = true;
                    button_Display_Device.BackColor = SystemColors.Control;
                    button_Display_Device.UseVisualStyleBackColor = true;
                    button_Display_CommunicationState.BackColor = SystemColors.Control;
                    button_Display_CommunicationState.UseVisualStyleBackColor = true;
                    button_Display_Log.BackColor = SystemColors.Control;
                    button_Display_Log.UseVisualStyleBackColor = true;
                    button_Display_Setting.BackColor = SystemColors.Control;
                    button_Display_Setting.UseVisualStyleBackColor = true;

                    panel_Display_Main.Visible = true;
                    panel_Display_RobotState.Visible = false;
                    panel_Display_Device.Visible = false;
                    panel_Display_CommunicationState.Visible = false;
                    panel_Display_Log.Visible = false;
                    panel_Display_Setting.Visible = false;
                    break;

                case "RobotState": //로봇상태 패널
                    button_Display_Main.BackColor = SystemColors.Control;
                    button_Display_Main.UseVisualStyleBackColor = true;

                    button_Display_RobotState.BackColor = Color.Chartreuse;
                    
                    button_Display_Device.BackColor = SystemColors.Control;
                    button_Display_Device.UseVisualStyleBackColor = true;
                    button_Display_CommunicationState.BackColor = SystemColors.Control;
                    button_Display_CommunicationState.UseVisualStyleBackColor = true;
                    button_Display_Log.BackColor = SystemColors.Control;
                    button_Display_Log.UseVisualStyleBackColor = true;
                    button_Display_Setting.BackColor = SystemColors.Control;
                    button_Display_Setting.UseVisualStyleBackColor = true;

                    panel_Display_Main.Visible = false;
                    panel_Display_RobotState.Visible = true;
                    panel_Display_Device.Visible = false;
                    panel_Display_CommunicationState.Visible = false;
                    panel_Display_Log.Visible = false;
                    panel_Display_Setting.Visible = false;
                    break;

                case "Device": //설정 패널
                    button_Display_Main.BackColor = SystemColors.Control;
                    button_Display_Main.UseVisualStyleBackColor = true;
                    button_Display_RobotState.BackColor = SystemColors.Control;
                    button_Display_RobotState.UseVisualStyleBackColor = true;

                    button_Display_Device.BackColor = Color.Chartreuse;

                    button_Display_CommunicationState.BackColor = SystemColors.Control;
                    button_Display_CommunicationState.UseVisualStyleBackColor = true;
                    button_Display_Log.BackColor = SystemColors.Control;
                    button_Display_Log.UseVisualStyleBackColor = true;
                    button_Display_Setting.BackColor = SystemColors.Control;
                    button_Display_Setting.UseVisualStyleBackColor = true;

                    panel_Display_Main.Visible = false;
                    panel_Display_RobotState.Visible = false;
                    panel_Display_Device.Visible = true;
                    panel_Display_CommunicationState.Visible = false;
                    panel_Display_Log.Visible = false;
                    panel_Display_Setting.Visible = false;
                    break;

                case "CommunicationState": //통신상태 패널
                    button_Display_Main.BackColor = SystemColors.Control;
                    button_Display_Main.UseVisualStyleBackColor = true;
                    button_Display_RobotState.BackColor = SystemColors.Control;
                    button_Display_RobotState.UseVisualStyleBackColor = true;
                    button_Display_Device.BackColor = SystemColors.Control;
                    button_Display_Device.UseVisualStyleBackColor = true;

                    button_Display_CommunicationState.BackColor = Color.Chartreuse;
                    
                    button_Display_Log.BackColor = SystemColors.Control;
                    button_Display_Log.UseVisualStyleBackColor = true;
                    button_Display_Setting.BackColor = SystemColors.Control;
                    button_Display_Setting.UseVisualStyleBackColor = true;

                    panel_Display_Main.Visible = false;
                    panel_Display_RobotState.Visible = false;
                    panel_Display_Device.Visible = false;
                    panel_Display_CommunicationState.Visible = true;
                    panel_Display_Log.Visible = false;
                    panel_Display_Setting.Visible = false;
                    break;

                case "Log": //로그패널
                    button_Display_Main.BackColor = SystemColors.Control;
                    button_Display_Main.UseVisualStyleBackColor = true;
                    button_Display_RobotState.BackColor = SystemColors.Control;
                    button_Display_RobotState.UseVisualStyleBackColor = true;
                    button_Display_Device.BackColor = SystemColors.Control;
                    button_Display_Device.UseVisualStyleBackColor = true;
                    button_Display_CommunicationState.BackColor = SystemColors.Control;
                    button_Display_CommunicationState.UseVisualStyleBackColor = true;

                    button_Display_Log.BackColor = Color.Chartreuse;

                    button_Display_Setting.BackColor = SystemColors.Control;
                    button_Display_Setting.UseVisualStyleBackColor = true;

                    panel_Display_Main.Visible = false;
                    panel_Display_RobotState.Visible = false;
                    panel_Display_Device.Visible = false;
                    panel_Display_CommunicationState.Visible = false;
                    panel_Display_Log.Visible = true;
                    panel_Display_Setting.Visible = false;
                    break;

                case "Setting": //설정패널
                    button_Display_Main.BackColor = SystemColors.Control;
                    button_Display_Main.UseVisualStyleBackColor = true;
                    button_Display_RobotState.BackColor = SystemColors.Control;
                    button_Display_RobotState.UseVisualStyleBackColor = true;
                    button_Display_Device.BackColor = SystemColors.Control;
                    button_Display_Device.UseVisualStyleBackColor = true;
                    button_Display_CommunicationState.BackColor = SystemColors.Control;
                    button_Display_CommunicationState.UseVisualStyleBackColor = true;
                    button_Display_Log.BackColor = SystemColors.Control;
                    button_Display_Log.UseVisualStyleBackColor = true;

                    button_Display_Setting.BackColor = Color.Chartreuse;

                    panel_Display_Main.Visible = false;
                    panel_Display_RobotState.Visible = false;
                    panel_Display_Device.Visible = false;
                    panel_Display_CommunicationState.Visible = false;
                    panel_Display_Log.Visible = false;
                    panel_Display_Setting.Visible = true;
                    break;
                default:
                    break;

            }

            //전환 후 화면갱신
            DisplayRefresh();

        }


        //프로그램 종료할 때 해야 할 일 여기에 코딩, 주로 스레드 종료, 파일 저장 및 닫기 등등
        private void ProgramClose()
        {


            //생성된 모든 스레드 종료
            AllThreadClose();


        }


        //생성된 모든 스레드 종료
        private void AllThreadClose()
        {
            //IO 스레드 종료
            IOclass.threadStop();

            //IMU 스레드 종료
            IMUclass.threadStop();

            //거리센서 스레드 종료
            DistanceSensorclass.threadStop();

            //UDP통신 스레드 종료
            UDPCommclass.threadStop();
        }


        //스레드 들이 정상 종료됬는지 체크하다가 전부 종료되면 프로그램 종료하는 타이머
        private void timer_CloseCheck_Tick(object sender, EventArgs e)
        {
            bool ThreadAllClose = true;

            //스레드가 종료됬는지 체크. 하나라도 살아있으면 false로 바꿈
            if (IOclass.IOthread.IsAlive == true) ThreadAllClose = false;
            if (IMUclass.IMUthread.IsAlive == true) ThreadAllClose = false;
            if (DistanceSensorclass.DistanceSensorthread.IsAlive == true) ThreadAllClose = false;
            //if (UDPCommthread.IsAlive == true) ThreadAllClose = false;

            
            //모든 스레드가 종료되었으면 프로그램 종료
            if(ThreadAllClose)
            {
                //커서모양 대기중 표시 해제
                this.Cursor = null;

                //아이콘트레이에서 아이콘 제거
                notifyIcon_TrayIcon.Visible = false;
                notifyIcon_TrayIcon.Dispose();

                //프로세스 종료
                Application.Exit();
                Environment.Exit(0);
                System.Diagnostics.Process.GetCurrentProcess().Kill();

            }

        }


        
        //프로그램 종료 버튼 누르면 종료하지 않고 폼 최소화
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true; // 종료 이벤트를 취소 시킨다
            this.Visible = false; // 폼을 표시하지 않는다;
        }
        //트레이아이콘에서 열기 누르면 폼 표시
        private void toolStripMenuItem_Open_Click(object sender, EventArgs e)
        {
            this.Visible = true; // 폼의 표시
            if (this.WindowState == FormWindowState.Minimized)
                this.WindowState = FormWindowState.Normal; // 최소화를 멈춘다 
            this.Activate(); // 폼을 활성화 시킨다
        }
        //트레이아이콘에서 종료 누르면 종료작업, 스레드 해제 한 뒤 종료타이머 실행
        private void toolStripMenuItem_Close_Click(object sender, EventArgs e)
        {
            //커서모양 대기중 표시 - 종료 진행중인 것을 알려주기 위해
            this.Cursor = Cursors.WaitCursor;


            //프로그램 종료할 때 해야 할 함수 호출
            ProgramClose();

            //종료 타이머 실행
            timer_CloseCheck.Enabled = true;

        }
        //트레이아이콘 더블클릭하면 폼 활성화
        private void notifyIcon_TrayIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Visible = true; // 폼의 표시
            if (this.WindowState == FormWindowState.Minimized)
                this.WindowState = FormWindowState.Normal; // 최소화를 멈춘다 
            this.Activate(); // 폼을 활성화 시킨다
        }

        //메인 버튼 클릭
        private void button_Display_Main_Click(object sender, EventArgs e)
        {
            //메인패널이 숨김상태이면 보여줌
            if (panel_Display_Main.Visible != true)
            {
                DisplayPanalChange("Main");
            }
        }
        //로봇 버튼 클릭
        private void button_Display_RobotState_Click(object sender, EventArgs e)
        {
            //로봇상태패널이 숨김상태이면 보여줌
            if (panel_Display_RobotState.Visible != true)
            {
                DisplayPanalChange("RobotState");
            }
        }
        //주변장치 버튼 클릭
        private void button_Display_Device_Click(object sender, EventArgs e)
        {
            //통신상태패널이 숨김상태이면 보여줌
            if (panel_Display_Device.Visible != true)
            {
                DisplayPanalChange("Device");
            }
        }
        //통신 버튼 클릭
        private void button_Display_CommunicationState_Click(object sender, EventArgs e)
        {
            //통신상태패널이 숨김상태이면 보여줌
            if (panel_Display_CommunicationState.Visible != true)
            {
                DisplayPanalChange("CommunicationState");
            }
        }
        //로그 버튼 클릭
        private void button_Display_Log_Click(object sender, EventArgs e)
        {
            //통신상태패널이 숨김상태이면 보여줌
            if (panel_Display_Log.Visible != true)
            {
                DisplayPanalChange("Log");
            }

        }
        //설정 버튼 클릭
        private void button_Display_Setting_Click(object sender, EventArgs e)
        {
            //설정패널이 숨김 상태이면 보여주는 절차 진행
            if (panel_Display_Setting.Visible != true)
            {
                Form login = new Password();
                DialogResult dlgres = login.ShowDialog();
                if (dlgres == DialogResult.OK)
                {
                    DisplayPanalChange("Setting");
                }
            }
        }


        //설정 취소버튼 클릭.
        private void button_SettingCancel1_Click(object sender, EventArgs e)
        {
            SettingCancel();
        }
        private void button_SettingCancel2_Click(object sender, EventArgs e)
        {
            SettingCancel();
        }
        private void button_SettingCancel3_Click(object sender, EventArgs e)
        {
            SettingCancel();
        }
        private void button_SettingCancel4_Click(object sender, EventArgs e)
        {
            SettingCancel();
        }

        //설정 저장버튼 클릭.
        private void button_SettingSave1_Click(object sender, EventArgs e)
        {
            SettingSave(ProgramInitFileFullPath);
        }
        private void button_SettingSave2_Click(object sender, EventArgs e)
        {
            SettingSave(ProgramInitFileFullPath);
        }
        private void button_SettingSave3_Click(object sender, EventArgs e)
        {
            SettingSave(ProgramInitFileFullPath);
        }
        private void button_SettingSave4_Click(object sender, EventArgs e)
        {
            SettingSave(ProgramInitFileFullPath);
        }

        //설정 데이터그리드뷰 떠나는 경우 선택된 셀 해제
        private void dataGridView_SettingPermission_Leave(object sender, EventArgs e)
        {
            dataGridView_SettingPermission.CurrentCell = null;
        }
        private void dataGridView_SettingControlAndMonitor_Leave(object sender, EventArgs e)
        {
            dataGridView_SettingControlAndMonitor.CurrentCell = null;
        }

        //화면에 데이터 뿌려주는 타이머. 현재 보이는 창만 갱신
        private void timer_Display_Tick(object sender, EventArgs e)
        {
            DisplayRefresh();


            if (IMUclass != null)
            {
                textBox_SettingRobotMountRxNow.Text = IMUclass.RobotRx.ToString("0.00");
                textBox_SettingRobotMountRyNow.Text = IMUclass.RobotRy.ToString("0.00");
            }

        }

        //화면 갱신. 화면에 나타난 패널만 갱신함
        private void DisplayRefresh()
        {
            if (panel_Display_Main.Visible)
            {
                PanelMainDisplay();
            }

            if (panel_Display_RobotState.Visible)
            {
                PanelRobotDisplay();
            }

            if (panel_Display_Device.Visible)
            {
                PanelDeviceDisplay();
            }

            if (panel_Display_CommunicationState.Visible)
            {
                PanelCommunicationDisplay();
            }

            if (panel_Display_Log.Visible)
            {
                PanelLogDisplay();
            }

        }


        //메인창 화면 출력
        private void PanelMainDisplay()
        {

            //선택된 탭 화면만 갱신함.
            if (tabControl_Main.SelectedIndex == 0)
            {
                //시스템 상태 탭

                if (textBox_MainInitLog.Text != ServerInitLog.ToString())
                {
                    textBox_MainInitLog.Text = ServerInitLog.ToString();
                    textBox_MainInitLog.Select(textBox_MainInitLog.Text.Length, 0);
                    textBox_MainInitLog.ScrollToCaret();
                }

                StringBuilder tempSTB = new StringBuilder();
                if (UDPCommclass != null) tempSTB.Append(UDPCommclass.UDPInitLog.ToString());
                if (IOclass != null) tempSTB.Append(IOclass.IOInitLog.ToString());
                if (IMUclass != null) tempSTB.Append(IMUclass.IMUInitLog.ToString());
                if (DistanceSensorclass != null) tempSTB.Append(DistanceSensorclass.DistanceInitLog.ToString());
                if (RobotCommclass != null) tempSTB.Append(RobotCommclass.RobotInitLog.ToString());

                if (textBox_SubInitLog.Text != tempSTB.ToString())
                {
                    textBox_SubInitLog.Text = tempSTB.ToString();
                    textBox_SubInitLog.Select(textBox_SubInitLog.Text.Length, 0);
                    textBox_SubInitLog.ScrollToCaret();
                }


                if (RobotCommclass != null)
                {
                    textBox_SystemStateRobotControlSeq.Text = RobotCommclass.RobotControlThreadSeq.ToString();
                    textBox_SystemStateRobotInit.Text = RobotCommclass.RobotInitState.ToString();
                    textBox_SystemStateRobotMoni.Text = RobotCommclass.RobotMoniState.ToString();
                    textBox_SystemStateRobotControl.Text = RobotCommclass.RobotControlState.ToString();
                }

                textBox_SystemStateMainSeq.Text = MainSequence;

                textBox_SystemStateCellWeldMain.Text = AutoSequenceState;
                textBox_SystemStateCellWeldDT.Text = AutoDTSubSeq;
                textBox_SystemStateCellWeldDTBuff.Text = AutoDTSubSeq_Buffer;
                textBox_SystemStateCellWeldTouch.Text = AutoTSSubSeq;
                textBox_SystemStateCellWeldWelding.Text = AutoWeldingSubState;

                textBox_SystemStateSampleWeldMain.Text = SampleSequenceState;
                textBox_SystemStateSampleWeldDT.Text = SampleDTSubSeq;
                textBox_SystemStateSampleWeldDTBuff.Text = SampleDTSubSeq_Buffer;
                textBox_SystemStateSampleWeldTouch.Text = SampleTSSubSeq;
                textBox_SystemStateSampleWeldWelding.Text = SampleWeldingSubState;

                textBox_SystemStateManualMainSeq.Text = ManualSequenceState;
                textBox_SystemStateManualWireCut.Text = WirecutState;
                textBox_SystemStateManualTCPCheck.Text = TCPCheckMotionState;


            }
            else if (tabControl_Main.SelectedIndex == 1)
            {
                //셀용접 탭
                string[] tempstrarr = MainLog_ReadBlock(100);
                string tempstr = "";

                for (int i = 1; i < tempstrarr.Length + 1; i++)
                {
                    int j = tempstrarr.Length - i;
                    tempstr = tempstr + tempstrarr[j] + Environment.NewLine;
                }
                if (textBox_MainLog1.Text != tempstr)
                {
                    textBox_MainLog1.Text = tempstr;
                }

                //직접교시중 이면 현재 단계에 해당하는 버튼 하일라이트처리
                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    if (AutoDTSubSeq.Split(' ')[0].Contains("L"))
                    {
                        tempstr = AutoDTSubSeq.Split(' ')[0].Replace("L", "");
                        int tempi = 0;
                        try
                        {
                            tempi = Convert.ToInt32(tempstr) + 1;
                        }
                        catch
                        {

                        }

                        for (int i = 1; i < 9; i++)
                        {
                            if (tempi == i)
                            {
                                if ((groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor != SystemColors.Highlight)
                                {
                                    (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor = SystemColors.Highlight;
                                }

                            }
                            else
                            {
                                if ((groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                                {
                                    (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                                    (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                                }
                            }

                        }

                    }
                    else
                    {
                        for (int i = 1; i < 9; i++)
                        {
                            if ((groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                            {
                                (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                                (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                            }
                        }

                    }


                    if (AutoDTSubSeq.Split(' ')[0].Contains("R"))
                    {
                        tempstr = AutoDTSubSeq.Split(' ')[0].Replace("R", "");
                        int tempi = 0;
                        try
                        {
                            tempi = Convert.ToInt32(tempstr) + 1;
                        }
                        catch
                        {

                        }

                        for (int i = 1; i < 9; i++)
                        {
                            if (tempi == i)
                            {
                                if ((groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor != SystemColors.Highlight)
                                {
                                    (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor = SystemColors.Highlight;
                                }

                            }
                            else
                            {
                                if ((groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                                {
                                    (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                                    (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 1; i < 9; i++)
                        {
                            if ((groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                            {
                                (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                                (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                            }
                        }

                    }
                }
                else
                {
                    for (int i = 1; i < 9; i++)
                    {
                        if ((groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                        {
                            (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                            (groupBox_AutoWeldDT.Controls["button_DTLeft" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                        }

                        if ((groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                        {
                            (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                            (groupBox_AutoWeldDT.Controls["button_DTRight" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                        }
                    }

                }

                //직접교시 기록데이터 표시
                for (int i = 0; i < 8; i++)
                {
                    tempstr = AutoWeld_DTPoint_Left_TCPPose[i].f1.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Left_TCPPose[i].f2.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Left_TCPPose[i].f3.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Left_TCPPose[i].f4.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Left_TCPPose[i].f5.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Left_TCPPose[i].f6.ToString("0.0");

                    if ((groupBox_AutoWeldDT.Controls["textBox_DTLeft" + Convert.ToString(i + 1)] as TextBox).Text != tempstr)
                    {
                        (groupBox_AutoWeldDT.Controls["textBox_DTLeft" + Convert.ToString(i + 1)] as TextBox).Text = tempstr;
                    }

                    tempstr = AutoWeld_DTPoint_Right_TCPPose[i].f1.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Right_TCPPose[i].f2.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Right_TCPPose[i].f3.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Right_TCPPose[i].f4.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Right_TCPPose[i].f5.ToString("0.0") + ", " +
                                AutoWeld_DTPoint_Right_TCPPose[i].f6.ToString("0.0");

                    if ((groupBox_AutoWeldDT.Controls["textBox_DTRight" + Convert.ToString(i + 1)] as TextBox).Text != tempstr)
                    {
                        (groupBox_AutoWeldDT.Controls["textBox_DTRight" + Convert.ToString(i + 1)] as TextBox).Text = tempstr;
                    }
                }

                textBox_WeldVol1.Text = RobotCommclass.Arc_AnalogToVol(RobotDataEX.moni_RobotIOValueAO[0]).ToString("0.00");
                textBox_WeldAmp1.Text = RobotCommclass.Arc_AnalogToAmp(RobotDataEX.moni_RobotIOValueAO[1]).ToString("0.0");




            }
            else if (tabControl_Main.SelectedIndex == 2)
            {   //단독용접탭
                string[] tempstrarr = MainLog_ReadBlock(100);
                string tempstr = "";

                for (int i = 1; i < tempstrarr.Length + 1; i++)
                {
                    int j = tempstrarr.Length - i;
                    tempstr = tempstr + tempstrarr[j] + Environment.NewLine;
                }
                if (textBox_MainLog2.Text != tempstr)
                {
                    textBox_MainLog2.Text = tempstr;
                }

                textBox_WeldVol2.Text = RobotCommclass.Arc_AnalogToVol(RobotDataEX.moni_RobotIOValueAO[0]).ToString("0.00");
                textBox_WeldAmp2.Text = RobotCommclass.Arc_AnalogToAmp(RobotDataEX.moni_RobotIOValueAO[1]).ToString("0.0");


                //단독작업 직접교시중이면 현재단계 하일라이트표시
                if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    if (SampleDTSubSeq.Split(' ')[0].Contains("DT"))
                    {
                        tempstr = SampleDTSubSeq.Split(' ')[0].Replace("DT", "");
                        int tempi = 0;
                        try
                        {
                            tempi = Convert.ToInt32(tempstr);
                        }
                        catch
                        {
                            tempi = 8;
                        }

                        for (int i = 0; i < 8; i++)
                        {
                            if (tempi == i)
                            {
                                if ((groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor != SystemColors.Highlight)
                                {
                                    (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor = SystemColors.Highlight;
                                }

                            }
                            else
                            {
                                if ((groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                                {
                                    (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                                    (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                                }
                            }

                        }

                    }
                    else
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            if ((groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                            {
                                (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                                (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                            }
                        }

                    }
                }
                else
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if ((groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor != SystemColors.Control)
                        {
                            (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).BackColor = SystemColors.Control;
                            (groupBox_SampleWeldDT.Controls["button_DTSample" + Convert.ToString(i)] as Button).UseVisualStyleBackColor = true;
                        }
                    }
                }

                //직접교시 기록데이터 표시
                for (int i = 0; i < 8; i++)
                {
                    tempstr = SampleWeld_DTPoint_TCPPose[i].f1.ToString("0.0") + ", " +
                                SampleWeld_DTPoint_TCPPose[i].f2.ToString("0.0") + ", " +
                                SampleWeld_DTPoint_TCPPose[i].f3.ToString("0.0") + ", " +
                                SampleWeld_DTPoint_TCPPose[i].f4.ToString("0.0") + ", " +
                                SampleWeld_DTPoint_TCPPose[i].f5.ToString("0.0") + ", " +
                                SampleWeld_DTPoint_TCPPose[i].f6.ToString("0.0");

                    if ((groupBox_SampleWeldDT.Controls["textBox_DTSample" + Convert.ToString(i)] as TextBox).Text != tempstr)
                    {
                        (groupBox_SampleWeldDT.Controls["textBox_DTSample" + Convert.ToString(i)] as TextBox).Text = tempstr;
                    }
                }

            }
            else if (tabControl_Main.SelectedIndex == 3)
            {
                //수동작업 탭


                switch (RobotCommclass.RobotInitState)
                {
                    case -1:
                        textBox_SystemStateConnect_1.Text = "로봇 접속 끊김";
                        break;
                    case 0:
                        textBox_SystemStateConnect_1.Text = "접속 대기상태";
                        break;
                    case 1:
                        textBox_SystemStateConnect_1.Text = "접속 시도중...";
                        break;
                    case 2:
                        textBox_SystemStateConnect_1.Text = "접속 시도중...";
                        break;
                    case 3:
                        textBox_SystemStateConnect_1.Text = "로봇 접속 완료";
                        break;
                    case 4:
                        textBox_SystemStateConnect_1.Text = "로봇 접속 끊김";
                        break;
                    case 5:
                        textBox_SystemStateConnect_1.Text = "로봇 접속 끊김";
                        break;
                    case 100:
                        textBox_SystemStateConnect_1.Text = "로봇 접속 완료";
                        break;
                    default:
                        break;
                }

                switch (RobotCommclass.RobotMoniState)
                {
                    case -1:
                        textBox_SystemStateMoni_1.Text = "로봇 접속 끊김";
                        break;
                    case 0:
                        textBox_SystemStateMoni_1.Text = "접속 대기상태";
                        break;
                    case 1:
                        textBox_SystemStateMoni_1.Text = "모니터링 실행중";
                        break;
                    case 2:
                        textBox_SystemStateMoni_1.Text = "모니터링 실행중";
                        break;
                    case 3:
                        textBox_SystemStateMoni_1.Text = "로봇 접속 끊김";
                        break;
                    default:
                        break;
                }


                switch (RobotCommclass.RobotControlState)
                {
                    case -1:
                        textBox_SystemStateControl1_1.Text = "로봇 접속 끊김";
                        break;
                    case 0:
                        textBox_SystemStateControl1_1.Text = "접속 대기상태";
                        break;
                    case 1:
                        textBox_SystemStateControl1_1.Text = "컨트롤 실행중";
                        break;
                    case 2:
                        textBox_SystemStateControl1_1.Text = "컨트롤 실행중";
                        break;
                    case 3:
                        textBox_SystemStateControl1_1.Text = "로봇 접속 끊김";
                        break;
                    default:
                        break;
                }

                switch (RobotCommclass.RobotControlThreadSeq)
                {
                    case 0:
                        textBox_SystemStateControl2_1.Text = "에러상태. 에러리셋 대기중";
                        break;
                    case 1:
                        textBox_SystemStateControl2_1.Text = "에러리셋 실행";
                        break;
                    case 2:
                        textBox_SystemStateControl2_1.Text = "서보온 대기중";
                        break;
                    case 3:
                        textBox_SystemStateControl2_1.Text = "속도 리미트 설정";
                        break;
                    case 4:
                        textBox_SystemStateControl2_1.Text = "속도펙터 설정";
                        break;
                    case 5:
                        textBox_SystemStateControl2_1.Text = "바운더리 설정";
                        break;
                    case 6:
                        textBox_SystemStateControl2_1.Text = "툴 무게 설정";
                        break;
                    case 7:
                        textBox_SystemStateControl2_1.Text = "툴 무게중심 설정";
                        break;
                    case 8:
                        textBox_SystemStateControl2_1.Text = "설치정보 설정";
                        break;
                    case 9:
                        textBox_SystemStateControl2_1.Text = "TCP정보 설정";
                        break;
                    case 10:
                        textBox_SystemStateControl2_1.Text = "로봇 서보온 실행";
                        break;
                    case 15:
                        textBox_SystemStateControl2_1.Text = "사용자 명령 대기";
                        break;
                    case 20:
                        textBox_SystemStateControl2_1.Text = "로봇모션 실행중";
                        break;
                    case 50:
                        textBox_SystemStateControl2_1.Text = "직접교시 실행중";
                        break;
                    case 1000:
                        textBox_SystemStateControl2_1.Text = "에러 - 비상정지 발생";
                        break;
                    case 1001:
                        textBox_SystemStateControl2_1.Text = "에러 - 충돌감지 발생";
                        break;
                    case 1002:
                        textBox_SystemStateControl2_1.Text = "에러 - 안전설정 위반";
                        break;
                    default:
                        break;
                }


                string[] tempstrarr = RobotCommclass.RobotControlStr_ReadBlock(40);
                string tempstr = "";

                for (int i = 1; i < tempstrarr.Length + 1; i++)
                {
                    int j = tempstrarr.Length - i;
                    tempstr = tempstr + tempstrarr[j] + Environment.NewLine;
                }
                if (textBox_RobotControlLog_1.Text != tempstr) textBox_RobotControlLog_1.Text = tempstr;

                textBox_RobotJointAngle1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
                textBox_RobotJointAngle2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
                textBox_RobotJointAngle3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
                textBox_RobotJointAngle4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
                textBox_RobotJointAngle5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
                textBox_RobotJointAngle6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");

                textBox_RobotTCPPose1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
                textBox_RobotTCPPose2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
                textBox_RobotTCPPose3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
                textBox_RobotTCPPose4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
                textBox_RobotTCPPose5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
                textBox_RobotTCPPose6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");

                textBox_WeldVol0.Text = RobotCommclass.Arc_AnalogToVol(RobotDataEX.moni_RobotIOValueAO[0]).ToString("0.00");
                textBox_WeldAmp0.Text = RobotCommclass.Arc_AnalogToAmp(RobotDataEX.moni_RobotIOValueAO[1]).ToString("0.0");
            }

        }
        //로봇창 화면 출력
        private void PanelRobotDisplay()
        {
            //현재 선택되어 있는 페이지 화면만 갱신함. 성능 위해
            if (tabControl_Robot.SelectedIndex==0)
            {
                //로봇 상태탭

                //로봇 접속로그 출력
                if (textBox_RobotInitLog.Text != RobotCommclass.RobotInitLog.ToString()) textBox_RobotInitLog.Text = RobotCommclass.RobotInitLog.ToString();

                //로봇 모니터링 에러메세지 출력
                if (textBox_RobotMoniErrorLog.Text != RobotCommclass.RobotMonitoringErrorList.ToString()) textBox_RobotMoniErrorLog.Text = RobotCommclass.RobotMonitoringErrorList.ToString();

                //로봇 컨트롤로그 출력
                string[] tempstrarr1 = RobotCommclass.RobotControlStr_ReadBlock(30);
                string tempstr = "";
                for (int i = 1; i < tempstrarr1.Length + 1; i++)
                {
                    int j = tempstrarr1.Length - i;
                    tempstr = tempstr + tempstrarr1[j] + Environment.NewLine;
                }
                if (textBox_RobotControlLog_2.Text != tempstr) textBox_RobotControlLog_2.Text = tempstr;

                textBox_RobotCommTime.Text = RobotDataEX.moni_RobotCommTime.ToString("yyyyMMdd-HH:mm:ss.fff");

                if (RobotDataEX.moni_RobotCommunicationState == 0)
                {
                    textBox_RobotCommState.Text = "통신 연결";
                }
                else if (RobotDataEX.moni_RobotCommunicationState == 1)
                {
                    textBox_RobotCommState.Text = "통신 안됨";
                }
                else
                {
                    textBox_RobotCommState.Text = "정의되지 않은 상태값";
                }

                textBox_RobotAPIVersion.Text = Convert.ToString(RobotDataEX.moni_RobotAPIVersion);

                if (RobotDataEX.moni_RobotEmergencyState == 0)
                {
                    textBox_RobotEmergencyState.Text = "정상";
                }
                else if (RobotDataEX.moni_RobotEmergencyState == 1)
                {
                    textBox_RobotEmergencyState.Text = "비상정지 상태";
                }
                else
                {
                    textBox_RobotEmergencyState.Text = "정의되지 않은 상태값";
                }

                if (RobotDataEX.moni_RobotSafetyState == 0)
                {
                    textBox_RobotSafetyState.Text = "정상";
                }
                else if (RobotDataEX.moni_RobotSafetyState == 1)
                {
                    textBox_RobotSafetyState.Text = "안전설정 위반";
                }
                else
                {
                    textBox_RobotSafetyState.Text = "정의되지 않은 상태값";
                }

                if (RobotDataEX.moni_RobotDirectTeachingState == 0)
                {
                    textBox_RobotDirectTeachingState.Text = "직접교시 On";
                }
                else if (RobotDataEX.moni_RobotDirectTeachingState == 1)
                {
                    textBox_RobotDirectTeachingState.Text = "직접교시 Off";
                }
                else
                {
                    textBox_RobotDirectTeachingState.Text = "정의되지 않은 상태값";
                }

                if (RobotDataEX.moni_RobotServoOnState == 0)
                {
                    textBox_RobotServoOnState.Text = "서보모터 On";
                }
                else if (RobotDataEX.moni_RobotServoOnState == 1)
                {
                    textBox_RobotServoOnState.Text = "서보모터 Off";
                }
                else
                {
                    textBox_RobotServoOnState.Text = "정의되지 않은 상태값";
                }

                if (RobotDataEX.moni_RobotMotionState == 0)
                {
                    textBox_RobotMotionState.Text = "대기상태";
                }
                else if (RobotDataEX.moni_RobotMotionState == 1)
                {
                    textBox_RobotMotionState.Text = "모션 실행중";
                }
                else if (RobotDataEX.moni_RobotMotionState == 2)
                {
                    textBox_RobotMotionState.Text = "일시정지 중";
                }
                else if (RobotDataEX.moni_RobotMotionState == 3)
                {
                    textBox_RobotMotionState.Text = "일시정지 완료";
                }
                else if (RobotDataEX.moni_RobotMotionState == 4)
                {
                    textBox_RobotMotionState.Text = "정지 중";
                }
                else if (RobotDataEX.moni_RobotMotionState == 5)
                {
                    textBox_RobotMotionState.Text = "정지 완료";
                }
                else
                {
                    textBox_RobotMotionState.Text = "정의되지 않은 상태값";
                }


                switch (RobotCommclass.RobotInitState)
                {
                    case -1:
                        textBox_SystemStateConnect_2.Text = "로봇 접속 끊김";
                        break;
                    case 0:
                        textBox_SystemStateConnect_2.Text = "접속 대기상태";
                        break;
                    case 1:
                        textBox_SystemStateConnect_2.Text = "접속 시도중...";
                        break;
                    case 2:
                        textBox_SystemStateConnect_2.Text = "접속 시도중...";
                        break;
                    case 3:
                        textBox_SystemStateConnect_2.Text = "로봇 접속 완료";
                        break;
                    case 4:
                        textBox_SystemStateConnect_2.Text = "로봇 접속 끊김";
                        break;
                    case 5:
                        textBox_SystemStateConnect_2.Text = "로봇 접속 끊김";
                        break;
                    case 100:
                        textBox_SystemStateConnect_2.Text = "로봇 접속 완료";
                        break;
                    default:
                        break;
                }

                switch (RobotCommclass.RobotMoniState)
                {
                    case -1:
                        textBox_SystemStateMoni_2.Text = "로봇 접속 끊김";
                        break;
                    case 0:
                        textBox_SystemStateMoni_2.Text = "접속 대기상태";
                        break;
                    case 1:
                        textBox_SystemStateMoni_2.Text = "모니터링 실행중";
                        break;
                    case 2:
                        textBox_SystemStateMoni_2.Text = "모니터링 실행중";
                        break;
                    case 3:
                        textBox_SystemStateMoni_2.Text = "로봇 접속 끊김";
                        break;
                    default:
                        break;
                }


                switch (RobotCommclass.RobotControlState)
                {
                    case -1:
                        textBox_SystemStateControl1_2.Text = "로봇 접속 끊김";
                        break;
                    case 0:
                        textBox_SystemStateControl1_2.Text = "접속 대기상태";
                        break;
                    case 1:
                        textBox_SystemStateControl1_2.Text = "컨트롤 실행중";
                        break;
                    case 2:
                        textBox_SystemStateControl1_2.Text = "컨트롤 실행중";
                        break;
                    case 3:
                        textBox_SystemStateControl1_2.Text = "로봇 접속 끊김";
                        break;
                    default:
                        break;
                }

                switch (RobotCommclass.RobotControlThreadSeq)
                {
                    case 0:
                        textBox_SystemStateControl2_2.Text = "에러상태. 에러리셋 대기중";
                        break;
                    case 1:
                        textBox_SystemStateControl2_2.Text = "에러리셋 실행";
                        break;
                    case 2:
                        textBox_SystemStateControl2_2.Text = "서보온 대기중";
                        break;
                    case 3:
                        textBox_SystemStateControl2_2.Text = "속도 리미트 설정";
                        break;
                    case 4:
                        textBox_SystemStateControl2_2.Text = "속도펙터 설정";
                        break;
                    case 5:
                        textBox_SystemStateControl2_2.Text = "바운더리 설정";
                        break;
                    case 6:
                        textBox_SystemStateControl2_2.Text = "툴 무게 설정";
                        break;
                    case 7:
                        textBox_SystemStateControl2_2.Text = "툴 무게중심 설정";
                        break;
                    case 8:
                        textBox_SystemStateControl2_2.Text = "설치정보 설정";
                        break;
                    case 9:
                        textBox_SystemStateControl2_2.Text = "TCP정보 설정";
                        break;
                    case 10:
                        textBox_SystemStateControl2_2.Text = "로봇 서보온 실행";
                        break;
                    case 15:
                        textBox_SystemStateControl2_2.Text = "사용자 명령 대기";
                        break;
                    case 20:
                        textBox_SystemStateControl2_2.Text = "로봇모션 실행중";
                        break;
                    case 50:
                        textBox_SystemStateControl2_2.Text = "직접교시 실행중";
                        break;
                    case 1000:
                        textBox_SystemStateControl2_2.Text = "에러 - 비상정지 발생";
                        break;
                    case 1001:
                        textBox_SystemStateControl2_2.Text = "에러 - 충돌감지 발생";
                        break;
                    case 1002:
                        textBox_SystemStateControl2_2.Text = "에러 - 안전설정 위반";
                        break;
                    default:
                        break;
                }


            }
            else if (tabControl_Robot.SelectedIndex == 1)
            {
                //로봇 모니터링 탭

                byte tempbyte1, tempbyte2;
                tempbyte1 = RobotDataEX.moni_RobotIOValueDI;
                tempbyte2 = RobotDataEX.moni_RobotIOValueDO;
                for (int i = 0; i < 8; i++)
                {
                    (groupBox_RobotDIO.Controls["textBox_RobotIOValueDI" + Convert.ToString(i)] as TextBox).Text = Convert.ToString(tempbyte1 % 2);
                    (groupBox_RobotDIO.Controls["textBox_RobotIOValueDO" + Convert.ToString(i)] as TextBox).Text = Convert.ToString(tempbyte2 % 2);
                    tempbyte1 = (byte)(tempbyte1 >> 1);
                    tempbyte2 = (byte)(tempbyte2 >> 1);
                }
                textBox_RobotIOValueAI0.Text = Convert.ToString(RobotDataEX.moni_RobotIOValueAI[0]);
                textBox_RobotIOValueAI1.Text = Convert.ToString(RobotDataEX.moni_RobotIOValueAI[1]);
                textBox_RobotIOValueAO0.Text = Convert.ToString(RobotDataEX.moni_RobotIOValueAO[0]);
                textBox_RobotIOValueAO1.Text = Convert.ToString(RobotDataEX.moni_RobotIOValueAO[1]);

                tempbyte1 = RobotDataEX.moni_RobotToolIOValueDI;
                tempbyte2 = RobotDataEX.moni_RobotToolIOValueDO;
                for (int i = 0; i < 4; i++)
                {
                    (groupBox_RobotToolDIO.Controls["textBox_RobotToolIOValueDI" + Convert.ToString(i)] as TextBox).Text = Convert.ToString(tempbyte1 % 2);
                    (groupBox_RobotToolDIO.Controls["textBox_RobotToolIOValueDO" + Convert.ToString(i)] as TextBox).Text = Convert.ToString(tempbyte2 % 2);
                    tempbyte1 = (byte)(tempbyte1 >> 1);
                    tempbyte2 = (byte)(tempbyte2 >> 1);
                }
                textBox_RobotToolIOValueAI0.Text = Convert.ToString(RobotDataEX.moni_RobotToolIOValueAI[0]);
                textBox_RobotToolIOValueAI1.Text = Convert.ToString(RobotDataEX.moni_RobotToolIOValueAI[1]);

                for (int i = 1; i < 7; i++)
                {
                    (groupBox_RobotMotion.Controls["textBox_RobotTCPCommandPose" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotTCPCommandPose[i - 1]);
                    (groupBox_RobotMotion.Controls["textBox_RobotTCPActualPose" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotTCPActualPose[i - 1]);
                    (groupBox_RobotMotion.Controls["textBox_RobotJointCommandAngle" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotJointCommandAngle[i - 1]);
                    (groupBox_RobotMotion.Controls["textBox_RobotJointActualAngle" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotJointActualAngle[i - 1]);

                    (groupBox_RobotMotor.Controls["textBox_RobotJointTmp" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotJointTmp[i - 1]);
                    (groupBox_RobotMotor.Controls["textBox_RobotJointVol" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotJointVol[i - 1]);
                    (groupBox_RobotMotor.Controls["textBox_RobotJointAmp" + Convert.ToString(i)] as TextBox).Text
                        = Convert.ToString(RobotDataEX.moni_RobotJointAmp[i - 1]);
                }


                if (RobotDataEX.moni_RobotMountingSerface == 0)
                {
                    textBox_RobotMountingSerface.Text = "바닥";
                }
                else if (RobotDataEX.moni_RobotMountingSerface == 1)
                {
                    textBox_RobotMountingSerface.Text = "벽";
                }
                else if (RobotDataEX.moni_RobotMountingSerface == 2)
                {
                    textBox_RobotMountingSerface.Text = "천장";
                }
                else
                {
                    textBox_RobotMountingSerface.Text = "정의되지 않은 상태값";
                }

                textBox_RobotMountingAngleRx.Text = RobotDataEX.moni_RobotMountingAngle[0].ToString("0.00");
                textBox_RobotMountingAngleRy.Text = RobotDataEX.moni_RobotMountingAngle[1].ToString("0.00");

                for (int i = 0; i < 6; i++)
                {
                    (groupBox_RobotTCP.Controls["textBox_RobotFlangeToTCP" + Convert.ToString(i + 1)] as TextBox).Text
                        = RobotDataEX.moni_RobotFlangeToTCP[i].ToString("0.00");
                    (groupBox_RobotCollision.Controls["textBox_RobotCollisionDetectionJointLimit" + Convert.ToString(i + 1)] as TextBox).Text
                        = RobotDataEX.moni_RobotCollisionDetectionJointLimit[i].ToString("0.00");
                }

                textBox_RobotTCPPayload.Text = RobotDataEX.moni_RobotTCPPayload.ToString("0.00");
                textBox_RobotTCPMassCenterX.Text = RobotDataEX.moni_RobotTCPMassCenter[0].ToString("0.00");
                textBox_RobotTCPMassCenterY.Text = RobotDataEX.moni_RobotTCPMassCenter[1].ToString("0.00");
                textBox_RobotTCPMassCenterZ.Text = RobotDataEX.moni_RobotTCPMassCenter[2].ToString("0.00");

                if (RobotDataEX.moni_RobotSafetySwitchState == 0)
                {
                    textBox_RobotSafetySwitchState.Text = "안전스위치 켜짐";
                }
                else if (RobotDataEX.moni_RobotSafetySwitchState == 1)
                {
                    textBox_RobotSafetySwitchState.Text = "안전스위치 꺼짐";
                }
                else
                {
                    textBox_RobotSafetySwitchState.Text = "정의되지 않은 상태값";
                }


            }
            else if (tabControl_Robot.SelectedIndex == 2)
            {
                //로봇 통신로그 탭
                RobotEventData[] tempREData = RobotCommclass.RobotEventLog_ReadBlock(100);

                StringBuilder tempSB = new StringBuilder();

                for (int i = 0; i < tempREData.Length; i++)
                {
                    int j = tempREData.Length - (i + 1);


                    switch (tempREData[j].eventMainGroup)
                    {
                        case (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED:
                            tempSB.AppendLine(tempREData[j].eventTime.ToString("yyyyMMdd-HH:mm:ss.fff") + "   CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED    "
                                                + Enum.GetName(typeof(CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED), tempREData[j].eventSubGroup) + tempREData[j].eventComment);
                            break;

                        case (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ERROR:
                            tempSB.AppendLine(tempREData[j].eventTime.ToString("yyyyMMdd-HH:mm:ss.fff") + "   CLINK_EVENT_GRP_ERROR    "
                                                + Enum.GetName(typeof(CLINK_EVENT_SUBGRP_ERROR), tempREData[j].eventSubGroup) + tempREData[j].eventComment);
                            break;

                        case (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND:
                            tempSB.AppendLine(tempREData[j].eventTime.ToString("yyyyMMdd-HH:mm:ss.fff") + "   CLINK_EVENT_GRP_MOTION_COMMAND    "
                                                + Enum.GetName(typeof(CLINK_EVENT_SUBGRP_MOTION_COMMAND), tempREData[j].eventSubGroup) + tempREData[j].eventComment);
                            break;

                        case (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_COLLISION_DETECTED:
                            tempSB.AppendLine(tempREData[j].eventTime.ToString("yyyyMMdd-HH:mm:ss.fff") + "   CLINK_EVENT_GRP_ROBOT_COLLISION_DETECTED    "
                                                + Enum.GetName(typeof(CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED), tempREData[j].eventSubGroup) + tempREData[j].eventComment);
                            break;

                        case (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED:
                            tempSB.AppendLine(tempREData[j].eventTime.ToString("yyyyMMdd-HH:mm:ss.fff") + "   CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED    "
                                                + Enum.GetName(typeof(CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED), tempREData[j].eventSubGroup) + tempREData[j].eventComment);
                            break;

                        case (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED:
                            tempSB.AppendLine(tempREData[j].eventTime.ToString("yyyyMMdd-HH:mm:ss.fff") + "   CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED    "
                                                + Enum.GetName(typeof(CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED), tempREData[j].eventSubGroup) + tempREData[j].eventComment);
                            break;

                        default:
                            break;

                    }

                }

                textBox_RobotEventLog.Text = tempSB.ToString();


                //로봇 펑션콜 로그 출력
                if (checkBox_RobotFuncCallMoni1.Checked == false)
                {
                    string[] tempstrarr1 = RobotCommclass.RobotFuncCallLog1_ReadBlock(50);
                    string tempstr = "";
                    for (int i = 1; i < tempstrarr1.Length + 1; i++)
                    {
                        int j = tempstrarr1.Length - i;
                        tempstr = tempstr + tempstrarr1[j] + Environment.NewLine;
                    }
                    if (textBox_RobotFuncCallLog1.Text != tempstr) textBox_RobotFuncCallLog1.Text = tempstr;
                }

                if (checkBox_RobotFuncCallMoni2.Checked == false)
                {
                    string[] tempstrarr1 = RobotCommclass.RobotFuncCallLog2_ReadBlock(50);
                    string tempstr = "";
                    for (int i = 1; i < tempstrarr1.Length + 1; i++)
                    {
                        int j = tempstrarr1.Length - i;
                        tempstr = tempstr + tempstrarr1[j] + Environment.NewLine;
                    }
                    if (textBox_RobotFuncCallLog2.Text != tempstr) textBox_RobotFuncCallLog2.Text = tempstr;
                }
            }





        }
        //주변장치창 화면 출력
        private void PanelDeviceDisplay()
        {
            string tempstr = "";

            if (textBox_IOModule_State1.Text != IOclass.IOCommunicationSeq) textBox_IOModule_State1.Text = IOclass.IOCommunicationSeq;

            if (IODataEX.IOModuleMonitoringDI[0] == 1) textBox_IOModule_DI10.Text = "1"; else textBox_IOModule_DI10.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[1] == 1) textBox_IOModule_DI11.Text = "1"; else textBox_IOModule_DI11.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[2] == 1) textBox_IOModule_DI12.Text = "1"; else textBox_IOModule_DI12.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[3] == 1) textBox_IOModule_DI13.Text = "1"; else textBox_IOModule_DI13.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[4] == 1) textBox_IOModule_DI14.Text = "1"; else textBox_IOModule_DI14.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[5] == 1) textBox_IOModule_DI15.Text = "1"; else textBox_IOModule_DI15.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[6] == 1) textBox_IOModule_DI16.Text = "1"; else textBox_IOModule_DI16.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[7] == 1) textBox_IOModule_DI17.Text = "1"; else textBox_IOModule_DI17.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[8] == 1) textBox_IOModule_DI20.Text = "1"; else textBox_IOModule_DI20.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[9] == 1) textBox_IOModule_DI21.Text = "1"; else textBox_IOModule_DI21.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[10] == 1) textBox_IOModule_DI22.Text = "1"; else textBox_IOModule_DI22.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[11] == 1) textBox_IOModule_DI23.Text = "1"; else textBox_IOModule_DI23.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[12] == 1) textBox_IOModule_DI24.Text = "1"; else textBox_IOModule_DI24.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[13] == 1) textBox_IOModule_DI25.Text = "1"; else textBox_IOModule_DI25.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[14] == 1) textBox_IOModule_DI26.Text = "1"; else textBox_IOModule_DI26.Text = "0";
            if (IODataEX.IOModuleMonitoringDI[15] == 1) textBox_IOModule_DI27.Text = "1"; else textBox_IOModule_DI27.Text = "0";
            
            if (IODataEX.IOModuleMonitoringDO[0] == 1) textBox_IOModule_DO10.Text = "1"; else textBox_IOModule_DO10.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[1] == 1) textBox_IOModule_DO11.Text = "1"; else textBox_IOModule_DO11.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[2] == 1) textBox_IOModule_DO12.Text = "1"; else textBox_IOModule_DO12.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[3] == 1) textBox_IOModule_DO13.Text = "1"; else textBox_IOModule_DO13.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[4] == 1) textBox_IOModule_DO14.Text = "1"; else textBox_IOModule_DO14.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[5] == 1) textBox_IOModule_DO15.Text = "1"; else textBox_IOModule_DO15.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[6] == 1) textBox_IOModule_DO16.Text = "1"; else textBox_IOModule_DO16.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[7] == 1) textBox_IOModule_DO17.Text = "1"; else textBox_IOModule_DO17.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[8] == 1) textBox_IOModule_DO20.Text = "1"; else textBox_IOModule_DO20.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[9] == 1) textBox_IOModule_DO21.Text = "1"; else textBox_IOModule_DO21.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[10] == 1) textBox_IOModule_DO22.Text = "1"; else textBox_IOModule_DO22.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[11] == 1) textBox_IOModule_DO23.Text = "1"; else textBox_IOModule_DO23.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[12] == 1) textBox_IOModule_DO24.Text = "1"; else textBox_IOModule_DO24.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[13] == 1) textBox_IOModule_DO25.Text = "1"; else textBox_IOModule_DO25.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[14] == 1) textBox_IOModule_DO26.Text = "1"; else textBox_IOModule_DO26.Text = "0";
            if (IODataEX.IOModuleMonitoringDO[15] == 1) textBox_IOModule_DO27.Text = "1"; else textBox_IOModule_DO27.Text = "0";


            if (textBox_IMUSTATE.Text != IMUclass.IMUCommunicationSeq) textBox_IMUSTATE.Text = IMUclass.IMUCommunicationSeq;
            if (textBox_IMUTMP.Text != IMUDataEX.IMUModuleTmp.ToString("0.00")) textBox_IMUTMP.Text = IMUDataEX.IMUModuleTmp.ToString("0.00");
            if (textBox_IMUACC1.Text != IMUDataEX.IMUModuleAcc[0].ToString("0.00")) textBox_IMUACC1.Text = IMUDataEX.IMUModuleAcc[0].ToString("0.00");
            if (textBox_IMUACC2.Text != IMUDataEX.IMUModuleAcc[1].ToString("0.00")) textBox_IMUACC2.Text = IMUDataEX.IMUModuleAcc[1].ToString("0.00");
            if (textBox_IMUACC3.Text != IMUDataEX.IMUModuleAcc[2].ToString("0.00")) textBox_IMUACC3.Text = IMUDataEX.IMUModuleAcc[2].ToString("0.00");
            if (textBox_IMUGYR1.Text != IMUDataEX.IMUModuleGyr[0].ToString("0.00")) textBox_IMUGYR1.Text = IMUDataEX.IMUModuleGyr[0].ToString("0.00");
            if (textBox_IMUGYR2.Text != IMUDataEX.IMUModuleGyr[1].ToString("0.00")) textBox_IMUGYR2.Text = IMUDataEX.IMUModuleGyr[1].ToString("0.00");
            if (textBox_IMUGYR3.Text != IMUDataEX.IMUModuleGyr[2].ToString("0.00")) textBox_IMUGYR3.Text = IMUDataEX.IMUModuleGyr[2].ToString("0.00");
            if (textBox_IMUANG1.Text != IMUDataEX.IMUModuleAng[0].ToString("0.00")) textBox_IMUANG1.Text = IMUDataEX.IMUModuleAng[0].ToString("0.00");
            if (textBox_IMUANG2.Text != IMUDataEX.IMUModuleAng[1].ToString("0.00")) textBox_IMUANG2.Text = IMUDataEX.IMUModuleAng[1].ToString("0.00");
            if (textBox_IMUANG3.Text != IMUDataEX.IMUModuleAng[2].ToString("0.00")) textBox_IMUANG3.Text = IMUDataEX.IMUModuleAng[2].ToString("0.00");
            if (textBox_IMUMAG1.Text != IMUDataEX.IMUModuleMag[0].ToString("0.00")) textBox_IMUMAG1.Text = IMUDataEX.IMUModuleMag[0].ToString("0.00");
            if (textBox_IMUMAG2.Text != IMUDataEX.IMUModuleMag[1].ToString("0.00")) textBox_IMUMAG2.Text = IMUDataEX.IMUModuleMag[1].ToString("0.00");
            if (textBox_IMUMAG3.Text != IMUDataEX.IMUModuleMag[2].ToString("0.00")) textBox_IMUMAG3.Text = IMUDataEX.IMUModuleMag[2].ToString("0.00");


            if (textBox_DISTSTATE.Text != DistanceSensorclass.DistanceCommunicationSeq) textBox_DISTSTATE.Text = DistanceSensorclass.DistanceCommunicationSeq;
            if (textBox_DISBASE1.Text != DistanceSensorDataEX.DistanceSensorValue[0].ToString("0.00")) textBox_DISBASE1.Text = DistanceSensorDataEX.DistanceSensorValue[0].ToString("0.00");


            textBox_IODebug.Text = IOclass.tempmonistr1 + " " + IOclass.tempmonistr2 + " " + IOclass.tempmonistr3;

        }
        //통신창 화면 출력
        private void PanelCommunicationDisplay()
        {
            //UDP 통신로그 출력
            if (checkBox_UDPCommLogStop.Checked == false)
            {
                string[] tempstrarr1 = UDPCommclass.UDPCommunicationLog_ReadBlock(100);
                string tempstr = "";
                for (int i = 1; i < tempstrarr1.Length + 1; i++)
                {
                    int j = tempstrarr1.Length - i;
                    tempstr = tempstr + tempstrarr1[j] + Environment.NewLine;
                }
                if (textBox_UDPCommunicationLog.Text != tempstr) textBox_UDPCommunicationLog.Text = tempstr;
            }
        }
        //이력창 화면 출력
        private void PanelLogDisplay()
        {


        }


        //프로그램 메인시퀀스 동작 타이머
        private void timer_Main_Tick(object sender, EventArgs e)
        {
            //프로그램 시작시 최초 1회는 500ms 대기. 이후에는 20ms 마다 실행됨
            if (timer_Main.Interval > 20) timer_Main.Interval = 20;


            //통신으로 받은 패킷플래그 처리하는부분
            UDPPacketCheck();

            //조작버튼, 비상정지 등 입출력 확인 및 조작부
            IOCheck();

            //로봇 에러체크하는 부분
            ErrorCheck();





            switch(MainSequence)
            {
                case "시작대기":
                    //초기상태. 아무것도 안함
                    break;

                case "초기화-시작":
                    MainLog_Add("서버 초기화 시작.");
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "서버 초기화 시작.");
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "설정파일 로드 시작.");

                    //초기설정 파일 불러오기. 없으면 기본설정으로 파일 생성
                    int result = LoadInitSetting(ProgramInitFileFullPath);
                    if (result == 1)
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "설정파일 로드 완료.");
                        MainSequence = "초기화-타이머";
                    }
                    else if (result == 2)
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "설정파일 없음. 초기 파일 생성.");
                        MainSequence = "초기화-파일로드 실패";
                    }
                    else if (result == 3)
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "설정파일 로드 실패.");
                        MainSequence = "초기화-파일로드 실패";
                    }

                    break;

                case "초기화-파일로드 실패":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "서버 초기화 실패.");
                    MainSequence = "초기화-타이머";
                    break;

                case "초기화-타이머":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "화면 출력 시작.");
                    timer_Display.Enabled = true;
                    MainSequence = "초기화-UDP통신실행";

                    break;

                case "초기화-UDP통신실행":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "UDP 통신기능 초기화 시작.");
                    UDPCommunicationinit();
                    MainSequence = "초기화-UDP통신실행완료 대기";
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "UDP 통신기능 초기화 완료 대기.");

                    break;

                case "초기화-UDP통신실행완료 대기":
                    if (UDPCommclass.udpCommunicationSeq == "초기화 실패")
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "UDP 통신기능 초기화 실패.");
                        MainSequence = "초기화-UDP통신실행 실패";
                    }
                    else if (UDPCommclass.udpCommunicationSeq == "메인반복-시작")
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "UDP 통신기능 초기화 성공.");
                        MainSequence = "초기화-IO모듈";
                    }

                    break;

                case "초기화-UDP통신실행 실패":

                    MainSequence = "초기화-IO모듈";
                    break;

                case "초기화-IO모듈":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IO모듈 초기화 시작.");
                    IOinit();
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IO모듈 초기화 완료 대기.");
                    MainSequence = "초기화-IO모듈 초기화완료 대기";
                    break;

                case "초기화-IO모듈 초기화완료 대기":
                    if (IOclass.IOCommunicationSeq == "초기화-실패")
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IO모듈 초기화 실패.");
                        MainSequence = "초기화-IO모듈 초기화 실패";
                    }
                    else if (IOclass.IOCommunicationSeq.Contains("메인반복"))
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IO모듈 초기화 성공.");
                        MainSequence = "초기화-IMU모듈";
                    }

                    break;

                case "초기화-IO모듈 초기화 실패":

                    MainSequence = "초기화-IMU모듈";
                    break;

                case "초기화-IMU모듈":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IMU모듈 초기화 시작.");
                    IMUinit();
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IMU모듈 초기화 완료 대기.");
                    MainSequence = "초기화-IMU모듈 초기화완료 대기";
                    break;

                case "초기화-IMU모듈 초기화완료 대기":
                    if (IMUclass.IMUCommunicationSeq == "초기화-실패")
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IMU모듈 초기화 실패.");
                        MainSequence = "초기화-IMU모듈 초기화 실패";
                    }
                    else if (IMUclass.IMUCommunicationSeq.Contains("메인반복"))
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "IMU모듈 초기화 성공.");
                        MainSequence = "초기화-거리센서모듈";
                    }

                    break;

                case "초기화-IMU모듈 초기화 실패":

                    MainSequence = "초기화-거리센서모듈";
                    break;

                case "초기화-거리센서모듈":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "거리센서 초기화 시작.");
                    DistanceSensorinit();
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "거리센서 초기화 완료 대기.");
                    MainSequence = "초기화-거리센서모듈 초기화완료 대기";
                    break;

                case "초기화-거리센서모듈 초기화완료 대기":
                    if (DistanceSensorclass.DistanceCommunicationSeq == "초기화-실패")
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "거리센서 초기화 실패.");
                        MainSequence = "초기화-거리센서모듈 초기화 실패";
                    }
                    else if (DistanceSensorclass.DistanceCommunicationSeq == "메인반복-시작")
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "거리센서 초기화 성공.");

                        if (TestEnvFlag == 1)
                        {
                            MainSequence = "초기화-로봇접속 성공";
                        }
                        else
                        {
                            MainSequence = "초기화-로봇접속";
                        }
                        
                    }

                    break;

                case "초기화-거리센서모듈 초기화 실패":
                    if (TestEnvFlag == 1)
                    {
                        MainSequence = "초기화-로봇접속 성공";
                    }
                    else
                    {
                        MainSequence = "초기화-로봇접속";
                    }

                    break;

                case "초기화-로봇접속":
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "로봇 접속 시작.");
                    RobotCommunicationInit();
                    ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "로봇 접속 완료 대기.");
                    MainSequence = "초기화-로봇 접속 완료 대기";
                    break;

                case "초기화-로봇 접속 완료 대기":
                    if (RobotCommclass.RobotInitState == -1)
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "로봇 접속 실패.");
                        MainSequence = "초기화-로봇 접속 실패";
                    }
                    else if (RobotCommclass.RobotInitState == 100)
                    {
                        ServerInitLog.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff-") + "로봇 접속 성공.");
                        MainSequence = "초기화-로봇접속 성공";
                    }

                    break;

                case "초기화-로봇 접속 실패":

                    break;

                case "초기화-로봇접속 성공":
                    MainLog_Add("서버 초기화 성공.");
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-대기":

                    break;

                case "메인반복-셀용접시작":
                    MainLog_Add("셀용접시퀀스 시작.");
                    AutoSequenceState = "셀용접-시작";
                    MainSequence = "메인반복-셀용접";
                    break;

                case "메인반복-셀용접":
                    AutoSequence();

                    if (AutoSequenceState == "셀용접-용접완료")
                    {
                        MainSequence = "메인반복-셀용접정상종료";
                    }
                    else if (AutoSequenceState == "셀용접-용접실패")
                    {
                        MainSequence = "메인반복-셀용접비정상종료";
                    }
                    break;

                case "메인반복-셀용접정상종료":
                    MainLog_Add("셀용접 성공.");
                    AutoSequenceState = "셀용접-대기";
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-셀용접비정상종료":
                    MainLog_Add("셀용접 실패.");
                    AutoSequenceState = "셀용접-대기";
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-개별용접시작":
                    MainLog_Add("개별용접시퀀스 시작.");
                    SampleSequenceState = "개별용접-시작";
                    MainSequence = "메인반복-개별용접";
                    break;

                case "메인반복-개별용접":
                    SampleSequence();

                    if (SampleSequenceState == "개별용접-용접완료")
                    {
                        MainSequence = "메인반복-개별용접정상종료";
                    }
                    else if (SampleSequenceState == "개별용접-용접실패")
                    {
                        MainSequence = "메인반복-개별용접비정상종료";
                    }
                    break;

                case "메인반복-개별용접정상종료":
                    MainLog_Add("개별용접 성공.");
                    SampleSequenceState = "개별용접-대기";
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-개별용접비정상종료":
                    MainLog_Add("개별용접 실패.");
                    SampleSequenceState = "개별용접-대기";
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-수동조작시작":
                    MainLog_Add("수동조작 시작.");
                    MainSequence = "메인반복-수동조작";
                    TestWeldingState = "시편 테스트 용접-시작";
                    break;

                case "메인반복-수동조작":

                    ManualSequence();

                    if (ManualSequenceState == "수동조작-종료")
                    {
                        MainSequence = "메인반복-수동조작정상종료";
                    }
                    else if (ManualSequenceState == "수동조작-실패")
                    {
                        MainSequence = "메인반복-수동조작비정상종료";
                    }
                    
                    break;

                case "메인반복-수동조작정상종료":
                    MainLog_Add("수동조작 완료.");
                    ManualSequenceState = "수동조작-대기";
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-수동조작비정상종료":
                    MainLog_Add("수동조작 실패.");
                    ManualSequenceState = "수동조작-대기";
                    MainSequence = "메인반복-대기";
                    break;

                case "메인반복-설정시작":
                    MainLog_Add("설정 시작.");
                    MainSequence = "메인반복-설정";
                    break;

                case "메인반복-설정":

                    break;

                case "메인반복-설정종료":
                    MainLog_Add("설정 종료.");
                    MainSequence = "메인반복-대기";
                    break;

                case "에러발생":
                    MainLog_Add("에러 발생");


                    MainSequence = "에러리셋 대기";
                    break;

                case "에러리셋 대기":
                    MainLog_Add("에러 리셋.");
                    MainSequence = "메인반복-대기";
                    break;


                default:
                    break;
            }


            //데이터 정리해서 UDP통신용 데이터클래스에 넣음
            DataGathering();

        }


        //외부 통신 클래스에서 데이터 복사&정리해서 UDP통신용 데이터클래스에 넣음
        private void DataGathering()
        {
            DataEX_UDPCommunication tempData = new DataEX_UDPCommunication();

            if(IODataEX != null)
            {
                tempData.moni_IOModulState = IODataEX.IOModuleStatus;

                for(int i=0; i<8; i++)
                {
                    tempData.moni_IOModuleValueDI[i] = 0;
                    tempData.moni_IOModuleValueDO[i] = 0;
                }

                byte tempDO1 = 0;
                byte tempDO2 = 0;
                byte tempDI1 = 0;
                byte tempDI2 = 0;

                ////터치센싱임시
                RobotCommclass.tempTouchSensingIO = IODataEX.IOModuleMonitoringDI[7];
                ////터치센싱임시

                for (int i = 0; i < 8; i++)
                {
                    if (IODataEX.IOModuleMonitoringDI[i] == 1)
                    {
                        tempDI1 = (byte)(tempDI1 + (1 << i));
                    }

                    if (IODataEX.IOModuleMonitoringDI[i + 8] == 1)
                    {
                        tempDI2 = (byte)(tempDI2 + (1 << i));
                    }

                    if (IODataEX.IOModuleMonitoringDO[i] == 1)
                    {
                        tempDO1 = (byte)(tempDO1 + (1 << i));
                    }

                    if (IODataEX.IOModuleMonitoringDO[i + 8] == 1)
                    {
                        tempDO2 = (byte)(tempDO2 + (1 << i));
                    }
                }
                tempData.moni_IOModuleValueDI[0] = tempDI1;
                tempData.moni_IOModuleValueDI[1] = tempDI2;
                tempData.moni_IOModuleValueDO[0] = tempDO1;
                tempData.moni_IOModuleValueDO[1] = tempDO2;

            }

            if(IMUDataEX != null)
            {
                tempData.moni_IMUModuleState = IMUDataEX.IMUModuleState;
                for(int i=0; i<3; i++)
                {
                    tempData.moni_IMUModuleAcc[i] = (float)IMUDataEX.IMUModuleAcc[i];
                    tempData.moni_IMUModuleGyr[i] = (float)IMUDataEX.IMUModuleGyr[i];
                    tempData.moni_IMUModuleAng[i] = (float)IMUDataEX.IMUModuleAng[i];
                    tempData.moni_IMUModuleMag[i] = (float)IMUDataEX.IMUModuleMag[i];
                }
                tempData.moni_IMUModuleTmp = (float)IMUDataEX.IMUModuleTmp;

            }

            if (DistanceSensorDataEX != null)
            {
                tempData.moni_DistanceSensorState = DistanceSensorDataEX.DistanceSensorState;
                tempData.moni_DistanceSensorBase[0] = (float)DistanceSensorDataEX.DistanceSensorValue[0];
                tempData.moni_DistanceSensorBase[1] = 0;
                tempData.moni_DistanceSensorBase[2] = 0;
            }


            if (RobotDataEX != null)
            {

                tempData.moni_RobotCommunicationState = RobotDataEX.moni_RobotCommunicationState;


                tempData.moni_RobotAPIVersion = RobotDataEX.moni_RobotAPIVersion;
                tempData.moni_RobotEmergencyState = RobotDataEX.moni_RobotEmergencyState;
                tempData.moni_RobotIOValueDI = RobotDataEX.moni_RobotIOValueDI;
                tempData.moni_RobotIOValueDO = RobotDataEX.moni_RobotIOValueDO;
                for (int i = 0; i < 2; i++)
                {
                    tempData.moni_RobotIOValueAI[i] = RobotDataEX.moni_RobotIOValueAI[i];
                    tempData.moni_RobotIOValueAO[i] = RobotDataEX.moni_RobotIOValueAO[i];
                    tempData.moni_RobotMountingAngle[i] = RobotDataEX.moni_RobotMountingAngle[i];
                    tempData.moni_RobotToolIOValueAI[i] = RobotDataEX.moni_RobotToolIOValueAI[i];
                }
                tempData.moni_RobotMotionState = RobotDataEX.moni_RobotMotionState;
                tempData.moni_RobotSafetySwitchState = RobotDataEX.moni_RobotSafetySwitchState;
                tempData.moni_RobotSafetyState = RobotDataEX.moni_RobotSafetyState;
                tempData.moni_RobotServoOnState = RobotDataEX.moni_RobotServoOnState;
                tempData.moni_RobotMountingSerface = RobotDataEX.moni_RobotMountingSerface;
                for (int i = 0; i < 6; i++)
                {
                    tempData.moni_RobotFlangeToTCP[i] = RobotDataEX.moni_RobotFlangeToTCP[i];
                    tempData.moni_RobotTCPCommandPose[i] = RobotDataEX.moni_RobotTCPCommandPose[i];
                    tempData.moni_RobotTCPActualPose[i] = RobotDataEX.moni_RobotTCPActualPose[i];
                    tempData.moni_RobotJointTmp[i] = RobotDataEX.moni_RobotJointTmp[i];
                    tempData.moni_RobotJointVol[i] = RobotDataEX.moni_RobotJointVol[i];
                    tempData.moni_RobotJointAmp[i] = RobotDataEX.moni_RobotJointAmp[i];
                    tempData.moni_RobotJointCommandAngle[i] = RobotDataEX.moni_RobotJointCommandAngle[i];
                    tempData.moni_RobotJointActualAngle[i] = RobotDataEX.moni_RobotJointActualAngle[i];
                    tempData.moni_RobotCollisionDetectionJointLimit[i] = RobotDataEX.moni_RobotCollisionDetectionJointLimit[i];
                }
                tempData.moni_RobotTCPPayload = RobotDataEX.moni_RobotTCPPayload;
                tempData.moni_RobotTCPMassCenter[0] = RobotDataEX.moni_RobotTCPMassCenter[0];
                tempData.moni_RobotTCPMassCenter[1] = RobotDataEX.moni_RobotTCPMassCenter[1];
                tempData.moni_RobotTCPMassCenter[2] = RobotDataEX.moni_RobotTCPMassCenter[2];
                tempData.moni_RobotToolIOValueDI = RobotDataEX.moni_RobotToolIOValueDI;
                tempData.moni_RobotToolIOValueDO = RobotDataEX.moni_RobotToolIOValueDO;
                tempData.moni_RobotDirectTeachingState = RobotDataEX.moni_RobotDirectTeachingState;
                tempData.moni_RobotCollisionDetectionState = RobotDataEX.moni_RobotCollisionDetectionState;
                tempData.moni_RobotCollisionMitigationState = RobotDataEX.moni_RobotCollisionMitigationState;
                tempData.moni_RobotEventLog.Clear();
                RobotEventData[] tempREData = RobotCommclass.RobotEventLog_ReadBlock(20);
                for (int i = 0; i < tempREData.Length; i++) tempData.moni_RobotEventLog.Add(tempREData[i]);

                //아날로그센서에서 툴 거리센서 거리값 계산해넣음. 아날로그신호 4~20ma 100~400mm
                if(RobotDataEX.moni_RobotToolIOValueAI[0]<0.004)
                {   //센서가 연결되지 않은경우 or 센서 신호선이 끊어진 경우
                    tempData.moni_DistanceSensorTool = 0;
                }
                else
                {
                    tempData.moni_DistanceSensorTool = (float)(100 + (RobotDataEX.moni_RobotToolIOValueAI[0] - 0.004) * 300 / 0.016);
                }
            }

            //서버 에러상태
            if (MainSequence.Contains("메인"))
            {
                tempData.moni_SWState = 0;
            }else
            {
                tempData.moni_SWState = (byte)(1<<7);
            }

            tempData.moni_MainSeqState = MainSequence;


            tempData.moni_ManualSeqState = "NULL";
            tempData.moni_SettingSeqState = "NULL";

            tempData.moni_WorkClientIP[0] = WorkClientIP[0];
            tempData.moni_WorkClientIP[1] = WorkClientIP[1];
            tempData.moni_WorkClientIP[2] = WorkClientIP[2];
            tempData.moni_WorkClientIP[3] = WorkClientIP[3];
            tempData.moni_WorkClientPort = WorkClientPort;
            tempData.moni_WorkClientID = WorkClientID;

            if (MainSequence.Contains("셀"))
            {
                tempData.moni_AutoSeqState = AutoSequenceState;
                tempData.moni_DTSeqState = AutoDTSubSeq;
                tempData.moni_TouchSeqState = AutoTSSubSeq;
                tempData.moni_WeldSeqState = AutoWeldingSubState;

                string tempstr = "";
                if(LeftWeldFlag == true)
                {
                    tempstr = CellTypeName_Left + "-";
                }
                else
                {
                    tempstr = "NULL-";
                }

                if(RightWeldFlag == true)
                {
                    tempstr = tempstr + CellTypeName_Right;
                }
                else
                {
                    tempstr = tempstr + "NULL";
                }
                tempData.moni_AutoWeldCellType = tempstr;
                
                for (int i = 0; i < 32; i++)
                {
                    tempData.moni_DTPointCompleteFlagLeft[i] = DTPointLeftOK[i];
                    tempData.moni_DTPointCompleteFlagRight[i] = DTPointRightOK[i];
                }
            }
            else if(MainSequence.Contains("개별"))
            {
                tempData.moni_AutoSeqState = SampleSequenceState;
                tempData.moni_DTSeqState = SampleDTSubSeq;
                tempData.moni_TouchSeqState = SampleTSSubSeq;
                tempData.moni_WeldSeqState = SampleWeldingSubState;
                tempData.moni_AutoWeldCellType = SampleTypeName;

                for (int i = 0; i < 32; i++)
                {
                    tempData.moni_DTPointCompleteFlagLeft[i] = false;
                    tempData.moni_DTPointCompleteFlagRight[i] = false;
                }
                for (int i = 0; i < 16; i++) tempData.moni_DTPointCompleteFlagLeft[i] = SampleWeldDTPointOK[i];
            }
            else
            {
                tempData.moni_AutoSeqState = "NULL";
                tempData.moni_DTSeqState = "NULL";
                tempData.moni_TouchSeqState = "NULL";
                tempData.moni_WeldSeqState = "NULL";
                tempData.moni_AutoWeldCellType = "NULL";

                for (int i = 0; i < 32; i++)
                {
                    tempData.moni_DTPointCompleteFlagLeft[i] = false;
                    tempData.moni_DTPointCompleteFlagRight[i] = false;
                }
            }


            tempData.moni_CellWeldProgress = 0;
            tempData.moni_ArcTimeTotal = 0;
            tempData.moni_ArcTimeLeft = 0;

            if (RobotDataEX != null)
            {
                if (((RobotDataEX.moni_RobotIOValueDO >> 5) % 2) == 1)
                {
                    tempData.moni_ArcOnFlag = 1;
                    tempData.moni_ActualArcVol = RobotCommclass.Arc_AnalogToVol(RobotDataEX.moni_RobotIOValueAO[0]);
                    tempData.moni_ActualArcAmp = RobotCommclass.Arc_AnalogToAmp(RobotDataEX.moni_RobotIOValueAO[1]);
                }
                else
                {
                    tempData.moni_ArcOnFlag = 0;
                    tempData.moni_ActualArcVol = 0;
                    tempData.moni_ActualArcAmp = 0;
                }
            }
            else
            {
                tempData.moni_ArcOnFlag = 0;
                tempData.moni_ActualArcVol = 0;
                tempData.moni_ActualArcAmp = 0;
            }



            if (UDPCommclass != null)
            {
                byte b1, b2, b3, b4;
                ushort s1;
                if (UDPCommclass.ControlClientFlag == true)
                {
                    tempData.moni_ControlState = 1;
                    try
                    {
                        b1 = Convert.ToByte(UDPCommclass.ControlClientIP.Split(':')[0].Split('.')[0]);
                        b2 = Convert.ToByte(UDPCommclass.ControlClientIP.Split(':')[0].Split('.')[1]);
                        b3 = Convert.ToByte(UDPCommclass.ControlClientIP.Split(':')[0].Split('.')[2]);
                        b4 = Convert.ToByte(UDPCommclass.ControlClientIP.Split(':')[0].Split('.')[3]);
                        s1 = Convert.ToUInt16(UDPCommclass.ControlClientIP.Split(':')[1]);
                    }
                    catch
                    {
                        b1 = 0;
                        b2 = 0;
                        b3 = 0;
                        b4 = 0;
                        s1 = 0;
                    }
                    tempData.moni_ControlClientIP[0] = b1;
                    tempData.moni_ControlClientIP[1] = b2;
                    tempData.moni_ControlClientIP[2] = b3;
                    tempData.moni_ControlClientIP[3] = b4;
                    tempData.moni_ControlClientPort = s1;
                    tempData.moni_ControlClientID = UDPCommclass.ControlClientID;
                } else
                {
                    tempData.moni_ControlState = 0;
                    tempData.moni_ControlClientIP[0] = 0;
                    tempData.moni_ControlClientIP[1] = 0;
                    tempData.moni_ControlClientIP[2] = 0;
                    tempData.moni_ControlClientIP[3] = 0;
                    tempData.moni_ControlClientPort = 0;
                    tempData.moni_ControlClientID = "NULL";
                }

                UDPCommclass.UDPDataEXWrite(tempData);
            }
                

        }

        //UDP 통신을 통해 수신된 제어패킷이 있는지 체크하는 함수
        private void UDPPacketCheck()
        {
            if (UDPCommclass == null) return;

            UDPPacketCheck_CellWeld();
            UDPPacketCheck_SampleWeld();
            UDPPacketCheck_Manual();
        }
        private void UDPPacketCheck_CellWeld()
        {
            if (UDPCommclass == null) return;

            //셀용접 시작요청 처리
            if (UDPCommclass.AutoWeldSeqStartFlag == true)
            {
                //셀용접시퀀스 실행요청 플래그

                UDPCommclass.AutoWeldSeqStartFlag = false;
                AutoTouchAndWeldFlag = false;

                //메인시퀀스가 대기상태인지 체크. 대기상태일때만 셀용접으로 전환됨
                if (MainSequence != "메인반복-대기")
                {
                    MainLog_Add("통신지령. 셀용접시퀀스를 시작할수 없습니다. 메인시퀀스가 대기중이 아닙니다.");
                    return;
                }

                //왼쪽용접ID가 있으면 데이터 저장
                if (UDPCommclass.AutoWeldLeftID != "NULL")
                {
                    //입력된 ID가 콤보박스 목록에 있는 ID인지 체크하고 콤보박스 선택.
                    bool ISID = false;
                    for (int i = 0; i < comboBox_WeldTypeLeft.Items.Count; i++)
                    {
                        if (comboBox_WeldTypeLeft.Items[i].ToString() == UDPCommclass.AutoWeldLeftID)
                        {
                            comboBox_WeldTypeLeft.SelectedIndex = i;
                            ISID = true;
                            break;
                        }
                    }

                    //선택된 셀이 있으면
                    if (ISID == true)
                    {
                        LeftWeldFlag = true;
                        CellTypeName_Left = UDPCommclass.AutoWeldLeftID;

                        //각장, 갭, 셀정보 저장
                        for (int i = 0; i < 32; i++)
                        {
                            WeldLineWidth_Left[i] = UDPCommclass.AutoWeldLegLengthLeft[i];
                            WeldLineGap_Left[i] = UDPCommclass.AutoWeldGapLeft[i];
                            WeldLineFlag_Left[i] = (WeldLineWidth_Left[i] > 4);
                        }
                        for (int i = 0; i < 20; i++)
                        {
                            WeldCellPara_Left[i] = UDPCommclass.AutoWeldParameterLeft[i];
                        }
                    }
                    else
                    {//선택된 셀ID가 없으면 Null로 선택함
                        LeftWeldFlag = false;
                        CellTypeName_Left = "";
                        comboBox_WeldTypeLeft.SelectedIndex = 0;
                    }
                }
                else
                {
                    LeftWeldFlag = false;
                    CellTypeName_Left = "";
                    comboBox_WeldTypeLeft.SelectedIndex = 0;
                }

                //오른쪽용접ID가 있으면 데이터 저장
                if (UDPCommclass.AutoWeldRightID != "NULL")
                {
                    //입력된 ID가 콤보박스 목록에 있는 ID인지 체크하고 콤보박스 선택.
                    bool ISID = false;
                    for (int i = 0; i < comboBox_WeldTypeRight.Items.Count; i++)
                    {
                        if (comboBox_WeldTypeRight.Items[i].ToString() == UDPCommclass.AutoWeldRightID)
                        {
                            comboBox_WeldTypeRight.SelectedIndex = i;
                            ISID = true;
                            break;
                        }
                    }

                    //선택된 셀이 있으면
                    if (ISID == true)
                    {
                        RightWeldFlag = true;
                        CellTypeName_Right = UDPCommclass.AutoWeldRightID;

                        //각장 갭 셀정보 저장
                        for (int i = 0; i < 32; i++)
                        {
                            WeldLineWidth_Right[i] = UDPCommclass.AutoWeldLegLengthRight[i];
                            WeldLineGap_Right[i] = UDPCommclass.AutoWeldGapRight[i];
                            WeldLineFlag_Right[i] = (WeldLineWidth_Right[i] > 4);
                        }
                        for (int i = 0; i < 20; i++)
                        {
                            WeldCellPara_Right[i] = UDPCommclass.AutoWeldParameterLeft[i];
                        }
                    }
                    else
                    {//선택된 셀ID가 없으면 Null로 선택함
                        RightWeldFlag = false;
                        CellTypeName_Right = "";
                        comboBox_WeldTypeRight.SelectedIndex = 0;
                    }

                }
                else
                {
                    RightWeldFlag = false;
                    CellTypeName_Right = "";
                    comboBox_WeldTypeRight.SelectedIndex = 0;
                }

                //나머지 수신데이터 UI에 표시
                try
                {
                    checkBox_WeldFlagLeft.Checked = LeftWeldFlag;
                    checkBox_WeldFlagRight.Checked = RightWeldFlag;

                    for (int i = 0; i < 15; i++)
                    {
                        (groupBox_AutoWeldDataLeft.Controls["checkBox_WeldLineLeft" + i.ToString()] as CheckBox).Checked = WeldLineFlag_Left[i];
                        (groupBox_AutoWeldDataLeft.Controls["textBox_WeldWidthLeft" + i.ToString()] as TextBox).Text = WeldLineWidth_Left[i].ToString("0.0");
                        (groupBox_AutoWeldDataLeft.Controls["textBox_WeldGapLeft" + i.ToString()] as TextBox).Text = WeldLineGap_Left[i].ToString("0.0");
                        (groupBox_AutoWeldDataLeft.Controls["textBox_LeftCellPara" + i.ToString()] as TextBox).Text = WeldLineGap_Left[i].ToString("0.0");

                        (groupBox_AutoWeldDataRight.Controls["checkBox_WeldLineRight" + i.ToString()] as CheckBox).Checked = WeldLineFlag_Right[i];
                        (groupBox_AutoWeldDataRight.Controls["textBox_WeldWidthRight" + i.ToString()] as TextBox).Text = WeldLineWidth_Right[i].ToString("0.0");
                        (groupBox_AutoWeldDataRight.Controls["textBox_WeldGapRight" + i.ToString()] as TextBox).Text = WeldLineGap_Right[i].ToString("0.0");
                        (groupBox_AutoWeldDataRight.Controls["textBox_RightCellPara" + i.ToString()] as TextBox).Text = WeldLineGap_Right[i].ToString("0.0");
                    }

                }
                catch
                {
                    MainLog_Add("통신지령 셀용접작업 데이터 표시 실패");
                }

                MainLog_Add("통신지령. 셀용접시퀀스 실행.");
                MainSequence = "메인반복-셀용접시작";
            }

            //직접교시 현재위치 기록요청 처리
            if (UDPCommclass.AutoDTPoseRecordFlag == true)
            {
                UDPCommclass.AutoDTPoseRecordFlag = false;

                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 교시점 위치기록 수행");
                    AutoDTPoseRecordFlag = true;
                }
                else
                {
                    MainLog_Add("통신지령. 교시점 위치기록 실패. 직접교시 단계가 아닙니다");
                }
            }

            //직접교시 다음번호로 바꿈 요청 처리
            if (UDPCommclass.AutoDTPoseNextFlag == true)
            {
                UDPCommclass.AutoDTPoseNextFlag = false;

                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 다음 교시점 번호이동 완료");
                    AutoDTPoseNextFlag = true;
                }
                else
                {
                    MainLog_Add("통신지령. 교시점 번호이동 실패. 직접교시 단계가 아닙니다");
                }
            }

            //직접교시 현재번호 기본자세로 모션 명령 처리
            if (UDPCommclass.AutoDTPoseMoveFlag == true)
            {
                UDPCommclass.AutoDTPoseMoveFlag = false;

                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 교시점 기본자세 모션실행");
                    AutoDTPoseMoveFlag = true;
                }
                else
                {
                    MainLog_Add("통신지령. 교시점 기본자세 모션 실패. 직접교시 단계가 아닙니다");
                }
            }

            //직접교시 교시점 변경 요청처리
            if (UDPCommclass.AutoDTChangeIDFlag == true)
            {
                UDPCommclass.AutoDTChangeIDFlag = false;

                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    if (UDPCommclass.AutoDTChangeID.Contains('L'))
                    {
                        try
                        {
                            int tempDTCount = Convert.ToInt32(UDPCommclass.AutoDTChangeID.Replace("L", "").Trim());
                            int tempDTMaxCount = CellTypeData[CellTypeName_Left + "_DTPoint"];
                            if (tempDTCount <= tempDTMaxCount)
                            {
                                AutoDTSubSeq = UDPCommclass.AutoDTChangeID + " 티칭대기";
                                MainLog_Add("통신지령. 직접교시 교시점 변경 완료.");
                            }
                        }
                        catch
                        {
                            MainLog_Add("통신지령. 직접교시 교시점 변경실패.");
                        }

                    }
                    else
                    {
                        try
                        {
                            int tempDTCount = Convert.ToInt32(UDPCommclass.AutoDTChangeID.Replace("R", "").Trim());
                            int tempDTMaxCount = CellTypeData[CellTypeName_Right + "_DTPoint"];
                            if (tempDTCount <= tempDTMaxCount)
                            {
                                AutoDTSubSeq = UDPCommclass.AutoDTChangeID + " 티칭대기";
                                MainLog_Add("통신지령. 직접교시 교시점 변경 완료.");
                            }
                        }
                        catch
                        {
                            MainLog_Add("통신지령. 직접교시 교시점 변경실패.");
                        }
                    }

                }
                else
                {
                    MainLog_Add("통신지령. 직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
                }


            }

            //이후 자동으로 터치센싱&용접하도록 처리
            if (UDPCommclass.AWTouchAndWeldFlag == true)
            {
                UDPCommclass.AWTouchAndWeldFlag = false;
                ArcFlag = true;
                if ((AutoSequenceState == "셀용접-직접교시 완료대기") || (AutoSequenceState == "셀용접-터치센싱 시작대기") || (AutoSequenceState == "셀용접-용접시작대기"))
                {
                    MainLog_Add("통신지령. 터치 및 용접진행");
                    AutoTouchAndWeldFlag = true;
                }
            }

            //직접교시 완료요청 처리
            if (UDPCommclass.AutoDTEndFlag == true)
            {
                UDPCommclass.AutoDTEndFlag = false;
                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 직접교시 완료요청");
                    AutoDTEndFlag = true;
                }
            }

            //터치센싱 시작요청 처리
            if (UDPCommclass.AutoTSStartFlag == true)
            {
                UDPCommclass.AutoTSStartFlag = false;
                if (AutoSequenceState == "셀용접-터치센싱 시작대기")
                {
                    MainLog_Add("통신지령. 터치센싱 시작요청");
                    AutoTSStartFlag = true;
                }
            }

            //용접 시작요청 처리
            if (UDPCommclass.AutoWeldStartFlag == true)
            {
                UDPCommclass.AutoWeldStartFlag = false;
                if (AutoSequenceState == "셀용접-용접시작대기")
                {
                    MainLog_Add("통신지령. 용접 시작요청");
                    AutoWeldStartFlag = true;
                }
            }

            //아크온오프 상태변경 요청 처리
            if (UDPCommclass.ArcStateSetFlag == 1)
            {
                UDPCommclass.ArcStateSetFlag = 2;
                ArcFlag = true;
            }
            else if (UDPCommclass.ArcStateSetFlag == 0)
            {
                UDPCommclass.ArcStateSetFlag = 2;
                ArcFlag = false;
            }

            //셀용접 터치단계로 변경요청 처리
            if (UDPCommclass.AutoSeqChangeTouch == true)
            {
                UDPCommclass.AutoSeqChangeTouch = false;
                if (MainSequence == "메인반복-대기") SeqChangeAutoTouch();
            }

            //셀용접 용접단계로 변경요청 처리
            if (UDPCommclass.AutoSeqChangeWeld == true)
            {
                UDPCommclass.AutoSeqChangeWeld = false;
                if (MainSequence == "메인반복-대기") SeqChangeAutoWeld();
            }


        }
        private void UDPPacketCheck_SampleWeld()
        {
            if (UDPCommclass == null) return;
            
            //개별용접 시작요청 처리
            if (UDPCommclass.SampleWeldSeqStartFlag == true)
            {
                //개별용접시퀀스 실행요청 플래그

                UDPCommclass.SampleWeldSeqStartFlag = false;
                SampleTouchAndWeldFlag = false;

                //메인시퀀스가 대기상태인지 체크. 대기상태일때만 셀용접으로 전환됨
                if (MainSequence != "메인반복-대기")
                {
                    MainLog_Add("통신지령. 개별용접시퀀스를 시작할수 없습니다. 메인시퀀스가 대기중이 아닙니다.");
                    return;
                }


                //입력된 ID가 콤보박스 목록에 있는 ID인지 체크하고 콤보박스 선택.
                bool ISID = false;
                for (int i = 0; i < comboBox_WeldSample.Items.Count; i++)
                {
                    if (comboBox_WeldSample.Items[i].ToString() == UDPCommclass.SampleTypeName)
                    {
                        comboBox_WeldSample.SelectedIndex = i;
                        ISID = true;
                        break;
                    }
                }

                //ID가 콤보박스 목록에 있으면
                if (ISID == true)
                {
                    SampleTypeName = UDPCommclass.SampleTypeName;

                    //각장, 갭등 정보 저장
                    for (int i = 0; i < 8; i++)
                    {
                        SampleWeldLineWidth[i] = UDPCommclass.SampleWeldLineWidth[i];
                        SampleWeldLineGap[i] = UDPCommclass.SampleWeldLineGap[i];
                    }
                    for (int i = 0; i < 20; i++)
                    {
                        SampleWeldCellPara[i] = UDPCommclass.SampleWeldPara[i];
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        SampleWeldCon_Vol[i] = UDPCommclass.SampleWeldCon_Vol[i];
                        SampleWeldCon_Amp[i] = UDPCommclass.SampleWeldCon_Amp[i];
                        SampleWeldCon_Spd[i] = UDPCommclass.SampleWeldCon_Spd[i];
                    }
                    //나머지 수신데이터 UI에 표시
                    try
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            (groupBox_SampleWeldData0.Controls["textBox_WeldWidthSample" + i.ToString()] as TextBox).Text = SampleWeldLineWidth[i].ToString("0.0");
                            (groupBox_SampleWeldData0.Controls["textBox_WeldGapSample" + i.ToString()] as TextBox).Text = SampleWeldLineGap[i].ToString("0.0");
                        }
                        for (int i = 0; i < 20; i++)
                        {
                            (groupBox_SampleWeldData2.Controls["textBox_WeldSamplePara" + i.ToString()] as TextBox).Text = SampleWeldCellPara[i].ToString("0.0");
                        }
                        for (int i = 1; i < 5; i++)
                        {
                            (groupBox_SampleWeldData0.Controls["textBox_WeldSampleVol" + i.ToString() + "F"] as TextBox).Text = SampleWeldLineWidth[i].ToString("0.0");
                            (groupBox_SampleWeldData0.Controls["textBox_WeldSampleAmp" + i.ToString() + "F"] as TextBox).Text = SampleWeldLineGap[i].ToString("0.0");
                            (groupBox_SampleWeldData0.Controls["textBox_WeldSampleSpd" + i.ToString() + "F"] as TextBox).Text = SampleWeldLineGap[i].ToString("0.0");
                        }

                    }
                    catch
                    {
                        MainLog_Add("통신지령 셀용접작업 데이터 표시 실패");
                    }

                    MainLog_Add("통신지령. 개별용접시퀀스 실행.");
                    MainSequence = "메인반복-개별용접시작";

                }
                else
                {//없으면 아무것도 안함
                    comboBox_WeldSample.SelectedIndex = 0;
                }
            }

            //기록요청
            if (UDPCommclass.SampleDTPoseRecordFlag == true)
            {
                UDPCommclass.SampleDTPoseRecordFlag = false;

                if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 교시점 위치기록 수행");
                    SampleDTPoseRecordFlag = true;
                }
                else
                {
                    MainLog_Add("통신지령. 교시점 위치기록 실패. 직접교시 단계가 아닙니다");
                }

            }


            //직접교시 다음번호로 바꿈 요청 처리
            if (UDPCommclass.SampleDTPoseNextFlag == true)
            {
                UDPCommclass.SampleDTPoseNextFlag = false;

                if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 다음 교시점 번호이동 완료");
                    SampleDTPoseNextFlag = true;
                }
                else
                {
                    MainLog_Add("통신지령. 교시점 번호이동 실패. 직접교시 단계가 아닙니다");
                }
            }

            //직접교시 현재번호 기본자세로 모션 명령 처리
            if (UDPCommclass.SampleDTPoseMoveFlag == true)
            {
                UDPCommclass.SampleDTPoseMoveFlag = false;

                if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    MainLog_Add("통신지령. 교시점 기본자세 모션실행");
                    SampleDTPoseMoveFlag = true;
                }
                else
                {
                    MainLog_Add("통신지령. 교시점 기본자세 모션 실패. 직접교시 단계가 아닙니다");
                }
            }



            //직접교시 교시점 변경 요청처리
            if (UDPCommclass.SampleDTChangeIDFlag == true)
            {
                UDPCommclass.SampleDTChangeIDFlag = false;

                if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    try
                    {
                        int tempDTCount = Convert.ToInt32(UDPCommclass.SampleDTChangeID.Replace("DT", "").Trim());
                        int tempDTMaxCount = SampleTypeData[SampleTypeName + "_DTPoint"];
                        if (tempDTCount <= tempDTMaxCount)
                        {
                            SampleDTSubSeq = UDPCommclass.SampleDTChangeID + " 티칭대기";
                            MainLog_Add("통신지령. 직접교시 교시점 변경 완료.");
                        }
                        else
                        {
                            MainLog_Add("통신지령. 직접교시 교시점 변경실패. 잘못된번호.");
                        }
                    }
                    catch
                    {
                        MainLog_Add("통신지령. 직접교시 교시점 변경실패.");
                    }
                }
                else
                {
                    MainLog_Add("통신지령. 직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
                }


            }



            //이후 자동으로 터치센싱&용접하도록 처리
            if (UDPCommclass.SWTouchAndWeldFlag == true)
            {
                UDPCommclass.SWTouchAndWeldFlag = false;
                ArcFlag = true;
                if ((SampleSequenceState == "개별용접-직접교시 완료대기") || (SampleSequenceState == "개별용접-터치센싱 시작대기") || (SampleSequenceState == "개별용접-용접시작대기"))
                {
                    SampleTouchAndWeldFlag = true;
                }
            }

            //직접교시 완료요청 처리
            if (UDPCommclass.SampleDTEndFlag == true)
            {
                UDPCommclass.SampleDTEndFlag = false;
                if (SampleSequenceState == "개별용접-직접교시 완료대기") SampleDTEndFlag = true;

            }

            //터치센싱 시작요청 처리
            if (UDPCommclass.SampleTSStartFlag == true)
            {
                UDPCommclass.SampleTSStartFlag = false;
                if (SampleSequenceState == "개별용접-터치센싱 시작대기") SampleTSStartFlag = true;
            }

            //용접 시작요청 처리
            if (UDPCommclass.SampleWeldStartFlag == true)
            {
                UDPCommclass.SampleWeldStartFlag = false;
                if (SampleSequenceState == "개별용접-용접시작대기") SampleWeldStartFlag = true;
            }

            //개별용접 터치단계로 변경요청 처리
            if (UDPCommclass.SampleSeqChangeTouch == true)
            {
                UDPCommclass.SampleSeqChangeTouch = false;
                if (MainSequence == "메인반복-대기") SeqChangeSampleTouch();
            }

            //개별용접 용접단계로 변경요청 처리
            if (UDPCommclass.SampleSeqChangeWeld == true)
            {
                UDPCommclass.SampleSeqChangeWeld = false;
                if (MainSequence == "메인반복-대기") SeqChangeSampleWeld();
            }


        }
        private void UDPPacketCheck_Manual()
        {
            if (UDPCommclass == null) return;

            //수동조작쪽 지령

            //메인시퀀스를 수동으로 바꿈
            if (UDPCommclass.ManualSeqStartFlag == true)
            {
                UDPCommclass.ManualSeqStartFlag = false;
                if (MainSequence == "메인반복-대기")
                {
                    MainLog_Add("통신지령. 수동조작 상태로 변경");
                    MainSequence = "메인반복-수동조작시작";
                }
            }
            //에러해제 요청. 당장은 하는거 없음
            if (UDPCommclass.ManualErrorResetFlag == true)
            {
                UDPCommclass.ManualErrorResetFlag = false;
            }
            //컷팅 요청
            if (UDPCommclass.ManualWireCutFlag == true)
            {
                UDPCommclass.ManualWireCutFlag = false;
                if (MainSequence != "메인반복-대기")
                {
                    MainLog_Add("통신지령. 컷팅실패 다른 작업 진행중");
                    return;
                }
                MainLog_Add("통신지령. 와이어컷팅");
                ManualSequenceState = "수동조작-와이어컷팅";
                MainSequence = "메인반복-수동조작시작";
            }
            //직접교시 온
            if (UDPCommclass.ManualDTOnFlag == true)
            {
                UDPCommclass.ManualDTOnFlag = false;
                MainLog_Add("통신지령. 직접교시 온");
                RobotCommclass.RobotDirectTeachingOn();
            }
            //직접교시 오프
            if (UDPCommclass.ManualDTOffFlag == true)
            {
                UDPCommclass.ManualDTOffFlag = false;
                MainLog_Add("통신지령. 직접교시 오프");
                RobotCommclass.RobotDirectTeachingOff();
            }
            //서보 온
            if (UDPCommclass.ManualServoOnFlag == true)
            {
                UDPCommclass.ManualServoOnFlag = false;
                MainLog_Add("통신지령. 서보 온");
                RobotCommclass.RobotServoOn();
            }
            //서보 오프
            if (UDPCommclass.ManualServoOffFlag == true)
            {
                UDPCommclass.ManualServoOffFlag = false;
                MainLog_Add("통신지령. 서보 오프");
                RobotCommclass.RobotServoOff();
            }
            //메인상태로 리셋
            if (UDPCommclass.ManualMainResetFlag == true)
            {
                UDPCommclass.ManualMainResetFlag = false;
                MainLog_Add("통신지령. 메인상태로 리셋");
                SeqChangeReset();
            }
            //인칭
            if (UDPCommclass.ManualInchingFlag == true)
            {
                UDPCommclass.ManualInchingFlag = false;
                MainLog_Add("통신지령. 인칭");
                UDPInchingTime = DateTime.Now;
            }
            //역인칭
            if (UDPCommclass.ManualInvInchingFlag == true)
            {
                UDPCommclass.ManualInvInchingFlag = false;
                MainLog_Add("통신지령. 역인칭");
                UDPInvInchingTime = DateTime.Now;
            }
            //가스토출
            if (UDPCommclass.ManualGasFlag == true)
            {
                UDPCommclass.ManualGasFlag = false;
                MainLog_Add("통신지령. 가스토출");
                UDPGasTime = DateTime.Now;
            }



        }

        //입출력 체크하는 함수
        private void IOCheck()
        {
            int tempi = 0;
            long tempLi = 0;
            int[] tempiarr = new int[4] { 0, 0, 0, 0 };

            //로봇 및 프로그램 정상동작 확인용 토글신호출력
            tempi = (int)(DateTime.Now - WatchDocTime).Ticks / 10000;
            
            if (tempi > 1000)
            {
                //로봇 DO출력 0번 토글
                //RobotCommclass.RobotBoxDOToggle(0);


                if (IODataEX != null)
                {

                    if (IODataEX.IOModuleMonitoringDO[7] == 0)
                    {
                        IODataEX.IOModuleOutputData[7] = 1;
                    }
                    else
                    {
                        IODataEX.IOModuleOutputData[7] = 0;
                    }

                }

                WatchDocTime = DateTime.Now;
            }
            


            //툴 버튼 눌렸는지 이전 상태와 비교하여 판단
            tempi = RobotDataEX.moni_RobotToolIOValueDI;
            for(int i=0; i<4; i++)
            {
                tempiarr[i] = tempi%2;
                tempi = tempi / 2;
            }
            //동쪽 스위치 눌림
            if((ToolDIBuff[0]==0) && (tempiarr[0]==1))
            {
                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    AutoDTPoseNextFlag = true;
                }else if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    SampleDTPoseNextFlag = true;
                }
            }
            //서쪽 스위치 눌림
            if ((ToolDIBuff[1] == 0) && (tempiarr[1] == 1))
            {
                if (AutoSequenceState == "셀용접-직접교시 완료대기")
                {
                    AutoDTPoseRecordFlag = true;
                }else if (SampleSequenceState == "개별용접-직접교시 완료대기")
                {
                    SampleDTPoseRecordFlag = true;
                }
            }
            //남쪽 스위치 눌림
            if ((ToolDIBuff[3] == 0) && (tempiarr[3] == 1))
            {
                RobotCommclass.RobotDirectTeachingOff();
            }
            //북쪽 스위치 눌림
            if ((ToolDIBuff[2] == 0) && (tempiarr[2] == 1))
            {
                RobotCommclass.RobotDirectTeachingOn();
            }
            //현재값 버퍼에 저장
            for (int i = 0; i < 4; i++) ToolDIBuff[i] = tempiarr[i];


            byte tempbyte1;
            byte[] tempbytearr = new byte[]{ 0,0,0,0,0,0,0,0};
            tempbyte1 = RobotDataEX.moni_RobotIOValueDO;
            for (int i = 0; i < 8; i++)
            {
                tempbytearr[i] = (byte)(tempbyte1 % 2);
                tempbyte1 = (byte)(tempbyte1 >> 1);
            }

            //통신으로 받은 가스 인칭 역인칭 처리
            //가스
            tempLi = (DateTime.Now - UDPGasTime).Ticks / 10000;
            if (tempLi < 600)
            {
                if(UDPGasFlag==false)
                {
                    UDPGasFlag = true;
                    RobotCommclass.Gas_On();
                }
            }
            else
            {
                if (UDPGasFlag == true)
                {
                    UDPGasFlag = false;
                    RobotCommclass.Gas_Off();
                }

                //if (tempbytearr[2]==1)
                //{
                //    RobotCommclass.Gas_Off();
                //}
            }
            //인칭
            tempLi = (DateTime.Now - UDPInchingTime).Ticks / 10000;
            if (tempLi < 600)
            {
                if ((UDPInchingFlag == false) && (UDPInvInchingFlag == false))
                {
                    UDPInchingFlag = true;
                    RobotCommclass.Wire_FInching_On();
                }
            }
            else
            {
                if (UDPInchingFlag == true)
                {
                    UDPInchingFlag = false;
                    RobotCommclass.Wire_FInching_Off();
                }
                //if (tempbytearr[3] == 1)
                //{
                //    RobotCommclass.Wire_FInching_Off();
                //}
            }
            //역인칭
            tempLi = (DateTime.Now - UDPInvInchingTime).Ticks / 10000;
            if (tempLi < 600)
            {
                if ((UDPInchingFlag == false) && (UDPInvInchingFlag == false))
                {
                    UDPInvInchingFlag = true;
                    RobotCommclass.Wire_IInching_On();
                }
            }
            else
            {
                if (UDPInvInchingFlag == true)
                {
                    UDPInvInchingFlag = false;
                    RobotCommclass.Wire_IInching_Off();
                }
                //if (tempbytearr[4] == 1)
                //{
                //    RobotCommclass.Wire_IInching_Off();
                //}
            }


            if (IODataEX != null)
            {
                //경광등 처리
                if (MainSequence.Contains("에러"))
                {   //에러상태. 적색등
                    IODataEX.IOModuleOutputData[1] = 1;     //적
                    IODataEX.IOModuleOutputData[2] = 0;     //황
                    IODataEX.IOModuleOutputData[3] = 0;     //녹

                }
                else if (RobotCommclass.RobotControlThreadSeq==0)
                {
                    tempi = (int)(DateTime.Now - LampTime).Ticks / 10000;
                    if (tempi > 250)
                    {   //황색 점멸
                        LampToggle(1);
                        LampTime = DateTime.Now;
                    }

                }
                else if (MainSequence.Contains("메인"))
                {
                    if (MainSequence == "메인반복-대기")
                    {   //메인 대기상태. 녹색 느린점멸
                        tempi = (int)(DateTime.Now - LampTime).Ticks / 10000;
                        if (tempi > 1000)
                        {   //황색 점멸
                            LampToggle(2);
                            LampTime = DateTime.Now;
                        }
                    }
                    else
                    {   //메인 용접작업 중. 녹색 빠른점멸
                        tempi = (int)(DateTime.Now - LampTime).Ticks / 10000;
                        if (tempi > 250)
                        {   //황색 점멸
                            LampToggle(2);
                            LampTime = DateTime.Now;
                        }
                    }

                }
            }

            if(IMUclass != null)
            {
                string value = "";

                if (Read_InitSetting_KeyValue("RobotMountAngleAutoSet", ref value))
                {
                    if (value == "1")
                    {
                        RobotCommclass.RobotControlParameter_MountAngleRx = (float)(IMUclass.RobotRx);
                        RobotCommclass.RobotControlParameter_MountAngleRy = (float)(IMUclass.RobotRy);
                    }
                }


            }


        }


        //에러 체크하는 함수
        void ErrorCheck()
        {
            //초기화 완료되기 이전에는 검사 안함, 이미 에러상태인 경우에도 검사 안함
            if (MainSequence.Contains("초기화") || MainSequence.Contains("에러"))
            {
                return;
            }
            

            //로봇 접속된 이후에 로봇쪽 검사 수행
            if ((RobotDataEX != null) && (RobotCommclass.RobotInitState == 100))
            {
                bool errorflag = false;
                string errorstr = "";

                if (RobotCommclass.RobotControlThreadSeq == 1099)
                {//로봇 에러 발생
                    RobotCommclass.RobotControlThreadSeq = 0;
                    errorflag = true;
                    errorstr = "로봇 종합에러 발생.";
                }
                else if (RobotCommclass.RobotControlThreadSeq == 199)
                {//연속용접 시퀸스 실행 중 실패
                    RobotCommclass.RobotControlThreadSeq = 15;
                    errorflag = true;
                    errorstr = "연속용접 시퀸스 수행 실패";
                }
                else if (RobotCommclass.RobotControlThreadSeq == 291)
                {//연속터치 시퀀스 실패
                    RobotCommclass.RobotControlThreadSeq = 15;
                    errorflag = true;
                    errorstr = "연속터치 시퀸스 수행 실패";
                }
                else if (RobotCommclass.RobotControlThreadSeq == 310)
                {//연속이동 시퀀스 실패
                    RobotCommclass.RobotControlThreadSeq = 15;
                    errorflag = true;
                    errorstr = "연속이동 시퀸스 수행 실패";
                }

                //에러가 발생한 경우. 어느 시퀸스 실행 중 발생했는지 체크하고 조치함
                if(errorflag == true)
                {
                    if (MainSequence.Contains("대기"))
                    {
                        MainLog_Add("시스템 대기상태에서 " + errorstr);
                    }
                    else if (MainSequence.Contains("셀"))
                    {
                        if (AutoSequenceState.Contains("직접교시"))
                        {
                            if (AutoDTSubSeq.Contains("기본자세"))
                            {
                                MainLog_Add("셀용접 직접교시 기본자세이동 단계에서 " + errorstr);
                                AutoDTSubSeq = "기본자세이동 실패";
                            }
                            else
                            {
                                MainLog_Add("셀용접 직접교시 " + AutoDTSubSeq + " 단계에서 " + errorstr);
                            }
                        }
                        else if (AutoSequenceState.Contains("터치센싱 중"))
                        {
                            MainLog_Add("셀용접-터치센싱 " + AutoTSSubSeq + " 단계에서 " + errorstr);
                            AutoTSSubSeq = "터치시퀀스 실패";
                        }
                        else if (AutoSequenceState.Contains("용접완료대기"))
                        {
                            MainLog_Add("셀용접-용접 " + AutoWeldingSubState + " 단계에서 " + errorstr);
                            AutoWeldingSubState = "연속용접 실패";
                        }


                    }
                    else if (MainSequence.Contains("개별"))
                    {
                        if (SampleSequenceState.Contains("직접교시"))
                        {
                            if (SampleDTSubSeq.Contains("기본자세"))
                            {
                                MainLog_Add("개별용접 직접교시 기본자세이동 단계에서 " + errorstr);
                                SampleDTSubSeq = "기본자세이동 실패";
                            }
                            else
                            {
                                MainLog_Add("개별용접 직접교시 " + SampleDTSubSeq + " 단계에서 " + errorstr);
                            }
                        }
                        else if (ManualSequenceState.Contains("터치센싱 중"))
                        {
                            MainLog_Add("개별용접-터치센싱 " + SampleTSSubSeq + " 단계에서 " + errorstr);
                            SampleTSSubSeq = "터치시퀀스 실패";
                        }
                        else if (ManualSequenceState.Contains("용접완료대기"))
                        {
                            MainLog_Add("개별용접-용접 " + SampleWeldingSubState + " 단계에서 " + errorstr);
                            SampleWeldingSubState = "연속용접 실패";
                        }


                    }
                    else if (MainSequence.Contains("수동"))
                    {
                        MainLog_Add(ManualSequenceState);

                        if (ManualSequenceState.Contains("시편테스트용접"))
                        {
                            MainLog_Add(TestWeldingState + " 단계에서 " + errorstr);
                            TestWeldingState = "시편 테스트 용접-용접실패";
                        }
                        else if (ManualSequenceState.Contains("와이어컷팅"))
                        {
                            MainLog_Add(WirecutState + " 단계에서 " + errorstr);
                            WirecutState = "와이어컷-실패";
                        }
                        else if (ManualSequenceState.Contains("TCP확인"))
                        {
                            MainLog_Add(TCPCheckMotionState + " 단계에서 " + errorstr);
                            TCPCheckMotionState = "TCP확인모션-실패";
                        }


                    }
                    else if (MainSequence.Contains("설정"))
                    {

                    }




                }
                
            }
        }

        //램프 토글해주는 함수 인덱스 0:적, 1:황, 2:녹
        private void LampToggle(int index)
        {
            if(index == 0)
            {
                if(IODataEX.IOModuleMonitoringDO[1] == 0)
                {
                    IODataEX.IOModuleOutputData[1] = 1;
                    IODataEX.IOModuleOutputData[2] = 0;
                    IODataEX.IOModuleOutputData[3] = 0;
                }else if(IODataEX.IOModuleMonitoringDO[1] == 1)
                {
                    IODataEX.IOModuleOutputData[1] = 0;
                    IODataEX.IOModuleOutputData[2] = 0;
                    IODataEX.IOModuleOutputData[3] = 0;
                }

            }else if(index == 1)
            {
                if (IODataEX.IOModuleMonitoringDO[2] == 0)
                {
                    IODataEX.IOModuleOutputData[1] = 0;
                    IODataEX.IOModuleOutputData[2] = 1;
                    IODataEX.IOModuleOutputData[3] = 0;
                }
                else if (IODataEX.IOModuleMonitoringDO[2] == 1)
                {
                    IODataEX.IOModuleOutputData[1] = 0;
                    IODataEX.IOModuleOutputData[2] = 0;
                    IODataEX.IOModuleOutputData[3] = 0;
                }
            }else if(index == 2)
            {
                if (IODataEX.IOModuleMonitoringDO[3] == 0)
                {
                    IODataEX.IOModuleOutputData[1] = 0;
                    IODataEX.IOModuleOutputData[2] = 0;
                    IODataEX.IOModuleOutputData[3] = 1;
                }
                else if (IODataEX.IOModuleMonitoringDO[3] == 1)
                {
                    IODataEX.IOModuleOutputData[1] = 0;
                    IODataEX.IOModuleOutputData[2] = 0;
                    IODataEX.IOModuleOutputData[3] = 0;
                } 
            }



        }





        //조그모션 버튼 이벤트
        private void button_RobotJointJogAngleM_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotJointJogAngle.Text);
            temp = temp - 1;
            if (temp < 1) temp = 1;
            RobotCommclass.RobotJogJointAngle = temp;
            textBox_RobotJointJogAngle.Text = temp.ToString();
        }
        private void button_RobotJointJogAngleP_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotJointJogAngle.Text);
            temp = temp + 1;
            if (temp > 10) temp = 10;
            RobotCommclass.RobotJogJointAngle = temp;
            textBox_RobotJointJogAngle.Text = temp.ToString();
        }
        private void button_RobotJointJogVelM_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotJointJogVel.Text);
            temp = temp - 1;
            if (temp < 1) temp = 1;
            RobotCommclass.RobotJogJointVel = temp;
            textBox_RobotJointJogVel.Text = temp.ToString();
        }
        private void button_RobotJointJogVelP_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotJointJogVel.Text);
            temp = temp + 1;
            if (temp > 10) temp = 10;
            RobotCommclass.RobotJogJointVel = temp;
            textBox_RobotJointJogVel.Text = temp.ToString();
        }
        private void button_RobotTCPJogLengthM_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotTCPJogLength.Text);
            temp = temp - 1;
            if (temp < 1) temp = 1;
            RobotCommclass.RobotJogTCPLength = temp;
            textBox_RobotTCPJogLength.Text = temp.ToString();
        }
        private void button_RobotTCPJogLengthP_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotTCPJogLength.Text);
            temp = temp + 1;
            if (temp > 10) temp = 10;
            RobotCommclass.RobotJogTCPLength = temp;
            textBox_RobotTCPJogLength.Text = temp.ToString();
        }
        private void button_RobotTCPJogVelM_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(textBox_RobotTCPJogVel.Text);
            temp = temp - 1;
            if (temp < 1) temp = 1;
            RobotCommclass.RobotJogTCPVel = temp;
            textBox_RobotTCPJogVel.Text = temp.ToString();
        }
        private void button_RobotTCPJogVelP_Click(object sender, EventArgs e)
        {

            int temp = Convert.ToInt32(textBox_RobotTCPJogVel.Text);
            temp = temp + 1;
            if (temp > 10) temp = 10;
            RobotCommclass.RobotJogTCPVel = temp;
            textBox_RobotTCPJogVel.Text = temp.ToString();
        }
        private void button_RobotJointAngle1M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[0] = 1;
            }
        }
        private void button_RobotJointAngle1M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[0] = 0;
        }
        private void button_RobotJointAngle2M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[1] = 1;
            }
        }
        private void button_RobotJointAngle2M_MouseUp(object sender, MouseEventArgs e)
        {

            RobotCommclass.RobotJogMotionCommand[1] = 0;
        }
        private void button_RobotJointAngle3M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[2] = 1;
            }
        }
        private void button_RobotJointAngle3M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[2] = 0;
        }
        private void button_RobotJointAngle4M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[3] = 1;
            }
        }
        private void button_RobotJointAngle4M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[3] = 0;
        }
        private void button_RobotJointAngle5M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[4] = 1;
            }
        }
        private void button_RobotJointAngle5M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[4] = 0;
        }
        private void button_RobotJointAngle6M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[5] = 1;
            }
        }
        private void button_RobotJointAngle6M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[5] = 0;
        }
        private void button_RobotJointAngle1P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[6] = 1;
            }
        }
        private void button_RobotJointAngle1P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[6] = 0;
        }
        private void button_RobotJointAngle2P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[7] = 1;
            }
        }
        private void button_RobotJointAngle2P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[7] = 0;
        }
        private void button_RobotJointAngle3P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[8] = 1;
            }
        }
        private void button_RobotJointAngle3P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[8] = 0;
        }
        private void button_RobotJointAngle4P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[9] = 1;
            }
        }
        private void button_RobotJointAngle4P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[9] = 0;
        }
        private void button_RobotJointAngle5P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[10] = 1;
            }
        }
        private void button_RobotJointAngle5P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[10] = 0;
        }
        private void button_RobotJointAngle6P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[11] = 1;
            }
        }
        private void button_RobotJointAngle6P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[11] = 0;
        }
        private void button_RobotTCPPose1M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[12] = 1;
            }
        }
        private void button_RobotTCPPose1M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[12] = 0;
        }
        private void button_RobotTCPPose2M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[13] = 1;
            }
        }
        private void button_RobotTCPPose2M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[13] = 0;
        }
        private void button_RobotTCPPose3M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[14] = 1;
            }
        }
        private void button_RobotTCPPose3M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[14] = 0;
        }
        private void button_RobotTCPPose4M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[15] = 1;
            }
        }
        private void button_RobotTCPPose4M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[15] = 0;
        }
        private void button_RobotTCPPose5M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[16] = 1;
            }
        }
        private void button_RobotTCPPose5M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[16] = 0;
        }
        private void button_RobotTCPPose6M_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[17] = 1;
            }
        }
        private void button_RobotTCPPose6M_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[17] = 0;
        }
        private void button_RobotTCPPose1P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[18] = 1;
            }
        }
        private void button_RobotTCPPose1P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[18] = 0;
        }
        private void button_RobotTCPPose2P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[19] = 1;
            }
        }
        private void button_RobotTCPPose2P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[19] = 0;
        }
        private void button_RobotTCPPose3P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[20] = 1;
            }
        }
        private void button_RobotTCPPose3P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[20] = 0;
        }
        private void button_RobotTCPPose4P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[21] = 1;
            }
        }
        private void button_RobotTCPPose4P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[21] = 0;
        }
        private void button_RobotTCPPose5P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[22] = 1;
            }
        }
        private void button_RobotTCPPose5P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[22] = 0;
        }
        private void button_RobotTCPPose6P_MouseDown(object sender, MouseEventArgs e)
        {
            int tempint = 0;
            for (int i = 0; i < 24; i++) tempint = tempint + RobotCommclass.RobotJogMotionCommand[i];
            if (tempint == 0)
            {
                RobotCommclass.RobotJogMotionCommand[23] = 1;
            }
        }
        private void button_RobotTCPPose6P_MouseUp(object sender, MouseEventArgs e)
        {
            RobotCommclass.RobotJogMotionCommand[23] = 0;
        }

        //현재 조인트각 복사
        private void button_JointAngleCopy1_Click(object sender, EventArgs e)
        {
            textBox_RobotJointMove1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_RobotJointMove2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_RobotJointMove3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_RobotJointMove4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_RobotJointMove5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_RobotJointMove6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }
        //현재 TCP좌표 복사
        private void button_TCPPoseCopy1_Click(object sender, EventArgs e)
        {
            textBox_RobotTCPMove1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_RobotTCPMove2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_RobotTCPMove3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_RobotTCPMove4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_RobotTCPMove5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_RobotTCPMove6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }

        //조그조작화면 조인트 무브 클릭
        private void button_RobotJointMove_Click(object sender, EventArgs e)
        {
            float[] tempFarr = new float[6] { 0, 0, 0, 0, 0, 0 };
            float tempVel = 0;
            try
            {
                tempFarr[0] = Convert.ToSingle(textBox_RobotJointMove1.Text);
                tempFarr[1] = Convert.ToSingle(textBox_RobotJointMove2.Text);
                tempFarr[2] = Convert.ToSingle(textBox_RobotJointMove3.Text);
                tempFarr[3] = Convert.ToSingle(textBox_RobotJointMove4.Text);
                tempFarr[4] = Convert.ToSingle(textBox_RobotJointMove5.Text);
                tempFarr[5] = Convert.ToSingle(textBox_RobotJointMove6.Text);
                tempVel = Convert.ToSingle(textBox_RobotJointMoveVel.Text);
            }
            catch
            {
                MessageBox.Show("숫자변환 에러. 입력값 확인하세요");
                return;
            }

            if ((tempVel < 0.01) || (tempVel > 20))
            {
                MessageBox.Show("속도값이 너무 크거나 작습니다. 0.01~20 사이에서 입력하세요");
                return;
            }

            RobotCommclass.RobotMove_Joint(tempFarr, tempVel);
        }
        //조그조작화면 TCP 무브 클릭
        private void button_RobotTCPMove_Click(object sender, EventArgs e)
        {
            //RobotMove_TCP
            float[] tempFarr = new float[6] { 0, 0, 0, 0, 0, 0 };
            float tempVel = 0;
            try
            {
                tempFarr[0] = Convert.ToSingle(textBox_RobotTCPMove1.Text);
                tempFarr[1] = Convert.ToSingle(textBox_RobotTCPMove2.Text);
                tempFarr[2] = Convert.ToSingle(textBox_RobotTCPMove3.Text);
                tempFarr[3] = Convert.ToSingle(textBox_RobotTCPMove4.Text);
                tempFarr[4] = Convert.ToSingle(textBox_RobotTCPMove5.Text);
                tempFarr[5] = Convert.ToSingle(textBox_RobotTCPMove6.Text);
                tempVel = Convert.ToSingle(textBox_RobotTCPMoveVel.Text);
            }
            catch
            {
                MessageBox.Show("숫자변환 에러. 입력값 확인하세요");
                return;
            }

            if ((tempVel < 0.01) || (tempVel > 1000))
            {
                MessageBox.Show("속도값이 너무 크거나 작습니다. 0.01~1000 사이에서 입력하세요");
                return;
            }

            RobotCommclass.RobotMove_TCP(tempFarr, tempVel);
        }
        //수동조작 에러해제 버튼
        private void button_RobotErrorReset_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotErrorReset();
        }
        //수동조작 서보온 버튼
        private void button_RobotServoOn_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotServoOn();
        }
        //수동조작 서보오프 버튼
        private void button_RobotServoOff_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotServoOff();
        }
        //수동조작 일시정지 버튼
        private void button_RobotPause_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotPause();
        }
        //수동조작 재시작 버튼
        private void button_RobotResume_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotPause();
        }
        //수동조작 정지 버튼
        private void button_RobotStop_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotStop();
        }
        //수동조작 응급정지 버튼
        private void button_RobotEMGStop_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotEMGStop();
        }
        //수동조작 직접교시 온 버튼
        private void button_RobotDTOn_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotDirectTeachingOn();
        }
        //수동조작 직접교시 오프 버튼
        private void button_RobotDTOff_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotDirectTeachingOff();
        }

        //현재 로봇자세 복사하는 버튼
        private void button_PosiCopyS1_Click(object sender, EventArgs e)
        {
            textBox_WeldStartPosi1_1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_WeldStartPosi1_2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_WeldStartPosi1_3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_WeldStartPosi1_4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_WeldStartPosi1_5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_WeldStartPosi1_6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }
        private void button_PosiCopyS2_Click(object sender, EventArgs e)
        {
            textBox_WeldStartPosi2_1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_WeldStartPosi2_2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_WeldStartPosi2_3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_WeldStartPosi2_4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_WeldStartPosi2_5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_WeldStartPosi2_6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }
        private void button_PosiCopyS3_Click(object sender, EventArgs e)
        {
            textBox_WeldStartPosi3_1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_WeldStartPosi3_2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_WeldStartPosi3_3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_WeldStartPosi3_4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_WeldStartPosi3_5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_WeldStartPosi3_6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }
        private void button_PosiCopyE1_Click(object sender, EventArgs e)
        {
            textBox_WeldEndPosi1_1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_WeldEndPosi1_2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_WeldEndPosi1_3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_WeldEndPosi1_4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_WeldEndPosi1_5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_WeldEndPosi1_6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }
        private void button_PosiCopyE2_Click(object sender, EventArgs e)
        {
            textBox_WeldEndPosi2_1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_WeldEndPosi2_2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_WeldEndPosi2_3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_WeldEndPosi2_4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_WeldEndPosi2_5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_WeldEndPosi2_6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }
        private void button_PosiCopyE3_Click(object sender, EventArgs e)
        {
            textBox_WeldEndPosi3_1.Text = RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.00");
            textBox_WeldEndPosi3_2.Text = RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.00");
            textBox_WeldEndPosi3_3.Text = RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.00");
            textBox_WeldEndPosi3_4.Text = RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.00");
            textBox_WeldEndPosi3_5.Text = RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.00");
            textBox_WeldEndPosi3_6.Text = RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.00");
        }

        //용접 본조건 좌표 복사하는 버튼
        private void button_PosiCopyM1_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain1_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain1_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain1_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain1_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain1_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain1_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM1_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain1_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain1_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain1_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain1_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain1_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain1_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM1_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain1_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain1_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain1_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain1_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain1_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain1_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM2_1_Click(null, null);
        }
        private void button_PosiCopyM2_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain2_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain2_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain2_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain2_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain2_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain2_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM2_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain2_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain2_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain2_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain2_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain2_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain2_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM2_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain2_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain2_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain2_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain2_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain2_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain2_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM3_1_Click(null, null);
        }
        private void button_PosiCopyM3_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain3_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain3_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain3_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain3_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain3_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain3_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM3_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain3_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain3_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain3_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain3_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain3_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain3_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM3_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain3_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain3_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain3_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain3_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain3_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain3_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM4_1_Click(null, null);
        }
        private void button_PosiCopyM4_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain4_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain4_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain4_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain4_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain4_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain4_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM4_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain4_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain4_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain4_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain4_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain4_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain4_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM4_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain4_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain4_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain4_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain4_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain4_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain4_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM5_1_Click(null, null);
        }
        private void button_PosiCopyM5_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain5_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain5_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain5_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain5_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain5_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain5_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM5_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain5_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain5_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain5_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain5_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain5_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain5_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM5_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain5_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain5_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain5_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain5_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain5_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain5_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM6_1_Click(null, null);
        }
        private void button_PosiCopyM6_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain6_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain6_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain6_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain6_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain6_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain6_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM6_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain6_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain6_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain6_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain6_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain6_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain6_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM6_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain6_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain6_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain6_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain6_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain6_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain6_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM7_1_Click(null, null);
        }
        private void button_PosiCopyM7_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain7_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain7_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain7_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain7_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain7_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain7_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM7_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain7_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain7_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain7_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain7_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain7_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain7_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM7_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain7_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain7_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain7_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain7_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain7_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain7_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM8_1_Click(null, null);
        }
        private void button_PosiCopyM8_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain8_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain8_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain8_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain8_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain8_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain8_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM8_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain8_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain8_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain8_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain8_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain8_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain8_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM8_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain8_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain8_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain8_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain8_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain8_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain8_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM9_1_Click(null, null);
        }
        private void button_PosiCopyM9_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain9_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain9_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain9_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain9_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain9_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain9_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM9_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain9_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain9_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain9_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain9_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain9_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain9_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM9_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain9_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain9_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain9_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain9_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain9_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain9_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
            button_PosiCopyM10_1_Click(null, null);
        }
        private void button_PosiCopyM10_1_Click(object sender, EventArgs e)
        {
            textBox_WeldMain10_Posi1_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain10_Posi1_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain10_Posi1_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain10_Posi1_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain10_Posi1_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain10_Posi1_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM10_2_Click(object sender, EventArgs e)
        {
            textBox_WeldMain10_Posi2_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain10_Posi2_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain10_Posi2_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain10_Posi2_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain10_Posi2_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain10_Posi2_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }
        private void button_PosiCopyM10_3_Click(object sender, EventArgs e)
        {
            textBox_WeldMain10_Posi3_1.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.00");
            textBox_WeldMain10_Posi3_2.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.00");
            textBox_WeldMain10_Posi3_3.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.00");
            textBox_WeldMain10_Posi3_4.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.00");
            textBox_WeldMain10_Posi3_5.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.00");
            textBox_WeldMain10_Posi3_6.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.00");
        }

        //용접기능 테스트버튼 이벤트
        private void button_WeldTestWire1_MouseDown(object sender, MouseEventArgs e)
        {   //와이어 정인칭 온
            RobotCommclass.Wire_FInching_On();
        }
        private void button_WeldTestWire1_MouseUp(object sender, MouseEventArgs e)
        {   //와이어 정인칭 오프
            RobotCommclass.Wire_FInching_Off();
        }
        private void button_WeldTestWire2_MouseDown(object sender, MouseEventArgs e)
        {   //와이어 역인칭 온
            RobotCommclass.Wire_IInching_On();
        }
        private void button_WeldTestWire2_MouseUp(object sender, MouseEventArgs e)
        {   //와이어 역인칭 오프
            RobotCommclass.Wire_IInching_Off();
        }
        private void button_WeldTestGas_MouseDown(object sender, MouseEventArgs e)
        {   //가스체크 온
            RobotCommclass.Gas_On();
        }
        private void button_WeldTestGas_MouseUp(object sender, MouseEventArgs e)
        {   //가스체크 오프
            RobotCommclass.Gas_Off();
        }
        private void button_TouchSenOn_Click(object sender, EventArgs e)
        {   //터치센서 온
            RobotCommclass.TouchSensing_On();
        }
        private void button_TouchSenOff_Click(object sender, EventArgs e)
        {   //터치센서 오프
            RobotCommclass.TouchSensing_Off();
        }

        //용접 선택 체크박스 이벤트
        private void checkBox_WeldingCheck1_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck1.Checked) checkBox_WeldingCheck1.Checked = true;
        }
        private void checkBox_WeldingCheck2_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck2.Checked)
            {
                checkBox_WeldingCheck3.Checked = false;
                checkBox_WeldingCheck4.Checked = false;
                checkBox_WeldingCheck5.Checked = false;
                checkBox_WeldingCheck6.Checked = false;
                checkBox_WeldingCheck7.Checked = false;
                checkBox_WeldingCheck8.Checked = false;
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
        }
        private void checkBox_WeldingCheck3_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck3.Checked)
            {
                checkBox_WeldingCheck4.Checked = false;
                checkBox_WeldingCheck5.Checked = false;
                checkBox_WeldingCheck6.Checked = false;
                checkBox_WeldingCheck7.Checked = false;
                checkBox_WeldingCheck8.Checked = false;
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck2.Checked)
            {
                checkBox_WeldingCheck3.Checked = false;
            }
        }
        private void checkBox_WeldingCheck4_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck4.Checked)
            {
                checkBox_WeldingCheck5.Checked = false;
                checkBox_WeldingCheck6.Checked = false;
                checkBox_WeldingCheck7.Checked = false;
                checkBox_WeldingCheck8.Checked = false;
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck3.Checked)
            {
                checkBox_WeldingCheck4.Checked = false;
            }
        }
        private void checkBox_WeldingCheck5_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck5.Checked)
            {
                checkBox_WeldingCheck6.Checked = false;
                checkBox_WeldingCheck7.Checked = false;
                checkBox_WeldingCheck8.Checked = false;
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck4.Checked)
            {
                checkBox_WeldingCheck5.Checked = false;
            }
        }
        private void checkBox_WeldingCheck6_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck6.Checked)
            {
                checkBox_WeldingCheck7.Checked = false;
                checkBox_WeldingCheck8.Checked = false;
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck5.Checked)
            {
                checkBox_WeldingCheck6.Checked = false;
            }
        }
        private void checkBox_WeldingCheck7_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck7.Checked)
            {
                checkBox_WeldingCheck8.Checked = false;
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck6.Checked)
            {
                checkBox_WeldingCheck7.Checked = false;
            }
        }
        private void checkBox_WeldingCheck8_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck8.Checked)
            {
                checkBox_WeldingCheck9.Checked = false;
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck7.Checked)
            {
                checkBox_WeldingCheck8.Checked = false;
            }
        }
        private void checkBox_WeldingCheck9_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck9.Checked)
            {
                checkBox_WeldingCheck10.Checked = false;
            }
            else if (!checkBox_WeldingCheck8.Checked)
            {
                checkBox_WeldingCheck9.Checked = false;
            }
        }
        private void checkBox_WeldingCheck10_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox_WeldingCheck9.Checked)
            {
                checkBox_WeldingCheck10.Checked = false;
            }
        }

        //수동용접 조건 입력값 객체로 저장하는 함수
        public int MakeWeldInformation()
        {
            tempWeldInfo = new WeldInformation();

            try
            {
                //용접 시작조건 입력
                tempWeldInfo.InitCondition.WeldStartTime = Convert.ToDouble(textBox_WeldStartTime.Text);
                tempWeldInfo.InitCondition.WeldStartVol = Convert.ToDouble(textBox_WeldStartVol.Text);
                tempWeldInfo.InitCondition.WeldStartAmp = Convert.ToDouble(textBox_WeldStartAmp.Text);
                tempWeldInfo.InitCondition.GasPreTime = Convert.ToDouble(textBox_WeldStartGasTime.Text);

                RobotPoseData tempRobotData1 = new RobotPoseData();
                tempRobotData1.PoseType = 1;
                tempRobotData1.f1 = Convert.ToSingle(textBox_WeldStartPosi1_1.Text);
                tempRobotData1.f2 = Convert.ToSingle(textBox_WeldStartPosi1_2.Text);
                tempRobotData1.f3 = Convert.ToSingle(textBox_WeldStartPosi1_3.Text);
                tempRobotData1.f4 = Convert.ToSingle(textBox_WeldStartPosi1_4.Text);
                tempRobotData1.f5 = Convert.ToSingle(textBox_WeldStartPosi1_5.Text);
                tempRobotData1.f6 = Convert.ToSingle(textBox_WeldStartPosi1_6.Text);

                RobotPoseData tempRobotData2 = new RobotPoseData();
                tempRobotData2.PoseType = 1;
                tempRobotData2.f1 = Convert.ToSingle(textBox_WeldStartPosi2_1.Text);
                tempRobotData2.f2 = Convert.ToSingle(textBox_WeldStartPosi2_2.Text);
                tempRobotData2.f3 = Convert.ToSingle(textBox_WeldStartPosi2_3.Text);
                tempRobotData2.f4 = Convert.ToSingle(textBox_WeldStartPosi2_4.Text);
                tempRobotData2.f5 = Convert.ToSingle(textBox_WeldStartPosi2_5.Text);
                tempRobotData2.f6 = Convert.ToSingle(textBox_WeldStartPosi2_6.Text);

                RobotPoseData tempRobotData3 = new RobotPoseData();
                tempRobotData3.PoseType = 1;
                tempRobotData3.f1 = Convert.ToSingle(textBox_WeldStartPosi3_1.Text);
                tempRobotData3.f2 = Convert.ToSingle(textBox_WeldStartPosi3_2.Text);
                tempRobotData3.f3 = Convert.ToSingle(textBox_WeldStartPosi3_3.Text);
                tempRobotData3.f4 = Convert.ToSingle(textBox_WeldStartPosi3_4.Text);
                tempRobotData3.f5 = Convert.ToSingle(textBox_WeldStartPosi3_5.Text);
                tempRobotData3.f6 = Convert.ToSingle(textBox_WeldStartPosi3_6.Text);

                tempWeldInfo.InitCondition.AddStartPosition(tempRobotData1);
                tempWeldInfo.InitCondition.AddStartPosition(tempRobotData2);
                tempWeldInfo.InitCondition.AddStartPosition(tempRobotData3);



                //용접 종료조건 입력
                tempWeldInfo.EndCondition.WeldEndTime = Convert.ToDouble(textBox_WeldEndTime.Text);
                tempWeldInfo.EndCondition.WeldEndVol = Convert.ToDouble(textBox_WeldEndVol.Text);
                tempWeldInfo.EndCondition.WeldEndAmp = Convert.ToDouble(textBox_WeldEndAmp.Text);
                tempWeldInfo.EndCondition.WeldEndLength = Convert.ToDouble(textBox_WeldEndLength.Text);
                tempWeldInfo.EndCondition.GasPostTime = Convert.ToDouble(textBox_WeldEndGasTime.Text);

                RobotPoseData tempRobotData4 = new RobotPoseData();
                tempRobotData4.PoseType = 1;
                tempRobotData4.f1 = Convert.ToSingle(textBox_WeldEndPosi1_1.Text);
                tempRobotData4.f2 = Convert.ToSingle(textBox_WeldEndPosi1_2.Text);
                tempRobotData4.f3 = Convert.ToSingle(textBox_WeldEndPosi1_3.Text);
                tempRobotData4.f4 = Convert.ToSingle(textBox_WeldEndPosi1_4.Text);
                tempRobotData4.f5 = Convert.ToSingle(textBox_WeldEndPosi1_5.Text);
                tempRobotData4.f6 = Convert.ToSingle(textBox_WeldEndPosi1_6.Text);

                RobotPoseData tempRobotData5 = new RobotPoseData();
                tempRobotData5.PoseType = 1;
                tempRobotData5.f1 = Convert.ToSingle(textBox_WeldEndPosi2_1.Text);
                tempRobotData5.f2 = Convert.ToSingle(textBox_WeldEndPosi2_2.Text);
                tempRobotData5.f3 = Convert.ToSingle(textBox_WeldEndPosi2_3.Text);
                tempRobotData5.f4 = Convert.ToSingle(textBox_WeldEndPosi2_4.Text);
                tempRobotData5.f5 = Convert.ToSingle(textBox_WeldEndPosi2_5.Text);
                tempRobotData5.f6 = Convert.ToSingle(textBox_WeldEndPosi2_6.Text);

                RobotPoseData tempRobotData6 = new RobotPoseData();
                tempRobotData6.PoseType = 1;
                tempRobotData6.f1 = Convert.ToSingle(textBox_WeldEndPosi3_1.Text);
                tempRobotData6.f2 = Convert.ToSingle(textBox_WeldEndPosi3_2.Text);
                tempRobotData6.f3 = Convert.ToSingle(textBox_WeldEndPosi3_3.Text);
                tempRobotData6.f4 = Convert.ToSingle(textBox_WeldEndPosi3_4.Text);
                tempRobotData6.f5 = Convert.ToSingle(textBox_WeldEndPosi3_5.Text);
                tempRobotData6.f6 = Convert.ToSingle(textBox_WeldEndPosi3_6.Text);

                tempWeldInfo.EndCondition.AddEndPosition(tempRobotData4);
                tempWeldInfo.EndCondition.AddEndPosition(tempRobotData5);
                tempWeldInfo.EndCondition.AddEndPosition(tempRobotData6);



                //본조건 입력

                //용접선 개수 확인
                int WeldCheckCount = 0;
                for (int i = 1; i < 11; i++)
                {
                    if ((groupBox14.Controls["checkBox_WeldingCheck" + Convert.ToString(i)] as CheckBox).Checked)
                    {
                        WeldCheckCount++;
                    }
                    else
                    {
                        break;
                    }
                }

                //용접 체크된 페이지의 정보로 본조건 생성
                for (int i = 1; i < WeldCheckCount + 1; i++)
                {
                    WeldMainCondition tempWeldMainCon = new WeldMainCondition();

                    TabPage tempPage = (groupBox14.Controls["tabControl_WeldMain"] as TabControl).TabPages[i - 1];
                    float f1, f2, f3, f4, f5, f6;

                    string s = Convert.ToString(i);

                    f1 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi1_1"] as TextBox).Text);
                    f2 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi1_2"] as TextBox).Text);
                    f3 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi1_3"] as TextBox).Text);
                    f4 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi1_4"] as TextBox).Text);
                    f5 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi1_5"] as TextBox).Text);
                    f6 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi1_6"] as TextBox).Text);
                    tempWeldMainCon.SetStartPose(new RobotPoseData(2, 100, f1, f2, f3, f4, f5, f6));
                    
                    f1 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi2_1"] as TextBox).Text);
                    f2 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi2_2"] as TextBox).Text);
                    f3 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi2_3"] as TextBox).Text);
                    f4 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi2_4"] as TextBox).Text);
                    f5 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi2_5"] as TextBox).Text);
                    f6 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi2_6"] as TextBox).Text);
                    tempWeldMainCon.SetMidPose(new RobotPoseData(2, 100, f1, f2, f3, f4, f5, f6));
                    
                    f1 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi3_1"] as TextBox).Text);
                    f2 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi3_2"] as TextBox).Text);
                    f3 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi3_3"] as TextBox).Text);
                    f4 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi3_4"] as TextBox).Text);
                    f5 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi3_5"] as TextBox).Text);
                    f6 = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Posi3_6"] as TextBox).Text);

                    tempWeldMainCon.SetEndPose(new RobotPoseData(2, 100, f1, f2, f3, f4, f5, f6));

                    tempWeldMainCon.PathType = (tempPage.Controls["comboBox_WeldMain" + s + "_LorC"] as ComboBox).SelectedIndex + 1;

                    tempWeldMainCon.WelVol = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Vol"] as TextBox).Text);
                    tempWeldMainCon.WeldAmp = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Amp"] as TextBox).Text);
                    tempWeldMainCon.WeldSpd = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_Speed"] as TextBox).Text);

                    tempWeldMainCon.Weaving = (tempPage.Controls["comboBox_WeldMain" + s + "_Weaving"] as ComboBox).SelectedIndex;
                    tempWeldMainCon.WeavHz = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_WeavHz"] as TextBox).Text);
                    tempWeldMainCon.WeavLength = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_WeavLength"] as TextBox).Text);
                    tempWeldMainCon.WeavLeftStopTime = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_WeavLStopTime"] as TextBox).Text);
                    tempWeldMainCon.WeavRightStopTime = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_WeavRStopTime"] as TextBox).Text);

                    tempWeldMainCon.ArcSen = (tempPage.Controls["comboBox_WeldMain" + s + "_ArcSen"] as ComboBox).SelectedIndex;
                    tempWeldMainCon.ArcSenTimeShift = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenTimeShift"] as TextBox).Text);
                    tempWeldMainCon.ArcSenHFactor = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenHFactor"] as TextBox).Text);
                    tempWeldMainCon.ArcSenVFactor = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenVFactor"] as TextBox).Text);
                    tempWeldMainCon.ArcSenHMaxdL = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenHMaxdL"] as TextBox).Text);
                    tempWeldMainCon.ArcSenVMaxdL = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenVMaxdL"] as TextBox).Text);
                    tempWeldMainCon.ArcSenHOncedL = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenHOncedL"] as TextBox).Text);
                    tempWeldMainCon.ArcSenVOncedL = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenVOncedL"] as TextBox).Text);
                    tempWeldMainCon.ArcSenWeightedFactorLeft = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenWFL"] as TextBox).Text);
                    tempWeldMainCon.ArcSenWeightedFactorRight = Convert.ToSingle((tempPage.Controls["textBox_WeldMain" + s + "_ArcSenWFR"] as TextBox).Text);

                    //메인조건을 추가
                    tempWeldInfo.AddMainCondition(tempWeldMainCon);
                }

            }
            catch
            {
                MessageBox.Show("용접데이터 생성 실패. 값을 확인하세요");
                return 0;
            }



            return 1;
        }

        //아크X 모션만 수행
        private void button_WeldRunWithoutArc_Click(object sender, EventArgs e)
        {
            if (MakeWeldInformation() == 0) return;

            tempWeldInfo.ArcOnFlag = false;

            RobotCommclass.WeldStart(tempWeldInfo);
        }
        //수동조건 입력한대로 용접 수행
        private void button_WeldRunWithArc_Click(object sender, EventArgs e)
        {
            if (MakeWeldInformation() == 0) return;

            tempWeldInfo.ArcOnFlag = true;

            RobotCommclass.WeldStart(tempWeldInfo);
        }
        //로봇 일시정지
        private void button_WeldPause_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotPause();
        }
        //로봇 재시작
        private void button_WeldResume_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotResume();
        }
        //로봇 정지
        private void button_WeldStop_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotStop();
        }
        //아크 온
        private void button_WeldArcOn_Click(object sender, EventArgs e)
        {
            if ((RobotCommclass.RobotControlThreadSeq >= 112) || (RobotCommclass.RobotControlThreadSeq <= 115))
            {
                //용접시퀀스가 본용접 경로에 있을 때 만 아크 켬. 실수로 잘못 누르는거 방지
                RobotCommclass.Arc_On();
            }
        }
        //아크 오프
        private void button_WeldArcOff_Click(object sender, EventArgs e)
        {
            RobotCommclass.Arc_Off();
        }
        //실시간 전압전류 변경
        private void button_WeldVolM_Click(object sender, EventArgs e)
        {
            float vol;

            RobotCommclass.Arc_VolRead(out vol);
            vol = vol - 0.25f;
            RobotCommclass.Arc_VolSet(vol);
        }
        private void button_WeldVolP_Click(object sender, EventArgs e)
        {
            float vol;

            RobotCommclass.Arc_VolRead(out vol);
            vol = vol + 0.25f;
            RobotCommclass.Arc_VolSet(vol);
        }
        private void button_WeldAmpM_Click(object sender, EventArgs e)
        {
            float amp;

            RobotCommclass.Arc_AmpRead(out amp);
            amp = amp - 5f;
            RobotCommclass.Arc_AmpSet(amp);
        }
        private void button_WeldAmpP_Click(object sender, EventArgs e)
        {
            float amp;

            RobotCommclass.Arc_AmpRead(out amp);
            amp = amp + 5f;
            RobotCommclass.Arc_AmpSet(amp);
        }

        //왼쪽 셀타입 용접선 UI에서 1~입력인수 까지는 보여주고 그 이상은 숨겨주는 함수
        private void CellTypeUIVisibleLeft(int count)
        {
            for(int i=0; i<=count; i++)
            {
                (groupBox_AutoWeldDataLeft.Controls["checkBox_WeldLineLeft" + i.ToString()] as CheckBox).Visible = true;
                (groupBox_AutoWeldDataLeft.Controls["textBox_WeldWidthLeft" + i.ToString()] as TextBox).Visible = true;
                (groupBox_AutoWeldDataLeft.Controls["textBox_WeldGapLeft" + i.ToString()] as TextBox).Visible = true;
            }

            for(int i=count+1; i<15; i++)
            {
                (groupBox_AutoWeldDataLeft.Controls["checkBox_WeldLineLeft" + i.ToString()] as CheckBox).Visible = false;
                (groupBox_AutoWeldDataLeft.Controls["textBox_WeldWidthLeft" + i.ToString()] as TextBox).Visible = false;
                (groupBox_AutoWeldDataLeft.Controls["textBox_WeldGapLeft" + i.ToString()] as TextBox).Visible = false;
            }
        }

        //왼쪽 직접교시 UI에서 1~입력인수 까지는 보여주고 그 이상은 숨겨주는 함수
        private void CellDTUIVisibleLeft(int count)
        {
            for (int i = 1; i <= count; i++)
            {
                (groupBox_AutoWeldDT.Controls["button_DTLeft" + i.ToString()] as Button).Visible = true;
                (groupBox_AutoWeldDT.Controls["textBox_DTLeft" + i.ToString()] as TextBox).Visible = true;
            }

            for (int i = count + 1; i <= 8; i++)
            {
                (groupBox_AutoWeldDT.Controls["button_DTLeft" + i.ToString()] as Button).Visible = false;
                (groupBox_AutoWeldDT.Controls["textBox_DTLeft" + i.ToString()] as TextBox).Visible = false;
            }
        }
        //왼쪽 셀타입 콤보박스 이벤트
        private void comboBox_WeldTypeLeft_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox_WeldTypeLeft.SelectedItem.ToString().Contains('_') == true)
            {
                comboBox_WeldTypeLeft.SelectedIndex = 0;
            }

            CellTypeUIVisibleLeft(CellTypeData[comboBox_WeldTypeLeft.SelectedItem.ToString().Trim() + "_WeldLine"]-1);
            CellDTUIVisibleLeft(CellTypeData[comboBox_WeldTypeLeft.SelectedItem.ToString() + "_DTPoint"]);


        }

        //오른쪽 셀타입 용접선 UI에서 1~입력인수 까지는 보여주고 그 이상은 숨겨주는 함수
        private void CellTypeUIVisibleRight(int count)
        {
            for (int i = 0; i <= count; i++)
            {
                (groupBox_AutoWeldDataRight.Controls["checkBox_WeldLineRight" + i.ToString()] as CheckBox).Visible = true;
                (groupBox_AutoWeldDataRight.Controls["textBox_WeldWidthRight" + i.ToString()] as TextBox).Visible = true;
                (groupBox_AutoWeldDataRight.Controls["textBox_WeldGapRight" + i.ToString()] as TextBox).Visible = true;
            }

            for (int i = count + 1; i < 15; i++)
            {
                (groupBox_AutoWeldDataRight.Controls["checkBox_WeldLineRight" + i.ToString()] as CheckBox).Visible = false;
                (groupBox_AutoWeldDataRight.Controls["textBox_WeldWidthRight" + i.ToString()] as TextBox).Visible = false;
                (groupBox_AutoWeldDataRight.Controls["textBox_WeldGapRight" + i.ToString()] as TextBox).Visible = false;
            }
            (groupBox_AutoWeldDataRight.Controls["checkBox_WeldLineRight0"] as CheckBox).Visible = false;
            (groupBox_AutoWeldDataRight.Controls["textBox_WeldWidthRight0"] as TextBox).Visible = false;
            (groupBox_AutoWeldDataRight.Controls["textBox_WeldGapRight0"] as TextBox).Visible = false;
        }

        //오른쪽 직접교시 UI에서 1~입력인수 까지는 보여주고 그 이상은 숨겨주는 함수
        private void DTUIVisibleRight(int count)
        {
            for (int i = 1; i <= count; i++)
            {
                (groupBox_AutoWeldDT.Controls["button_DTRight" + i.ToString()] as Button).Visible = true;
                (groupBox_AutoWeldDT.Controls["textBox_DTRight" + i.ToString()] as TextBox).Visible = true;
            }

            for (int i = count + 1; i <= 8; i++)
            {
                (groupBox_AutoWeldDT.Controls["button_DTRight" + i.ToString()] as Button).Visible = false;
                (groupBox_AutoWeldDT.Controls["textBox_DTRight" + i.ToString()] as TextBox).Visible = false;
            }
        }
        //오른쪽 셀타입 콤보박스 이벤트
        private void comboBox_WeldTypeRight_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBox_WeldTypeRight.SelectedItem.ToString().Contains('_') == true)
            {
                comboBox_WeldTypeRight.SelectedIndex = 0;
            }

            CellTypeUIVisibleRight(CellTypeData[comboBox_WeldTypeRight.SelectedItem.ToString() + "_WeldLine"]-1);
            DTUIVisibleRight(CellTypeData[comboBox_WeldTypeRight.SelectedItem.ToString() + "_DTPoint"]);

        }

        //직접교시 종료버튼
        private void button_RobotDTOff1_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotDirectTeachingOff();
        }
        //직접교시 시작버튼
        private void button_RobotDTOn1_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotDirectTeachingOn();
        }

        //셀타입 및 용접선 각장 갭정보 저장버튼
        private void button_LeftCellDataSave_Click(object sender, EventArgs e)
        {
           //메인시퀀스가 대기상태인지 체크. 대기상태일때만 셀용접으로 전환됨
           if(MainSequence != "메인반복-대기")
            {
                MainLog_Add("셀용접시퀀스를 시작할수 없습니다. 메인시퀀스가 대기중이 아닙니다.");
                return;
            }

            //왼쪽, 오른쪽 둘 다 용접체크가 되어있지 않으면 경고띄우고 종료
            if ((checkBox_WeldFlagLeft.Checked==false) && (checkBox_WeldFlagRight.Checked == false))
            {
                MainLog_Add("셀용접시퀀스를 시작할수 없습니다. 용접 체크된 셀이 없습니다.");
                return;
            }

            //왼쪽용접 체크되어 있으면 데이터 저장
            if (checkBox_WeldFlagLeft.Checked == true)
            {
                try
                {
                    LeftWeldFlag = true;
                    CellTypeName_Left = comboBox_WeldTypeLeft.SelectedItem.ToString();

                    for (int i = 0; i < 15; i++)
                    {
                        WeldLineFlag_Left[i] = (groupBox_AutoWeldDataLeft.Controls["checkBox_WeldLineLeft" + i.ToString()] as CheckBox).Checked;
                        WeldLineWidth_Left[i] = Convert.ToDouble((groupBox_AutoWeldDataLeft.Controls["textBox_WeldWidthLeft" + i.ToString()] as TextBox).Text);
                        WeldLineGap_Left[i] = Convert.ToDouble((groupBox_AutoWeldDataLeft.Controls["textBox_WeldGapLeft" + i.ToString()] as TextBox).Text);
                        WeldCellPara_Left[i] = Convert.ToDouble((groupBox_AutoWeldDataLeft.Controls["textBox_LeftCellPara" + i.ToString()] as TextBox).Text);
                    }
                }
                catch
                {
                    MainLog_Add("셀용접시퀀스를 시작할수 없습니다. 왼쪽셀 입력값이 잘못되었습니다.");
                    return;
                }
            }
            else
            {
                LeftWeldFlag = false;
            }

            //오른쪽 용접 체크되어 있으면 데이터 저장
            if (checkBox_WeldFlagRight.Checked == true)
            {
                try
                {
                    RightWeldFlag = true;
                    CellTypeName_Right = comboBox_WeldTypeRight.SelectedItem.ToString();

                    for (int i = 0; i < 15; i++)
                    {
                        WeldLineFlag_Right[i] = (groupBox_AutoWeldDataRight.Controls["checkBox_WeldLineRight" + i.ToString()] as CheckBox).Checked;
                        WeldLineWidth_Right[i] = Convert.ToDouble((groupBox_AutoWeldDataRight.Controls["textBox_WeldWidthRight" + i.ToString()] as TextBox).Text);
                        WeldLineGap_Right[i] = Convert.ToDouble((groupBox_AutoWeldDataRight.Controls["textBox_WeldGapRight" + i.ToString()] as TextBox).Text);
                        WeldCellPara_Right[i] = Convert.ToDouble((groupBox_AutoWeldDataRight.Controls["textBox_RightCellPara" + i.ToString()] as TextBox).Text);
                    }
                }
                catch
                {
                    MainLog_Add("셀용접시퀀스를 시작할수 없습니다. 오른쪽셀 입력값이 잘못되었습니다.");
                    return;
                }
            }
            else
            {
                RightWeldFlag = false;
            }

            //셀용접 시퀀스로 전환
            MainSequence = "메인반복-셀용접시작";


        }

        //직접교시점 입력 버튼 이벤트
        private void button_DTLeft1_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L0 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft2_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L1 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft3_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L2 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft4_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L3 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft5_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L4 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft6_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L5 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft7_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L6 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTLeft8_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "L7 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight1_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R0 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight2_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R1 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight3_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R2 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight4_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R3 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight5_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R4 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight6_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R5 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight7_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R6 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }
        private void button_DTRight8_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTSubSeq = "R7 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        //직접교시 위치 기록
        private void button_RobotDTPoseRecord_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTPoseRecordFlag = true;
            }
        }
        //직접교시 다음위치
        private void button_RobotDTPoseNext_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTPoseNextFlag = true;
            }
        }
        //직접교시 자세 취함
        private void button_RobotDTPoseMove_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTPoseMoveFlag = true;
            }
        }
        //직접교시 종료
        private void button_RobotDTSeqEnd_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-직접교시 완료대기")
            {
                AutoDTEndFlag = true;
            }
        }

        private void button_AutoWeldTouchStart_Click(object sender, EventArgs e)
        {
            if (AutoSequenceState == "셀용접-터치센싱 시작대기")
            {
                AutoTSStartFlag = true;
            }
        }

        
        //로봇 IO테스트
        private void button_RobotBoxDO0_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(0);
        }
        private void button_RobotBoxDO1_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(1);
        }
        private void button_RobotBoxDO2_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(2);
        }
        private void button_RobotBoxDO3_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(3);
        }
        private void button_RobotBoxDO4_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(4);
        }
        private void button_RobotBoxDO5_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(5);
        }
        private void button_RobotBoxDO6_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(6);
        }
        private void button_RobotBoxDO7_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotBoxDOToggle(7);
        }
        private void button_RobotBoxAO0_Click(object sender, EventArgs e)
        {
            try
            {
                float temp = Convert.ToSingle(textBox_RobotBoxAO0.Text);

                if((temp<0) || (temp>10))
                {
                    MessageBox.Show("입력값이 0~10 범위를 벗어났습니다.");
                }
                else
                {
                    RobotCommclass.RobotBoxAO(0, temp);
                }
            }
            catch
            {
                MessageBox.Show("값 입력이 잘못되었습니다.");
            }
        }
        private void button_RobotBoxAO1_Click(object sender, EventArgs e)
        {
            try
            {
                float temp = Convert.ToSingle(textBox_RobotBoxAO1.Text);

                if ((temp < 0) || (temp > 10))
                {
                    MessageBox.Show("입력값이 0~10 범위를 벗어났습니다.");
                }
                else
                {
                    RobotCommclass.RobotBoxAO(1, temp);
                }
            }
            catch
            {
                MessageBox.Show("값 입력이 잘못되었습니다.");
            }
        }
        private void button_RobotToolDO0_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotToolDOToggle(0);
        }
        private void button_RobotToolDO1_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotToolDOToggle(1);
        }
        private void button_RobotToolDO2_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotToolDOToggle(2);
        }
        private void button_RobotToolDO3_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotToolDOToggle(3);
        }
        private void button_RobotToolAO0_Click(object sender, EventArgs e)
        {
            try
            {
                float temp = Convert.ToSingle(textBox_RobotToolAO0.Text);

                if ((temp < 0) || (temp > 10))
                {
                    MessageBox.Show("입력값이 0~10 범위를 벗어났습니다.");
                }
                else
                {
                    RobotCommclass.RobotToolAO(0, temp);
                }
            }
            catch
            {
                MessageBox.Show("값 입력이 잘못되었습니다.");
            }
        }
        private void button_RobotToolAO1_Click(object sender, EventArgs e)
        {
            try
            {
                float temp = Convert.ToSingle(textBox_RobotToolAO1.Text);

                if ((temp < 0) || (temp > 10))
                {
                    MessageBox.Show("입력값이 0~10 범위를 벗어났습니다.");
                }
                else
                {
                    RobotCommclass.RobotToolAO(1, temp);
                }
            }
            catch
            {
                MessageBox.Show("값 입력이 잘못되었습니다.");
            }
        }

        //DO 출력 토글하는 버튼
        private void button_IOModule_DOToggle0_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[0] == 0) IODataEX.IOModuleOutputData[0] = 1; else IODataEX.IOModuleOutputData[0] = 0;
        }
        private void button_IOModule_DOToggle1_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[1] == 0) IODataEX.IOModuleOutputData[1] = 1; else IODataEX.IOModuleOutputData[1] = 0;
        }
        private void button_IOModule_DOToggle2_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[2] == 0) IODataEX.IOModuleOutputData[2] = 1; else IODataEX.IOModuleOutputData[2] = 0;
        }
        private void button_IOModule_DOToggle3_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[3] == 0) IODataEX.IOModuleOutputData[3] = 1; else IODataEX.IOModuleOutputData[3] = 0;
        }
        private void button_IOModule_DOToggle4_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[4] == 0) IODataEX.IOModuleOutputData[4] = 1; else IODataEX.IOModuleOutputData[4] = 0;
        }
        private void button_IOModule_DOToggle5_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[5] == 0) IODataEX.IOModuleOutputData[5] = 1; else IODataEX.IOModuleOutputData[5] = 0;
        }
        private void button_IOModule_DOToggle6_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[6] == 0) IODataEX.IOModuleOutputData[6] = 1; else IODataEX.IOModuleOutputData[6] = 0;
        }
        private void button_IOModule_DOToggle7_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[7] == 0) IODataEX.IOModuleOutputData[7] = 1; else IODataEX.IOModuleOutputData[7] = 0;
        }
        private void button_IOModule_DOToggle8_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[8] == 0) IODataEX.IOModuleOutputData[8] = 1; else IODataEX.IOModuleOutputData[8] = 0;
        }
        private void button_IOModule_DOToggle9_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[9] == 0) IODataEX.IOModuleOutputData[9] = 1; else IODataEX.IOModuleOutputData[9] = 0;
        }
        private void button_IOModule_DOToggle10_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[10] == 0) IODataEX.IOModuleOutputData[10] = 1; else IODataEX.IOModuleOutputData[10] = 0;
        }
        private void button_IOModule_DOToggle11_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[11] == 0) IODataEX.IOModuleOutputData[11] = 1; else IODataEX.IOModuleOutputData[11] = 0;
        }
        private void button_IOModule_DOToggle12_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[12] == 0) IODataEX.IOModuleOutputData[12] = 1; else IODataEX.IOModuleOutputData[12] = 0;
        }
        private void button_IOModule_DOToggle13_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[13] == 0) IODataEX.IOModuleOutputData[13] = 1; else IODataEX.IOModuleOutputData[13] = 0;
        }
        private void button_IOModule_DOToggle14_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[14] == 0) IODataEX.IOModuleOutputData[14] = 1; else IODataEX.IOModuleOutputData[14] = 0;
        }
        private void button_IOModule_DOToggle15_Click(object sender, EventArgs e)
        {
            if (IODataEX.IOModuleOutputData[15] == 0) IODataEX.IOModuleOutputData[15] = 1; else IODataEX.IOModuleOutputData[15] = 0;
        }

        private void radioButton_JogMotionSelectBase_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_JogMotionSelectBase.Checked)
            {
                RobotCommclass.RobotJogTCPCoord = 1;
            }
        }

        private void radioButton_JogMotionSelectTool_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_JogMotionSelectTool.Checked)
            {
                RobotCommclass.RobotJogTCPCoord = 2;
            }
        }

        private void button_AutoWeldStartArcOff_Click(object sender, EventArgs e)
        {
            AutoWeldStartFlag = true;
            ArcFlag = false;
        }

        private void button_AutoWeldStartArcOn_Click(object sender, EventArgs e)
        {
            AutoWeldStartFlag = true;
            ArcFlag = true;
        }

        //안전설정 켜기 버튼
        private void button_RobotSafetySwitchOn_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotSafetySwitchOn();
        }

        //안전설정 끄기 버튼
        private void button_RobotSafetySwitchOff_Click(object sender, EventArgs e)
        {
            RobotCommclass.RobotSafetySwitchOff();
        }

        void SeqChangeReset()
        {
            MainSequence = "메인반복-대기";

            AutoSequenceState = "셀용접-대기";
            AutoDTSubSeq = "대기";
            AutoDTSubSeq_Buffer = "대기";
            AutoTSSubSeq = "대기";
            AutoWeldingSubState = "대기";
            AutoDTPoseRecordFlag = false;
            AutoDTPoseNextFlag = false;
            AutoDTPoseMoveFlag = false;
            AutoDTEndFlag = false;
            AutoTSStartFlag = false;
            AutoTouchAndWeldFlag = false;
            AutoWeldStartFlag = false;

            SampleSequenceState = "개별용접-대기";
            SampleDTSubSeq = "대기";
            SampleDTSubSeq_Buffer = "대기";
            SampleTSSubSeq = "대기";
            SampleWeldingSubState = "대기";
            SampleDTPoseRecordFlag = false;
            SampleDTPoseNextFlag = false;
            SampleDTPoseMoveFlag = false;
            SampleDTEndFlag = false;
            SampleTSStartFlag = false;
            SampleTouchAndWeldFlag = false;
        }

        void SeqChangeAutoTouch()
        {
            MainSequence = "메인반복-셀용접";

            AutoSequenceState = "셀용접-터치센싱 시작대기";
            AutoDTSubSeq = "대기";
            AutoTSSubSeq = "대기";
            AutoWeldingSubState = "대기";
            AutoTSStartFlag = false;
            AutoTouchAndWeldFlag = false;
            AutoWeldStartFlag = false;


            SampleSequenceState = "개별용접-대기";
            SampleDTSubSeq = "대기";
            SampleDTSubSeq_Buffer = "대기";
            SampleTSSubSeq = "대기";
            SampleWeldingSubState = "대기";
            SampleDTPoseRecordFlag = false;
            SampleDTPoseNextFlag = false;
            SampleDTPoseMoveFlag = false;
            SampleDTEndFlag = false;
            SampleTSStartFlag = false;
            SampleTouchAndWeldFlag = false;
        }

        void SeqChangeAutoWeld()
        {
            MainSequence = "메인반복-셀용접";

            AutoSequenceState = "셀용접-용접시작대기";
            AutoDTSubSeq = "대기";
            AutoTSSubSeq = "대기";
            AutoWeldingSubState = "대기";
            AutoTSStartFlag = false;
            AutoTouchAndWeldFlag = false;
            AutoWeldStartFlag = false;


            SampleSequenceState = "개별용접-대기";
            SampleDTSubSeq = "대기";
            SampleDTSubSeq_Buffer = "대기";
            SampleTSSubSeq = "대기";
            SampleWeldingSubState = "대기";
            SampleDTPoseRecordFlag = false;
            SampleDTPoseNextFlag = false;
            SampleDTPoseMoveFlag = false;
            SampleDTEndFlag = false;
            SampleTSStartFlag = false;
            SampleTouchAndWeldFlag = false;
        }

        void SeqChangeSampleTouch()
        {
            MainSequence = "메인반복-개별용접";

            AutoSequenceState = "셀용접-대기";
            AutoDTSubSeq = "대기";
            AutoDTSubSeq_Buffer = "대기";
            AutoTSSubSeq = "대기";
            AutoWeldingSubState = "대기";
            AutoDTPoseRecordFlag = false;
            AutoDTPoseNextFlag = false;
            AutoDTPoseMoveFlag = false;
            AutoDTEndFlag = false;
            AutoTSStartFlag = false;
            AutoTouchAndWeldFlag = false;
            AutoWeldStartFlag = false;


            SampleSequenceState = "개별용접-터치센싱 시작대기";
            SampleDTSubSeq = "대기";
            SampleDTSubSeq_Buffer = "대기";
            SampleTSSubSeq = "대기";
            SampleWeldingSubState = "대기";
            SampleDTPoseRecordFlag = false;
            SampleDTPoseNextFlag = false;
            SampleDTPoseMoveFlag = false;
            SampleDTEndFlag = false;
            SampleTSStartFlag = false;
            SampleTouchAndWeldFlag = false;

        }

        void SeqChangeSampleWeld()
        {
            MainSequence = "메인반복-개별용접";

            AutoSequenceState = "셀용접-대기";
            AutoDTSubSeq = "대기";
            AutoDTSubSeq_Buffer = "대기";
            AutoTSSubSeq = "대기";
            AutoWeldingSubState = "대기";
            AutoDTPoseRecordFlag = false;
            AutoDTPoseNextFlag = false;
            AutoDTPoseMoveFlag = false;
            AutoDTEndFlag = false;
            AutoTSStartFlag = false;
            AutoTouchAndWeldFlag = false;
            AutoWeldStartFlag = false;

            SampleSequenceState = "개별용접-용접시작대기";
            SampleDTSubSeq = "대기";
            SampleDTSubSeq_Buffer = "대기";
            SampleTSSubSeq = "대기";
            SampleWeldingSubState = "대기";
            SampleDTPoseRecordFlag = false;
            SampleDTPoseNextFlag = false;
            SampleDTPoseMoveFlag = false;
            SampleDTEndFlag = false;
            SampleTSStartFlag = false;
            SampleTouchAndWeldFlag = false;
        }


        //셀용접 시퀀스 리셋
        private void button_AutoWeldSeqReset_Click(object sender, EventArgs e)
        {
            SeqChangeReset();
        }

        //셀용접시퀀스 용접대기상태로 변경
        private void button_AutoWeldSeqChange2_Click(object sender, EventArgs e)
        {
            SeqChangeAutoWeld();

            //왼쪽용접 체크되어 있으면 데이터 저장
            if (checkBox_WeldFlagLeft.Checked == true)
            {
                try
                {
                    LeftWeldFlag = true;
                    CellTypeName_Left = comboBox_WeldTypeLeft.SelectedItem.ToString();

                    for (int i = 0; i < 15; i++)
                    {
                        WeldLineFlag_Left[i] = (groupBox_AutoWeldDataLeft.Controls["checkBox_WeldLineLeft" + i.ToString()] as CheckBox).Checked;
                        WeldLineWidth_Left[i] = Convert.ToDouble((groupBox_AutoWeldDataLeft.Controls["textBox_WeldWidthLeft" + i.ToString()] as TextBox).Text);
                        WeldLineGap_Left[i] = Convert.ToDouble((groupBox_AutoWeldDataLeft.Controls["textBox_WeldGapLeft" + i.ToString()] as TextBox).Text);
                        WeldCellPara_Left[i] = Convert.ToDouble((groupBox_AutoWeldDataLeft.Controls["textBox_LeftCellPara" + i.ToString()] as TextBox).Text);
                    }
                }
                catch
                {
                    MainLog_Add("셀용접시퀀스를 시작할수 없습니다. 왼쪽셀 입력값이 잘못되었습니다.");
                    return;
                }
            }
            else
            {
                LeftWeldFlag = false;
            }

            //오른쪽 용접 체크되어 있으면 데이터 저장
            if (checkBox_WeldFlagRight.Checked == true)
            {
                try
                {
                    RightWeldFlag = true;
                    CellTypeName_Right = comboBox_WeldTypeRight.SelectedItem.ToString();

                    for (int i = 0; i < 15; i++)
                    {
                        WeldLineFlag_Right[i] = (groupBox_AutoWeldDataRight.Controls["checkBox_WeldLineRight" + i.ToString()] as CheckBox).Checked;
                        WeldLineWidth_Right[i] = Convert.ToDouble((groupBox_AutoWeldDataRight.Controls["textBox_WeldWidthRight" + i.ToString()] as TextBox).Text);
                        WeldLineGap_Right[i] = Convert.ToDouble((groupBox_AutoWeldDataRight.Controls["textBox_WeldGapRight" + i.ToString()] as TextBox).Text);
                        WeldCellPara_Right[i] = Convert.ToDouble((groupBox_AutoWeldDataRight.Controls["textBox_RightCellPara" + i.ToString()] as TextBox).Text);
                    }
                }
                catch
                {
                    MainLog_Add("셀용접시퀀스를 시작할수 없습니다. 오른쪽셀 입력값이 잘못되었습니다.");
                    return;
                }
            }
            else
            {
                RightWeldFlag = false;
            }
        }

        //셀용접시퀀스 터치대기 상태로 변경
        private void button_AutoWeldSeqChange1_Click(object sender, EventArgs e)
        {
            SeqChangeAutoTouch();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "축 : " + RobotDataEX.moni_RobotJointActualAngle[0].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotJointActualAngle[1].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotJointActualAngle[2].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotJointActualAngle[3].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotJointActualAngle[4].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotJointActualAngle[5].ToString("0.0 ")
                            + "직교 : "     + RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.0 ")
                                        + "," + RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.0 ");
        }

        private void button_FilletStart_Click(object sender, EventArgs e)
        {
            if (MainSequence != "메인반복-대기")
            {
                MainLog_Add("다른 작업 진행중"); ;
                return;
            }
            ManualSequenceState = "수동조작-시편테스트용접";
            MainSequence = "메인반복-수동조작시작";
        }

        private void button_FilletDTST_Click(object sender, EventArgs e)
        {
           // if (TestWeldingState == "시편 테스트 용접-직접교시 입력대기")
          //  {
                if (1 == RobotCommclass.RobotDirectTeachingOn())
                {
                    MainLog_Add("다이랙트 티칭 시작");
                    TestWeldingState = "시편 테스트 용접-1번티칭";
                }
                else
                {
                    MainLog_Add("다이랙트 티칭 실행 실패");
                }
          //  }
          //  else
          //  {
          //      MainLog_Add("해당 단계가 아닙니다"); 
          //  }
            

        }

        private void button_Filletpoint1_Click(object sender, EventArgs e)
        {
            // if (TestWeldingState == "시편 테스트 용접-1번티칭")
            // {
            //현재위치 기록

            DTLeftPoseRecord(0); // 수직
            //else if (radioButton2.Checked) DTLeftPoseRecord(0);// DTLeftPoseRecord_test(0); // 수평
                                                                    

            TestWeldingState = "시편 테스트 용접-2번티칭";
                MainLog_Add("좌표0 저장 성공");
          //  }
          //  else { MainLog_Add("좌표0 저장 실패"); }

        }

        private void button_Filletpoint2_Click(object sender, EventArgs e)
        {

            // if (TestWeldingState == "시편 테스트 용접-2번티칭")
            //  {
            //현재위치 기록
            DTRightPoseRecord(0); // 수직
            //else if (radioButton2.Checked) DTRightPoseRecord(0);// DTRightPoseRecord_test(0);// 수평

            TestWeldingState = "시편 테스트 용접-티칭종료";
                    MainLog_Add("좌표1 저장 성공");
              //  }
             //   else { MainLog_Add("좌표1 저장 실패"); }

        }

        private void button_FilletDTEnd_Click(object sender, EventArgs e)
        {
           // if (TestWeldingState == "시편 테스트 용접-티칭종료")
          //  {
                RobotCommclass.RobotDirectTeachingOff();
                MainLog_Add("직접교시 종료");
              
                AutoTSSubSeq = "시작";
           // }
           // else { MainLog_Add("직접교시 종료 실패"); }
        }

        private void button_FilletWeldST_Click(object sender, EventArgs e)
        {
                AutoWeldStartFlag = true;
                ArcFlag = true;
        }

        private void button_FilletMoveSt_Click(object sender, EventArgs e)
        {
                AutoWeldStartFlag = true;
                ArcFlag = false;
        }

        private void button_TCST_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked) direction = 1; // 수직
            else if (radioButton2.Checked) direction = 2; // 수평
            else if (radioButton3.Checked) direction = 3; // 위보기

            TestWeldingState = "시편 테스트 용접-터치센싱 시작";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainSequence = "메인반복-대기";
            ManualSequenceState = "수동조작-대기";
        }

        private void Wirecut_Click(object sender, EventArgs e)
        {
            if (MainSequence != "메인반복-대기")
            {
                MainLog_Add("다른 작업 진행중"); ;
                return;
            }
            ManualSequenceState = "수동조작-와이어컷팅";
            MainSequence = "메인반복-수동조작시작";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int tempi = 0;
            float tempf = 0;

            CLINK_API_RESULT caRetVal = clinkCs.robot_tool_power_voltage_current_get(RobotCommclass.robotID, out tempi, out tempf);

            string temps = "";

            if(tempi == (int)CLINK_TOOL_IO_POWER_VOLTAGE_OPTION.CLINK_TOOL_POWER_VOLTAGE_OPTION_0)
            {
                temps = "0V, ";
            }
            else if (tempi == (int)CLINK_TOOL_IO_POWER_VOLTAGE_OPTION.CLINK_TOOL_POWER_VOLTAGE_OPTION_12)
            {
                temps = "12V, ";
            }
            else if (tempi == (int)CLINK_TOOL_IO_POWER_VOLTAGE_OPTION.CLINK_TOOL_POWER_VOLTAGE_OPTION_24)
            {
                temps = "24V, ";
            }
            else
            {
                temps = "??V, ";
            }
            textBox_ToolPower.Text = temps + tempf.ToString();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            test_VolIO.Text = Convert.ToString(RobotDataEX.moni_RobotIOValueAO[0]);
            test_AmpIO.Text = Convert.ToString(RobotDataEX.moni_RobotIOValueAO[1]);
        }

        private void button6_Click(object sender, EventArgs e)
        {

            //DTLeftPoseRecord_V1(0);
            TestWeldingState = "시편 테스트 용접-2번티칭";
            MainLog_Add("좌표0 저장 성공");
            //DTRightPoseRecord_V1(0);
            TestWeldingState = "시편 테스트 용접-티칭종료";
            MainLog_Add("좌표1 저장 성공");
        }


        private void button_CalRotation_Click(object sender, EventArgs e)
        {
            float ORx, ORy, ORz;
            float AxisX, AxisY, AxisZ, RAngle;
            float RRx, RRy, RRz;

            try
            {
                ORx = Convert.ToSingle(textBox_CalOriginalRotation.Text.Trim().Split(',')[0].Trim());
                ORy = Convert.ToSingle(textBox_CalOriginalRotation.Text.Trim().Split(',')[1].Trim());
                ORz = Convert.ToSingle(textBox_CalOriginalRotation.Text.Trim().Split(',')[2].Trim());

                AxisX = Convert.ToSingle(textBox_CalRotationVectorAndAngle.Text.Trim().Split(',')[0].Trim());
                AxisY = Convert.ToSingle(textBox_CalRotationVectorAndAngle.Text.Trim().Split(',')[1].Trim());
                AxisZ = Convert.ToSingle(textBox_CalRotationVectorAndAngle.Text.Trim().Split(',')[2].Trim());
                RAngle = Convert.ToSingle(textBox_CalRotationVectorAndAngle.Text.Trim().Split(',')[3].Trim());
            }
            catch
            {
                textBox_CalResultRotation.Text = "입력이 잘못됨";
                return;
            }
            
            RobotCommclass.RobotBaseRotation(ORx, ORy, ORz, AxisX, AxisY, AxisZ, RAngle, out RRx, out RRy, out RRz);
            textBox_CalResultRotation.Text = RRx.ToString(".00") + "," + RRy.ToString(".00") + "," + RRz.ToString(".00");

        }


        float[] TCPCalcPose_X = new float[5];
        float[] TCPCalcPose_Y = new float[5];
        float[] TCPCalcPose_Z = new float[5];
        float[] TCPCalcPose_Rx = new float[5];
        float[] TCPCalcPose_Ry = new float[5];
        float[] TCPCalcPose_Rz = new float[5];
        int TCPCalcPoseCount = 0;

        private void button_RobotMountAngleRead_Click(object sender, EventArgs e)
        {
            textBox_SettingRobotMountRxNow.Text = IMUclass.RobotRx.ToString("0.00");
            textBox_SettingRobotMountRyNow.Text = IMUclass.RobotRy.ToString("0.00");
        }

        private void button_TCPCalc_Click(object sender, EventArgs e)
        {
            float[] tcp = RobotCommclass.TCPCalculation(TCPCalcPose_X, TCPCalcPose_Y, TCPCalcPose_Z, TCPCalcPose_Rx, TCPCalcPose_Ry, TCPCalcPose_Rz);
            textBox_TCP_X_Now.Text = tcp[0].ToString("0.00");
            textBox_TCP_Y_Now.Text = tcp[1].ToString("0.00");
            textBox_TCP_Z_Now.Text = tcp[2].ToString("0.00");
            textBox_TCP_Rx_Now.Text = tcp[3].ToString("0.00");
            textBox_TCP_Ry_Now.Text = tcp[4].ToString("0.00");
            textBox_TCP_Rz_Now.Text = tcp[5].ToString("0.00");
        }

        private void button_TCPPoseRecord_Click(object sender, EventArgs e)
        {
            TCPCalcPose_X[TCPCalcPoseCount] = RobotDataEX.moni_RobotTCPActualPose[0];
            TCPCalcPose_Y[TCPCalcPoseCount] = RobotDataEX.moni_RobotTCPActualPose[1];
            TCPCalcPose_Z[TCPCalcPoseCount] = RobotDataEX.moni_RobotTCPActualPose[2];
            TCPCalcPose_Rx[TCPCalcPoseCount] = RobotDataEX.moni_RobotTCPActualPose[3];
            TCPCalcPose_Ry[TCPCalcPoseCount] = RobotDataEX.moni_RobotTCPActualPose[4];
            TCPCalcPose_Rz[TCPCalcPoseCount] = RobotDataEX.moni_RobotTCPActualPose[5];
            TCPCalcPoseCount++;
            if (TCPCalcPoseCount >= 5) TCPCalcPoseCount = 0;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            DTRightPoseRecord(0);
            MainLog_Add("좌표0 저장 성공");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            DTRightPoseRecord(1);
            MainLog_Add("좌표1 저장 성공");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            DTRightPoseRecord(2);
            MainLog_Add("좌표2 저장 성공");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            DTRightPoseRecord(3);
            MainLog_Add("좌표3 저장 성공");
        }

        private void button23_Click(object sender, EventArgs e)
        {
            DTRightPoseRecord(4);
            MainLog_Add("좌표4 저장 성공");
            TestWeldingState = "시편 테스트 용접-티칭종료";
        }

        private void button15_Click(object sender, EventArgs e)
        {
             if (radioButton4.Checked) direction = 4; // 위보기

            TestWeldingState = "시편 테스트 용접-터치센싱 시작";

        }

        private void button_SettingPoseCopy1_Click(object sender, EventArgs e)
        {
            textBox_SettingPoseCutReadyX.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.0");
            textBox_SettingPoseCutReadyY.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.0");
            textBox_SettingPoseCutReadyZ.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.0");
            textBox_SettingPoseCutReadyRx.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.0");
            textBox_SettingPoseCutReadyRy.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.0");
            textBox_SettingPoseCutReadyRz.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.0");
        }

        private void button_SettingPoseCopy2_Click(object sender, EventArgs e)
        {
            textBox_SettingPoseCutX.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.0");
            textBox_SettingPoseCutY.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.0");
            textBox_SettingPoseCutZ.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.0");
            textBox_SettingPoseCutRx.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.0");
            textBox_SettingPoseCutRy.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.0");
            textBox_SettingPoseCutRz.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.0");
        }

        private void button_SettingPoseCopy3_Click(object sender, EventArgs e)
        {
            textBox_SettingPoseTCPX.Text = RobotDataEX.moni_RobotTCPActualPose[0].ToString("0.0");
            textBox_SettingPoseTCPY.Text = RobotDataEX.moni_RobotTCPActualPose[1].ToString("0.0");
            textBox_SettingPoseTCPZ.Text = RobotDataEX.moni_RobotTCPActualPose[2].ToString("0.0");
            textBox_SettingPoseTCPRx.Text = RobotDataEX.moni_RobotTCPActualPose[3].ToString("0.0");
            textBox_SettingPoseTCPRy.Text = RobotDataEX.moni_RobotTCPActualPose[4].ToString("0.0");
            textBox_SettingPoseTCPRz.Text = RobotDataEX.moni_RobotTCPActualPose[5].ToString("0.0");
        }

        private void button_TCPCheck1_Click(object sender, EventArgs e)
        {
            if (MainSequence != "메인반복-대기")
            {
                MainLog_Add("다른 작업 진행중"); ;
                return;
            }
            ManualSequenceState = "수동조작-TCP확인";
            MainSequence = "메인반복-수동조작시작";
        }

        private void button_WeldDBLoad_Click(object sender, EventArgs e)
        {
            //기존 DB데이터 삭제
            WeldDatabase.Clear();

            //용접DB파일 로드
            WeldDatabaseLoad();
        }

        private void button_MotionTest0_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(TCP_LCP_B());
            tempRobotPoseArr.Add(TCP_LCP_LB());
            tempRobotPoseArr.Add(TCP_LCP_L());
            tempRobotPoseArr.Add(TCP_LCP_LU());
            tempRobotPoseArr.Add(TCP_U_L());
            tempRobotPoseArr.Add(TCP_L_U());
            tempRobotPoseArr.Add(TCP_L());
            tempRobotPoseArr.Add(TCP_L_B());
            tempRobotPoseArr.Add(TCP_L_BB());
            tempRobotPoseArr.Add(TCP_BL());
            tempRobotPoseArr.Add(TCP_B_L());
            tempRobotPoseArr.Add(TCP_B());
            tempRobotPoseArr.Add(TCP_B_RR());
            tempRobotPoseArr.Add(TCP_BR());
            tempRobotPoseArr.Add(TCP_R_BB());
            tempRobotPoseArr.Add(TCP_R_B());
            tempRobotPoseArr.Add(TCP_R());
            tempRobotPoseArr.Add(TCP_R_U());
            tempRobotPoseArr.Add(TCP_U_RR());
            tempRobotPoseArr.Add(TCP_RCP_RU());
            tempRobotPoseArr.Add(TCP_RCP_R());
            tempRobotPoseArr.Add(TCP_RCP_RB());
            tempRobotPoseArr.Add(TCP_RCP_B());
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest1_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(TCP_LCP_B());
            tempRobotPoseArr.Add(TCP_LCP_LB());
            tempRobotPoseArr.Add(TCP_LCP_L());
            tempRobotPoseArr.Add(TCP_LCP_LU());
            tempRobotPoseArr.Add(TCP_U_L());
            tempRobotPoseArr.Add(TCP_L_U());
            tempRobotPoseArr.Add(TCP_L());
            tempRobotPoseArr.Add(TCP_L_B());
            tempRobotPoseArr.Add(TCP_L_BB());
            tempRobotPoseArr.Add(TCP_BL());
            tempRobotPoseArr.Add(TCP_B_L());
            tempRobotPoseArr.Add(TCP_B());
            tempRobotPoseArr.Add(TCP_B_RR());
            tempRobotPoseArr.Add(TCP_BR());
            tempRobotPoseArr.Add(TCP_R_BB());
            tempRobotPoseArr.Add(TCP_R_B());
            tempRobotPoseArr.Add(TCP_R());
            tempRobotPoseArr.Add(TCP_R_U());
            tempRobotPoseArr.Add(TCP_U_RR());
            tempRobotPoseArr.Add(TCP_RCP_RU());
            tempRobotPoseArr.Add(TCP_RCP_R());
            tempRobotPoseArr.Add(TCP_RCP_RB());
            tempRobotPoseArr.Add(TCP_RCP_B());
            tempRobotPoseArr.Reverse();
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest2_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(TCP_DirChange0());
            tempRobotPoseArr.Add(TCP_DirChange1());
            tempRobotPoseArr.Add(TCP_DirChange2());
            tempRobotPoseArr.Add(TCP_DirChange3());
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest3_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(TCP_DirChange0());
            tempRobotPoseArr.Add(TCP_DirChange1());
            tempRobotPoseArr.Add(TCP_DirChange2());
            tempRobotPoseArr.Add(TCP_DirChange3());
            tempRobotPoseArr.Reverse();
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest4_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(Joint_LCP_B());
            tempRobotPoseArr.Add(Joint_LCP_LB());
            tempRobotPoseArr.Add(Joint_LCP_L());
            tempRobotPoseArr.Add(Joint_LCP_LU());
            tempRobotPoseArr.Add(Joint_U_L());
            tempRobotPoseArr.Add(Joint_L_U());
            tempRobotPoseArr.Add(Joint_L());
            tempRobotPoseArr.Add(Joint_L_B());
            tempRobotPoseArr.Add(Joint_L_BB());
            tempRobotPoseArr.Add(Joint_BL());
            tempRobotPoseArr.Add(Joint_B_L());
            tempRobotPoseArr.Add(Joint_B());
            tempRobotPoseArr.Add(Joint_B_RR());
            tempRobotPoseArr.Add(Joint_BR());
            tempRobotPoseArr.Add(Joint_R_BB());
            tempRobotPoseArr.Add(Joint_R_B());
            tempRobotPoseArr.Add(Joint_R());
            tempRobotPoseArr.Add(Joint_R_U());
            tempRobotPoseArr.Add(Joint_U_RR());
            tempRobotPoseArr.Add(Joint_RCP_RU());
            tempRobotPoseArr.Add(Joint_RCP_R());
            tempRobotPoseArr.Add(Joint_RCP_RB());
            tempRobotPoseArr.Add(Joint_RCP_B());
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest5_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(Joint_LCP_B());
            tempRobotPoseArr.Add(Joint_LCP_LB());
            tempRobotPoseArr.Add(Joint_LCP_L());
            tempRobotPoseArr.Add(Joint_LCP_LU());
            tempRobotPoseArr.Add(Joint_U_L());
            tempRobotPoseArr.Add(Joint_L_U());
            tempRobotPoseArr.Add(Joint_L());
            tempRobotPoseArr.Add(Joint_L_B());
            tempRobotPoseArr.Add(Joint_L_BB());
            tempRobotPoseArr.Add(Joint_BL());
            tempRobotPoseArr.Add(Joint_B_L());
            tempRobotPoseArr.Add(Joint_B());
            tempRobotPoseArr.Add(Joint_B_RR());
            tempRobotPoseArr.Add(Joint_BR());
            tempRobotPoseArr.Add(Joint_R_BB());
            tempRobotPoseArr.Add(Joint_R_B());
            tempRobotPoseArr.Add(Joint_R());
            tempRobotPoseArr.Add(Joint_R_U());
            tempRobotPoseArr.Add(Joint_U_RR());
            tempRobotPoseArr.Add(Joint_RCP_RU());
            tempRobotPoseArr.Add(Joint_RCP_R());
            tempRobotPoseArr.Add(Joint_RCP_RB());
            tempRobotPoseArr.Add(Joint_RCP_B());
            tempRobotPoseArr.Reverse();
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest6_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(Joint_DirChange0());
            tempRobotPoseArr.Add(Joint_DirChange1());
            tempRobotPoseArr.Add(Joint_DirChange2());
            tempRobotPoseArr.Add(Joint_DirChange3());
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_MotionTest7_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            tempRobotPoseArr.Add(Joint_DirChange0());
            tempRobotPoseArr.Add(Joint_DirChange1());
            tempRobotPoseArr.Add(Joint_DirChange2());
            tempRobotPoseArr.Add(Joint_DirChange3());
            tempRobotPoseArr.Reverse();
            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
        }

        private void button_ClosePoseFind_Click(object sender, EventArgs e)
        {
            int index = FindCloseRDPIndex(RobotDataEX.moni_RobotTCPActualPose[0], RobotDataEX.moni_RobotTCPActualPose[1], RobotDataEX.moni_RobotTCPActualPose[2], RobotDataEX.moni_RobotTCPActualPose[3], RobotDataEX.moni_RobotTCPActualPose[4], RobotDataEX.moni_RobotTCPActualPose[5]);
            textBox_ClosePoseFind.Text = index.ToString();
        }

        private void button_ClosePoseMove_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();

            int InitPoseIndex = FindCloseRDPIndex(RobotDataEX.moni_RobotTCPActualPose[0], RobotDataEX.moni_RobotTCPActualPose[1], RobotDataEX.moni_RobotTCPActualPose[2], RobotDataEX.moni_RobotTCPActualPose[3], RobotDataEX.moni_RobotTCPActualPose[4], RobotDataEX.moni_RobotTCPActualPose[5]);
            int TargetPoseIndex = Convert.ToInt32(textBox_TargetPose.Text);

            string[] tempstr = textBox_TestMovePose.Text.Split(',');
            List<int> movepose = new List<int>();
            try
            {
                foreach (string str in tempstr) movepose.Add(Convert.ToInt32(str));
            }
            catch
            {
                return;
            }

            
            if (TargetPoseIndex > InitPoseIndex)
            {
                tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[InitPoseIndex].Clone());

                for (int i = InitPoseIndex + 1; i < TargetPoseIndex; i++)
                {
                    foreach(int tempi in movepose) if(i == tempi) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                }

                tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[TargetPoseIndex].Clone());
            }
            else if (TargetPoseIndex < InitPoseIndex)
            {
                tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[InitPoseIndex].Clone());
                
                for (int i = InitPoseIndex + 1; i > TargetPoseIndex; i--)
                {
                    foreach (int tempi in movepose) if (i == tempi) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                }
                
                tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[TargetPoseIndex].Clone());
            }
            else
            {
                tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[TargetPoseIndex].Clone());
            }

            RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);

        }


        //시편용접 데이터 UI에서 1~입력인수 까지는 보여주고 그 이상은 숨겨주는 함수
        private void SampleTypeUIVisible(int count)
        {
            for (int i = 0; i <= count; i++)
            {
                (groupBox_SampleWeldData0.Controls["textBox_WeldWidthSample" + i.ToString()] as TextBox).Visible = true;
                (groupBox_SampleWeldData0.Controls["textBox_WeldGapSample" + i.ToString()] as TextBox).Visible = true;
            }

            for (int i = count + 1; i < 8; i++)
            {
                (groupBox_SampleWeldData0.Controls["textBox_WeldWidthSample" + i.ToString()] as TextBox).Visible = false;
                (groupBox_SampleWeldData0.Controls["textBox_WeldGapSample" + i.ToString()] as TextBox).Visible = false;
            }
        }

        //시편용접 직접교시 UI에서 1~입력인수 까지는 보여주고 그 이상은 숨겨주는 함수
        private void SampleDTUIVisibleLeft(int count)
        {
            for (int i = 0; i <= count; i++)
            {
                (groupBox_SampleWeldDT.Controls["button_DTSample" + i.ToString()] as Button).Visible = true;
                (groupBox_SampleWeldDT.Controls["textBox_DTSample" + i.ToString()] as TextBox).Visible = true;
            }

            for (int i = count + 1; i < 8; i++)
            {
                (groupBox_SampleWeldDT.Controls["button_DTSample" + i.ToString()] as Button).Visible = false;
                (groupBox_SampleWeldDT.Controls["textBox_DTSample" + i.ToString()] as TextBox).Visible = false;
            }
        }


        private void comboBox_WeldSample_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet2F")
            {
                textBox_WeldSamplePara0.Text = "0";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if(comboBox_WeldSample.SelectedItem.ToString() == "Fillet2F.Wide")
            {
                comboBox_WeldSample.SelectedIndex = 0;
                textBox_WeldSamplePara0.Text = "1";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";

            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet3F")
            {
                textBox_WeldSamplePara0.Text = "0";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet3F.Left")
            {
                comboBox_WeldSample.SelectedIndex = 2;
                textBox_WeldSamplePara0.Text = "1";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet3F.Left.Wide")
            {
                comboBox_WeldSample.SelectedIndex = 2;
                textBox_WeldSamplePara0.Text = "2";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet3F.Right")
            {
                comboBox_WeldSample.SelectedIndex = 2;
                textBox_WeldSamplePara0.Text = "3";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet3F.Right.Wide")
            {
                comboBox_WeldSample.SelectedIndex = 2;
                textBox_WeldSamplePara0.Text = "4";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet4F")
            {
                textBox_WeldSamplePara0.Text = "0";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet4F.Left")
            {
                comboBox_WeldSample.SelectedIndex = 7;
                textBox_WeldSamplePara0.Text = "1";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }
            else if (comboBox_WeldSample.SelectedItem.ToString() == "Fillet4F.Right")
            {
                comboBox_WeldSample.SelectedIndex = 7;
                textBox_WeldSamplePara0.Text = "2";
                textBox_WeldSamplePara1.Text = "0";
                textBox_WeldSamplePara2.Text = "0";
                textBox_WeldSamplePara3.Text = "0";
                textBox_WeldSamplePara4.Text = "0";
                textBox_WeldSamplePara5.Text = "0";
                textBox_WeldSamplePara6.Text = "0";
                textBox_WeldSamplePara7.Text = "0";
                textBox_WeldSamplePara8.Text = "0";
                textBox_WeldSamplePara9.Text = "0";
                textBox_WeldSamplePara10.Text = "0";
                textBox_WeldSamplePara11.Text = "0";
                textBox_WeldSamplePara12.Text = "0";
                textBox_WeldSamplePara13.Text = "0";
                textBox_WeldSamplePara14.Text = "0";
            }

            SampleTypeUIVisible(SampleTypeData[comboBox_WeldSample.SelectedItem.ToString().Trim() + "_WeldLine"] - 1);
            SampleDTUIVisibleLeft(SampleTypeData[comboBox_WeldSample.SelectedItem.ToString().Trim() + "_DTPoint"] - 1);
        }

        private void button_SampleWeldStart_Click(object sender, EventArgs e)
        {
            string SampleName = comboBox_WeldSample.SelectedItem.ToString().Trim().Split('.')[0];

            //메인시퀀스가 대기상태인지 체크. 대기상태일때만 셀용접으로 전환됨
            if (MainSequence != "메인반복-대기")
            {
                MainLog_Add("단독용접시퀀스를 시작할수 없습니다. 메인시퀀스가 대기중이 아닙니다.");
                return;
            }
            

            //왼쪽용접 체크되어 있으면 데이터 저장
            if ((SampleName=="Fillet2F")|| (SampleName == "Fillet3F") || (SampleName == "Fillet4F") )
            {
                try
                {
                    SampleTypeName = SampleName;
                    for (int i = 0; i < 8; i++)
                    {
                        SampleWeldLineWidth[i] = Convert.ToDouble((groupBox_SampleWeldData0.Controls["textBox_WeldWidthSample" + i.ToString()] as TextBox).Text);
                        SampleWeldLineGap[i] = Convert.ToDouble((groupBox_SampleWeldData0.Controls["textBox_WeldGapSample" + i.ToString()] as TextBox).Text);
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        SampleWeldCon_Vol[i] = Convert.ToDouble((groupBox_SampleWeldData1.Controls["textBox_WeldSampleVol" + (i + 1).ToString() + "F"] as TextBox).Text);
                        SampleWeldCon_Amp[i] = Convert.ToDouble((groupBox_SampleWeldData1.Controls["textBox_WeldSampleAmp" + (i + 1).ToString() + "F"] as TextBox).Text);
                        SampleWeldCon_Spd[i] = Convert.ToDouble((groupBox_SampleWeldData1.Controls["textBox_WeldSampleSpd" + (i + 1).ToString() + "F"] as TextBox).Text);
                    }
                    for (int i = 0; i < 15; i++) SampleWeldCellPara[i] = Convert.ToDouble((groupBox_SampleWeldData2.Controls["textBox_WeldSamplePara" + i.ToString()] as TextBox).Text);

                }
                catch
                {
                    MainLog_Add("단독용접시퀀스를 시작할수 없습니다. 입력 데이터가 잘못되었습니다.");
                    return;
                }
            }
            else
            {
                MainLog_Add("단독용접시퀀스를 시작할수 없습니다. 단독용접 ID가 잘못되었습니다.");
                LeftWeldFlag = false;
            }
            

            //단독용접 시퀀스로 전환
            MainSequence = "메인반복-개별용접시작";


        }

        private void button_SampleWeldDTRecord_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTPoseRecordFlag = true;
            }
        }

        private void button_SampleWeldDTNext_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTPoseNextFlag = true;
            }
        }

        private void button_SampleWeldDTPose_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTPoseMoveFlag = true;
            }
        }

        private void button_SampleWeldDTComplete_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTEndFlag = true;
            }
        }

        private void button_DTSample0_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT0 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample1_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT1 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample2_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT2 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample3_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT3 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample4_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT4 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample5_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT5 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample6_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT6 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_DTSample7_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-직접교시 완료대기")
            {
                SampleDTSubSeq = "DT7 티칭대기";
                MainLog_Add("직접교시 단계를 변경 완료.");
            }
            else
            {
                MainLog_Add("직접교시 단계를 변경할 수 없습니다. 현재 직접교시중이 아닙니다.");
            }
        }

        private void button_SampleWeldSeqReset_Click(object sender, EventArgs e)
        {
            SeqChangeReset();
        }

        private void button_SampleWeldSeqChange1_Click(object sender, EventArgs e)
        {
            SeqChangeSampleTouch();
        }

        private void button_SampleWeldSeqChange2_Click(object sender, EventArgs e)
        {
            SeqChangeSampleWeld();
        }

        private void button_SampleWeldTouchStart_Click(object sender, EventArgs e)
        {
            if (SampleSequenceState == "개별용접-터치센싱 시작대기")
            {
                SampleTSStartFlag = true;
            }
        }

        private void button_SampleWeldStartArcOff_Click(object sender, EventArgs e)
        {
            SampleWeldStartFlag = true;
            ArcFlag = false;
        }

        private void button_SampleWeldStartArcOn_Click(object sender, EventArgs e)
        {
            SampleWeldStartFlag = true;
            ArcFlag = true;
        }

        private void button_TestRobotMove_Click(object sender, EventArgs e)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            tempRobotPoseArr.Clear();
            string tempstr;
            try
            {
                tempstr = textBox_TestRobotMove.Text.Split(',')[0];
                int index = Convert.ToInt32(tempstr);
                tempstr = textBox_TestRobotMove.Text.Split(',')[1];
                float Spd = Convert.ToSingle(tempstr);
                RobotPoseData temppose = (RobotPoseData)RDP_TCP[index].Clone();
                temppose.Speed = Spd;
                tempRobotPoseArr.Add(temppose);

                RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr);
            }
            catch
            {

            }

        }

        private void button_AutoLastDTDataLoad_Click(object sender, EventArgs e)
        {
            DTDataLoad();
        }

        private void button_AutoLastTouchDataLoad_Click(object sender, EventArgs e)
        {
            TouchDataLoad();
        }
    }
}
