﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Net.Sockets;
using System.Net;

//큐 사용하기위해
using System.Collections.Concurrent;

namespace OpenBlockWeldingRobot
{

    //통신으로 주고받을 데이터 클래스
    class DataEX_UDPCommunication
    {
        public int test;

        //상태 모니터링용 변수 정의
        //곡블록 프로토콜 엑셀문서 참고


        //IO모듈 관련 모니터링값
        public byte moni_IOModulState;                                                 //IO모듈 상태
        public byte[] moni_IOModuleValueDI = new byte[8];                              //IO모듈 DI입력값
        public byte[] moni_IOModuleValueDO = new byte[8];                              //IO모듈 DO출력값

        //IMU센서 관련 모니터링값
        public byte moni_IMUModuleState;                                               //IMU모듈 상태, 0:정상, 1:비정상
        public float[] moni_IMUModuleAcc = new float[3];                               //IMU모듈 가속도 측정값 x, y, z
        public float[] moni_IMUModuleGyr = new float[3];                               //IMU모듈 각속도 측정값 x, y, z
        public float[] moni_IMUModuleAng = new float[3];                               //IMU모듈 회전각 측정값 x, y, z
        public float[] moni_IMUModuleMag = new float[3];                               //IMU모듈 자기센서값 x, y, z
        public float moni_IMUModuleTmp;                                                //IMU모듈 온도센서값

        //거리센서 관련 모니터링값
        public byte moni_DistanceSensorState;                                          //레이저 거리센서 상태, 0:정상, 1:비정상
        public float moni_DistanceSensorTool;                                          //툴 거리센서 측정값
        public float[] moni_DistanceSensorBase = new float[3];                         //베이스 거리센서 측정값 센서 1~3

        //로봇 관련 모니터링값
        public byte moni_RobotCommunicationState;                                      //로봇 통신상태 0:통신 연결됨, 1:통신연결 안됨
        public string moni_RobotAPIVersion;                                            //로봇 API SW 버전
        public byte moni_RobotEmergencyState;                                          //로봇 비상정지버튼 상태, 0:안눌림, 1:눌림
        public byte moni_RobotIOValueDI;                                               //로봇 DI 입력값
        public byte moni_RobotIOValueDO;                                               //로봇 DO 출력값
        public float[] moni_RobotIOValueAI = new float[2];                             //로봇 AI1, AI2 입력값
        public float[] moni_RobotIOValueAO = new float[2];                             //로봇 AO1, AO2 출력값
        public byte moni_RobotMotionState;                                             //로봇 모션이동 상태 0~5, 엑셀문서 참고
        public byte moni_RobotSafetySwitchState;                                       //로봇 안전상태스위치 0:켜짐, 1:꺼짐
        public byte moni_RobotSafetyState;                                             //로봇 안전상태 0:정상, 1:세이프티 위반
        public byte moni_RobotServoOnState;                                            //로봇 서보모터 상태 0:서보온, 1:서보 오프
        public byte moni_RobotMountingSerface;                                         //로봇 설치면
        public float[] moni_RobotMountingAngle = new float[2];                         //로봇 설치 각도 Rx, Ry
        public float[] moni_RobotFlangeToTCP = new float[6];                           //로봇 TCP 설정값 x,y,z,Rx,Ry,Rz
        public float moni_RobotTCPPayload;                                             //로봇 TCP 무게
        public float[] moni_RobotTCPMassCenter = new float[3];                         //로봇 TCP 무게중심 좌표 x,y,z
        public float[] moni_RobotTCPCommandPose = new float[6];                        //로봇 TCP 목표좌표 x,y,z,Rx,Ry,Rz
        public float[] moni_RobotTCPActualPose = new float[6];                         //로봇 TCP 현재좌표 x,y,z,Rx,Ry,Rz
        public float[] moni_RobotJointTmp = new float[6];                              //로봇 각축 모터 온도 1~6
        public float[] moni_RobotJointVol = new float[6];                              //로봇 각축 모터 전압 1~6
        public float[] moni_RobotJointAmp = new float[6];                              //로봇 각축 모터 전류 1~6
        public float[] moni_RobotJointCommandAngle = new float[6];                     //로봇 각축 모터 목표각도 1~6
        public float[] moni_RobotJointActualAngle = new float[6];                      //로봇 각축 모터 현재각도 1~6
        public byte moni_RobotToolIOValueDI;                                           //로봇 툴IO DI 입력값
        public byte moni_RobotToolIOValueDO;                                           //로봇 툴IO DO 출력값
        public float[] moni_RobotToolIOValueAI = new float[2];                         //로봇 툴IO AI1, AI2 입력값
        public byte moni_RobotDirectTeachingState;                                     //로봇 직접교시 상태 0:직접교시 실행중, 1:직접교시 실행중이 아님
        public byte moni_RobotCollisionDetectionState;                                 //로봇 충돌감지 기능 상태 0:충돌감지기능 켜짐, 1:충돌감지기능 꺼짐
        public float[] moni_RobotCollisionDetectionJointLimit = new float[6];          //로봇 각축 충돌감지 임계치값 1~6
        public byte moni_RobotCollisionMitigationState;                                //로봇 충돌감지 완화 기능 상태 0:충돌감지 완화기능 켜짐, 1:충돌감지 완화기능 꺼짐
        public List<RobotEventData> moni_RobotEventLog = new List<RobotEventData>();   //로봇 이벤트 기록 (발생시간, 메인그룹, 서브그룹)

        //서버 프로그램 관련 모니터링 값
        public byte moni_SWState;                                                ////-서버 프로그램 상태 0:정상, 1:비정상
        public byte moni_ControlState;                                           //서버 프로그램 제어권 상태 0:비어있음, 1:점유됨
        public byte[] moni_ControlClientIP = new byte[4];                        //서버 제어권 점유중인 클라이언트 IP
        public ushort moni_ControlClientPort;                                    //서버 제어권 점유중인 클라이언트 포트
        public string moni_ControlClientID;                                      //서버 제어권 점유중인 클라이언트 ID
        //public string moni_ControlClientUserID;                                  //서버 제어권 점유중인 클라이언트에 접속한 유저 ID

        //작업시퀀스 상태
        public string moni_MainSeqState;                                         ////-메인시퀸스 상태문자열
        public string moni_AutoSeqState;                                         ////-자동작업시퀸스 상태문자열
        public string moni_DTSeqState;                                           ////-직접교시시퀸스 상태문자열
        public string moni_TouchSeqState;                                        ////-터치센싱시퀸스 상태문자열
        public string moni_WeldSeqState;                                         ////용접시퀸스 상태문자열
        public string moni_ManualSeqState;                                       ////수동조작시퀸스 상태문자열
        public string moni_SettingSeqState;                                      ////설정시퀸스 상태문자열
        public byte[] moni_WorkClientIP = new byte[4];                           ////현재 작업지령 내린 클라이언트 IP
        public ushort moni_WorkClientPort;                                       ////현재 작업지령 내린 클라이언트 포트
        public string moni_WorkClientID;                                         ////현재 작업지령 내린 클라이언트 ID

        public string moni_AutoWeldCellType;                                     ////-자동작업 셀타입 문자열
        public bool[] moni_DTPointCompleteFlagLeft = new bool[33];               ////왼쪽 교시점 저장완료 플래그
        public bool[] moni_DTPointCompleteFlagRight = new bool[33];              ////오른쪽 교시점 저장완료 플래그

        public byte moni_CellWeldProgress;                                     ////자동용접 진행률
        public int moni_ArcTimeTotal;                                         ////자동용접 아크타임 추정시간(초)
        public int moni_ArcTimeLeft;                                          ////자동용접 남은 아크타임 추정시간(초)
        public byte moni_ArcOnFlag;                                             //용접중 전압
        public float moni_ActualArcVol;                                             //용접중 전압
        public float moni_ActualArcAmp;                                             //용접중 전류


        public DataEX_UDPCommunication()
        {
            moni_RobotAPIVersion = "0";
            moni_ControlClientID = "0";
            //moni_ControlClientUserID = "0";
            moni_MainSeqState = "0";
            moni_AutoSeqState = "0";
            moni_DTSeqState = "0";
            moni_TouchSeqState = "0";
            moni_WeldSeqState = "0";
            moni_ManualSeqState = "0";
            moni_SettingSeqState = "0";
            moni_WorkClientID = "0";
            moni_AutoWeldCellType = "0";
        }

    }

    //UDP 통신 스레드에서 받은 데이터를 통신시퀀스 스레드로 넘기는 데이터구조
    class UDP_ReceiveData
    {
        //패킷을 수신한 시간
        public DateTime receivetime;
        //패킷을 보낸 주소
        public string remoteIP;
        //패킷 데이터
        public byte[] receiveData;
        //패킷을 수신한 주소
        public string localIP;
        //패킷카운트
        public UInt16 packetCount;
        //해당 패킷이 가지고있는 권한
        public byte PermisionValue;
    }

    //UDP 통신 스레드에서 전송할 패킷 데이터구조
    class UDP_SendData
    {
        //패킷을 보낼 주소
        public string remoteIP;
        //패킷 데이터. 전송 시점에 배열 처음 2개(패킷카운트), 배열 마지막 4개(crc32값)를 채워서 전송함
        public byte[] sendData;
        //패킷을 보내는데 사용할 주소
        public string localIP;
    }


    //프로토콜 권한 및 패킷카운트 데이터 클래스
    class UDPPermisionData
    {
        public byte PermisionIP1, PermisionIP2, PermisionIP3, PermisionIP4;
        public UInt16 PermisionPort;
        public byte PermisionValue;
        public UInt16 ValidReceivePacketCount;
        public UInt16[] ReceivePacketCount;
        public UInt16 SendPacketCount;
    }

    
    class SettingChangeData
    {
        public int index;
        public int[] datai;
        public double[] datad;
        public string datas;

        public SettingChangeData()
        {
            index = 0;
            datai = new int[20] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            datad = new double[20] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            datas = "";
        }
    }


    class ThreadClass_UDPCommunication_Server
    {
        public DataEX_UDPCommunication MoniData;
        private object lockObject_UDPDataEX = new object();
        


        CRC_Check CRC_Calculator = new CRC_Check();

        //통신스레드 실행 전 통신정보 저장해 놓은 리스트
        List<string> udpIPPortList;
        List<string> udpPermisionList;

        //접속 초기화 로그
        public StringBuilder UDPInitLog = new StringBuilder();
        //UDP 통신 로그
        public List<string> UDPCommunicationLog = new List<string>();
        private object lockObject_UDPCommunicationLog = new object();


        //udp 통신 객체 생성. 여러 IP와 포트에서 받을거라 리스트로 만듬
        private List<UdpClient> UDPReceiveList = new List<UdpClient>();
        //udp 전송 전용 객체
        private UdpClient UDPSendOBJ = new UdpClient();

        //통신 허용대상 목록
        private List<UDPPermisionData> UDPPermisionList = new List<UDPPermisionData>();

        //메인 시퀀스 실행하는 스레드
        public Thread udpMainThread;
        private bool threadContinue;
        public string udpCommunicationSeq = "시작대기";

        //현재 제어권이 할당되어 있는 클라이언트 데이터
        public bool ControlClientFlag = false;   //제어권 할당 유무. true:할당횜
        public string ControlClientIP = "";
        public string ControlClientID = "";
        public DateTime ControlClient_LastReqTime = DateTime.Now;

        //작업자 ID
        public string WorkerID = "";

        //작업부재 ID
        public string WorkPiece = "";


        //자동용접 수신데이터 저장해 놓는 변수들
        public bool AutoWeldSeqStartFlag = false; //셀자동용접 시작 플래그
        public string AutoWeldLeftID = "";
        public string AutoWeldRightID = "";
        public double[] AutoWeldLegLengthLeft = new double[32];
        public double[] AutoWeldGapLeft = new double[32];
        public double[] AutoWeldParameterLeft = new double[20];
        public double[] AutoWeldLegLengthRight = new double[32];
        public double[] AutoWeldGapRight = new double[32];
        public double[] AutoWeldParameterRight = new double[20];

        public bool AutoDTPoseRecordFlag = false;       //직접교시 위치지정 플래그
        public bool AutoDTPoseNextFlag = false;         //직접교시 다음 점으로 변경 플래그
        public bool AutoDTPoseMoveFlag = false;         //직접교시 현재 기준자세모션 수행 플래그
        public bool AutoDTChangeIDFlag = false;         //직접교시 지정ID로 변경 플래그
        public string AutoDTChangeID = "";              //지정ID 정보
        public bool AutoDTEndFlag = false;              //직접교시 종료 (터치센싱 시작대기) 플래그
        public bool AutoTSStartFlag = false;  //터치센싱 시작요청 플래그 (이후 용접대기)
        public bool AutoWeldStartFlag = false;          //용접시작 플래그
        public int ArcStateSetFlag = 2;             //아크온오프 상태변경 플래그 0:이후 용접모션 아크오프, 1:이후 용접모션 아크온, 2:변경 안함
        public bool AWTouchAndWeldFlag = false;     //직접교시 완료후 또는 터치센싱 시작 후 용접까지 자동 수행하는 플래그
        public bool AutoSeqChangeTouchFlag = false; //자동용접시퀀스를 터치 단계로 변경
        public bool AutoSeqChangeWeldFlag = false; //자동용접시퀀스를 용접 단계로 변경
        public bool AutoWeldContinueFlag = false; //자동용접 용접 중 멈춰있을 때 다음용접 진행하라는 플래그

        
        //개별용접 수신데이터 저장해 놓는 변수들
        public bool SampleWeldSeqStartFlag = false; //개별용접 시작 플래그 ///
        public string SampleTypeName = "";
        public double[] SampleWeldLineWidth = new double[8];
        public double[] SampleWeldLineGap = new double[8];
        public double[] SampleWeldPara = new double[20];
        public double[] SampleWeldCon_Vol = new double[4];
        public double[] SampleWeldCon_Amp = new double[4];
        public double[] SampleWeldCon_Spd = new double[4];

        public bool SampleDTPoseRecordFlag = false;       //직접교시 위치지정 플래그
        public bool SampleDTPoseNextFlag = false;         //직접교시 다음 점으로 변경 플래그
        public bool SampleDTPoseMoveFlag = false;         //직접교시 현재 기준자세모션 수행 플래그
        public bool SampleDTChangeIDFlag = false;         //직접교시 지정ID로 변경 플래그
        public string SampleDTChangeID = "";              //지정ID 정보
        public bool SampleDTEndFlag = false;              //직접교시 종료 (터치센싱 시작대기) 플래그
        public bool SampleTSStartFlag = false;  //터치센싱 시작요청 플래그 (이후 용접대기)
        public bool SampleWeldStartFlag = false;          //용접시작 플래그
        public bool SWTouchAndWeldFlag = false;     //직접교시 완료후 또는 터치센싱 시작 후 용접까지 자동 수행하는 플래그
        public bool SampleSeqChangeTouchFlag = false;//개별용접시퀀스를 터치 단계로 변경
        public bool SampleSeqChangeWeldFlag = false; //개별용접시퀀스를 용접 단계로 변경
        public bool SampleWeldContinueFlag = false; //개별용접 용접 중 멈춰있을 때 다음용접 진행하라는 플래그


        //수동프로토콜
        public bool ManualSeqStartFlag = false;
        public bool ManualErrorResetFlag = false;
        public bool ManualMainResetFlag = false;
        public bool ManualWireCutFlag = false;
        public bool ManualDTOnFlag = false;
        public bool ManualDTOffFlag = false;
        public bool ManualServoOnFlag = false;
        public bool ManualServoOffFlag = false;
        public bool ManualInchingFlag = false;
        public bool ManualInvInchingFlag = false;
        public bool ManualGasFlag = false;


        //설정변경 프로토콜
        public ConcurrentQueue<SettingChangeData> SettingChangeProtocol = new ConcurrentQueue<SettingChangeData>();


        //설정값 모니터링
        public int Setting_WeldingAutoManualStart = 0;
        public double Setting_WeldOffsetV = 0;
        public double Setting_WeldOffsetA = 0;






        //UDP 패킷을 송,수신하는 스레드
        Thread receiveThread;
        private bool receiveThreadContinue;
        

        ConcurrentQueue<UDP_ReceiveData> UDPReceiveQueue = new ConcurrentQueue<UDP_ReceiveData>();
        ConcurrentQueue<UDP_SendData> UDPSendQueue = new ConcurrentQueue<UDP_SendData>();


        //utf-16 인코딩용 객체
        UnicodeEncoding unicode;

        public List<string> textbuffer = new List<string>();



        //생성자 2 데이터 교환용 객체와 통신포트리스트, 권한 리스트를 한꺼번에 설정하는 생성자
        /// <summary>
        /// 데이터 교환용 객체와 통신포트리스트, 권한 리스트를 한꺼번에 설정하는 생성자
        /// </summary>
        /// <param name="mainForm">메인폼 컨트롤에 접근하기 위해 넘김</param>
        /// <param name="atemp">데이터교환 객체</param>
        /// <param name="udpReceiveList">통신포트 리스트, 형식은 "IP주소/포트번호"</param>
        /// <param name="udpPermisionList">권한 리스트, 형식은 "IP주소/포트번호/권한"</param>
        public ThreadClass_UDPCommunication_Server(DataEX_UDPCommunication atemp)
        {
            //데이터교환 객체 등록
            MoniData = atemp;

            //string <> 유니코드 전환용 객체. 빅에디안 설정으로 생성
            unicode = new UnicodeEncoding(true, false);
        }

        //통신시퀀스 실행 전에 통신 IP와 권한 저장해 놓는 함수
        public void SetIPPortAndPermision(List<string> IPPortList, List<string> PermisionList)
        {
            udpIPPortList = new List<string>();
            foreach (string str in IPPortList) udpIPPortList.Add(str);

            udpPermisionList = new List<string>();
            foreach (string str in PermisionList) udpPermisionList.Add(str);
        }

        //통신기능 시작
        public void UDPCommunicationStart()
        {
            threadContinue = true;
            udpCommunicationSeq = "초기화-시작";

            //스래드클래스의 함수를 스래드로 돌림
            udpMainThread = new Thread(new ThreadStart(threadfunc));
            udpMainThread.Start();

        }

        public void UDPCommunicationStop()
        {




        }

        //권한정보를 가진 스트링리스트를 이용해서 권한객체 생성 객체 생성에 성공한 개수 리턴
        int MakePermisionObject()
        {
            int makeCount = 0;
            //권한 리스트 생성
            UDPPermisionList.Clear();
            foreach (string str in udpPermisionList)
            {
                try
                {
                    UDPPermisionData tempPermisiondata = new UDPPermisionData();
                    //들어온 인자 객체로 만들어서 리스트에 등록
                    tempPermisiondata.PermisionIP1 = Convert.ToByte(str.Split('/')[0].Split('.')[0]);
                    tempPermisiondata.PermisionIP2 = Convert.ToByte(str.Split('/')[0].Split('.')[1]);
                    tempPermisiondata.PermisionIP3 = Convert.ToByte(str.Split('/')[0].Split('.')[2]);
                    tempPermisiondata.PermisionIP4 = Convert.ToByte(str.Split('/')[0].Split('.')[3]);
                    tempPermisiondata.PermisionPort = Convert.ToUInt16(str.Split('/')[1]);
                    tempPermisiondata.PermisionValue = Convert.ToByte(str.Split('/')[2]);
                    tempPermisiondata.ValidReceivePacketCount = 0;
                    tempPermisiondata.ReceivePacketCount = new UInt16[10];
                    for (int i = 0; i < 10; i++) tempPermisiondata.ReceivePacketCount[i] = 0;
                    tempPermisiondata.SendPacketCount = 0;
                    UDPPermisionList.Add(tempPermisiondata);

                    UDPInitLog.AppendLine(str+" 권한설정 성공");
                    makeCount++;
                }
                catch
                {
                    UDPInitLog.AppendLine(str + " 권한설정 실패");
                }
            }

            return makeCount;
        }

        //통신용 UDP 객체 생성. 생성에 성공한 갯수 리턴
        int MakeUDPObject()
        {
            int makeCount = 0;
            //통신포트 리스트에 따라 UDP객체 생성. 리스트 등록
            UDPReceiveList.Clear();
            foreach (string str in udpIPPortList)
            {
                try
                {
                    IPEndPoint localEP = new IPEndPoint(IPAddress.Parse(str.Split('/')[0]), Convert.ToInt32(str.Split('/')[1]));
                    UdpClient udpCL = new UdpClient(localEP);
                    udpCL.Client.ReceiveBufferSize = 65535 * 16;
                    udpCL.Client.SendBufferSize = 65535 * 16;
                    UDPReceiveList.Add(udpCL);

                    UDPInitLog.AppendLine(str + " UDP통신 오픈 성공");
                    makeCount++;
                }
                catch
                {
                    UDPInitLog.AppendLine(str + " UDP통신 오픈 실패");
                }
            }

            return makeCount;
        }





        //UDP통신 메인스레드
        public void threadfunc()
        {

            while (threadContinue)
            {

                switch (udpCommunicationSeq)
                {
                    case "시작대기":
                        //초기상태. 아무것도 안함
                        break;

                    case "초기화-시작":
                        //외부에서 "접속시작-0" 단계로 바꾸면 접속절차 시작함
                        UDPInitLog.Clear();
                        UDPInitLog.AppendLine("UDP통신 초기화 시작");
                        udpCommunicationSeq = "초기화-권한객체생성";
                        break;

                    case "초기화-권한객체생성":
                        //통신, 권한정보로 실제 사용할 객체 만듬
                        UDPInitLog.AppendLine("접속권한 설정 시작...");

                        if (0 != MakePermisionObject())
                        {
                            udpCommunicationSeq = "초기화-UDP객체생성";
                        }
                        else
                        {
                            UDPInitLog.AppendLine("접속권한 설정 실패");
                            udpCommunicationSeq = "초기화 실패";
                        }
                        break;

                    case "초기화-UDP객체생성":
                        //UDP객체 만듬
                        UDPInitLog.AppendLine("UDP 포트 생성 시작...");

                        if (0 != MakeUDPObject())
                        {
                            udpCommunicationSeq = "초기화-통신스레드생성";
                        }
                        else
                        {
                            UDPInitLog.AppendLine("UDP 포트 생성 실패");
                            udpCommunicationSeq = "초기화 실패";
                        }
                        break;

                    case "초기화-통신스레드생성":
                        //통신스레드 실행
                        UDPInitLog.AppendLine("통신스레드 생성");

                        //udp 통신 스래드 실행
                        receiveThread = new Thread(new ThreadStart(this.UDPCommunicationthread));
                        receiveThread.Start();
                        UDPInitLog.AppendLine("초기화 완료");
                        udpCommunicationSeq = "메인반복-시작";
                        UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff")+" 통신초기화 완료. 수신 대기.");
                        break;

                    case "초기화 실패":
                        //초기화 실패함. 외부 조작 대기
                        break;

                    case "메인반복-시작":
                        //통신스레드 실행

                        //제어권이 할당되어 있는 경우 타임아웃체크
                        if(ControlClientFlag)
                        {
                            int temptime = (int)(DateTime.Now - ControlClient_LastReqTime).Ticks / 10000;

                            //마지막 제어권 요청 후 3초 이상 경과한 경우 제어권 반납처리함
                            if (temptime > 3000)
                            {
                                //요청 클라이언트 정보 리셋
                                ControlClientFlag = false;
                                ControlClientIP = "";
                                ControlClientID = "";
                                ControlClient_LastReqTime = DateTime.Now;
                            }
                        }


                        //큐에 데이터가 있는경우 꺼내서 프로토콜 확인
                        int UDPReceivecount = UDPReceiveQueue.Count;
                        for (int i = 0; i < UDPReceivecount; i++)
                        {
                            //하나 꺼냄
                            UDP_ReceiveData tempUDPrData;
                            UDPReceiveQueue.TryDequeue(out tempUDPrData);

                            //프로토콜 확인

                            //모니터링 프로토콜이라면
                            if ((tempUDPrData.receiveData[2] == 0) && (tempUDPrData.receiveData[3] == 0))
                            {
                                protocol_Monitoring(tempUDPrData);
                            }

                            //제어권 프로토콜이라면
                            if ((tempUDPrData.receiveData[2] == 1) && ((tempUDPrData.receiveData[3] == 0) || (tempUDPrData.receiveData[3] == 1) || (tempUDPrData.receiveData[3] == 2)))
                            {
                                protocol_ControlPermission(tempUDPrData);
                            }

                            //자동작업 프로토콜이라면
                            if ((tempUDPrData.receiveData[2] == 2) && ((tempUDPrData.receiveData[3] >= 0) && (tempUDPrData.receiveData[3] <= 13) ))
                            {
                                protocol_AutoWeld(tempUDPrData);
                            }

                            //개별작업 프로토콜이라면
                            if ((tempUDPrData.receiveData[2] == 4) && ((tempUDPrData.receiveData[3] >= 0) && (tempUDPrData.receiveData[3] <= 13)))
                            {
                                protocol_SampleWeld(tempUDPrData);
                            }
                            
                            //수동작업 프로토콜이라면
                            if ((tempUDPrData.receiveData[2] == 3) && ((tempUDPrData.receiveData[3] >= 0) && (tempUDPrData.receiveData[3] <= 10)))
                            {
                                protocol_Manual(tempUDPrData);
                            }

                            //설정변경 프로토콜이라면
                            if ((tempUDPrData.receiveData[2] == 5) && ((tempUDPrData.receiveData[3] >= 0) && (tempUDPrData.receiveData[3] <= 1)))
                            {
                                protocol_Setting(tempUDPrData);
                            }

                        }

                        break;

                    default:
                        break;

                }

                Thread.Sleep(1);
            }

            //udp 통신 스레드 중지
            receiveThreadContinue = false;
            receiveThread.Join();

        }

        //스레드 종료 호출
        public void threadStop()
        {
            threadContinue = false;
        }


        //내부적으로 돌아갈 스래드 함수. UDP 통신 받아서 큐에 넣어주는 역할 수행
        private void UDPCommunicationthread()
        {
            receiveThreadContinue = true;

            //리모트 IP정보 받을 객체 생성
            IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, 1);

            //스레드 반복문
            while (receiveThreadContinue)
            {

                //수신 데이터 처리. 
                foreach (UdpClient udptemp in UDPReceiveList)
                {
                    //해당 객체에 수신된 패킷이 있는 경우
                    while (udptemp.Available > 0)
                    {
                        byte[] udpdata;
                        bool countvalid = false;
                        //데이터 받아서 큐에 넣음
                        try
                        {
                            udpdata = udptemp.Receive(ref groupEP);
                            UDP_ReceiveData tempUDPdata = new UDP_ReceiveData();
                            tempUDPdata.receivetime = DateTime.Now;
                            tempUDPdata.remoteIP = groupEP.ToString();
                            tempUDPdata.receiveData = udpdata;
                            tempUDPdata.localIP = udptemp.Client.LocalEndPoint.ToString();

                            //데이터 패킷 길이가 8보다 작으면 해당 패킷은 처리 안하고 다음으로 넘어감 (최소 길이가 8임)
                            if (udpdata.Length < 8)
                            {
                                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 패킷 수신 실패. 데이터길이 짧음.");
                                continue;
                            }

                            //crc값이 다른경우 현재데이터 큐에 안넣고 다음 데이터로 넘어감
                            if (CRC32C_Check(udpdata) == false)
                            {
                                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 패킷 수신 실패. CRC 불일치.");
                                continue;
                            }

                            //패킷에서 카운트 데이터 추출. 빅엔디안 형식이라 값을 뒤집어서 넣음
                            byte[] tempbyte = new byte[] { udpdata[1], udpdata[0] };
                            UInt16 packetCount = BitConverter.ToUInt16(tempbyte, 0);

                            //수신된 패킷의 IP/Port 권한 확인
                            int perm = PermisionAndCountCheck(tempUDPdata.remoteIP, packetCount, ref countvalid);

                            //IP가 잘못 입력되었거나 권한데이터 목록에 없으면 진행 안함
                            if ((perm == 0) || (perm == -1))
                            {
                                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 패킷 수신 실패. IP 등록안됨.");
                                continue;
                            }

                            //카운트가 유효한 값이 아니면 진행 안함
                            if (countvalid == false)
                            {
                                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 패킷 수신 실패. 카운트 무효.");
                                continue;
                            }

                            //전부 정상이면 데이터 큐에 넣음
                            tempUDPdata.packetCount = packetCount;
                            tempUDPdata.PermisionValue = (byte)perm;

                            UDPReceiveQueue.Enqueue(tempUDPdata);
                        }
                        catch
                        {

                        }

                    }
                }


                //송신큐에 있는 데이터 전송
                int UDPSendCount = UDPSendQueue.Count;
                for (int i = 0; i < UDPSendCount; i++)
                {
                    UDP_SendData tempUDPSendData;
                    UDPSendQueue.TryDequeue(out tempUDPSendData);

                    UInt16 sandcount = 0;

                    byte remIP1, remIP2, remIP3, remIP4;
                    UInt16 remPort;

                    //일단 꺼낸 패킷의 IP를 숫자로 바꿈
                    try
                    {
                        remIP1 = Convert.ToByte(tempUDPSendData.remoteIP.Split(':')[0].Split('.')[0]);
                        remIP2 = Convert.ToByte(tempUDPSendData.remoteIP.Split(':')[0].Split('.')[1]);
                        remIP3 = Convert.ToByte(tempUDPSendData.remoteIP.Split(':')[0].Split('.')[2]);
                        remIP4 = Convert.ToByte(tempUDPSendData.remoteIP.Split(':')[0].Split('.')[3]);
                        remPort = Convert.ToUInt16(tempUDPSendData.remoteIP.Split(':')[1]);
                    }
                    catch
                    {
                        //인자가 잘못됐으면 다음데이터
                        continue;
                    }

                    //카운트값 검색
                    foreach (UDPPermisionData tempPDate in UDPPermisionList)
                    {
                        if ((tempPDate.PermisionIP1 == remIP1) && (tempPDate.PermisionIP2 == remIP2) && (tempPDate.PermisionIP3 == remIP3)
                            && (tempPDate.PermisionIP4 == remIP4) && (tempPDate.PermisionPort == remPort))
                        {
                            //검색이 되면 카운트 값 읽어오고 검색 빠져나옴
                            tempPDate.SendPacketCount++;
                            sandcount = tempPDate.SendPacketCount;
                            break;
                        }
                    }

                    //패킷카운트 자리에 검색된 카운트 넣음
                    byte[] temp1;
                    temp1 = BitConverter.GetBytes(sandcount);
                    tempUDPSendData.sendData[0] = temp1[1];
                    tempUDPSendData.sendData[1] = temp1[0];

                    //CRC 계산해서 넣음
                    UInt32 tempCRC = CRC_Calculator.crc32c(tempUDPSendData.sendData, tempUDPSendData.sendData.Length - 4);
                    byte[] temp2 = BitConverter.GetBytes(tempCRC);
                    Array.Reverse(temp2);
                    Array.Copy(temp2, 0, tempUDPSendData.sendData, tempUDPSendData.sendData.Length - 4, 4);

                    //수신된 주소 찾아서 해당 udp객체로 회신함
                    foreach (UdpClient udptemp in UDPReceiveList)
                    {
                        if (tempUDPSendData.localIP == udptemp.Client.LocalEndPoint.ToString())
                        {
                            try
                            {
                                int tempPort = Convert.ToInt32(tempUDPSendData.remoteIP.Split(':')[1]);
                                udptemp.Send(tempUDPSendData.sendData, tempUDPSendData.sendData.Length, tempUDPSendData.remoteIP.Split(':')[0], tempPort);
                            }catch
                            {
                                break;
                            }
                            break;
                        }
                    }
                }

                Thread.Sleep(1);

            }



        }




        //다중스레드에서 접근하기 위해 UDP데이터클래스 접근하는 부분은 함수로 따로 빼서 록걸어둠
        public void UDPDataEXWrite(DataEX_UDPCommunication tempData)
        {
            lock (lockObject_UDPDataEX)
            {
                MoniData.test = tempData.test;
                MoniData.moni_IOModulState = tempData.moni_IOModulState;
                for (int i = 0; i < 8; i++)
                {
                    MoniData.moni_IOModuleValueDI[i] = tempData.moni_IOModuleValueDI[i];
                    MoniData.moni_IOModuleValueDO[i] = tempData.moni_IOModuleValueDO[i];
                }

                MoniData.moni_IMUModuleState = tempData.moni_IMUModuleState;
                for (int i = 0; i < 3; i++)
                {
                    MoniData.moni_IMUModuleAcc[i] = tempData.moni_IMUModuleAcc[i];
                    MoniData.moni_IMUModuleGyr[i] = tempData.moni_IMUModuleGyr[i];
                    MoniData.moni_IMUModuleAng[i] = tempData.moni_IMUModuleAng[i];
                    MoniData.moni_IMUModuleMag[i] = tempData.moni_IMUModuleMag[i];
                }
                MoniData.moni_IMUModuleTmp = tempData.moni_IMUModuleTmp;

                MoniData.moni_DistanceSensorState = tempData.moni_DistanceSensorState;
                MoniData.moni_DistanceSensorTool = tempData.moni_DistanceSensorTool;
                MoniData.moni_DistanceSensorBase[0] = tempData.moni_DistanceSensorBase[0];
                MoniData.moni_DistanceSensorBase[1] = tempData.moni_DistanceSensorBase[1];
                MoniData.moni_DistanceSensorBase[2] = tempData.moni_DistanceSensorBase[2];

                MoniData.moni_RobotCommunicationState = tempData.moni_RobotCommunicationState;
                MoniData.moni_RobotAPIVersion = tempData.moni_RobotAPIVersion;
                MoniData.moni_RobotEmergencyState = tempData.moni_RobotEmergencyState;
                MoniData.moni_RobotIOValueDI = tempData.moni_RobotIOValueDI;
                MoniData.moni_RobotIOValueDO = tempData.moni_RobotIOValueDO;
                for (int i = 0; i < 2; i++)
                {
                    MoniData.moni_RobotIOValueAI[i] = tempData.moni_RobotIOValueAI[i];
                    MoniData.moni_RobotIOValueAO[i] = tempData.moni_RobotIOValueAO[i];
                    MoniData.moni_RobotMountingAngle[i] = tempData.moni_RobotMountingAngle[i];
                    MoniData.moni_RobotToolIOValueAI[i] = tempData.moni_RobotToolIOValueAI[i];
                }
                MoniData.moni_RobotMotionState = tempData.moni_RobotMotionState;
                MoniData.moni_RobotSafetySwitchState = tempData.moni_RobotSafetySwitchState;
                MoniData.moni_RobotSafetyState = tempData.moni_RobotSafetyState;
                MoniData.moni_RobotServoOnState = tempData.moni_RobotServoOnState;
                MoniData.moni_RobotMountingSerface = tempData.moni_RobotMountingSerface;
                for (int i = 0; i < 6; i++)
                {
                    MoniData.moni_RobotFlangeToTCP[i] = tempData.moni_RobotFlangeToTCP[i];
                    MoniData.moni_RobotTCPCommandPose[i] = tempData.moni_RobotTCPCommandPose[i];
                    MoniData.moni_RobotTCPActualPose[i] = tempData.moni_RobotTCPActualPose[i];
                    MoniData.moni_RobotJointTmp[i] = tempData.moni_RobotJointTmp[i];
                    MoniData.moni_RobotJointVol[i] = tempData.moni_RobotJointVol[i];
                    MoniData.moni_RobotJointAmp[i] = tempData.moni_RobotJointAmp[i];
                    MoniData.moni_RobotJointCommandAngle[i] = tempData.moni_RobotJointCommandAngle[i];
                    MoniData.moni_RobotJointActualAngle[i] = tempData.moni_RobotJointActualAngle[i];
                    MoniData.moni_RobotCollisionDetectionJointLimit[i] = tempData.moni_RobotCollisionDetectionJointLimit[i];
                }
                MoniData.moni_RobotTCPPayload = tempData.moni_RobotTCPPayload;
                MoniData.moni_RobotTCPMassCenter[0] = tempData.moni_RobotTCPMassCenter[0];
                MoniData.moni_RobotTCPMassCenter[1] = tempData.moni_RobotTCPMassCenter[1];
                MoniData.moni_RobotTCPMassCenter[2] = tempData.moni_RobotTCPMassCenter[2];
                MoniData.moni_RobotToolIOValueDI = tempData.moni_RobotToolIOValueDI;
                MoniData.moni_RobotToolIOValueDO = tempData.moni_RobotToolIOValueDO;
                MoniData.moni_RobotDirectTeachingState = tempData.moni_RobotDirectTeachingState;
                MoniData.moni_RobotCollisionDetectionState = tempData.moni_RobotCollisionDetectionState;
                MoniData.moni_RobotCollisionMitigationState = tempData.moni_RobotCollisionMitigationState;
                MoniData.moni_RobotEventLog.Clear();
                for (int i = 0; i < tempData.moni_RobotEventLog.Count; i++) MoniData.moni_RobotEventLog.Add(tempData.moni_RobotEventLog[i]);
                MoniData.moni_SWState = tempData.moni_SWState;
                MoniData.moni_ControlState = tempData.moni_ControlState;
                MoniData.moni_ControlClientIP[0] = tempData.moni_ControlClientIP[0];
                MoniData.moni_ControlClientIP[1] = tempData.moni_ControlClientIP[1];
                MoniData.moni_ControlClientIP[2] = tempData.moni_ControlClientIP[2];
                MoniData.moni_ControlClientIP[3] = tempData.moni_ControlClientIP[3];
                MoniData.moni_ControlClientPort = tempData.moni_ControlClientPort;
                MoniData.moni_ControlClientID = tempData.moni_ControlClientID;
                //MoniData.moni_ControlClientUserID = tempData.moni_ControlClientUserID;

                MoniData.moni_MainSeqState = tempData.moni_MainSeqState;
                MoniData.moni_AutoSeqState = tempData.moni_AutoSeqState;
                MoniData.moni_DTSeqState = tempData.moni_DTSeqState;
                MoniData.moni_TouchSeqState = tempData.moni_TouchSeqState;
                MoniData.moni_WeldSeqState = tempData.moni_WeldSeqState;
                MoniData.moni_ManualSeqState = tempData.moni_ManualSeqState;
                MoniData.moni_SettingSeqState = tempData.moni_SettingSeqState;
                MoniData.moni_WorkClientIP[0] = tempData.moni_WorkClientIP[0];
                MoniData.moni_WorkClientIP[1] = tempData.moni_WorkClientIP[1];
                MoniData.moni_WorkClientIP[2] = tempData.moni_WorkClientIP[2];
                MoniData.moni_WorkClientIP[3] = tempData.moni_WorkClientIP[3];
                MoniData.moni_WorkClientPort = tempData.moni_WorkClientPort;
                MoniData.moni_WorkClientID = tempData.moni_WorkClientID;

                MoniData.moni_AutoWeldCellType = tempData.moni_AutoWeldCellType;
                for(int i=0; i<33; i++)
                {
                    MoniData.moni_DTPointCompleteFlagLeft[i] = tempData.moni_DTPointCompleteFlagLeft[i];
                    MoniData.moni_DTPointCompleteFlagRight[i] = tempData.moni_DTPointCompleteFlagRight[i];
                }
                MoniData.moni_CellWeldProgress = tempData.moni_CellWeldProgress;
                MoniData.moni_ArcTimeTotal = tempData.moni_ArcTimeTotal;
                MoniData.moni_ArcTimeLeft = tempData.moni_ArcTimeLeft;

            }
        }

        public DataEX_UDPCommunication UDPDataEXRead()
        {
            lock (lockObject_UDPDataEX)
            {
                DataEX_UDPCommunication tempData = new DataEX_UDPCommunication();

                tempData.test = MoniData.test;
                tempData.moni_IOModulState = MoniData.moni_IOModulState;
                for (int i = 0; i < 8; i++)
                {
                    tempData.moni_IOModuleValueDI[i] = MoniData.moni_IOModuleValueDI[i];
                    tempData.moni_IOModuleValueDO[i] = MoniData.moni_IOModuleValueDO[i];
                }

                tempData.moni_IMUModuleState = MoniData.moni_IMUModuleState;
                for (int i = 0; i < 3; i++)
                {
                    tempData.moni_IMUModuleAcc[i] = MoniData.moni_IMUModuleAcc[i];
                    tempData.moni_IMUModuleGyr[i] = MoniData.moni_IMUModuleGyr[i];
                    tempData.moni_IMUModuleAng[i] = MoniData.moni_IMUModuleAng[i];
                    tempData.moni_IMUModuleMag[i] = MoniData.moni_IMUModuleMag[i];
                }
                tempData.moni_IMUModuleTmp = MoniData.moni_IMUModuleTmp;

                tempData.moni_DistanceSensorState = MoniData.moni_DistanceSensorState;
                tempData.moni_DistanceSensorTool = MoniData.moni_DistanceSensorTool;
                tempData.moni_DistanceSensorBase[0] = MoniData.moni_DistanceSensorBase[0];
                tempData.moni_DistanceSensorBase[1] = MoniData.moni_DistanceSensorBase[1];
                tempData.moni_DistanceSensorBase[2] = MoniData.moni_DistanceSensorBase[2];

                tempData.moni_RobotCommunicationState = MoniData.moni_RobotCommunicationState;
                tempData.moni_RobotAPIVersion = MoniData.moni_RobotAPIVersion;
                tempData.moni_RobotEmergencyState = MoniData.moni_RobotEmergencyState;
                tempData.moni_RobotIOValueDI = MoniData.moni_RobotIOValueDI;
                tempData.moni_RobotIOValueDO = MoniData.moni_RobotIOValueDO;
                for (int i = 0; i < 2; i++)
                {
                    tempData.moni_RobotIOValueAI[i] = MoniData.moni_RobotIOValueAI[i];
                    tempData.moni_RobotIOValueAO[i] = MoniData.moni_RobotIOValueAO[i];
                    tempData.moni_RobotMountingAngle[i] = MoniData.moni_RobotMountingAngle[i];
                    tempData.moni_RobotToolIOValueAI[i] = MoniData.moni_RobotToolIOValueAI[i];
                }
                tempData.moni_RobotMotionState = MoniData.moni_RobotMotionState;
                tempData.moni_RobotSafetySwitchState = MoniData.moni_RobotSafetySwitchState;
                tempData.moni_RobotSafetyState = MoniData.moni_RobotSafetyState;
                tempData.moni_RobotServoOnState = MoniData.moni_RobotServoOnState;
                tempData.moni_RobotMountingSerface = MoniData.moni_RobotMountingSerface;
                for (int i = 0; i < 6; i++)
                {
                    tempData.moni_RobotFlangeToTCP[i] = MoniData.moni_RobotFlangeToTCP[i];
                    tempData.moni_RobotTCPCommandPose[i] = MoniData.moni_RobotTCPCommandPose[i];
                    tempData.moni_RobotTCPActualPose[i] = MoniData.moni_RobotTCPActualPose[i];
                    tempData.moni_RobotJointTmp[i] = MoniData.moni_RobotJointTmp[i];
                    tempData.moni_RobotJointVol[i] = MoniData.moni_RobotJointVol[i];
                    tempData.moni_RobotJointAmp[i] = MoniData.moni_RobotJointAmp[i];
                    tempData.moni_RobotJointCommandAngle[i] = MoniData.moni_RobotJointCommandAngle[i];
                    tempData.moni_RobotJointActualAngle[i] = MoniData.moni_RobotJointActualAngle[i];
                    tempData.moni_RobotCollisionDetectionJointLimit[i] = MoniData.moni_RobotCollisionDetectionJointLimit[i];
                }
                tempData.moni_RobotTCPPayload = MoniData.moni_RobotTCPPayload;
                tempData.moni_RobotTCPMassCenter[0] = MoniData.moni_RobotTCPMassCenter[0];
                tempData.moni_RobotTCPMassCenter[1] = MoniData.moni_RobotTCPMassCenter[1];
                tempData.moni_RobotTCPMassCenter[2] = MoniData.moni_RobotTCPMassCenter[2];
                tempData.moni_RobotToolIOValueDI = MoniData.moni_RobotToolIOValueDI;
                tempData.moni_RobotToolIOValueDO = MoniData.moni_RobotToolIOValueDO;
                tempData.moni_RobotDirectTeachingState = MoniData.moni_RobotDirectTeachingState;
                tempData.moni_RobotCollisionDetectionState = MoniData.moni_RobotCollisionDetectionState;
                tempData.moni_RobotCollisionMitigationState = MoniData.moni_RobotCollisionMitigationState;
                tempData.moni_RobotEventLog.Clear();
                for (int i = 0; i < MoniData.moni_RobotEventLog.Count; i++) tempData.moni_RobotEventLog.Add(MoniData.moni_RobotEventLog[i]);

                tempData.moni_SWState = MoniData.moni_SWState;
                tempData.moni_ControlState = MoniData.moni_ControlState;
                tempData.moni_ControlClientIP[0] = MoniData.moni_ControlClientIP[0];
                tempData.moni_ControlClientIP[1] = MoniData.moni_ControlClientIP[1];
                tempData.moni_ControlClientIP[2] = MoniData.moni_ControlClientIP[2];
                tempData.moni_ControlClientIP[3] = MoniData.moni_ControlClientIP[3];
                tempData.moni_ControlClientPort = MoniData.moni_ControlClientPort;
                tempData.moni_ControlClientID = MoniData.moni_ControlClientID;
                //tempData.moni_ControlClientUserID = MoniData.moni_ControlClientUserID;

                tempData.moni_MainSeqState = MoniData.moni_MainSeqState;
                tempData.moni_AutoSeqState = MoniData.moni_AutoSeqState;
                tempData.moni_DTSeqState = MoniData.moni_DTSeqState;
                tempData.moni_TouchSeqState = MoniData.moni_TouchSeqState;
                tempData.moni_WeldSeqState = MoniData.moni_WeldSeqState;
                tempData.moni_ManualSeqState = MoniData.moni_ManualSeqState;
                tempData.moni_SettingSeqState = MoniData.moni_SettingSeqState;
                tempData.moni_WorkClientIP[0] = MoniData.moni_WorkClientIP[0];
                tempData.moni_WorkClientIP[1] = MoniData.moni_WorkClientIP[1];
                tempData.moni_WorkClientIP[2] = MoniData.moni_WorkClientIP[2];
                tempData.moni_WorkClientIP[3] = MoniData.moni_WorkClientIP[3];
                tempData.moni_WorkClientPort = MoniData.moni_WorkClientPort;
                tempData.moni_WorkClientID = MoniData.moni_WorkClientID;

                tempData.moni_AutoWeldCellType = MoniData.moni_AutoWeldCellType;
                for (int i = 0; i < 33; i++)
                {
                    tempData.moni_DTPointCompleteFlagLeft[i] = MoniData.moni_DTPointCompleteFlagLeft[i];
                    tempData.moni_DTPointCompleteFlagRight[i] = MoniData.moni_DTPointCompleteFlagRight[i];
                }
                tempData.moni_CellWeldProgress = MoniData.moni_CellWeldProgress;
                tempData.moni_ArcTimeTotal = MoniData.moni_ArcTimeTotal;
                tempData.moni_ArcTimeLeft = MoniData.moni_ArcTimeLeft;

                return tempData;
            }
        }




        //통신로그에 데이터 추가하는 함수. 메인스레드에서 접근할 때 충돌하는것을 막기 위해 록 걸어둠
        private void UDPCommunicationLog_Add(string tempstr)
        {
            lock (lockObject_UDPCommunicationLog)
            {
                UDPCommunicationLog.Add(tempstr);

                if (UDPCommunicationLog.Count > 1000)
                {
                    UDPCommunicationLog.RemoveAt(0);
                }
            }
        }

        //메인스레드에서 통신로그 최근 count개 읽어가는 함수. 통신스레드와 충돌 막기위해 록걸어둠
        public string[] UDPCommunicationLog_ReadBlock(int count)
        {
            string[] tempdata;

            lock (lockObject_UDPCommunicationLog)
            {
                if (UDPCommunicationLog.Count < count)
                {
                    tempdata = new string[UDPCommunicationLog.Count];
                    UDPCommunicationLog.CopyTo(0, tempdata, 0, UDPCommunicationLog.Count);
                }
                else
                {
                    tempdata = new string[count];
                    UDPCommunicationLog.CopyTo(UDPCommunicationLog.Count - count, tempdata, 0, count);
                }
            }

            return tempdata;
        }


        //crc32 유효성 검사
        private bool CRC32C_Check(byte[] data)
        {
            CRC_Check crc32cCheck = new CRC_Check();

            //패킷의 0번째 부터 CRC32값을 제외한 Length - 4번째 까지의 crc32c 값 계산
            UInt32 crccalc = crc32cCheck.crc32c(data, data.Length - 4);

            //패킷의 CRC값 가져옴
            byte[] tempbyte = new byte[] { data[data.Length - 1], data[data.Length - 2], data[data.Length - 3], data[data.Length - 4] };
            UInt32 packetcrc = BitConverter.ToUInt32(tempbyte, 0);


            //계산한 crc와 패킷의 crc 비교해서 같으면 true 다르면 false 반환
            if (crccalc == packetcrc)
            {
                return true;
            }
            else
            {
                return false;
            }

        }



        //해당 IP,Port의 권한과 카운트 유효성 체크 입력인자 IP/Port 형식은 x.x.x.x:x
        private int PermisionAndCountCheck(string remoteIP, UInt16 count, ref bool valid)
        {
            byte remIP1, remIP2, remIP3, remIP4;
            UInt16 remPort;

            //일단 들어온 인자 숫자로 바꿈
            try
            {
                remIP1 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[0]);
                remIP2 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[1]);
                remIP3 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[2]);
                remIP4 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[3]);
                remPort = Convert.ToUInt16(remoteIP.Split(':')[1]);
            }
            catch
            {
                //인자가 잘못됬으면 -1 리턴
                return -1;
            }

            foreach (UDPPermisionData tempPermisionData in UDPPermisionList)
            {
                if( (tempPermisionData.PermisionIP1 == remIP1) 
                    && (tempPermisionData.PermisionIP2 == remIP2)
                    && (tempPermisionData.PermisionIP3 == remIP3)
                    && (tempPermisionData.PermisionIP4 == remIP4)
                    && (tempPermisionData.PermisionPort == remPort))
                {
                    //검색 되면 카운트가 유효한지 검사함

                    if (tempPermisionData.ValidReceivePacketCount < count)
                    {
                        //현재 카운트가 이전 유효 카운트보다 크면 유효함
                        tempPermisionData.ValidReceivePacketCount = count;
                        valid = true;
                    }
                    else if ((int)count - (int)tempPermisionData.ValidReceivePacketCount < -60000)
                    {
                        //현재 카운트가 이전 카운트보다 60000이상 작으면 유효 65535->0으로 전환되는 경우
                        tempPermisionData.ValidReceivePacketCount = count;
                        valid = true;
                    }
                    else
                    {
                        //그 외에는 패킷 순서가 뒤바뀐것으로 간주하고 무효처리
                        valid = false;
                    }

                    for (int i = 9; i > 0; i--) tempPermisionData.ReceivePacketCount[i] = tempPermisionData.ReceivePacketCount[i-1];
                    tempPermisionData.ReceivePacketCount[0] = count;


                    if ( (valid==false)
                        && ((tempPermisionData.ReceivePacketCount[0] - tempPermisionData.ReceivePacketCount[1]) == 1)
                        && ((tempPermisionData.ReceivePacketCount[1] - tempPermisionData.ReceivePacketCount[2]) == 1)
                        && ((tempPermisionData.ReceivePacketCount[2] - tempPermisionData.ReceivePacketCount[3]) == 1))
                    {
                        //하지만 무효일지라도 패킷 카운트가 세번연속으로 순서대로 들어오면 유효처리 하고 해당 카운트로 교체
                        //클라이언트가 재시작 되거나 오래동안 통신이 끊어졌다가 다시 연결되거나 하는 경우
                        tempPermisionData.ValidReceivePacketCount = count;
                        valid = true;
                    }

                    //검색된 권한 반환
                    return (int)tempPermisionData.PermisionValue;
                }


            }

            //권한 목록에 없으면 0 리턴
            return 0;
        }


        //해당 IP,Port의 권한만 체크 입력인자 IP/Port 형식은 x.x.x.x:x
        private int PermisionCheck(string remoteIP)
        {
            byte remIP1, remIP2, remIP3, remIP4;
            UInt16 remPort;

            //일단 들어온 인자 숫자로 바꿈
            try
            {
                remIP1 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[0]);
                remIP2 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[1]);
                remIP3 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[2]);
                remIP4 = Convert.ToByte(remoteIP.Split(':')[0].Split('.')[3]);
                remPort = Convert.ToUInt16(remoteIP.Split(':')[1]);
            }
            catch
            {
                //인자가 잘못됬으면 -1 리턴
                return -1;
            }

            foreach (UDPPermisionData tempPermisionData in UDPPermisionList)
            {
                if ((tempPermisionData.PermisionIP1 == remIP1) && (tempPermisionData.PermisionIP2 == remIP2) && (tempPermisionData.PermisionIP3 == remIP3)
                    && (tempPermisionData.PermisionIP4 == remIP4) && (tempPermisionData.PermisionPort == remPort))
                {
                    //검색된 권한 반환
                    return (int)tempPermisionData.PermisionValue;
                }
            }

            //권한 목록에 없으면 0 리턴
            return 0;
        }


        //모니터링 프로토콜 처리하는 함수
        private void protocol_Monitoring(UDP_ReceiveData UDPReceiveData)
        {
            UDP_SendData tempUDPSendData;
            
            //수신된 패킷의 IP/Port 권한 확인
            int perm = PermisionCheck(UDPReceiveData.remoteIP);

            //모니터링 권한이 없는경우
            if (!((perm == 1) || (perm == 3)))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 모니터링 요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 모니터링 권한 없음");
                
                //권한없음 패킷 만들어서 송신큐에 추가
                tempUDPSendData = new UDP_SendData();
                tempUDPSendData.localIP = UDPReceiveData.localIP;
                tempUDPSendData.remoteIP = UDPReceiveData.remoteIP;
                tempUDPSendData.sendData = new byte[18];

                byte[] tempByteArr;
                tempByteArr = BitConverter.GetBytes(DateTime.Now.Ticks);
                Array.Reverse(tempByteArr);
                Array.Copy(tempByteArr, 0, tempUDPSendData.sendData, 2, 8);
                tempUDPSendData.sendData[10] = 0;
                tempUDPSendData.sendData[11] = 201;
                tempUDPSendData.sendData[12] = UDPReceiveData.receiveData[0];
                tempUDPSendData.sendData[13] = UDPReceiveData.receiveData[1];
                UDPSendQueue.Enqueue(tempUDPSendData);
                return;
            }

            //모니터링 기능이 꺼진경우
            if (false)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 모니터링 요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 모니터링 기능 꺼짐");

                //권한없음 패킷 만들어서 송신큐에 추가
                tempUDPSendData = new UDP_SendData();
                tempUDPSendData.localIP = UDPReceiveData.localIP;
                tempUDPSendData.remoteIP = UDPReceiveData.remoteIP;
                tempUDPSendData.sendData = new byte[18];

                byte[] tempByteArr;
                tempByteArr = BitConverter.GetBytes(DateTime.Now.Ticks);
                Array.Reverse(tempByteArr);
                Array.Copy(tempByteArr, 0, tempUDPSendData.sendData, 2, 8);
                tempUDPSendData.sendData[10] = 0;
                tempUDPSendData.sendData[11] = 200;
                tempUDPSendData.sendData[12] = UDPReceiveData.receiveData[0];
                tempUDPSendData.sendData[13] = UDPReceiveData.receiveData[1];
                UDPSendQueue.Enqueue(tempUDPSendData);
                return;
            }

            //모니터링 데이터 회신
            UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 모니터링 요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 회신완료");

            //회신패킷 만들어서 송신큐에 추가
            tempUDPSendData = new UDP_SendData();
            tempUDPSendData.localIP = UDPReceiveData.localIP;
            tempUDPSendData.remoteIP = UDPReceiveData.remoteIP;
            tempUDPSendData.sendData = MakeMonitoringData();
            tempUDPSendData.sendData[12] = UDPReceiveData.receiveData[0];
            tempUDPSendData.sendData[13] = UDPReceiveData.receiveData[1];
            UDPSendQueue.Enqueue(tempUDPSendData);

        }

        //제어권 요청 프로토콜 처리하는 함수
        void protocol_ControlPermission(UDP_ReceiveData UDPReceiveData)
        {
            UDP_SendData tempUDPSendData;

            //수신된 패킷의 IP/Port 권한 확인
            int perm = PermisionCheck(UDPReceiveData.remoteIP);

            //제어권 프로토콜 회신패킷 공통데이터 입력
            tempUDPSendData = new UDP_SendData();
            tempUDPSendData.localIP = UDPReceiveData.localIP;
            tempUDPSendData.remoteIP = UDPReceiveData.remoteIP;
            tempUDPSendData.sendData = new byte[18];
            byte[] tempByteArr;
            tempByteArr = BitConverter.GetBytes(DateTime.Now.Ticks);
            Array.Reverse(tempByteArr);
            Array.Copy(tempByteArr, 0, tempUDPSendData.sendData, 2, 8);
            tempUDPSendData.sendData[10] = 1;
            tempUDPSendData.sendData[12] = UDPReceiveData.receiveData[0];
            tempUDPSendData.sendData[13] = UDPReceiveData.receiveData[1];


            
            if ((UDPReceiveData.receiveData[3] == 0) || (UDPReceiveData.receiveData[3] == 2))
            {   
                //제어권 요청 또는 강제요청 패킷인 경우

                //제어권한이 없는경우
                if (!((perm == 2) || (perm == 3)))
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");

                    //제어권한없음 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 3;
                    UDPSendQueue.Enqueue(tempUDPSendData);
                    return;
                }

                //제어기능이 꺼진경우
                if (false)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어기능 꺼짐");

                    //제어기능 꺼짐 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 2;
                    UDPSendQueue.Enqueue(tempUDPSendData);
                    return;
                }

                //제어권 강제 할당 요청인경우
                if (UDPReceiveData.receiveData[3] == 2)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 강제요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권 할당 완료");

                    //제어권한 할당 완료 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 0;
                    UDPSendQueue.Enqueue(tempUDPSendData);

                    //요청 클라이언트 정보 저장
                    int n1 = UDPReceiveData.receiveData[4];
                    int n2 = UDPReceiveData.receiveData[n1 + 5];
                    int n3 = UDPReceiveData.receiveData[n1 + n2 + 6];

                    ControlClientFlag = true;
                    ControlClientIP = UDPReceiveData.remoteIP;
                    ControlClientID = unicode.GetString(UDPReceiveData.receiveData, 5, n1);
                    ControlClient_LastReqTime = DateTime.Now;

                    WorkerID = unicode.GetString(UDPReceiveData.receiveData, n1 + 6, n2);
                    WorkPiece = unicode.GetString(UDPReceiveData.receiveData, n1 + n2 + 7, n3);




                    return;
                }

                //강제할당요청이 아니고 제어권이 비어있는 경우
                if(ControlClientFlag==false)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권 할당 완료");

                    //제어권한 할당 완료 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 0;
                    UDPSendQueue.Enqueue(tempUDPSendData);

                    //요청 클라이언트 정보 저장
                    int n1 = UDPReceiveData.receiveData[4];
                    int n2 = UDPReceiveData.receiveData[n1 + 5];
                    int n3 = UDPReceiveData.receiveData[n1 + n2 + 6];

                    ControlClientFlag = true;
                    ControlClientIP = UDPReceiveData.remoteIP;
                    ControlClientID = unicode.GetString(UDPReceiveData.receiveData, 5, n1);
                    ControlClient_LastReqTime = DateTime.Now;

                    WorkerID = unicode.GetString(UDPReceiveData.receiveData, n1 + 6, n2);
                    WorkPiece = unicode.GetString(UDPReceiveData.receiveData, n1 + n2 + 7, n3);

                    return;
                }

                //제어권이 이미 할당된 경우 (제어권 갱신요청인 경우)
                if ((ControlClientFlag == true) && (ControlClientIP == UDPReceiveData.remoteIP))
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 갱신요청. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권 할당 완료");

                    //제어권한 할당 완료 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 0;
                    UDPSendQueue.Enqueue(tempUDPSendData);

                    //요청 클라이언트 정보 저장
                    int n1 = UDPReceiveData.receiveData[4];
                    int n2 = UDPReceiveData.receiveData[n1 + 5];
                    int n3 = UDPReceiveData.receiveData[n1 + n2 + 6];

                    ControlClientFlag = true;
                    ControlClientIP = UDPReceiveData.remoteIP;
                    ControlClientID = unicode.GetString(UDPReceiveData.receiveData, 5, n1);
                    ControlClient_LastReqTime = DateTime.Now;

                    WorkerID = unicode.GetString(UDPReceiveData.receiveData, n1 + 6, n2);
                    WorkPiece = unicode.GetString(UDPReceiveData.receiveData, n1 + n2 + 7, n3);

                    return;
                }

                //모두 아닌경우 다른 클라이언트가 제어권 소유 회신

                tempUDPSendData.sendData[11] = 4;
                UDPSendQueue.Enqueue(tempUDPSendData);




            }else if(UDPReceiveData.receiveData[3] == 1)
            {
                //제어권 반납 요청인 경우

                //제어권한이 없는경우
                if (!((perm == 2) || (perm == 3)))
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 반납. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");

                    //제어권한없음 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 6;
                    UDPSendQueue.Enqueue(tempUDPSendData);
                    return;
                }

                //제어기능이 꺼진경우
                if (false)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 반납. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어기능 꺼짐");

                    //제어기능 꺼짐 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 5;
                    UDPSendQueue.Enqueue(tempUDPSendData);
                    return;
                }

                //제어권이 비어있는 경우
                if (ControlClientFlag == false)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 반납. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권 비어있음");

                    //제어권한 할당 완료 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 1;
                    UDPSendQueue.Enqueue(tempUDPSendData);

                    return;
                }

                //제어권이 이미 할당된 경우 
                if ((ControlClientFlag == true) && (ControlClientIP == UDPReceiveData.remoteIP))
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권 반납. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권 반환 완료");

                    //제어권한 할당 완료 회신 송신큐에 추가
                    tempUDPSendData.sendData[11] = 0;
                    UDPSendQueue.Enqueue(tempUDPSendData);

                    //요청 클라이언트 정보 리셋
                    ControlClientFlag = false;
                    ControlClientIP = "";
                    ControlClientID = "";
                    ControlClient_LastReqTime = DateTime.Now;

                    return;
                }

                //전부 아닌경우 다른 클라이언트가 제어권 소유중 회신
                tempUDPSendData.sendData[11] = 7;
                UDPSendQueue.Enqueue(tempUDPSendData);




            }


        }


        //자동용접 프로토콜 처리하는 함수
        void protocol_AutoWeld(UDP_ReceiveData UDPReceiveData)
        {
            byte[] temp = new byte[] { 0, 0, 0, 0 };

            //수신된 패킷의 IP/Port 권한 확인
            int perm = PermisionCheck(UDPReceiveData.remoteIP);

            //제어권한이 없는경우
            if (!((perm == 2) || (perm == 3)))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권한이 없는 대상에서 자동용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }

            //제어권을 소유한 클라이언트가 아닌경우
            if ((ControlClientFlag==false) || (ControlClientIP != UDPReceiveData.remoteIP))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권을 소유하지 않은 대상에서 자동용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }

            //셀타입 및 용접조건 전송 패킷
            if (UDPReceiveData.receiveData[3] == 0)
            {
                int n1 = UDPReceiveData.receiveData[4];
                int n2 = UDPReceiveData.receiveData[n1 + 5];
                int n3 = UDPReceiveData.receiveData[n1 + n2 + 6];
                int n4 = UDPReceiveData.receiveData[n1 + n2 + n3 * 4 + 87];
                int n5 = UDPReceiveData.receiveData[n1 + n2 + n3 * 4 + n4 + 88];
                int sum2 = n1 + n2;
                int sum3 = n1 + n2 + n3 * 4;
                int sum4 = n1 + n2 + n3 * 4 + n4;
                int sum5 = n1 + n2 + n3 * 4 + n4 + n5 * 4;


                UnicodeEncoding tempunicode = new UnicodeEncoding(false, false);

                AutoWeldLeftID = unicode.GetString(UDPReceiveData.receiveData, n1 + 6, n2);
                AutoWeldRightID = unicode.GetString(UDPReceiveData.receiveData, n1 + n2 + n3 * 4 + 88, n4);

                byte[] tempbarr = new byte[2];

                //변수 초기화
                for (int i = 0; i < 32; i++ )
                {
                    AutoWeldLegLengthLeft[i] = 0;
                    AutoWeldGapLeft[i] = 0;
                    AutoWeldLegLengthRight[i] = 0;
                    AutoWeldGapRight[i] = 0;
                }
                for (int i = 0; i < 20; i++)
                {
                    AutoWeldParameterLeft[i] = 0;
                    AutoWeldParameterRight[i] = 0;
                }

                //패킷에서 왼쪽 각장 및 갭 데이터 추출
                for (int i = 0; i < n3; i++)
                {
                    tempbarr = new byte[] { UDPReceiveData.receiveData[sum2 + 8 + 2 * i], UDPReceiveData.receiveData[sum2 + 7 + 2 * i] };
                    AutoWeldLegLengthLeft[i] = ((double)(BitConverter.ToUInt16(tempbarr, 0))) / 100;

                    tempbarr = new byte[] { UDPReceiveData.receiveData[sum2 + n3 * 2 + 8 + 2 * i], UDPReceiveData.receiveData[sum2 + n3 * 2 + 7 + 2 * i] };
                    AutoWeldGapLeft[i] = ((double)(BitConverter.ToUInt16(tempbarr, 0))) / 100;
                }

                //패킷에서 오른쪽 각장 및 갭 데이터 추출
                for (int i = 0; i < n5; i++)
                {
                    tempbarr = new byte[] { UDPReceiveData.receiveData[sum4 + 90 + 2 * i], UDPReceiveData.receiveData[sum4 + 89 + 2 * i] };
                    AutoWeldLegLengthRight[i] = ((double)(BitConverter.ToUInt16(tempbarr, 0))) / 100;

                    tempbarr = new byte[] { UDPReceiveData.receiveData[sum4 + n5 * 2 + 90 + 2 * i], UDPReceiveData.receiveData[sum4 + n5 * 2 + 89 + 2 * i] };
                    AutoWeldGapRight[i] = ((double)(BitConverter.ToUInt16(tempbarr, 0))) / 100;
                }

                for (int i = 0; i < 20; i++ )
                {
                    Array.Copy(UDPReceiveData.receiveData, sum3 + 7 + i * 4, temp, 0, 4);
                    Array.Reverse(temp);
                    AutoWeldParameterLeft[i] = BitConverter.ToSingle(temp, 0);
                    Array.Copy(UDPReceiveData.receiveData, sum5 + 89 + i * 4, temp, 0, 4);
                    Array.Reverse(temp);
                    AutoWeldParameterRight[i] = BitConverter.ToSingle(temp, 0);
                }

                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 셀용접시퀀스 시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoWeldSeqStartFlag = true;
            }

            //기록요청 패킷
            if (UDPReceiveData.receiveData[3] == 1)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 위치기록패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoDTPoseRecordFlag = true;
            }

            //다음 교시점으로 넘어감 요청패킷
            if (UDPReceiveData.receiveData[3] == 2)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 다음 교시점 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoDTPoseNextFlag = true;
            }

            //로봇 현재교시점 기준자세로 변경 패킷
            if (UDPReceiveData.receiveData[3] == 3)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 교시점 기준자세 이동패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoDTPoseMoveFlag = true;
            }

            //교시점 변경패킷
            if (UDPReceiveData.receiveData[3] == 4)
            {
                //왼쪽 ID변경데이터와 오른쪽 ID변경데이터 둘 중 하나는 0이어야 함
                byte n1 = UDPReceiveData.receiveData[4];
                if (((UDPReceiveData.receiveData[n1 + 5] != 100) && (UDPReceiveData.receiveData[n1 + 6] == 100)) || ((UDPReceiveData.receiveData[n1 + 5] == 100) && (UDPReceiveData.receiveData[n1 + 6] != 100)) )
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 특정 교시점 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                    AutoDTChangeIDFlag = true;

                    if(UDPReceiveData.receiveData[n1 + 5] != 100)
                    {
                        AutoDTChangeID = "L"+ UDPReceiveData.receiveData[n1 + 5].ToString();
                    }
                    else
                    {
                        AutoDTChangeID = "R" + UDPReceiveData.receiveData[n1 + 6].ToString();
                    }
                }
                else
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 특정 교시점 변경패킷에서 번호 잘못됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                }
            }

            //자동용접 진행 패킷
            if ((UDPReceiveData.receiveData[3] == 5) || (UDPReceiveData.receiveData[3] == 7) )
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 터치&용접시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];
                ArcStateSetFlag = UDPReceiveData.receiveData[n1 + 5];
                AWTouchAndWeldFlag = true;
            }

            //직접교시 완료패킷
            if (UDPReceiveData.receiveData[3] == 6)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 직접교시완료패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoDTEndFlag = true;
            }

            //터치센싱 시작 패킷
            if (UDPReceiveData.receiveData[3] == 8)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 터치시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoTSStartFlag = true;
            }

            //용접 시작 패킷
            if (UDPReceiveData.receiveData[3] == 9)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 용접시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];
                ArcStateSetFlag = UDPReceiveData.receiveData[n1 + 5];
                AutoWeldStartFlag = true;
            }

            //아크온오프 상태변경 요청 패킷
            if (UDPReceiveData.receiveData[3] == 10)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 아크상태변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];
                ArcStateSetFlag = UDPReceiveData.receiveData[n1 + 5];
            }

            //터치시퀀스로 변경 패킷
            if (UDPReceiveData.receiveData[3] == 11)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 터치단계로 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoSeqChangeTouchFlag = true;
            }

            //용접시퀀스로 변경 패킷
            if (UDPReceiveData.receiveData[3] == 12)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 용접단계로 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoSeqChangeWeldFlag = true;
            }
            
            //용접 계속 진행 패킷
            if (UDPReceiveData.receiveData[3] == 13)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 셀용접프로토콜 - 용접 계속 진행패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                AutoWeldContinueFlag = true;
            }
        }


        //개별용접 프로토콜 처리하는 함수
        void protocol_SampleWeld(UDP_ReceiveData UDPReceiveData)
        {
            byte[] temp = new byte[] { 0, 0, 0, 0 };

            //수신된 패킷의 IP/Port 권한 확인
            int perm = PermisionCheck(UDPReceiveData.remoteIP);

            //제어권한이 없는경우
            if (!((perm == 2) || (perm == 3)))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권한이 없는 대상에서 개별용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }

            //제어권을 소유한 클라이언트가 아닌경우
            if ((ControlClientFlag == false) || (ControlClientIP != UDPReceiveData.remoteIP))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권을 소유하지 않은 대상에서 개별용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }

            //셀타입 및 용접조건 전송 패킷
            if (UDPReceiveData.receiveData[3] == 0)
            {
                int n1 = UDPReceiveData.receiveData[4];
                int n2 = UDPReceiveData.receiveData[n1 + 5];
                int n3 = UDPReceiveData.receiveData[n1 + n2 + 6];
                int sum2 = n1 + n2;
                int sum3 = n1 + n2 + n3 * 4;


                UnicodeEncoding tempunicode = new UnicodeEncoding(false, false);

                SampleTypeName = unicode.GetString(UDPReceiveData.receiveData, n1 + 6, n2);

                byte[] tempbarr = new byte[2];

                //변수 초기화
                for (int i = 0; i < 8; i++)
                {
                    SampleWeldLineWidth[i] = 0;
                    SampleWeldLineGap[i] = 0;
                }
                for (int i = 0; i < 4; i++)
                {
                    SampleWeldCon_Vol[i] = 0;
                    SampleWeldCon_Amp[i] = 0;
                    SampleWeldCon_Spd[i] = 0;
                }
                for (int i = 0; i < 20; i++)
                {
                    SampleWeldPara[i] = 0;
                }

                //패킷에서 왼쪽 각장 및 갭 데이터 추출
                for (int i = 0; i < n3; i++)
                {
                    tempbarr = new byte[] { UDPReceiveData.receiveData[sum2 + 8 + 2 * i], UDPReceiveData.receiveData[sum2 + 7 + 2 * i] };
                    SampleWeldLineWidth[i] = ((double)(BitConverter.ToUInt16(tempbarr, 0))) / 100;

                    tempbarr = new byte[] { UDPReceiveData.receiveData[sum2 + n3 * 2 + 8 + 2 * i], UDPReceiveData.receiveData[sum2 + n3 * 2 + 7 + 2 * i] };
                    SampleWeldLineGap[i] = ((double)(BitConverter.ToUInt16(tempbarr, 0))) / 100;
                }
                for (int i = 0; i < 4; i++)
                {
                    Array.Copy(UDPReceiveData.receiveData, sum3 + 7 + i * 12, temp, 0, 4);
                    Array.Reverse(temp);
                    SampleWeldCon_Vol[i] = BitConverter.ToSingle(temp, 0);
                    Array.Copy(UDPReceiveData.receiveData, sum3 + 11 + i * 12, temp, 0, 4);
                    Array.Reverse(temp);
                    SampleWeldCon_Amp[i] = BitConverter.ToSingle(temp, 0);
                    Array.Copy(UDPReceiveData.receiveData, sum3 + 15 + i * 12, temp, 0, 4);
                    Array.Reverse(temp);
                    SampleWeldCon_Spd[i] = BitConverter.ToSingle(temp, 0);
                }
                for (int i = 0; i < 20; i++)
                {
                    Array.Copy(UDPReceiveData.receiveData, sum3 + 55 + i * 4, temp, 0, 4);
                    Array.Reverse(temp);
                    SampleWeldPara[i] = BitConverter.ToSingle(temp, 0);
                }

                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 개별용접시퀀스 시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleWeldSeqStartFlag = true;
            }

            //기록요청 패킷
            if (UDPReceiveData.receiveData[3] == 1)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 위치기록패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleDTPoseRecordFlag = true;
            }

            //다음 교시점으로 넘어감 요청패킷
            if (UDPReceiveData.receiveData[3] == 2)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 다음 교시점 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleDTPoseNextFlag = true;
            }

            //로봇 현재교시점 기준자세로 변경 패킷
            if (UDPReceiveData.receiveData[3] == 3)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 교시점 기준자세 이동패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleDTPoseMoveFlag = true;
            }

            //교시점 변경패킷
            if (UDPReceiveData.receiveData[3] == 4)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 특정 교시점 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];

                SampleDTChangeIDFlag = true;
                SampleDTChangeID = "DT" + UDPReceiveData.receiveData[n1 + 5].ToString();
            }

            //자동용접 진행 패킷
            if ((UDPReceiveData.receiveData[3] == 5) || (UDPReceiveData.receiveData[3] == 7))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 터치&용접시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];
                ArcStateSetFlag = UDPReceiveData.receiveData[n1 + 5];
                SWTouchAndWeldFlag = true;
            }

            //직접교시 완료패킷
            if (UDPReceiveData.receiveData[3] == 6)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 직접교시완료패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleDTEndFlag = true;
            }

            //터치센싱 시작 패킷
            if (UDPReceiveData.receiveData[3] == 8)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 터치시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleTSStartFlag = true;
            }

            //용접 시작 패킷
            if (UDPReceiveData.receiveData[3] == 9)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 용접시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];
                ArcStateSetFlag = UDPReceiveData.receiveData[n1 + 5];
                SampleWeldStartFlag = true;
            }

            //아크온오프 상태변경 요청 패킷
            if (UDPReceiveData.receiveData[3] == 10)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 아크상태변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                byte n1 = UDPReceiveData.receiveData[4];
                ArcStateSetFlag = UDPReceiveData.receiveData[n1 + 5];
            }

            //터치시퀀스로 변경 패킷
            if (UDPReceiveData.receiveData[3] == 11)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 터치단계로 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleSeqChangeTouchFlag = true;
            }

            //용접시퀀스로 변경 패킷
            if (UDPReceiveData.receiveData[3] == 12)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 용접단계로 변경패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleSeqChangeWeldFlag = true;
            }

            //용접 계속 진행 패킷
            if (UDPReceiveData.receiveData[3] == 13)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 개별용접프로토콜 - 용접 계속 진행패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SampleWeldContinueFlag = true;
            }
        }


        void protocol_Manual(UDP_ReceiveData UDPReceiveData)
        {

            //수신된 패킷의 IP/Port 권한 확인
            int perm = PermisionCheck(UDPReceiveData.remoteIP);

            //제어권한이 없는경우
            if (!((perm == 2) || (perm == 3)))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권한이 없는 대상에서 개별용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }

            //제어권을 소유한 클라이언트가 아닌경우
            if ((ControlClientFlag == false) || (ControlClientIP != UDPReceiveData.remoteIP))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권을 소유하지 않은 대상에서 개별용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }


            //수동조작 상태로 전환. 커팅 홈자세 조그조작 등 동작할수있도록
            if (UDPReceiveData.receiveData[3] == 0)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 시작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualSeqStartFlag = true;
            }

            //에러해제 패킷
            if (UDPReceiveData.receiveData[3] == 1)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 에러해제패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualErrorResetFlag = true;
            }

            //와이어컷팅
            if (UDPReceiveData.receiveData[3] == 2)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 와이어컷패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualWireCutFlag = true;
            }

            //직접교시
            if (UDPReceiveData.receiveData[3] == 3)
            {
                byte n1 = UDPReceiveData.receiveData[4];
                int onoff = UDPReceiveData.receiveData[n1 + 5];

                if (onoff == 1)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 직접교시온패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                    ManualDTOnFlag = true;
                }
                else
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 직접교시오프패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                    ManualDTOffFlag = true;
                }
            }

            //서보온
            if (UDPReceiveData.receiveData[3] == 4)
            {
                byte n1 = UDPReceiveData.receiveData[4];
                int onoff = UDPReceiveData.receiveData[n1 + 5];

                if(onoff==1)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 서보온패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                    ManualServoOnFlag = true;
                }
                else
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 서보오프패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                    ManualServoOffFlag = true;
                }
            }

            //인칭
            if (UDPReceiveData.receiveData[3] == 5)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 인칭패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualInchingFlag = true;
            }

            //역인칭
            if (UDPReceiveData.receiveData[3] == 6)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 역인칭패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualInvInchingFlag = true;
            }

            //가스
            if (UDPReceiveData.receiveData[3] == 7)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 가스토출패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualGasFlag = true;
            }

            //조그
            if (UDPReceiveData.receiveData[3] == 8)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 조그조작패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                //SampleDTPoseMoveFlag = true;
            }
            
            //좌표이동
            if (UDPReceiveData.receiveData[3] == 9)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 이동패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                //SampleDTPoseMoveFlag = true;
            }

            //메인리셋
            if (UDPReceiveData.receiveData[3] == 10)
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 수동조작프로토콜 - 메인리셋패킷 수신. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                ManualMainResetFlag = true;
            }
            

        }


        void protocol_Setting(UDP_ReceiveData UDPReceiveData)
        {

            //수신된 패킷의 IP/Port 권한 확인
            int perm = PermisionCheck(UDPReceiveData.remoteIP);

            //제어권한이 없는경우
            if (!((perm == 2) || (perm == 3)))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권한이 없는 대상에서 개별용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }

            //제어권을 소유한 클라이언트가 아닌경우
            if ((ControlClientFlag == false) || (ControlClientIP != UDPReceiveData.remoteIP))
            {
                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 제어권을 소유하지 않은 대상에서 개별용접 패킷 수신됨. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 제어권한 없음");
                return;
            }




            //용접 후 자동진행설정
            if (UDPReceiveData.receiveData[3] == 0)
            {
                byte n1 = UDPReceiveData.receiveData[4];
                byte data = UDPReceiveData.receiveData[n1 + 5];

                if (data > 3)
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 설정변경중 잘못된 값 들어옴. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 용접후 자동진행설정");
                    return;
                }

                SettingChangeData tempdata = new SettingChangeData();
                tempdata.index = 0;
                tempdata.datai[0] = data;

                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 설정변경패킷 수신 - 용접후 자동진행설정. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SettingChangeProtocol.Enqueue(tempdata);
            }

            //용접조건 오프셋설정
            if (UDPReceiveData.receiveData[3] == 1)
            {
                byte n1 = UDPReceiveData.receiveData[4];
                byte data1 = UDPReceiveData.receiveData[n1 + 5];
                byte data2 = UDPReceiveData.receiveData[n1 + 6];

                if ((data1 > 100) || (data2 > 100))
                {
                    UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 설정변경중 잘못된 값 들어옴. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP + " 용접조건 오프셋설정");
                    return;
                }

                SettingChangeData tempdata = new SettingChangeData();
                tempdata.index = 1;
                tempdata.datad[0] = ((double)data1-50)/10.0;
                tempdata.datad[1] = (double)data2 - 50.0;

                UDPCommunicationLog_Add(DateTime.Now.ToString("yyyyMMdd-HH:mm:ss.fff") + " 설정변경패킷 수신 - 용접조건 오프셋변경. 수신:" + UDPReceiveData.localIP + " 송신:" + UDPReceiveData.remoteIP);
                SettingChangeProtocol.Enqueue(tempdata);
            }
        }


        //모니터링 데이터 전송해주는 함수
        public byte[] MakeMonitoringData()
        {
            DateTime starttime = DateTime.Now;

            byte[] temp;
            byte tempb;

            DataEX_UDPCommunication tempMoniData = UDPDataEXRead();



            //고정 길이가 아닌 항목 - 문자열 인자를 미리 유니코드로 인코딩 해서 길이계산
            if (tempMoniData.moni_RobotAPIVersion == null) tempMoniData.moni_RobotAPIVersion = "NULL";
            byte[] RobotAPIVersion = unicode.GetBytes(tempMoniData.moni_RobotAPIVersion);
            int n2 = RobotAPIVersion.Length;

            if (tempMoniData.moni_ControlClientID == null) tempMoniData.moni_ControlClientID = "NULL";
            byte[] ControlClientID = unicode.GetBytes(tempMoniData.moni_ControlClientID);
            int n3 = ControlClientID.Length;

            if (tempMoniData.moni_MainSeqState == null) tempMoniData.moni_MainSeqState = "NULL";
            byte[] MainSeqState = unicode.GetBytes(tempMoniData.moni_MainSeqState);
            int n4 = MainSeqState.Length;

            if (tempMoniData.moni_AutoSeqState == null) tempMoniData.moni_AutoSeqState = "NULL";
            byte[] AutoSeqState = unicode.GetBytes(tempMoniData.moni_AutoSeqState);
            int n5 = AutoSeqState.Length;

            if (tempMoniData.moni_DTSeqState == null) tempMoniData.moni_DTSeqState = "NULL";
            byte[] DTSeqState = unicode.GetBytes(tempMoniData.moni_DTSeqState);
            int n6 = DTSeqState.Length;

            if (tempMoniData.moni_TouchSeqState == null) tempMoniData.moni_TouchSeqState = "NULL";
            byte[] TouchSeqState = unicode.GetBytes(tempMoniData.moni_TouchSeqState);
            int n7 = TouchSeqState.Length;

            if (tempMoniData.moni_WeldSeqState == null) tempMoniData.moni_WeldSeqState = "NULL";
            byte[] WeldSeqState = unicode.GetBytes(tempMoniData.moni_WeldSeqState);
            int n8 = WeldSeqState.Length;

            if (tempMoniData.moni_ManualSeqState == null) tempMoniData.moni_ManualSeqState = "NULL";
            byte[] ManualSeqState = unicode.GetBytes(tempMoniData.moni_ManualSeqState);
            int n9 = ManualSeqState.Length;

            if (tempMoniData.moni_SettingSeqState == null) tempMoniData.moni_SettingSeqState = "NULL";
            byte[] SettingSeqState = unicode.GetBytes(tempMoniData.moni_SettingSeqState);
            int n10 = SettingSeqState.Length;

            if (tempMoniData.moni_WorkClientID == null) tempMoniData.moni_WorkClientID = "NULL";
            byte[] WorkClientID = unicode.GetBytes(tempMoniData.moni_WorkClientID);
            int n11 = WorkClientID.Length;

            if (tempMoniData.moni_AutoWeldCellType == null) tempMoniData.moni_AutoWeldCellType = "NULL";
            byte[] AutoWeldCellType = unicode.GetBytes(tempMoniData.moni_AutoWeldCellType);
            int n12 = AutoWeldCellType.Length;

            byte Sum_n2 = (byte)(n2);
            byte Sum_n3 = (byte)(n2 + n3);
            byte Sum_n4 = (byte)(n2 + n3 + n4);
            byte Sum_n5 = (byte)(n2 + n3 + n4 + n5);
            byte Sum_n6 = (byte)(n2 + n3 + n4 + n5 + n6);
            byte Sum_n7 = (byte)(n2 + n3 + n4 + n5 + n6 + n7);
            byte Sum_n8 = (byte)(n2 + n3 + n4 + n5 + n6 + n7 + n8);
            byte Sum_n9 = (byte)(n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9);
            byte Sum_n10 = (byte)(n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10);
            byte Sum_n11 = (byte)(n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11);
            byte Sum_n12 = (byte)(n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11 + n12);


            //고정길이 + 가변길이 해서 전체 바이트배열 선언
            byte[] UDPsandData = new byte[768 + Sum_n12];
            for (int i = 0; i < UDPsandData.Length; i++) UDPsandData[i] = 0;

            temp = BitConverter.GetBytes(DateTime.Now.Ticks);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 2, 8);

            UDPsandData[10] = 0; //모니터링 프로토콜
            UDPsandData[11] = 0; //페이지 번호

            UDPsandData[14] = tempMoniData.moni_IOModulState;
            Array.Copy(tempMoniData.moni_IOModuleValueDI, 0, UDPsandData, 15, 8);
            Array.Copy(tempMoniData.moni_IOModuleValueDO, 0, UDPsandData, 23, 8);
            UDPsandData[31] = tempMoniData.moni_IMUModuleState;

            for (int i = 0; i < 3; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_IMUModuleAcc[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 32 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_IMUModuleGyr[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 44 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_IMUModuleAng[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 56 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_IMUModuleMag[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 68 + 4 * i, 4);
            }

            temp = BitConverter.GetBytes(tempMoniData.moni_IMUModuleTmp);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 80, 4);

            UDPsandData[84] = tempMoniData.moni_DistanceSensorState;

            temp = BitConverter.GetBytes(tempMoniData.moni_DistanceSensorTool);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 85, 4);

            for (int i = 0; i < 3; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_DistanceSensorBase[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 89 + 4 * i, 4);
            }

            UDPsandData[101] = tempMoniData.moni_RobotCommunicationState;
            UDPsandData[102] = (byte)n2;
            Array.Copy(RobotAPIVersion, 0, UDPsandData, 103, n2);
            UDPsandData[103 + n2] = tempMoniData.moni_RobotEmergencyState;
            UDPsandData[104 + n2] = tempMoniData.moni_RobotIOValueDI;
            UDPsandData[105 + n2] = tempMoniData.moni_RobotIOValueDO;

            for (int i = 0; i < 2; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotIOValueAI[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 106 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotIOValueAO[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 114 + n2 + 4 * i, 4);
            }
            UDPsandData[122 + n2] = tempMoniData.moni_RobotMotionState;

            tempb = 0;
            if (tempMoniData.moni_RobotSafetySwitchState == 1) tempb = 1;
            if (tempMoniData.moni_RobotSafetyState == 1) tempb = (byte)(tempb + 2);

            UDPsandData[123 + n2] = tempMoniData.moni_RobotSafetyState;



            UDPsandData[124 + n2] = tempMoniData.moni_RobotServoOnState;
            UDPsandData[125 + n2] = tempMoniData.moni_RobotMountingSerface;

            for (int i = 0; i < 2; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotMountingAngle[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 126 + n2 + 4 * i, 4);
            }

            for (int i = 0; i < 6; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotFlangeToTCP[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 134 + n2 + 4 * i, 4);
            }

            temp = BitConverter.GetBytes(tempMoniData.moni_RobotTCPPayload);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 158 + n2, 4);

            for (int i = 0; i < 3; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotTCPMassCenter[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 162 + n2 + 4 * i, 4);
            }

            for (int i = 0; i < 6; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotTCPCommandPose[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 174 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotTCPActualPose[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 198 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotJointTmp[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 222 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotJointVol[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 246 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotJointAmp[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 270 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotJointCommandAngle[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 294 + n2 + 4 * i, 4);
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotJointActualAngle[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 318 + n2 + 4 * i, 4);
            }

            UDPsandData[342 + n2] = tempMoniData.moni_RobotToolIOValueDI;
            UDPsandData[343 + n2] = tempMoniData.moni_RobotToolIOValueDO;

            for (int i = 0; i < 2; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotToolIOValueAI[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 344 + n2 + 4 * i, 4);
            }

            UDPsandData[352 + n2] = tempMoniData.moni_RobotDirectTeachingState;
            UDPsandData[353 + n2] = tempMoniData.moni_RobotCollisionDetectionState;

            for (int i = 0; i < 6; i++)
            {
                temp = BitConverter.GetBytes(tempMoniData.moni_RobotCollisionDetectionJointLimit[i]);
                Array.Reverse(temp);
                Array.Copy(temp, 0, UDPsandData, 354 + n2 + 4 * i, 4);
            }

            UDPsandData[378 + n2] = tempMoniData.moni_RobotCollisionMitigationState;

            if (tempMoniData.moni_RobotEventLog.Count > 19)
            {
                for (int i = 0; i < 20; i++)
                {
                    temp = BitConverter.GetBytes(tempMoniData.moni_RobotEventLog[i].eventTime.Ticks);
                    Array.Reverse(temp);
                    Array.Copy(temp, 0, UDPsandData, 379 + n2 + 16 * i, 8);
                    temp = BitConverter.GetBytes(tempMoniData.moni_RobotEventLog[i].eventMainGroup);
                    Array.Reverse(temp);
                    Array.Copy(temp, 0, UDPsandData, 387 + n2 + 16 * i, 4);
                    temp = BitConverter.GetBytes(tempMoniData.moni_RobotEventLog[i].eventSubGroup);
                    Array.Reverse(temp);
                    Array.Copy(temp, 0, UDPsandData, 391 + n2 + 16 * i, 4);
                }
            }
            else
            {
                for (int i = 0; i < tempMoniData.moni_RobotEventLog.Count; i++)
                {
                    temp = BitConverter.GetBytes(tempMoniData.moni_RobotEventLog[i].eventTime.Ticks);
                    Array.Reverse(temp);
                    Array.Copy(temp, 0, UDPsandData, 379 + n2 + 16 * i, 8);
                    temp = BitConverter.GetBytes(tempMoniData.moni_RobotEventLog[i].eventMainGroup);
                    Array.Reverse(temp);
                    Array.Copy(temp, 0, UDPsandData, 387 + n2 + 16 * i, 4);
                    temp = BitConverter.GetBytes(tempMoniData.moni_RobotEventLog[i].eventSubGroup);
                    Array.Reverse(temp);
                    Array.Copy(temp, 0, UDPsandData, 391 + n2 + 16 * i, 4);
                }
            }

            UDPsandData[699 + n2] = tempMoniData.moni_SWState;
            UDPsandData[700 + n2] = tempMoniData.moni_ControlState;
            UDPsandData[701 + n2] = tempMoniData.moni_ControlClientIP[0];
            UDPsandData[702 + n2] = tempMoniData.moni_ControlClientIP[1];
            UDPsandData[703 + n2] = tempMoniData.moni_ControlClientIP[2];
            UDPsandData[704 + n2] = tempMoniData.moni_ControlClientIP[3];

            temp = BitConverter.GetBytes(tempMoniData.moni_ControlClientPort);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 705 + n2, 2);

            UDPsandData[707 + n2] = (byte)n3;
            Array.Copy(ControlClientID, 0, UDPsandData, 708 + n2, n3);

            UDPsandData[708 + Sum_n3] = (byte)n4;
            Array.Copy(MainSeqState, 0, UDPsandData, 709 + Sum_n3, n4);

            UDPsandData[709 + Sum_n4] = (byte)n5;
            Array.Copy(AutoSeqState, 0, UDPsandData, 710 + Sum_n4, n5);

            UDPsandData[710 + Sum_n5] = (byte)n6;
            Array.Copy(DTSeqState, 0, UDPsandData, 711 + Sum_n5, n6);

            UDPsandData[711 + Sum_n6] = (byte)n7;
            Array.Copy(TouchSeqState, 0, UDPsandData, 712 + Sum_n6, n7);

            UDPsandData[712 + Sum_n7] = (byte)n8;
            Array.Copy(WeldSeqState, 0, UDPsandData, 713 + Sum_n7, n8);

            UDPsandData[713 + Sum_n8] = (byte)n9;
            Array.Copy(ManualSeqState, 0, UDPsandData, 714 + Sum_n8, n9);

            UDPsandData[714 + Sum_n9] = (byte)n10;
            Array.Copy(SettingSeqState, 0, UDPsandData, 715 + Sum_n9, n10);

            UDPsandData[715 + Sum_n10] = tempMoniData.moni_WorkClientIP[0];
            UDPsandData[716 + Sum_n10] = tempMoniData.moni_WorkClientIP[1];
            UDPsandData[717 + Sum_n10] = tempMoniData.moni_WorkClientIP[2];
            UDPsandData[718 + Sum_n10] = tempMoniData.moni_WorkClientIP[3];

            temp = BitConverter.GetBytes(tempMoniData.moni_WorkClientPort);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 719 + Sum_n10, 2);

            UDPsandData[721 + Sum_n10] = (byte)n11;
            Array.Copy(WorkClientID, 0, UDPsandData, 722 + Sum_n10, n11);

            UDPsandData[722 + Sum_n11] = (byte)n12;
            Array.Copy(AutoWeldCellType, 0, UDPsandData, 723 + Sum_n11, n12);

            temp = new byte[8]{0,0,0,0,0,0,0,0};
            for(int i=0; i<8; i++)
            {
                if (tempMoniData.moni_DTPointCompleteFlagLeft[i + 0]) temp[0] = (byte)(temp[0] + (1 << i));
                if (tempMoniData.moni_DTPointCompleteFlagLeft[i + 8]) temp[1] = (byte)(temp[1] + (1 << i));
                if (tempMoniData.moni_DTPointCompleteFlagLeft[i + 16]) temp[2] = (byte)(temp[2] + (1 << i));
                if (tempMoniData.moni_DTPointCompleteFlagLeft[i + 24]) temp[3] = (byte)(temp[3] + (1 << i));

                if (tempMoniData.moni_DTPointCompleteFlagRight[i + 0]) temp[4] = (byte)(temp[4] + (1 << i));
                if (tempMoniData.moni_DTPointCompleteFlagRight[i + 8]) temp[5] = (byte)(temp[5] + (1 << i));
                if (tempMoniData.moni_DTPointCompleteFlagRight[i + 16]) temp[6] = (byte)(temp[6] + (1 << i));
                if (tempMoniData.moni_DTPointCompleteFlagRight[i + 24]) temp[7] = (byte)(temp[7] + (1 << i));
            }
            Array.Copy(temp, 0, UDPsandData, 723 + Sum_n12, 8);

            UDPsandData[731 + Sum_n12] = tempMoniData.moni_CellWeldProgress;

            temp = BitConverter.GetBytes(tempMoniData.moni_ArcTimeTotal);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 732 + Sum_n12, 2);

            temp = BitConverter.GetBytes(tempMoniData.moni_ArcTimeLeft);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 734 + Sum_n12, 2);

            UDPsandData[736 + Sum_n12] = tempMoniData.moni_ArcOnFlag;

            temp = BitConverter.GetBytes(tempMoniData.moni_ActualArcVol);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 737 + Sum_n12, 4);

            temp = BitConverter.GetBytes(tempMoniData.moni_ActualArcAmp);
            Array.Reverse(temp);
            Array.Copy(temp, 0, UDPsandData, 741 + Sum_n12, 4);

            UDPsandData[745 + Sum_n12] = Convert.ToByte(Setting_WeldingAutoManualStart);
            UDPsandData[746 + Sum_n12] = Convert.ToByte((int)(Setting_WeldOffsetV * 10) + 50);
            UDPsandData[747 + Sum_n12] = Convert.ToByte((int)Setting_WeldOffsetA + 50);


            DateTime time2 = DateTime.Now;

            return UDPsandData;
           

        }



    }
}
