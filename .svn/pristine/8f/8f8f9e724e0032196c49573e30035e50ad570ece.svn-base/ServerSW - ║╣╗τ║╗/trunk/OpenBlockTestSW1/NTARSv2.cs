﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.IO;
using System.IO.Ports;

namespace OpenBlockWeldingRobot
{

    class DataEX_NTARSv2
    {
        public int test;

        //여기에 데이터교환 필요한 변수 정의

        //상태변수
        public byte IMUModuleState;    // 상태 변수. 정의 필요

        public DateTime IMUModuleCommTime;      //마지막 통신 성공 시간

        //센서 입력 변수. 스레드에서 통신으로 받아온 값을 여기에 씀. 메인스레드에서 읽어감

        //IMUModuleAcc[0]:X축 가속도
        //IMUModuleAcc[1]:Y축 가속도
        //IMUModuleAcc[2]:Z축 가속도
        public double[] IMUModuleAcc = new double[3];

        //IMUModuleGyr[0]:X축 각속도
        //IMUModuleGyr[1]:Y축 각속도
        //IMUModuleGyr[2]:Z축 각속도
        public double[] IMUModuleGyr = new double[3];

        //z-y-x축 오일러각 기준
        //IMUModuleAng[0]:X축 회전각
        //IMUModuleAng[1]:Y축 회전각
        //IMUModuleAng[2]:Z축 회전각
        public double[] IMUModuleAng = new double[3];

        //IMUModuleMag[0]:자기센서값 X
        //IMUModuleMag[1]:자기센서값 Y
        //IMUModuleMag[2]:자기센서값 Z
        public double[] IMUModuleMag = new double[3];

        //온도센서 값
        public double IMUModuleTmp;

    }




    class ThreadClass_NTARSv2
    {
        public DataEX_NTARSv2 IMUData;
        private bool threadContinue;
        public Thread IMUthread;

        //시퀸스 상태변수
        public string IMUCommunicationSeq = "초기화-시작";
        //초기화 로그
        public StringBuilder IMUInitLog = new StringBuilder();

        SerialPort IMUSerialPort = new SerialPort();

        List<char> IMURxDataList = new List<char>();

        DateTime TxTime = DateTime.Now;

        public double RobotRx;
        public double RobotRy;
        List<double> RobotRxBuff = new List<double>();
        List<double> RobotRyBuff = new List<double>();
        int averagecount = 20;

        //포트번호
        string PortName;
        //통신속도
        int BaudRate;


        ////생성자 1
        //public ThreadClass_NTARSv2()
        //{

        //}

        //생성자 2
        public ThreadClass_NTARSv2(DataEX_NTARSv2 atemp, string COMname, int COMspeed)
        {
            IMUData = atemp;

            PortName = COMname;
            BaudRate = COMspeed;

            //스래드클래스의 함수를 스래드로 돌림
            IMUthread = new Thread(new ThreadStart(threadfunc));
            IMUthread.Start();
            
        }

        //IMURxDataList에 저장된 문자열 해석하는 함수. 실패하면 0 일반테이터패킷 1 온도패킷 2 밚환
        int DataParsing()
        {
            int CheckIndex = 0;
            string tempstr = "";
            string[] tempstrarr = new string[12] { "", "", "", "", "", "", "", "", "", "", "", "", };
            double tempd = 0;
            double[] tempdarr = new double[12] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };

            for(int i=0; i< IMURxDataList.Count-1; i++)
            {
                if ((IMURxDataList[i] == '\r') && (IMURxDataList[i + 1] == '\n'))
                {
                    CheckIndex = i;
                    break;
                }
            }

            if(CheckIndex==0)
            {
                //종료문자가 들어오지 않음. 실패처리
                return 0;
            }


            if(CheckIndex+2 == 109)
            {
                //일반 주기데이터 입력일 때
                if( (IMURxDataList[8]!=' ') || (IMURxDataList[17] != ' ') || (IMURxDataList[26] != ' ') || (IMURxDataList[35] != ' ') || (IMURxDataList[44] != ' ') || (IMURxDataList[53] != ' ') || (IMURxDataList[62] != ' ') || (IMURxDataList[71] != ' ') || (IMURxDataList[80] != ' ') || (IMURxDataList[89] != ' ') || (IMURxDataList[98] != ' '))
                {
                    //패킷 내용 에러. 데이터 삭제하고 실패처리함
                    IMURxDataList.RemoveRange(0, CheckIndex + 2);
                    return 0;
                }

                try
                {
                    for(int i=0; i<12; i++)
                    {
                        tempstrarr[i] = new string(IMURxDataList.ToArray(), 9 * i, 8);
                        tempdarr[i] = Convert.ToDouble(tempstrarr[i]);
                    }

                    IMUData.IMUModuleCommTime = DateTime.Now;
                    IMUData.IMUModuleAcc[0] = tempdarr[0];
                    IMUData.IMUModuleAcc[1] = tempdarr[1];
                    IMUData.IMUModuleAcc[2] = tempdarr[2];
                    IMUData.IMUModuleGyr[0] = tempdarr[3];
                    IMUData.IMUModuleGyr[1] = tempdarr[4];
                    IMUData.IMUModuleGyr[2] = tempdarr[5];
                    IMUData.IMUModuleAng[0] = tempdarr[6];
                    IMUData.IMUModuleAng[1] = tempdarr[7];
                    IMUData.IMUModuleAng[2] = tempdarr[8];
                    IMUData.IMUModuleMag[0] = tempdarr[9];
                    IMUData.IMUModuleMag[1] = tempdarr[10];
                    IMUData.IMUModuleMag[2] = tempdarr[11];

                    IMURxDataList.RemoveRange(0, CheckIndex + 2);
                    return 1;
                }
                catch
                {
                    //패킷 내용 에러. 데이터 삭제하고 실패처리함
                    IMURxDataList.RemoveRange(0, CheckIndex + 2);
                    return 0;
                }

            }else if(CheckIndex + 2 == 14)
            {
                //온도데이터 입력일 때
                if ((IMURxDataList[0] != 't') || (IMURxDataList[1] != 'm') || (IMURxDataList[2] != 'p') || (IMURxDataList[3] != '=') )
                {
                    //패킷 내용 에러. 데이터 삭제하고 실패처리함
                    IMURxDataList.RemoveRange(0, CheckIndex + 2);
                    return 0;
                }

                try
                {
                    tempstr = new string(IMURxDataList.ToArray(), 4, 8);
                    tempd = Convert.ToDouble(tempstr);

                    IMUData.IMUModuleCommTime = DateTime.Now;
                    IMUData.IMUModuleTmp = tempd;

                    IMURxDataList.RemoveRange(0, CheckIndex + 2);
                    return 2;
                }
                catch
                {
                    //패킷 내용 에러. 데이터 삭제하고 실패처리함
                    IMURxDataList.RemoveRange(0, CheckIndex + 2);
                    return 0;
                }

            }
            else
            {
                //그외. 데이터 삭제하고 실패처리함
                IMURxDataList.RemoveRange(0, CheckIndex + 2);
                return 0;
            }
            
        }




        //스레드 함수
        public void threadfunc()
        {
            threadContinue = true;
            DateTime InitStartTime = DateTime.Now;
            char[] txdata, rxdata, tempchar;
            int tempi;

            while (threadContinue)
            {
                //여기에 통신관련 코드 구현


                switch (IMUCommunicationSeq)
                {
                    case "시작대기":
                        //초기상태. 아무것도 안함
                        break;

                    case "초기화-시작":
                        //외부에서 "접속시작-0" 단계로 바꾸면 접속절차 시작함
                        IMUInitLog.Clear();
                        IMUInitLog.AppendLine("IMU모듈-초기화 시작");
                        IMUInitLog.AppendLine("IMU모듈-통신포트 생성 시작");

                        //IMUSerialPort.PortName = "COM3";
                        //IMUSerialPort.BaudRate = 115200;
                        IMUSerialPort.PortName = PortName;
                        IMUSerialPort.BaudRate = BaudRate;
                        IMUSerialPort.Parity = Parity.None;
                        IMUSerialPort.StopBits = StopBits.One;
                        IMUSerialPort.DataBits = 8;
                        IMUSerialPort.Handshake = Handshake.None;
                        IMUSerialPort.RtsEnable = true;
                        IMUSerialPort.DtrEnable = true;


                        try
                        {
                            IMUSerialPort.Open();
                            IMUInitLog.AppendLine("IMU모듈-통신포트 생성 성공");
                            IMUInitLog.AppendLine("IMU모듈-통신 수신대기 시작");
                            InitStartTime = DateTime.Now;
                            IMUCommunicationSeq = "초기화-통신 수신대기";
                        }
                        catch
                        {
                            IMUInitLog.AppendLine("IMU모듈-통신포트 생성 실패");
                            IMUCommunicationSeq = "초기화-실패";
                        }


                        break;

                    case "초기화-통신 수신대기":
                        //센서에서 제대로 된 패킷이 날라오는지 확인함. 0.5초 이상 정상패킷이 수신되지 않으면 에러처리

                        //시간 체크함. 500ms 이상 경과하면 실패처리
                        tempi = (int)(DateTime.Now - InitStartTime).Ticks / 10000;
                        if (tempi > 1000)
                        {
                            IMUInitLog.AppendLine("IMU모듈-센서 통신 수신실패");
                            IMUCommunicationSeq = "초기화-실패";
                        }


                        //수신데이터 처리함
                        rxdata = IMUSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length == 0)
                        {
                            break;
                        }

                        for (int i = 0; i < rxdata.Length; i++)
                        {
                            IMURxDataList.Add(rxdata[i]);
                        }

                        if(1==DataParsing())
                        {
                            IMUInitLog.AppendLine("IMU모듈-센서 통신 수신성공");
                            IMUCommunicationSeq = "메인반복-시작";
                            TxTime = DateTime.Now;
                        }
                        
                        break;
                        
                    case "초기화-실패":



                        break;

                    case "메인반복-시작":

                        //수신데이터 처리함
                        rxdata = IMUSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length != 0)
                        {
                            for (int i = 0; i < rxdata.Length; i++)
                            {
                                IMURxDataList.Add(rxdata[i]);
                            }
                        }


                        if(DataParsing()==2)
                        {
                            DataProcess();
                        }

                        //시간 체크함. 100ms 이상 경과하면 온도데이터 요청패킷 날림
                        tempi = (int)(DateTime.Now - TxTime).Ticks / 10000;
                        if (tempi > 100)
                        {
                            txdata = new char[]{ 't', 'm', 'p', '\r', '\n' };
                            IMUSerialPort.Write(txdata, 0, 5);
                            TxTime = DateTime.Now;
                        }

                        break;

                    default:
                        break;

                }





                //10m 대기
                Thread.Sleep(10);
            }
        }

        //스레드 종료 호출
        public void threadStop()
        {
            threadContinue = false;
        }


        public void DataProcess()
        {
            double Robotx, Roboty, Robotz, tempd0, tempd1, tempd2;

            Robotx = IMUData.IMUModuleAcc[1];
            Roboty = IMUData.IMUModuleAcc[0];
            Robotz = -IMUData.IMUModuleAcc[2];
            double length = Math.Sqrt(Robotx * Robotx + Roboty * Roboty + Robotz * Robotz);

            if (Math.Abs(length - 1) > 0.1) return;

            tempd0 = -Roboty / length;
            if (tempd0 < -1) tempd0 = -1;
            if (tempd0 > 1) tempd0 = 1;
            tempd1 = Math.Asin(tempd0);

            tempd0 = Robotx / (length * Math.Cos(tempd1));
            if (tempd0 < -1) tempd0 = -1;
            if (tempd0 > 1) tempd0 = 1;
            tempd2 = Math.Asin(tempd0);

            RobotRxBuff.Insert(0, tempd1 * (180 / Math.PI));
            RobotRyBuff.Insert(0, tempd2 * (180 / Math.PI));

            if (RobotRxBuff.Count > 100) RobotRxBuff.RemoveAt(99);
            if (RobotRyBuff.Count > 100) RobotRyBuff.RemoveAt(99);

            tempd1 = 0;
            tempd2 = 0;

            if (RobotRxBuff.Count > averagecount)
            {
                for (int i = 0; i < averagecount; i++)
                {
                    tempd1 = tempd1 + RobotRxBuff[i];
                    tempd2 = tempd2 + RobotRyBuff[i];
                }
                RobotRx = tempd1 / averagecount;
                RobotRy = tempd2 / averagecount;
            }
            else
            {
                for (int i = 0; i < RobotRxBuff.Count; i++)
                {
                    tempd1 = tempd1 + RobotRxBuff[i];
                    tempd2 = tempd2 + RobotRyBuff[i];
                }
                RobotRx = tempd1 / RobotRxBuff.Count;
                RobotRy = tempd2 / RobotRxBuff.Count;
            }
        }


    }
}
