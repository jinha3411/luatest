﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace OpenBlockWeldingRobot
{
    //로봇 좌표 저장용 클래스
    public class RobotPoseData : ICloneable
    {
        // 1:절대좌표-조인트 각도, 
        // 2:절대좌표-베이스좌표계 
        // 3:상대좌표 직선이동-베이스좌표계 기준(f1, f2, f3만 사용) 
        // 4:상대좌표 직선이동-툴좌표계 기준(f1, f2, f3만 사용)
        // 5:절대좌표 각도변경(f4, f5, f6만 사용)
        public int PoseType = 0; 

        public float Speed = 0;
        public float f1 = 0;
        public float f2 = 0;
        public float f3 = 0;
        public float f4 = 0;
        public float f5 = 0;
        public float f6 = 0;

        //빈 생성자
        public RobotPoseData()
        {

        }

        //해당 값을 가지고 변수 초기화하는 생성자
        public RobotPoseData(int iPoseType, double iSpeed, double if1, double if2, double if3, double if4, double if5, double if6)
        {
            PoseType = iPoseType;
            Speed = (float)iSpeed;
            f1 = (float)if1;
            f2 = (float)if2;
            f3 = (float)if3;
            f4 = (float)if4;
            f5 = (float)if5;
            f6 = (float)if6;
        }

        //로봇포즈데이터 변수 두개를 받아서 첫번째거에 f1, f2, f3, 두번째거에서 f4, f5, f6 복사해서 만드는 생성자
        public RobotPoseData(int iPoseType, double iSpeed, RobotPoseData i1, RobotPoseData i2)
        {
            PoseType = iPoseType;
            Speed = (float)iSpeed;
            f1 = i1.f1;
            f2 = i1.f2;
            f3 = i1.f3;
            f4 = i2.f4;
            f5 = i2.f5;
            f6 = i2.f6;
        }


        //x,y,z 값과 로봇포즈데이터를 받아 자세는 로봇포즈데이터, 좌표는 값으로 사용
        public RobotPoseData(int iPoseType, double iSpeed, double if1, double if2, double if3, RobotPoseData i2)
        {
            PoseType = iPoseType;
            Speed = (float)iSpeed;
            f1 = (float)if1;
            f2 = (float)if2;
            f3 = (float)if3;
            f4 = i2.f4;
            f5 = i2.f5;
            f6 = i2.f6;
        }

        public RobotPoseData(int iPoseType, double iSpeed, RobotPoseData i2, double if1, double if2, double if3)
        {
            PoseType = iPoseType;
            Speed = (float)iSpeed;

            f1 = i2.f1;
            f2 = i2.f2;
            f3 = i2.f3;
            f4 = (float)if1;
            f5 = (float)if2;
            f6 = (float)if3;

        }

        public void Copy(RobotPoseData temp)
        {
            f1 = temp.f1;
            f2 = temp.f2;
            f3 = temp.f3;
            f4 = temp.f4;
            f5 = temp.f5;
            f6 = temp.f6;
            PoseType = temp.PoseType;
            Speed = temp.Speed;
        }

        public float[] ToPoseArray()
        {
            float[] tempfloat = new float[6] { 0, 0, 0, 0, 0, 0 };
            tempfloat[0] = f1;
            tempfloat[1] = f2;
            tempfloat[2] = f3;
            tempfloat[3] = f4;
            tempfloat[4] = f5;
            tempfloat[5] = f6;

            return tempfloat;
        }

        public void AddOffset(double OffsetX, double OffsetY, double OffsetZ)
        {
            f1 = (float)(f1 + OffsetX);
            f2 = (float)(f2 + OffsetY);
            f3 = (float)(f3 + OffsetZ);

        }


        public object Clone()
        {
            RobotPoseData temp = new RobotPoseData();

            temp.f1 = this.f1;
            temp.f2 = this.f2;
            temp.f3 = this.f3;
            temp.f4 = this.f4;
            temp.f5 = this.f5;
            temp.f6 = this.f6;
            temp.PoseType = this.PoseType;
            temp.Speed = this.Speed;

            return temp;
        }

    }


    class RobotPositionRecordData : ICloneable
    {
        public DateTime RecordTime;
        public RobotPoseData ActualPosition;
        public RobotPoseData WeavingMiddlePosition;
        public object Clone()
        {
            RobotPositionRecordData tempdata = new RobotPositionRecordData();
            tempdata.ActualPosition = (RobotPoseData)this.ActualPosition.Clone();
            tempdata.WeavingMiddlePosition = (RobotPoseData)this.WeavingMiddlePosition.Clone();
            tempdata.RecordTime = this.RecordTime;

            return tempdata;
        }
    }


    class ActualWeldingPathRecord : ICloneable
    {
        public RobotPoseData StartPose;
        public RobotPoseData EndPose;
        public DateTime StartTime;
        public DateTime EndTime;
        public List<RobotPositionRecordData> MidPath = new List<RobotPositionRecordData>();

        public object Clone()
        {
            ActualWeldingPathRecord tempdata = new ActualWeldingPathRecord();
            tempdata.StartPose = (RobotPoseData)this.StartPose.Clone();
            tempdata.EndPose = (RobotPoseData)this.EndPose.Clone();
            tempdata.StartTime = this.StartTime;
            tempdata.EndTime = this.EndTime;

            for (int i = 0; i < this.MidPath.Count; i++)
            {
                tempdata.MidPath.Add((RobotPositionRecordData)this.MidPath[i].Clone());
            }

            return tempdata;
        }
    }



    class RobotEventData
    {
        public DateTime eventTime;
        public uint eventMainGroup;
        public uint eventSubGroup;
        public string eventComment;
    }

    class RobotWeldAngle
    {
        public double Rx;
        public double Ry;
        public RobotWeldAngle()
        { }
        public void RobotWeldAngleLeft(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            double x3 = x1 - x2;
            double y3 = y1 - y2;
            double z3 = z1 - z2;

            if (x3>0) this.Ry = Math.PI / 2 + Math.Acos(z3 / (Math.Sqrt(x3 * x3 + z3 * z3))) ; 
            else if (x3<0) this.Ry = Math.PI / 2 - Math.Acos(z3 / (Math.Sqrt(x3 * x3 + z3 * z3) ));
            else  this.Ry = Math.PI / 2 ;


            if (y3 > 0) this.Rx = Math.PI / 2 + Math.Acos(z3 / (Math.Sqrt(y3 * y3 + z3 * z3) ));
            else if (y3 < 0) this.Rx = Math.PI / 2 - Math.Acos(z3 / (Math.Sqrt(y3 * y3 + z3 * z3) ));
            else this.Rx = Math.PI / 2;

        }

        public void RobotWeldAngleRight(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            double x3 = x1 - x2;
            double y3 = y1 - y2;
            double z3 = z1 - z2;

            if (x3 > 0) this.Ry = Math.PI / 2 + Math.Acos(z3 / (Math.Sqrt(x3 * x3 + z3 * z3)));
            else if (x3 < 0) this.Ry = Math.PI / 2 - Math.Acos(z3 / (Math.Sqrt(x3 * x3 + z3 * z3)));
            else this.Ry = Math.PI / 2;


            if (y3 > 0) this.Rx = Math.PI / 2 - Math.Acos(z3 / (Math.Sqrt(y3 * y3 + z3 * z3)));
            else if (y3 < 0) this.Rx = Math.PI / 2 + Math.Acos(z3 / (Math.Sqrt(y3 * y3 + z3 * z3)));
            else this.Rx = Math.PI / 2;

        }

        public double xmove(double Ry)
        {
            return -1 / Math.Tan(Math.PI - Ry);
        }
    }

    class DataEX_HCRRobot
    {
        public int test;

        //여기에 데이터교환 필요한 변수 정의

        //로봇 통신상태
        public byte moni_RobotCommunicationState;                                      //로봇 통신상태 0:통신 연결됨, 1:통신연결 안됨
        public DateTime moni_RobotCommTime;                                            //마지막으로 모니터링통신 성곡한 시각
        public double moni_RobotCommTimeTaken;                                         //모니터링함수 실행하는데 걸린 시간. ms단위
        //public List<string> moni_RobotCommErrorList;                                   //모니터링 함수 호출 중 실패한 경우 내역 기록

        //로봇 모니터링값
        public string moni_RobotAPIVersion;                                            //로봇 API SW 버전
        public byte moni_RobotEmergencyState;                                          //로봇 비상정지버튼 상태, 0:안눌림, 1:눌림
        public byte moni_RobotIOValueDI;                                               //로봇 DI 입력값
        public byte moni_RobotIOValueDO;                                               //로봇 DO 출력값
        public float[] moni_RobotIOValueAI = new float[2];                             //로봇 AI1, AI2 입력값
        public float[] moni_RobotIOValueAO = new float[2];                             //로봇 AO1, AO2 출력값
        public byte moni_RobotMotionState;                                             //로봇 모션이동 상태 0~5, 엑셀문서 참고
        public byte moni_RobotSafetySwitchState;                                       //로봇 안전상태스위치 0:켜짐, 1:꺼짐
        public byte moni_RobotSafetyState;                                             //로봇 안전상태 0:정상, 1:세이프티 위반
        public byte moni_RobotServoOnState;                                            //로봇 서보모터 상태 0:서보온, 1:서보 오프
        public byte moni_RobotMountingSerface;                                         //로봇 설치면
        public float[] moni_RobotMountingAngle = new float[2];                         //로봇 설치 각도 Rx, Ry
        public float[] moni_RobotFlangeToTCP = new float[6];                           //로봇 TCP 설정값 x,y,z,Rx,Ry,Rz
        public float moni_RobotTCPPayload;                                             //로봇 TCP 무게
        public float[] moni_RobotTCPMassCenter = new float[3];                         //로봇 TCP 무게중심 좌표 x,y,z
        public float[] moni_RobotTCPCommandPose = new float[6];                        //로봇 TCP 목표좌표 x,y,z,Rx,Ry,Rz
        public float[] moni_RobotTCPActualPose = new float[6];                         //로봇 TCP 현재좌표 x,y,z,Rx,Ry,Rz
        public float[] moni_RobotJointTmp = new float[6];                              //로봇 각축 모터 온도 1~6
        public float[] moni_RobotJointVol = new float[6];                              //로봇 각축 모터 전압 1~6
        public float[] moni_RobotJointAmp = new float[6];                              //로봇 각축 모터 전류 1~6
        public float[] moni_RobotJointCommandAngle = new float[6];                     //로봇 각축 모터 목표각도 1~6
        public float[] moni_RobotJointActualAngle = new float[6];                      //로봇 각축 모터 현재각도 1~6
        public byte moni_RobotToolIOValueDI;                                           //로봇 툴IO DI 입력값
        public byte moni_RobotToolIOValueDO;                                           //로봇 툴IO DO 출력값
        public float[] moni_RobotToolIOValueAI = new float[2];                         //로봇 툴IO AI1, AI2 입력값
        public byte moni_RobotDirectTeachingState;                                     //로봇 직접교시 상태 0:직접교시 실행중, 1:직접교시 실행중이 아님
        public byte moni_RobotCollisionDetectionState;                                 //로봇 충돌감지 기능 상태 0:충돌감지기능 켜짐, 1:충돌감지기능 꺼짐
        public float[] moni_RobotCollisionDetectionJointLimit = new float[6];          //로봇 각축 충돌감지 임계치값 1~6
        public byte moni_RobotCollisionMitigationState;                                //로봇 충돌감지 완화 기능 상태 0:충돌감지 완화기능 켜짐, 1:충돌감지 완화기능 꺼짐
        //public List<RobotEventData> moni_RobotEventLog = new List<RobotEventData>();   //로봇 이벤트 기록 (발생시간, 메인그룹, 서브그룹)


        public DataEX_HCRRobot()
        {
            moni_RobotCommunicationState = 1;
            moni_RobotAPIVersion = "NULL";

        }
    }




    class HCRRobotCommunication
    {
        public DataEX_HCRRobot RobotMonitoringData;
        private bool ThreadContinue;

        //콜백 이벤트용 함수
        csEventCallbackFunc EVT_Collback_Del_ERROR1;
        csEventCallbackFunc EVT_Collback_Del_ERROR2;
        csEventCallbackFunc EVT_Collback_Del_ERROR3;
        csEventCallbackFunc EVT_Collback_Del_ERROR4;

        csEventCallbackFunc EVT_Collback_Del_BUTTON1;
        csEventCallbackFunc EVT_Collback_Del_BUTTON2;
        csEventCallbackFunc EVT_Collback_Del_BUTTON3;
        csEventCallbackFunc EVT_Collback_Del_BUTTON4;
        csEventCallbackFunc EVT_Collback_Del_BUTTON5;

        csEventCallbackFunc EVT_Collback_Del_MOTION1;
        csEventCallbackFunc EVT_Collback_Del_MOTION2;
        csEventCallbackFunc EVT_Collback_Del_MOTION3;
        csEventCallbackFunc EVT_Collback_Del_MOTION4;
        csEventCallbackFunc EVT_Collback_Del_MOTION5;
        csEventCallbackFunc EVT_Collback_Del_MOTION6;
        csEventCallbackFunc EVT_Collback_Del_MOTION7;

        csEventCallbackFunc EVT_Collback_Del_COLLISION1;
        csEventCallbackFunc EVT_Collback_Del_COLLISION2;
        csEventCallbackFunc EVT_Collback_Del_COLLISION3;

        csEventCallbackFunc EVT_Collback_Del_SAFETY1;
        csEventCallbackFunc EVT_Collback_Del_SAFETY2;
        csEventCallbackFunc EVT_Collback_Del_SAFETY3;
        csEventCallbackFunc EVT_Collback_Del_SAFETY4;
        csEventCallbackFunc EVT_Collback_Del_SAFETY5;
        csEventCallbackFunc EVT_Collback_Del_SAFETY6;
        csEventCallbackFunc EVT_Collback_Del_SAFETY7;

        csEventCallbackFunc EVT_Collback_Del_SPEC1;
        csEventCallbackFunc EVT_Collback_Del_SPEC2;
        csEventCallbackFunc EVT_Collback_Del_SPEC3;
        csEventCallbackFunc EVT_Collback_Del_SPEC4;
        csEventCallbackFunc EVT_Collback_Del_SPEC5;
        csEventCallbackFunc EVT_Collback_Del_SPEC6;
        csEventCallbackFunc EVT_Collback_Del_SPEC7;

        String HOST_IPADDR = "192.168.100.10";
        String TARGET_IPADDR = "192.168.100.240";
        uint BOARD_PORT_NUMBER = 5000;
        String HCR5_CONFIG_FILE_NAME = "C:/HHIAutomation/OpenBlockWeldingRobot_Server/Init/sample_config.txt";

        CLINK_ROBOT_MODEL INT_TEST_CUR_ROBOT_ID = CLINK_ROBOT_MODEL.CLINK_ROBOT_MODEL_HCR5;

        public const int NUM_OF_ROBOT_JOINTS = 6;

        bool BootingFlag = false;

        //로봇 설정
        public float RobotControlParameter_TCPMaxSpeed = 1000.0F;
        public float RobotControlParameter_SpeedFactor = 1.0F;
        public float RobotControlParameter_ToolWeight = 2.8F;
        public float RobotControlParameter_ToolMassCenterX = 0F;
        public float RobotControlParameter_ToolMassCenterY = 0F;
        public float RobotControlParameter_ToolMassCenterZ = 0F;
        public int RobotControlParameter_MountType = 0; //0:바닥, 1:벽, 2:천장
        public float RobotControlParameter_MountAngleRx = 0;
        public float RobotControlParameter_MountAngleRy = 0;
        //public float[] RobotControlParameter_TCP = new float[6] { 0F, -160F, 195F, 45F, 0F, 0F }; //3d 프린팅 툴
        //public float[] RobotControlParameter_TCP = new float[6] { -108F, -102.8F, 208F, 45F, 0F, -45F}; //현장툴
        //public float[] RobotControlParameter_TCP = new float[6] { -97.03762F, -258.387268F, 297.896881F, 45F, 0F, 0F }; //1호기 툴데이터
        public float[] RobotControlParameter_TCP = new float[6] { -85.15121F, -243.0711F, 317.5071F, 39F, 0F, 0F }; //2호기 툴데이터
        //public float[] RobotControlParameter_TCP = new float[6] { 0, 0,0, 0, 0, 0F }; //2호기 툴데이터



        //모션 가감속도 설정
        public float RobotControlParameter_JointAcc = 200.0F; //조인트 가속도
        public float RobotControlParameter_JointDec = 200.0F; //조인트 감속도
        public float RobotControlParameter_JointJerk = 1.0F;  //조인트 저크값
        public float RobotControlParameter_TCPAcc = 1000.0F; //TCP 가속도
        public float RobotControlParameter_TCPDec = 1000.0F; //TCP 감속도
        public float RobotControlParameter_TCPJerk = 1.0F;  //TCP 저크값

        //축 구동범위
        public float RobotControlParameter_JointAngle1Max = 355;
        public float RobotControlParameter_JointAngle1Min = -355;
        public float RobotControlParameter_JointAngle2Max = 355;
        public float RobotControlParameter_JointAngle2Min = -355;
        public float RobotControlParameter_JointAngle3Max = 160;
        public float RobotControlParameter_JointAngle3Min = -160;
        public float RobotControlParameter_JointAngle4Max = 355;
        public float RobotControlParameter_JointAngle4Min = -355;
        public float RobotControlParameter_JointAngle5Max = 355;
        public float RobotControlParameter_JointAngle5Min = -355;
        public float RobotControlParameter_JointAngle6Max = 355;
        public float RobotControlParameter_JointAngle6Min = -355;
        public float RobotControlParameter_JointAngle3TCPModeNotUse = 10; //보간모드 모션일 때 3축 비사용각도 0도에서 +- 해당 값 이내이면 에러. 너무 팔이 펴진 모션 방지

        uint ctrlBoxID;
        public uint robotID;
        uint motionCmdID_Jog = 0;
        uint motionCmdID_TCP = 0;
        uint motionCmdID_Weld = 0;
        uint motionCompleteCheckID = 0;
        bool motionCompleteCheckFlag = false;

        //로봇 동작설정
        public bool AlwaysErrorReset = true;
        public bool AlwaysServoOn = true;

        public bool ErrorState_Safety = true;
        public bool ErrorState_Coll = true;
        public bool ErrorState_EMGRel = true;
        public DateTime ErrorTime_Safety = DateTime.Now;
        public DateTime ErrorTime_Coll = DateTime.Now;
        public DateTime ErrorTime_EMGRel = DateTime.Now;

        Stopwatch sw;
        Stopwatch sw1;
        public string strcommtimetmep;

        //로봇 메인스레드
        Thread RobotMainThread;

        //로봇 이벤트 로그
        List<RobotEventData> RobotEventLog = new List<RobotEventData>();
        private object lockObject_RobotEventLog = new object();

        //로봇 컨트롤 함수호출 로그
        List<string> RobotFuncCallLog1 = new List<string>();
        private object lockObject_RobotFuncCallLog1 = new object();

        //로봇 모니터링 함수호출 로그
        List<string> RobotFuncCallLog2 = new List<string>();
        private object lockObject_RobotFuncCallLog2 = new object();

        //로봇 포즈 기록 함수
        List<RobotPositionRecordData> RobotPosiRecord = new List<RobotPositionRecordData>();
        private object lockObject_RobotPosiRecord = new object();

        //초기 접속시퀀스 관련 변수들
        Thread RobotConnThread;
        public int RobotInitState = 0;
        int RobotConnectFlag = 0; //접속함수에서 결과 회신 플래그. 1:접속성공 2:접속실패
        DateTime RobotConnectStartTime;
        int RobotConnectTimeOutSec = 1000000; //로봇 통신접속 타임아웃 시간설정 단위 ms
        public StringBuilder RobotInitLog = new StringBuilder();
        private object lockObject_RobotInitStr = new object();

        //접속 완료 후 모니터링시퀀스 관련 변수들
        Thread RobotMoniThread;
        public int RobotMoniState = 0;
        int RobotMonitoringTimeOutSec = 200000; //로봇 모니터링함수 타임아웃 시간설정 단위 ms
        private bool MoniThreadContinue = true;
        public StringBuilder RobotMonitoringErrorList = new StringBuilder();

        //로봇 컨트롤시퀀스 관련 변수들
        Thread RobotControlThread;
        public int RobotControlState = 0;
        public int RobotControlThreadSeq = 0;
        int RobotControlThreadSeqB = 2;
        DateTime RobotControlThreadRunTime;
        int RobotControlThreadRunTimeout = 350000; //로봇 모니터링함수 타임아웃 시간설정 단위 ms
        private bool RobotControlThreadContinue = true;
        public List<string> RobotControlStr = new List<string>();
        private object lockObject_RobotControlStr = new object();

        bool RobotControlEMGFlag = false;
        bool RobotControlCollisionFlag = false;
        bool RobotControlSafetyVioFlag = false;
        bool RobotControlManualMoveFlag = false;
        bool RobotControlServoOnFlag = false;
        bool RobotControlServoOffFlag = false;
        bool RobotControlErrorClearFlag = false;
        bool RobotControlDirectTeachingOnFlag = false;
        bool RobotControlDirectTeachingOffFlag = false;
        bool RobotControlWeldStartFlag = false;
        bool RobotControlTouchSensingFlag = false;
        bool RobotControlContinuousMoveFlag = false;
        bool RobotControlPWRFlag = false;


        //수동조작 조그모션 지령 0~5 축별 마이너스지령, 6~11 축별 플러스지령, 12~17 TCP마이너스지령, 18~23 TCP 플러스지령. 한번에 하나만 1이 되야 함. 동시 1이되면 앞선거만 실행됨
        public int[] RobotJogMotionCommand = new int[24] {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        public int RobotJogJointAngle = 10;
        public int RobotJogJointVel = 10;
        public int RobotJogTCPLength = 10;
        public int RobotJogTCPVel = 10;
        public int RobotJogTCPCoord = 1;

        //로봇 박스 디지털아웃풋 지령. 0:출력 0으로 만듬, 1:출력 1로 만듬, 2:대기상태
        public int[] RobotBoxDOOutFlag = new int[8] { 2, 2, 2, 2, 2, 2, 2, 2 };
        //로봇 박스 디지털아웃풋 지령. true:토글지령, false:대기
        public bool[] RobotBoxDOToggleFlag = new bool[8] { false, false , false , false , false , false , false , false };


        //용접용 데이터
        WeldInformation WeldData;
        int WeldInitPosiCount;
        int WeldEndPosiCount;
        int WeldMainCount;
        int WeldInitPosiWaitTime = 200; 

        //터치센싱용 데이터
        List<TouchSensingData> TouchData = new List<TouchSensingData>();
        public List<RobotPoseData> TouchPosition = new List<RobotPoseData>();
        int TouchCount;

        //로봇 연속이동용 데이터
        public List<RobotPoseData> RobotPoseArray = new List<RobotPoseData>();
        int RobotMoveCount;


        //IO관련 데이터
        uint VolIO = 0;
        uint CurIO = 1;
        uint GasIO = 2;//정인칭3 역인칭4
        uint TouchSensorIO = 1;
        uint ArcSwitchIO = 5;

        //용접기 선형화 관련 변수들
        //전압전류가 작은쪽 조건
        public float RefVoltIO_1 = 0;
        public float RefAmpIO_1 = 0;
        public float WeldVolt_1 = 0;
        public float WeldAmp_1 = 0;

        //전압전류가 큰쪽 조건
        public float RefVoltIO_2 = 0;
        public float RefAmpIO_2 = 0;
        public float WeldVolt_2 = 0;
        public float WeldAmp_2 = 0;

        List<double> InitArcDetect = new List<double>();


        RobotPoseData CenterCal1Hz, CenterCal1_5Hz, CenterCal2Hz, CenterCal2_5Hz, CenterCal3Hz, CenterCal3_5Hz, CenterCal4Hz, CenterCal4_5Hz;
        RobotPoseData CenterCalVertical;

        //용접 경로 저장
        List<ActualWeldingPathRecord> WeldingPathRecord = new List<ActualWeldingPathRecord>();
        ActualWeldingPathRecord WeldingSinglePath;
        DateTime MidPathLastRecordTime = DateTime.Now;

        //용접조건 오프셋
        public float WeldOffsetV = 0;
        public float WeldOffsetA = 0;


        //생성자 1
        public HCRRobotCommunication()
        {

        }

        //생성자 2
        public HCRRobotCommunication(DataEX_HCRRobot atemp)
        {
            RobotMonitoringData = atemp;
            sw = new Stopwatch();
            sw1 = new Stopwatch();
            strcommtimetmep = "";
            
            RobotMoniThread = new Thread(new ThreadStart(this.MonitiringThread));
            RobotControlThread = new Thread(new ThreadStart(this.RobotControlThreadFuc));

            RobotMainThread = new Thread(new ThreadStart(this.threadfunc));
            RobotMainThread.Start();

            for (int i = 0; i < 100; i++) InitArcDetect.Add(0);
        }


        //스레드 함수
        public void threadfunc()
        {
            ThreadContinue = true;

            while (ThreadContinue)
            {
                //여기에 통신관련 코드 구현

                RobotMonitoringData.test++;

                if(RobotInitState != 100)
                {
                    RobotInitSequance();
                }else if(RobotInitState==100)
                {
                    RobotMonitoringSequance();
                    RobotControlSequance();
                }

                

                //100m 대기
                Thread.Sleep(100);
            }

            MoniThreadContinue = false;
            if(RobotMoniThread.IsAlive)RobotMoniThread.Join();

            RobotControlThreadContinue = false;
            if(RobotControlThread.IsAlive)RobotControlThread.Join();

        }

        //스레드 종료 호출
        public void threadStop()
        {
            ThreadContinue = false;
        }

        //외부에서 로봇 접속 시작하라고 호출하는 함수
        public int RobotConnect()
        {
            if (RobotInitState == 0) //접속 대기 상태라면 접속 시작 상태로 전환. 접속 시작함
            {
                RobotInitState = 1;
                return 1;
            }
            else if ((RobotInitState > 0) && (RobotInitState < 100)) //접속 시도 중인 상태면 2 리턴
            {
                return 2;
            }
            else if (RobotInitState == 100) // 이미 접속된 상태이면 3 리턴
            {
                return 3;
            }

            return 0;
        }

        //외부에서 로봇 접속 종료하라고 호출하는 함수
        public int RobotDisConnect()
        {
            if(RobotMoniState == 2)//로봇과 접속된 상태이면 접속종료 실행
            {
                MoniThreadContinue = false;
                TearDown();
                RobotInitState = 0;
                RobotMoniState = 0;
                return 1;
            }else
            {
                //접속되지 않은 상태이면 2 리턴
                return 2;
            }
        }


        //로봇 통신 접속 시퀀스
        private void RobotInitSequance()
        {
            switch(RobotInitState)
            {
                case 0:
                    //0일때는 아무것도 안함. 외부에서 1로 바꿔 줄 때 까지 대기상태임
                    break;

                case 1:
                    //초기상태가 1로 변경되면 스레드를 만들어서 SetUp함수 실행. 상태2로 변경
                    RobotConnectFlag = 0;
                    RobotConnectStartTime = DateTime.Now;
                    RobotConnThread = new Thread(new ThreadStart(this.SetUp));
                    RobotConnThread.Start();
                    RobotInitState = 2;
                    break;

                case 2:
                    //접속결과 플래그 감시
                    if(RobotConnectFlag==1)
                    {
                        //접속 성공하면 상태 3으로 변경
                        RobotInitState = 3;
                    }
                    else if (RobotConnectFlag == 2)
                    {
                        //접속 실패하면 상태 3으로 변경
                        RobotInitState = 4;
                    }
                    else
                    {
                        //접속 시작시간보다 현재 시간이 타임아웃시간 보다 더 경과했을 때. 타임아웃실패 판단.
                        int temptime = (int)(DateTime.Now - RobotConnectStartTime).Ticks/10000;
                        if (temptime > RobotConnectTimeOutSec)
                        {
                            //스레드 강제종료하고 상태 5로 변경
                            RobotConnThread.Abort(); 
                            RobotInitState = 5;
                        }
                    }
                    break;
                    
                case 3:
                    //접속 성공 상태로 변경
                    RobotInitState = 100; 
                    RobotMoniState = 1;
                    RobotMonitoringData.moni_RobotCommunicationState = 0;
                    RobotInitLog.AppendLine("로봇 접속 완료");
                    break;

                case 4:
                    //접속 실패 상태로 변경
                    RobotInitState = -1;
                    RobotInitLog.AppendLine("로봇 접속 실패. 로봇제어기와 프로그램을 재부팅하세요");
                    break;

                case 5:
                    //타임아웃 상태로 변경
                    RobotInitState = -1;
                    RobotInitLog.AppendLine("로봇 접속 타임아웃. 로봇제어기와 프로그램을 재부팅하세요");
                    break;

                default:
                    break;

            }

        }

        //로봇 모니터링 시작시퀀스
        private void RobotMonitoringSequance()
        {
            switch (RobotMoniState)
            {
                case 0:
                    //0일때는 아무것도 안함. 접속시퀀스가 성공해서 1로 바뀔 때 까지 대기상태임
                    break;

                case 1:
                    //접속시퀀스 성공하면 모니터링 스레드 실행. 상태2로 변경
                    RobotMonitoringData.moni_RobotCommTime = DateTime.Now;
                    RobotMoniThread.Start();
                    RobotMoniState = 2;
                    //로봇 컨트롤스레드 시작함
                    RobotControlState = 1;
                    break;

                case 2:
                    //모니터링 스레드로 로봇 접속 감시. 마지막 모니터링 성공 시간보다 타임아웃 이상 경과했을 때 로봇 접속 끊김으로 판단
                    int temptime = (int)((DateTime.Now - RobotMonitoringData.moni_RobotCommTime).Ticks / 10000);
                    if (temptime > RobotMonitoringTimeOutSec)
                    {
                        //스레드 강제종료하고 상태 3으로 변경
                        RobotMoniThread.Abort();
                        RobotMoniState = 3;
                    }
                    break;

                case 3:
                    RobotInitState = -1; //접속 실패 상태로 변경
                    RobotMoniState = -1;
                    RobotMonitoringErrorList.Clear();
                    RobotMonitoringErrorList.AppendLine("로봇 접속 끊김. 로봇제어기와 프로그램을 재부팅하세요");
                    break;

                default:
                    break;

            }


        }
        
        //로봇 컨트롤 시작시퀀스
        private void RobotControlSequance()
        {
            switch (RobotControlState)
            {
                case 0:
                    //0일때는 아무것도 안함. 접속시퀀스가 성공해서 1로 바뀔 때 까지 대기상태임
                    break;

                case 1:
                    //접속시퀀스 성공하면 로봇컨트롤 스레드 실행. 상태2로 변경
                    RobotControlThreadRunTime = DateTime.Now;
                    RobotControlThread.Start();
                    RobotControlState = 2;
                    break;

                case 2:
                    //컨트롤스레드 실행 감시. 스래드가 일정시간 이상 블럭되어 있으면 로봇 접속 끊김으로 판단
                    int temptime = (int)(DateTime.Now - RobotControlThreadRunTime).Ticks / 10000;
                    if (temptime > RobotControlThreadRunTimeout)
                    {
                        //스레드 강제종료하고 상태 3으로 변경
                        RobotControlThread.Abort();
                        RobotControlState = 3;
                    }
                    break;

                case 3:
                    RobotInitState = -1; //접속 실패 상태로 변경
                    RobotMoniState = -1;
                    RobotControlState = -1;
                    RobotControlLogAdd("로봇 컨트롤스레드 타임아웃");
                    break;

                default:
                    break;

            }


        }

        //로봇 접속 스레드
        private void SetUp()
        {
            Console.WriteLine("--SetUp()----");
            RobotInitLog.AppendLine("로봇 접속 시작...");

            // initialize library
            RobotInitLog.Append("system_create 시작...");
            CLINK_API_RESULT caRetVal = clinkCs.system_create(HCR5_CONFIG_FILE_NAME);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: system_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine( " 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }
            else
            {
                RobotInitLog.AppendLine(" 완료");
            }

            // create a control box instance
            RobotInitLog.Append("control_box_create 시작...");
            caRetVal = clinkCs.control_box_create(CLINK_CBOX_MODEL.CLINK_CBOX_MODEL_HCR5_001, HCR5_CONFIG_FILE_NAME, out ctrlBoxID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: control_box_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine( " 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }
            else
            {
                RobotInitLog.AppendLine(" 완료");
            }


            RobotInitLog.Append("control_box_name_get 시작...");
            int cbModel;
            caRetVal = clinkCs.control_box_name_get(ctrlBoxID, out cbModel);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (cbModel != (int)CLINK_CBOX_MODEL.CLINK_CBOX_MODEL_HCR5_001)
                {
                    Console.WriteLine("Error: control_box_name_get() returned a invalid control box model name: {0}", cbModel);
                    RobotInitLog.AppendLine(" 에러발생 - 제어기 모델명 불일치");

                    RobotConnectFlag = 2;
                    return;
                }
                else
                {
                    RobotInitLog.AppendLine(" 완료");
                }
            }
            else
            {
                Console.WriteLine("Error: control_box_name_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine(" 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }

            // connect to a control box
            RobotInitLog.Append("control_box_connect_by_socket 시작...");
            caRetVal = clinkCs.control_box_connect_by_socket(ctrlBoxID, HOST_IPADDR, TARGET_IPADDR, BOARD_PORT_NUMBER);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: control_box_connect_by_socket() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine(" 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }
            else
            {
                RobotInitLog.AppendLine(" 완료");
            }

            // create a robot instance
            RobotInitLog.Append("robot_create 시작...");
            caRetVal = clinkCs.robot_create(ctrlBoxID, INT_TEST_CUR_ROBOT_ID, null, 0, out robotID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_create() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine(" 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }
            else
            {
                RobotInitLog.AppendLine(" 완료");
            }

            RobotInitLog.Append("robot_model_name_get 시작...");
            int rbModel;
            caRetVal = clinkCs.robot_model_name_get(robotID, out rbModel);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (rbModel != (int)INT_TEST_CUR_ROBOT_ID)
                {
                    Console.WriteLine("Error: control_box_name_get() returned a invalid robot model name: {0}", rbModel);
                    RobotInitLog.AppendLine(" 에러발생 - 로봇 모델명 불일치");

                    RobotConnectFlag = 2;
                    return;
                }
                else
                {
                    RobotInitLog.AppendLine(" 완료");
                }
            }
            else
            {
                Console.WriteLine("Error: robot_model_name_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine(" 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }

            RobotInitLog.Append("robot_operational_mode_get 시작...");
            // current operational mode of robot
            int opMode;
            caRetVal = clinkCs.robot_operational_mode_get(robotID, out opMode);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.Write("---- info: current operationa mode is \"");
                switch (opMode)
                {
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_INIT:
                        Console.Write("INIT");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_PRE_OPERATIONAL:
                        Console.Write("PRE_OPERATIONAL");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_BOOTSTRAP:
                        Console.Write("BOOTSTRAP");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_SAFE_OPERATIONAL:
                        Console.Write("SAFE_OPERATIONAL");
                        break;
                    case (int)CLINK_OPERATIONAL_MODE.CLINK_OPERATIONAL_MODE_OPERATIONAL:
                        Console.Write("OPERATIONAL");
                        break;
                    default:
                        Console.Write("unknown");
                        break;
                }
                Console.WriteLine("\".");
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                Console.WriteLine("Error: robot_operational_mode_get() ({0})", clinkCs.system_api_result_description_get(caRetVal));
                RobotInitLog.AppendLine(" 에러발생 - " + clinkCs.system_api_result_description_get(caRetVal));

                RobotConnectFlag = 2;
                return;
            }


            RobotInitLog.Append("아날로그 IO 초기화 시작...");
            bool tempresult = true;
            caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;
            caRetVal = clinkCs.robot_tool_io_analog_io_mode_set(robotID, 0, CLINK_ANALOG_IO_MODE.CLINK_ANALOG_IO_MODE_CURRENT, 0, 0.0f);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.robot_tool_io_analog_io_mode_set(robotID, 1, CLINK_ANALOG_IO_MODE.CLINK_ANALOG_IO_MODE_CURRENT, 0, 0.0f);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.control_box_io_analog_io_mode_set(ctrlBoxID, 0, CLINK_ANALOG_IO_MODE.CLINK_ANALOG_IO_MODE_VOLTAGE, 0, 0.0f);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.control_box_io_analog_io_mode_set(ctrlBoxID, 1, CLINK_ANALOG_IO_MODE.CLINK_ANALOG_IO_MODE_VOLTAGE, 0, 0.0f);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, 0, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, 1, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            if (tempresult == true)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
                return;
            }

            //RobotInitLog.Append("Tool D0 출력전압 설정 시작...");
            //caRetVal = clinkCs.robot_tool_power_voltage_set(robotID, CLINK_TOOL_IO_POWER_VOLTAGE_OPTION.CLINK_TOOL_POWER_VOLTAGE_OPTION_24, (char)0);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    RobotInitLog.AppendLine(" 완료");
            //}
            //else
            //{
            //    RobotInitLog.AppendLine(" 실패");
            //    RobotConnectFlag = 2;
            //    return;
            //}




            RobotInitLog.Append("이벤트함수 등록 시작...");
            tempresult = true;
            EVT_Collback_Del_ERROR1 = new csEventCallbackFunc(event_handler_callback_func_ERROR1);
            EVT_Collback_Del_ERROR2 = new csEventCallbackFunc(event_handler_callback_func_ERROR2);
            EVT_Collback_Del_ERROR3 = new csEventCallbackFunc(event_handler_callback_func_ERROR3);
            EVT_Collback_Del_ERROR4 = new csEventCallbackFunc(event_handler_callback_func_ERROR4);

            EVT_Collback_Del_BUTTON1 = new csEventCallbackFunc(event_handler_callback_func_BUTTON1);
            EVT_Collback_Del_BUTTON2 = new csEventCallbackFunc(event_handler_callback_func_BUTTON2);
            EVT_Collback_Del_BUTTON3 = new csEventCallbackFunc(event_handler_callback_func_BUTTON3);
            EVT_Collback_Del_BUTTON4 = new csEventCallbackFunc(event_handler_callback_func_BUTTON4);
            EVT_Collback_Del_BUTTON5 = new csEventCallbackFunc(event_handler_callback_func_BUTTON5);

            EVT_Collback_Del_MOTION1 = new csEventCallbackFunc(event_handler_callback_func_MOTION1);
            EVT_Collback_Del_MOTION2 = new csEventCallbackFunc(event_handler_callback_func_MOTION2);
            EVT_Collback_Del_MOTION3 = new csEventCallbackFunc(event_handler_callback_func_MOTION3);
            EVT_Collback_Del_MOTION4 = new csEventCallbackFunc(event_handler_callback_func_MOTION4);
            EVT_Collback_Del_MOTION5 = new csEventCallbackFunc(event_handler_callback_func_MOTION5);
            EVT_Collback_Del_MOTION6 = new csEventCallbackFunc(event_handler_callback_func_MOTION6);
            EVT_Collback_Del_MOTION7 = new csEventCallbackFunc(event_handler_callback_func_MOTION7);
            
            EVT_Collback_Del_COLLISION1 = new csEventCallbackFunc(event_handler_callback_func_COLLISION1);
            EVT_Collback_Del_COLLISION2 = new csEventCallbackFunc(event_handler_callback_func_COLLISION2);
            EVT_Collback_Del_COLLISION3 = new csEventCallbackFunc(event_handler_callback_func_COLLISION3);

            EVT_Collback_Del_SAFETY1 = new csEventCallbackFunc(event_handler_callback_func_SAFETY1);
            EVT_Collback_Del_SAFETY2 = new csEventCallbackFunc(event_handler_callback_func_SAFETY2);
            EVT_Collback_Del_SAFETY3 = new csEventCallbackFunc(event_handler_callback_func_SAFETY3);
            EVT_Collback_Del_SAFETY4 = new csEventCallbackFunc(event_handler_callback_func_SAFETY4);
            EVT_Collback_Del_SAFETY5 = new csEventCallbackFunc(event_handler_callback_func_SAFETY5);
            EVT_Collback_Del_SAFETY6 = new csEventCallbackFunc(event_handler_callback_func_SAFETY6);
            EVT_Collback_Del_SAFETY7 = new csEventCallbackFunc(event_handler_callback_func_SAFETY7);

            EVT_Collback_Del_SPEC1 = new csEventCallbackFunc(event_handler_callback_func_SPEC1);
            EVT_Collback_Del_SPEC2 = new csEventCallbackFunc(event_handler_callback_func_SPEC2);
            EVT_Collback_Del_SPEC3 = new csEventCallbackFunc(event_handler_callback_func_SPEC3);
            EVT_Collback_Del_SPEC4 = new csEventCallbackFunc(event_handler_callback_func_SPEC4);
            EVT_Collback_Del_SPEC5 = new csEventCallbackFunc(event_handler_callback_func_SPEC5);
            EVT_Collback_Del_SPEC6 = new csEventCallbackFunc(event_handler_callback_func_SPEC6);
            EVT_Collback_Del_SPEC7 = new csEventCallbackFunc(event_handler_callback_func_SPEC7);

            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_ERROR2, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ERROR, (uint)CLINK_EVENT_SUBGRP_ERROR.CLINK_EVENT_SUBGRP_ERROR_CONTROL_BOX_ROBOT_DISCONNECTED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_ERROR3, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ERROR, (uint)CLINK_EVENT_SUBGRP_ERROR.CLINK_EVENT_SUBGRP_ERROR_INVALID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_ERROR4, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ERROR, (uint)CLINK_EVENT_SUBGRP_ERROR.CLINK_EVENT_SUBGRP_ERROR_MOTOR_FAULT);
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_ERROR1, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ERROR, (uint)CLINK_EVENT_SUBGRP_ERROR.CLINK_EVENT_SUBGRP_ERROR_CONTROL_BOX_HOST_PC_DISCONNECTED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;

            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_BUTTON1, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED, (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_PUSHED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_BUTTON2, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED, (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_RELEASED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_BUTTON3, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED, (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_INVALID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_BUTTON4, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED, (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_PWR_PUSHED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_BUTTON5, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_CONTROL_BOX_BUTTON_CHANGED, (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_PWR_RELEASED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;

            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION1, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_INVALID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION2, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_PAUSE_SETTLED_DOWN);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION3, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_PROFILE_COMPLETED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION4, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_PUASE_PROFILE_COMPLETED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION5, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_SETTLED_DOWN);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION6, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_STOP_PROFILE_COMPLETED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_MOTION7, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_MOTION_COMMAND, (uint)CLINK_EVENT_SUBGRP_MOTION_COMMAND.CLINK_EVENT_SUBGRP_MOTION_COMMAND_STOP_SETTLED_DOWN);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;

            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_COLLISION1, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_COLLISION_DETECTED, (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_INVALID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_COLLISION2, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_COLLISION_DETECTED, (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_JOINT);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_COLLISION3, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_COLLISION_DETECTED, (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_TCP);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;

            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY1, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_INVALID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY2, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_JOINT_ACCELERATION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY3, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_JOINT_POSITION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY4, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_JOINT_SPEED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY5, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_TCP_ACCELERATION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY6, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_TCP_POSITION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SAFETY7, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SAFETY_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SAFETY_VIOLATED_TCP_SPEED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;

            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC1, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_INVALID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC2, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_JOINT_ACCELERATION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC3, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_JOINT_POSITION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC4, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_JOINT_SPEED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC5, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_TCP_ACCELERATION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC6, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_TCP_POSITION);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;
            caRetVal = clinkCs.system_event_group_subgroup_callback_add(EVT_Collback_Del_SPEC7, (uint)CLINK_EVENT_GRP.CLINK_EVENT_GRP_ROBOT_SPEC_VIOLATED, (uint)CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED.CLINK_EVENT_SUBGRP_ROBOT_SPEC_VIOLATED_TCP_SPEED);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) tempresult = false;

            if (tempresult == true)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
                return;
            }


            // public uint motionCmdID_Jog = 0;
            //public uint motionCmdID_TCP = 0;

            RobotInitLog.Append("조인트 모션커멘트 생성 시작...");
            caRetVal = clinkCs.motion_command_robot_joint_create(out motionCmdID_Jog);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
            }

            //실행할 로봇 지정
            RobotInitLog.Append("조인트 모션커멘트 로봇 지정 시작...");
            caRetVal = clinkCs.motion_command_robot_robot_id_set(motionCmdID_Jog, robotID);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
            }

            RobotInitLog.Append("TCP 모션커멘트 생성 시작...");
            caRetVal = clinkCs.motion_command_robot_tcp_create(out motionCmdID_TCP);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
            }

            //실행할 로봇 지정
            RobotInitLog.Append("TCP 모션커멘트 로봇 지정 시작...");
            caRetVal = clinkCs.motion_command_robot_robot_id_set(motionCmdID_TCP, robotID);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
            }

            RobotInitLog.Append("용접 모션커멘트 생성 시작...");
            caRetVal = clinkCs.motion_command_robot_tcp_welding_create(out motionCmdID_Weld);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
            }

            //실행할 로봇 지정
            RobotInitLog.Append("용접 모션커멘트 로봇 지정 시작...");
            caRetVal = clinkCs.motion_command_robot_robot_id_set(motionCmdID_Weld, robotID);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotInitLog.AppendLine(" 완료");
            }
            else
            {
                RobotInitLog.AppendLine(" 실패");
                RobotConnectFlag = 2;
            }




            RobotConnectFlag = 1;
        }

        //로봇 접속해제 함수
        private void TearDown()
        {
            CLINK_API_RESULT caRetVal = clinkCs.robot_destroy(robotID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: robot_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.control_box_destroy(ctrlBoxID);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: control_box_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            caRetVal = clinkCs.system_destroy();
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                Console.WriteLine("Error: system_destroy() ({0})", clinkCs.system_api_result_description_get(caRetVal));
            }

            Console.WriteLine("--TearDown()----");
        }

        private void MonitiringThread()
        {
            List<string> tempstrlist0 = new List<string>();
            List<string> tempstrlist1 = new List<string>();

            while (MoniThreadContinue)
            {
                tempstrlist0.Clear();

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring1();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring2();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring3();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring4();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring5();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring6();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring7();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring8();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring9();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                tempstrlist1.Clear();
                tempstrlist1 = Monitoring10();
                for (int i = 0; i < tempstrlist1.Count; i++) tempstrlist0.Add(tempstrlist1[i]);
                RobotPositionRecord();
                Thread.Sleep(5);

                RobotMonitoringErrorList.Clear();
                foreach (string tempstr in tempstrlist0.ToArray()) RobotMonitoringErrorList.AppendLine(tempstr);

                RobotMonitoringData.moni_RobotCommTime = DateTime.Now;

                RobotCentorPositionCalc();
            }

        }

        void RobotPositionRecord()
        {
            RobotPositionRecordData tempPosiData = new RobotPositionRecordData();
            float f, f1, f2, f3, f4, f5, f6;
            CLINK_API_RESULT caRetVal;

            //public float[] moni_RobotTCPActualPose = new float[6];                         //로봇 TCP 현재좌표 x,y,z,Rx,Ry,Rz
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                tempPosiData.ActualPosition = new RobotPoseData(1, 100, f1, f2, f3, f4, f5, f6);
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotTCPActualPose, 0);
            }
            else
            {
            }

            tempPosiData.RecordTime = DateTime.Now;

            RobotPosiRecord_Add(tempPosiData);
        }

        void RobotCentorPositionCalc()
        {
            CenterCal1Hz = RobotCentorPositionCalc_Sub(1000);
            CenterCal1_5Hz = RobotCentorPositionCalc_Sub(666);
            CenterCal2Hz = RobotCentorPositionCalc_Sub(500);
            CenterCal2_5Hz = RobotCentorPositionCalc_Sub(400);
            CenterCal3Hz = RobotCentorPositionCalc_Sub(333);
            CenterCal3_5Hz = RobotCentorPositionCalc_Sub(285);
            CenterCal4Hz = RobotCentorPositionCalc_Sub(250);
            CenterCal4_5Hz = RobotCentorPositionCalc_Sub(222);
        }
        RobotPoseData RobotCentorPositionCalc_Sub(int millisec)
        {
            RobotPoseData CentorPose = (RobotPoseData)RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.Clone();

            DateTime nowtime = DateTime.Now;

            double MaxX, MaxY, MaxZ, MinX, MinY, MinZ;
            MaxX = RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.f1;
            MaxY = RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.f2;
            MaxZ = RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.f3;
            MinX = RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.f1;
            MinY = RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.f2;
            MinZ = RobotPosiRecord[RobotPosiRecord.Count - 1].ActualPosition.f3;

            for (int i = RobotPosiRecord.Count - 1; i >= 0; i--)
            {
                if (MaxX < RobotPosiRecord[i].ActualPosition.f1) MaxX = RobotPosiRecord[i].ActualPosition.f1;
                if (MaxY < RobotPosiRecord[i].ActualPosition.f2) MaxY = RobotPosiRecord[i].ActualPosition.f2;
                if (MaxZ < RobotPosiRecord[i].ActualPosition.f3) MaxZ = RobotPosiRecord[i].ActualPosition.f3;

                if (MinX > RobotPosiRecord[i].ActualPosition.f1) MinX = RobotPosiRecord[i].ActualPosition.f1;
                if (MinY > RobotPosiRecord[i].ActualPosition.f2) MinY = RobotPosiRecord[i].ActualPosition.f2;
                if (MinZ > RobotPosiRecord[i].ActualPosition.f3) MinZ = RobotPosiRecord[i].ActualPosition.f3;

                if (((nowtime - RobotPosiRecord[i].RecordTime).Ticks / 10000) > millisec) break;
            }

            CentorPose.f1 = (float)((MaxX + MinX) / 2);
            CentorPose.f2 = (float)((MaxY + MinY) / 2);
            CentorPose.f3 = (float)((MaxZ + MinZ) / 2);

            return CentorPose;
        }

        List<string> Monitoring1()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();

            //public string moni_RobotAPIVersion;                                            //로봇 API SW 버전
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), system_api_version_get()");
            RobotMonitoringData.moni_RobotAPIVersion = clinkCs.system_api_version_get();


            //public byte moni_RobotEmergencyState;                                          //로봇 비상정지버튼 상태, 0:안눌림, 1:눌림
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_emergency_button_state_get(ctrlBoxID, out i)");
            caRetVal = clinkCs.control_box_emergency_button_state_get(ctrlBoxID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_BUTTON_STATE.CLINK_BUTTON_STATE_RELEASED)
                {
                    RobotMonitoringData.moni_RobotEmergencyState = 0;
                }
                else if (i == (int)CLINK_BUTTON_STATE.CLINK_BUTTON_STATE_PUSHED)
                {
                    RobotMonitoringData.moni_RobotEmergencyState = 1;
                    ErrorState_EMGRel = true;
                    ErrorTime_EMGRel = DateTime.Now;
                    //RobotControlThreadSeq = 0;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:control_box_emergency_button_state_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }


            //public float[] moni_RobotIOValueAI = new float[2];                             //로봇 AI1, AI2 입력값
            //public float[] moni_RobotIOValueAO = new float[2];                             //로봇 AO1, AO2 출력값
            for (uint count = 0; count < 2; count++)
            {

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_analog_input_get(ctrlBoxID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.control_box_io_analog_input_get(ctrlBoxID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotIOValueAI[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:control_box_io_analog_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_analog_output_get(ctrlBoxID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.control_box_io_analog_output_get(ctrlBoxID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotIOValueAO[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:control_box_io_analog_output_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }
            }


            return tempstrlist1;
        }

        List<string> Monitoring2()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();



            //public byte moni_RobotIOValueDI;                                               //로봇 DI 입력값
            //public byte moni_RobotIOValueDO;                                               //로봇 DO 출력값
            tempb1 = 0;
            for (uint count = 0; count < 8; count++)
            {
                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_digital_input_get(ctrlBoxID, count, out u), count=" + count.ToString());
                caRetVal = clinkCs.control_box_io_digital_input_get(ctrlBoxID, count, out u);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    tempb1 += (byte)((int)u << (int)count);
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:control_box_io_digital_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

            }
            RobotMonitoringData.moni_RobotIOValueDI = tempb1;





            return tempstrlist1;
        }

        List<string> Monitoring3()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();


            //public byte moni_RobotIOValueDI;                                               //로봇 DI 입력값
            //public byte moni_RobotIOValueDO;                                               //로봇 DO 출력값
            tempb2 = 0;
            for (uint count = 0; count < 8; count++)
            {
                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_digital_output_get(ctrlBoxID, count, out u), count=" + count.ToString());
                caRetVal = clinkCs.control_box_io_digital_output_get(ctrlBoxID, count, out u);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    tempb2 += (byte)((int)u << (int)count);
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:control_box_io_digital_output_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }
            }
            RobotMonitoringData.moni_RobotIOValueDO = tempb2;

            return tempstrlist1;
        }

        List<string> Monitoring4()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();


            //public byte moni_RobotMotionState;                                             //로봇 모션이동 상태 0~5, 엑셀문서 참고
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_state_moving_get(robotID, out i)");
            caRetVal = clinkCs.robot_state_moving_get(robotID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
                {
                    RobotMonitoringData.moni_RobotMotionState = 0;
                }
                else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_MOVING)
                {
                    RobotMonitoringData.moni_RobotMotionState = 1;
                }
                else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_PAUSING)
                {
                    RobotMonitoringData.moni_RobotMotionState = 2;
                }
                else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_PAUSED)
                {
                    RobotMonitoringData.moni_RobotMotionState = 3;
                }
                else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPING)
                {
                    RobotMonitoringData.moni_RobotMotionState = 4;
                }
                else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPED)
                {
                    RobotMonitoringData.moni_RobotMotionState = 5;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_state_moving_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }



            //로봇 안전기능 온오프상태 0:온, 1:오프
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_safety_limit_switch_get(robotID, out i)");
            caRetVal = clinkCs.robot_safety_limit_switch_get(robotID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    RobotMonitoringData.moni_RobotSafetySwitchState = 0;
                }
                else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    RobotMonitoringData.moni_RobotSafetySwitchState = 1;
                }
                else
                {
                    RCommOK = false;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_state_safety_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }



            ////public byte moni_RobotSafetyState;                                             //로봇 안전상태 0:정상, 1:세이프티 위반
            //RobotFuncCallLog_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_state_safety_get(robotID, out i)");
            //caRetVal = clinkCs.robot_state_safety_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_ROBOT_SAFETY_STATE.CLINK_ROBOT_SAFETY_STATE_SAFE)
            //    {
            //        RobotMonitoringData.moni_RobotSafetyState = 0;
            //    }else if(i == (int)CLINK_ROBOT_SAFETY_STATE.CLINK_ROBOT_SAFETY_STATE_NOT_SAFE)
            //    {
            //        RobotMonitoringData.moni_RobotSafetyState = 1;
            //        RobotControlThreadSeq = 0;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_state_safety_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}



            //public byte moni_RobotServoOnState;                                            //로봇 서보모터 상태 0:서보온, 1:서보 오프
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_servo_switch_get(robotID, out i)");
            caRetVal = clinkCs.robot_servo_switch_get(robotID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    RobotMonitoringData.moni_RobotServoOnState = 0;
                }
                else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    RobotMonitoringData.moni_RobotServoOnState = 1;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_servo_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }



            //public byte moni_RobotMountingSerface;                                         //로봇 설치면
            //public float[] moni_RobotMountingAngle = new float[2];                         //로봇 설치 각도 Rx, Ry
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_installation_mount_get(robotID, out i, out f1, out f2)");
            caRetVal = clinkCs.robot_installation_mount_get(robotID, out i, out f1, out f2);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_FLOOR)
                {
                    RobotMonitoringData.moni_RobotMountingSerface = 0;
                }
                else if (i == (int)CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_WALL)
                {
                    RobotMonitoringData.moni_RobotMountingSerface = 1;
                }
                else if (i == (int)CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_CEILING)
                {
                    RobotMonitoringData.moni_RobotMountingSerface = 2;
                }
                RobotMonitoringData.moni_RobotMountingAngle[0] = f1;
                RobotMonitoringData.moni_RobotMountingAngle[1] = f2;
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_installation_mount_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }




            //public float[] moni_RobotFlangeToTCP = new float[6];                           //로봇 TCP 설정값 x,y,z,Rx,Ry,Rz
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_from_flange_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            caRetVal = clinkCs.robot_tcp_from_flange_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotFlangeToTCP, 0);
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_tcp_from_flange_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }



            //public float moni_RobotTCPPayload;                                             //로봇 TCP 무게
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_payload_get(robotID, out f)");
            caRetVal = clinkCs.robot_tcp_payload_get(robotID, out f);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotMonitoringData.moni_RobotTCPPayload = f;
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_tcp_payload_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }




            return tempstrlist1;
        }

        List<string> Monitoring5()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();





            //public float[] moni_RobotTCPMassCenter = new float[3];                         //로봇 TCP 무게중심 좌표 x,y,z
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_center_of_mass_get(robotID, out f1, out f2, out f3)");
            caRetVal = clinkCs.robot_tcp_center_of_mass_get(robotID, out f1, out f2, out f3);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3 }.CopyTo(RobotMonitoringData.moni_RobotTCPMassCenter, 0);
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_tcp_center_of_mass_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }



            //public float[] moni_RobotTCPCommandPose = new float[6];                        //로봇 TCP 목표좌표 x,y,z,Rx,Ry,Rz
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_pose_command_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            caRetVal = clinkCs.robot_tcp_pose_command_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotTCPCommandPose, 0);
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_tcp_pose_command_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }




            //public float[] moni_RobotTCPActualPose = new float[6];                         //로봇 TCP 현재좌표 x,y,z,Rx,Ry,Rz
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotTCPActualPose, 0);
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_tcp_pose_actual_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }





            return tempstrlist1;
        }

        List<string> Monitoring6()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();



            //public float[] moni_RobotToolIOValueAI = new float[2];                         //로봇 툴IO AI1, AI2 입력값
            for (uint count = 0; count < 2; count++)
            {

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tool_io_analog_input_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_tool_io_analog_input_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotToolIOValueAI[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_tool_io_analog_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }
            }



            //public byte moni_RobotDirectTeachingState;                                     //로봇 직접교시 상태 0:직접교시 실행중, 1:직접교시 실행중이 아님
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_direct_teaching_switch_get(robotID, out i)");
            caRetVal = clinkCs.robot_direct_teaching_switch_get(robotID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    RobotMonitoringData.moni_RobotDirectTeachingState = 0;
                }
                else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    RobotMonitoringData.moni_RobotDirectTeachingState = 1;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_direct_teaching_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }




            return tempstrlist1;
        }

        List<string> Monitoring7()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();



            //public byte moni_RobotToolIOValueDI;                                           //로봇 툴IO DI 입력값
            //public byte moni_RobotToolIOValueDO;                                           //로봇 툴IO DO 출력값
            tempb1 = 0;
            tempb2 = 0;
            for (uint count = 0; count < 4; count++)
            {
                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tool_io_digital_input_get(robotID, count, out u), count=" + count.ToString());
                caRetVal = clinkCs.robot_tool_io_digital_input_get(robotID, count, out u);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    tempb1 += (byte)((int)u << (int)count);
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_tool_io_digital_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tool_io_digital_output_get(robotID, count, out u), count=" + count.ToString());
                caRetVal = clinkCs.robot_tool_io_digital_output_get(robotID, count, out u);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    tempb2 += (byte)((int)u << (int)count);
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_tool_io_digital_output_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }
            }
            RobotMonitoringData.moni_RobotToolIOValueDI = tempb1;
            RobotMonitoringData.moni_RobotToolIOValueDO = tempb2;





            //public byte moni_RobotCollisionDetectionState;                                 //로봇 충돌감지 기능 상태 0:충돌감지기능 켜짐, 1:충돌감지기능 꺼짐
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_collision_detection_switch_get(robotID, out i)");
            caRetVal = clinkCs.robot_collision_detection_switch_get(robotID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    RobotMonitoringData.moni_RobotCollisionDetectionState = 0;
                }
                else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    RobotMonitoringData.moni_RobotCollisionDetectionState = 1;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_collision_detection_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }



            //public byte moni_RobotCollisionMitigationState;                                //로봇 충돌감지 완화 기능 상태 0:충돌감지 완화기능 켜짐, 1:충돌감지 완화기능 꺼짐
            RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_collision_mitigation_switch_get(robotID, out i)");
            caRetVal = clinkCs.robot_collision_mitigation_switch_get(robotID, out i);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
                {
                    RobotMonitoringData.moni_RobotCollisionMitigationState = 0;
                }
                else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    RobotMonitoringData.moni_RobotCollisionMitigationState = 1;
                }
            }
            else
            {
                RCommOK = false;
                tempstrlist1.Add("API:robot_collision_mitigation_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            }


            return tempstrlist1;
        }

        List<string> Monitoring8()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();




            //public float[] moni_RobotCollisionDetectionJointLimit = new float[6];          //로봇 각축 충돌감지 임계치값 1~6
            for (uint count = 0; count < 6; count++)
            {
                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_collision_detection_threshold_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_collision_detection_threshold_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotCollisionDetectionJointLimit[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_collision_detection_threshold_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }
            }



            //public float[] moni_RobotJointTmp = new float[6];                              //로봇 각축 모터 온도 1~6
            //public float[] moni_RobotJointVol = new float[6];                              //로봇 각축 모터 전압 1~6
            //public float[] moni_RobotJointAmp = new float[6];                              //로봇 각축 모터 전류 1~6
            //public float[] moni_RobotJointCommandAngle = new float[6];                     //로봇 각축 모터 목표각도 1~6
            //public float[] moni_RobotJointActualAngle = new float[6];                      //로봇 각축 모터 현재각도 1~6
            for (uint count = 0; count < 6; count++)
            {
                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_temperature_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_joint_temperature_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotJointTmp[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_joint_temperature_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

            }


            return tempstrlist1;
        }

        List<string> Monitoring9()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();



            //public float[] moni_RobotJointTmp = new float[6];                              //로봇 각축 모터 온도 1~6
            //public float[] moni_RobotJointVol = new float[6];                              //로봇 각축 모터 전압 1~6
            //public float[] moni_RobotJointAmp = new float[6];                              //로봇 각축 모터 전류 1~6
            //public float[] moni_RobotJointCommandAngle = new float[6];                     //로봇 각축 모터 목표각도 1~6
            //public float[] moni_RobotJointActualAngle = new float[6];                      //로봇 각축 모터 현재각도 1~6
            for (uint count = 0; count < 6; count++)
            {
                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_voltage_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_joint_voltage_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotJointVol[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_joint_voltage_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_current_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_joint_current_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotJointAmp[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_joint_current_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

            }



            return tempstrlist1;
        }

        List<string> Monitoring10()
        {
            byte tempb1, tempb2;
            int i;
            uint u;
            float f, f1, f2, f3, f4, f5, f6;
            string tempstr1;
            bool RCommOK = true;
            CLINK_API_RESULT caRetVal;
            List<string> tempstrlist1 = new List<string>();


            //public float[] moni_RobotJointTmp = new float[6];                              //로봇 각축 모터 온도 1~6
            //public float[] moni_RobotJointVol = new float[6];                              //로봇 각축 모터 전압 1~6
            //public float[] moni_RobotJointAmp = new float[6];                              //로봇 각축 모터 전류 1~6
            //public float[] moni_RobotJointCommandAngle = new float[6];                     //로봇 각축 모터 목표각도 1~6
            //public float[] moni_RobotJointActualAngle = new float[6];                      //로봇 각축 모터 현재각도 1~6
            for (uint count = 0; count < 6; count++)
            {

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_angle_command_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_joint_angle_command_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotJointCommandAngle[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_joint_angle_command_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }

                RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_angle_actual_get(robotID, count, out f), count=" + count.ToString());
                caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    RobotMonitoringData.moni_RobotJointActualAngle[count] = f;
                }
                else
                {
                    RCommOK = false;
                    tempstrlist1.Add("API:robot_joint_angle_actual_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                }
            }




            return tempstrlist1;
        }


        //모니터링 스레드에서 실행하는 함수
        public void Monitoring()
        {

            //byte tempb1, tempb2;
            //int i;
            //uint u;
            //float f, f1, f2, f3, f4, f5, f6;
            //string tempstr1;

            //List<string> tempstrlist1 = new List<string>();


            //bool RCommOK = true;                        //함수 호출 정상적으로 완료되었는지 체크하는 플래그

            //RobotMonitoringData.moni_RobotCommTime = DateTime.Now;
            //sw.Reset();
            //sw.Start();
            //tempstrlist1.Clear();

            //sw1.Reset();
            //sw1.Start();
            //tempstr1 = "";

            ////public string moni_RobotAPIVersion;                                            //로봇 API SW 버전
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), system_api_version_get()");
            //RobotMonitoringData.moni_RobotAPIVersion = clinkCs.system_api_version_get();

            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms API버전" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public byte moni_RobotEmergencyState;                                          //로봇 비상정지버튼 상태, 0:안눌림, 1:눌림
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_emergency_button_state_get(ctrlBoxID, out i)");
            //CLINK_API_RESULT caRetVal = clinkCs.control_box_emergency_button_state_get(ctrlBoxID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_BUTTON_STATE.CLINK_BUTTON_STATE_RELEASED)
            //    {
            //        RobotMonitoringData.moni_RobotEmergencyState = 0;
            //    }
            //    else if (i == (int)CLINK_BUTTON_STATE.CLINK_BUTTON_STATE_PUSHED)
            //    {
            //        RobotMonitoringData.moni_RobotEmergencyState = 1;
            //        ErrorState_EMGRel = true;
            //        ErrorTime_EMGRel = DateTime.Now;
            //        //RobotControlThreadSeq = 0;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:control_box_emergency_button_state_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 비상정지" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();

            ////public byte moni_RobotIOValueDI;                                               //로봇 DI 입력값
            ////public byte moni_RobotIOValueDO;                                               //로봇 DO 출력값
            //tempb1 = 0;
            //tempb2 = 0;
            //for (uint count = 0; count < 8; count++)
            //{
            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_digital_input_get(ctrlBoxID, count, out u), count=" + count.ToString());
            //    caRetVal = clinkCs.control_box_io_digital_input_get(ctrlBoxID, count, out u);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        tempb1 += (byte)((int)u << (int)count);
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:control_box_io_digital_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_digital_output_get(ctrlBoxID, count, out u), count=" + count.ToString());
            //    caRetVal = clinkCs.control_box_io_digital_output_get(ctrlBoxID, count, out u);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        tempb2 += (byte)((int)u << (int)count);
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:control_box_io_digital_output_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }
            //}
            //RobotMonitoringData.moni_RobotIOValueDI = tempb1;
            //RobotMonitoringData.moni_RobotIOValueDO = tempb2;


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 박스DIO" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();

            ////public float[] moni_RobotIOValueAI = new float[2];                             //로봇 AI1, AI2 입력값
            ////public float[] moni_RobotIOValueAO = new float[2];                             //로봇 AO1, AO2 출력값

            //for (uint count = 0; count < 2; count++)
            //{

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_analog_input_get(ctrlBoxID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.control_box_io_analog_input_get(ctrlBoxID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotIOValueAI[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:control_box_io_analog_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), control_box_io_analog_output_get(ctrlBoxID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.control_box_io_analog_output_get(ctrlBoxID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotIOValueAO[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:control_box_io_analog_output_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 박스AIO" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();

            ////public byte moni_RobotMotionState;                                             //로봇 모션이동 상태 0~5, 엑셀문서 참고
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_state_moving_get(robotID, out i)");
            //caRetVal = clinkCs.robot_state_moving_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
            //    {
            //        RobotMonitoringData.moni_RobotMotionState = 0;
            //    }
            //    else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_MOVING)
            //    {
            //        RobotMonitoringData.moni_RobotMotionState = 1;
            //    }
            //    else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_PAUSING)
            //    {
            //        RobotMonitoringData.moni_RobotMotionState = 2;
            //    }
            //    else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_PAUSED)
            //    {
            //        RobotMonitoringData.moni_RobotMotionState = 3;
            //    }
            //    else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPING)
            //    {
            //        RobotMonitoringData.moni_RobotMotionState = 4;
            //    }
            //    else if (i == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPED)
            //    {
            //        RobotMonitoringData.moni_RobotMotionState = 5;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_state_moving_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 무빙상태" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////로봇 안전기능 온오프상태 0:온, 1:오프
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_safety_limit_switch_get(robotID, out i)");
            //caRetVal = clinkCs.robot_safety_limit_switch_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
            //    {
            //        RobotMonitoringData.moni_RobotSafetySwitchState = 0;
            //    }
            //    else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
            //    {
            //        RobotMonitoringData.moni_RobotSafetySwitchState = 1;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_state_safety_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}



            //////public byte moni_RobotSafetyState;                                             //로봇 안전상태 0:정상, 1:세이프티 위반
            ////RobotFuncCallLog_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_state_safety_get(robotID, out i)");
            ////caRetVal = clinkCs.robot_state_safety_get(robotID, out i);
            ////if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            ////{
            ////    if (i == (int)CLINK_ROBOT_SAFETY_STATE.CLINK_ROBOT_SAFETY_STATE_SAFE)
            ////    {
            ////        RobotMonitoringData.moni_RobotSafetyState = 0;
            ////    }else if(i == (int)CLINK_ROBOT_SAFETY_STATE.CLINK_ROBOT_SAFETY_STATE_NOT_SAFE)
            ////    {
            ////        RobotMonitoringData.moni_RobotSafetyState = 1;
            ////        RobotControlThreadSeq = 0;
            ////    }
            ////    else
            ////    {
            ////        RCommOK = false;
            ////    }
            ////}
            ////else
            ////{
            ////    RCommOK = false;
            ////    tempstrlist1.Add("API:robot_state_safety_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            ////}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 안전상태" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();

            ////public byte moni_RobotServoOnState;                                            //로봇 서보모터 상태 0:서보온, 1:서보 오프
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_servo_switch_get(robotID, out i)");
            //caRetVal = clinkCs.robot_servo_switch_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
            //    {
            //        RobotMonitoringData.moni_RobotServoOnState = 0;
            //    }
            //    else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
            //    {
            //        RobotMonitoringData.moni_RobotServoOnState = 1;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_servo_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 서보온" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public byte moni_RobotMountingSerface;                                         //로봇 설치면
            ////public float[] moni_RobotMountingAngle = new float[2];                         //로봇 설치 각도 Rx, Ry
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_installation_mount_get(robotID, out i, out f1, out f2)");
            //caRetVal = clinkCs.robot_installation_mount_get(robotID, out i, out f1, out f2);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_FLOOR)
            //    {
            //        RobotMonitoringData.moni_RobotMountingSerface = 0;
            //    }
            //    else if (i == (int)CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_WALL)
            //    {
            //        RobotMonitoringData.moni_RobotMountingSerface = 1;
            //    }
            //    else if (i == (int)CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_CEILING)
            //    {
            //        RobotMonitoringData.moni_RobotMountingSerface = 2;
            //    }
            //    RobotMonitoringData.moni_RobotMountingAngle[0] = f1;
            //    RobotMonitoringData.moni_RobotMountingAngle[1] = f2;
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_installation_mount_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 설치자세" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotFlangeToTCP = new float[6];                           //로봇 TCP 설정값 x,y,z,Rx,Ry,Rz
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_from_flange_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            //caRetVal = clinkCs.robot_tcp_from_flange_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotFlangeToTCP, 0);
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_tcp_from_flange_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms TCP정보" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float moni_RobotTCPPayload;                                             //로봇 TCP 무게
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_payload_get(robotID, out f)");
            //caRetVal = clinkCs.robot_tcp_payload_get(robotID, out f);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    RobotMonitoringData.moni_RobotTCPPayload = f;
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_tcp_payload_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 툴무게" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotTCPMassCenter = new float[3];                         //로봇 TCP 무게중심 좌표 x,y,z
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_center_of_mass_get(robotID, out f1, out f2, out f3)");
            //caRetVal = clinkCs.robot_tcp_center_of_mass_get(robotID, out f1, out f2, out f3);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    new float[] { f1, f2, f3 }.CopyTo(RobotMonitoringData.moni_RobotTCPMassCenter, 0);
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_tcp_center_of_mass_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 툴 무게중심" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotTCPCommandPose = new float[6];                        //로봇 TCP 목표좌표 x,y,z,Rx,Ry,Rz
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_pose_command_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            //caRetVal = clinkCs.robot_tcp_pose_command_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotTCPCommandPose, 0);
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_tcp_pose_command_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms TCP목표좌표" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotTCPActualPose = new float[6];                         //로봇 TCP 현재좌표 x,y,z,Rx,Ry,Rz
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6)");
            //caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(RobotMonitoringData.moni_RobotTCPActualPose, 0);
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_tcp_pose_actual_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms TCP현재좌표" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotJointTmp = new float[6];                              //로봇 각축 모터 온도 1~6
            ////public float[] moni_RobotJointVol = new float[6];                              //로봇 각축 모터 전압 1~6
            ////public float[] moni_RobotJointAmp = new float[6];                              //로봇 각축 모터 전류 1~6
            ////public float[] moni_RobotJointCommandAngle = new float[6];                     //로봇 각축 모터 목표각도 1~6
            ////public float[] moni_RobotJointActualAngle = new float[6];                      //로봇 각축 모터 현재각도 1~6
            //for (uint count = 0; count < 6; count++)
            //{
            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_temperature_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_joint_temperature_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotJointTmp[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_joint_temperature_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_voltage_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_joint_voltage_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotJointVol[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_joint_voltage_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_current_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_joint_current_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotJointAmp[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_joint_current_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_angle_command_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_joint_angle_command_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotJointCommandAngle[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_joint_angle_command_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_joint_angle_actual_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotJointActualAngle[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_joint_angle_actual_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 축정보" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public byte moni_RobotToolIOValueDI;                                           //로봇 툴IO DI 입력값
            ////public byte moni_RobotToolIOValueDO;                                           //로봇 툴IO DO 출력값
            //tempb1 = 0;
            //tempb2 = 0;
            //for (uint count = 0; count < 4; count++)
            //{
            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tool_io_digital_input_get(robotID, count, out u), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_tool_io_digital_input_get(robotID, count, out u);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        tempb1 += (byte)((int)u << (int)count);
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_tool_io_digital_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tool_io_digital_output_get(robotID, count, out u), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_tool_io_digital_output_get(robotID, count, out u);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        tempb2 += (byte)((int)u << (int)count);
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_tool_io_digital_output_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }
            //}
            //RobotMonitoringData.moni_RobotToolIOValueDI = tempb1;
            //RobotMonitoringData.moni_RobotToolIOValueDO = tempb2;


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 툴DIO" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotToolIOValueAI = new float[2];                         //로봇 툴IO AI1, AI2 입력값
            //for (uint count = 0; count < 2; count++)
            //{

            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_tool_io_analog_input_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_tool_io_analog_input_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotToolIOValueAI[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_tool_io_analog_input_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 툴AI" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public byte moni_RobotDirectTeachingState;                                     //로봇 직접교시 상태 0:직접교시 실행중, 1:직접교시 실행중이 아님
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_direct_teaching_switch_get(robotID, out i)");
            //caRetVal = clinkCs.robot_direct_teaching_switch_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
            //    {
            //        RobotMonitoringData.moni_RobotDirectTeachingState = 0;
            //    }
            //    else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
            //    {
            //        RobotMonitoringData.moni_RobotDirectTeachingState = 1;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_direct_teaching_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 직접교시상태" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();

            ////public byte moni_RobotCollisionDetectionState;                                 //로봇 충돌감지 기능 상태 0:충돌감지기능 켜짐, 1:충돌감지기능 꺼짐
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_collision_detection_switch_get(robotID, out i)");
            //caRetVal = clinkCs.robot_collision_detection_switch_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
            //    {
            //        RobotMonitoringData.moni_RobotCollisionDetectionState = 0;
            //    }
            //    else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
            //    {
            //        RobotMonitoringData.moni_RobotCollisionDetectionState = 1;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_collision_detection_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 충돌감지" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public float[] moni_RobotCollisionDetectionJointLimit = new float[6];          //로봇 각축 충돌감지 임계치값 1~6
            //for (uint count = 0; count < 6; count++)
            //{
            //    RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_collision_detection_threshold_get(robotID, count, out f), count=" + count.ToString());
            //    caRetVal = clinkCs.robot_collision_detection_threshold_get(robotID, count, out f);
            //    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        RobotMonitoringData.moni_RobotCollisionDetectionJointLimit[count] = f;
            //    }
            //    else
            //    {
            //        RCommOK = false;
            //        tempstrlist1.Add("API:robot_collision_detection_threshold_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //    }
            //}


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 충돌감지기준" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();


            ////public byte moni_RobotCollisionMitigationState;                                //로봇 충돌감지 완화 기능 상태 0:충돌감지 완화기능 켜짐, 1:충돌감지 완화기능 꺼짐
            //RobotFuncCallLog2_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Monitoring(), robot_collision_mitigation_switch_get(robotID, out i)");
            //caRetVal = clinkCs.robot_collision_mitigation_switch_get(robotID, out i);
            //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //{
            //    if (i == (int)CLINK_SWITCH.CLINK_SWITCH_ON)
            //    {
            //        RobotMonitoringData.moni_RobotCollisionMitigationState = 0;
            //    }
            //    else if (i == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
            //    {
            //        RobotMonitoringData.moni_RobotCollisionMitigationState = 1;
            //    }
            //}
            //else
            //{
            //    RCommOK = false;
            //    tempstrlist1.Add("API:robot_collision_mitigation_switch_get , ERROR:" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
            //}

            //RobotMonitoringErrorList.Clear();
            //foreach (string tempstr in tempstrlist1.ToArray()) RobotMonitoringErrorList.AppendLine(tempstr);


            //sw1.Stop();
            //tempstr1 = tempstr1 + sw1.Elapsed.TotalMilliseconds.ToString("0.000") + "ms 충돌완화" + Environment.NewLine;
            //sw1.Reset();
            //sw1.Start();
            //strcommtimetmep = tempstr1;

            ////public List<RobotEventData> moni_RobotEventLog = new List<RobotEventData>();   //로봇 이벤트 기록 (발생시간, 메인그룹, 서브그룹)
            ////public void EventCallbackTest(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
            ////{
            ////aaa.moni_RobotEventLog.Add(, event_grp, event_subgrp);
            ////}

            //if (RCommOK == false)
            //{


            //}

            //sw.Stop();
            //RobotMonitoringData.moni_RobotCommTimeTaken = sw.Elapsed.TotalMilliseconds;
        }




        //리스트를 여러 스레드에서 접근 할 때 간혹 에러가 발생해서 스레드세이프 구조로 만듬. 최대 개수도 제한함
        private void RobotEventLog_Add(RobotEventData tempevt)
        {
            lock(lockObject_RobotEventLog)
            {
                RobotEventLog.Add(tempevt);

                if (RobotEventLog.Count > 1000)
                {
                    RobotEventLog.RemoveAt(0);
                }
            }
        }

        //외부에서 이벤트 데이터 읽어감. 쓰는 함수와 동시 실행 안되도록 락 걸어놨음
        public RobotEventData[] RobotEventLog_ReadBlock(int count)
        {
            RobotEventData[] tempdata;

            lock (lockObject_RobotEventLog)
            {
                if(RobotEventLog.Count< count)
                {
                    tempdata = new RobotEventData[RobotEventLog.Count];
                    RobotEventLog.CopyTo(0, tempdata, 0, RobotEventLog.Count);
                }
                else
                {
                    tempdata = new RobotEventData[count];
                    RobotEventLog.CopyTo(RobotEventLog.Count - count, tempdata, 0, count);
                }
            }

            return tempdata;
        }
        
        private void RobotControlStr_Add(string tempstr)
        {
            lock (lockObject_RobotControlStr)
            {
                RobotControlStr.Add(tempstr);

                if (RobotControlStr.Count > 1000)
                {
                    RobotControlStr.RemoveAt(0);
                }
            }
        }

        public string[] RobotControlStr_ReadBlock(int count)
        {
            string[] tempdata;

            lock (lockObject_RobotControlStr)
            {
                if (RobotControlStr.Count < count)
                {
                    tempdata = new string[RobotControlStr.Count];
                    RobotControlStr.CopyTo(0, tempdata, 0, RobotControlStr.Count);
                }
                else
                {
                    tempdata = new string[count];
                    RobotControlStr.CopyTo(RobotControlStr.Count - count, tempdata, 0, count);
                }
            }

            return tempdata;
        }
        

        private void RobotFuncCallLog1_Add(string tempstr)
        {
            lock (lockObject_RobotFuncCallLog1)
            {
                RobotFuncCallLog1.Add(tempstr);

                if (RobotFuncCallLog1.Count > 2000)
                {
                    RobotFuncCallLog1.RemoveAt(0);
                }
            }
        }

        public string[] RobotFuncCallLog1_ReadBlock(int count)
        {
            string[] tempdata;

            lock (lockObject_RobotFuncCallLog1)
            {
                if (RobotFuncCallLog1.Count < count)
                {
                    tempdata = new string[RobotFuncCallLog1.Count];
                    RobotFuncCallLog1.CopyTo(0, tempdata, 0, RobotFuncCallLog1.Count);
                }
                else
                {
                    tempdata = new string[count];
                    RobotFuncCallLog1.CopyTo(RobotFuncCallLog1.Count - count, tempdata, 0, count);
                }
            }

            return tempdata;
        }


        private void RobotFuncCallLog2_Add(string tempstr)
        {
            lock (lockObject_RobotFuncCallLog2)
            {
                RobotFuncCallLog2.Add(tempstr);

                if (RobotFuncCallLog2.Count > 2000)
                {
                    RobotFuncCallLog2.RemoveAt(0);
                }
            }
        }

        public string[] RobotFuncCallLog2_ReadBlock(int count)
        {
            string[] tempdata;

            lock (lockObject_RobotFuncCallLog2)
            {
                if (RobotFuncCallLog2.Count < count)
                {
                    tempdata = new string[RobotFuncCallLog2.Count];
                    RobotFuncCallLog2.CopyTo(0, tempdata, 0, RobotFuncCallLog2.Count);
                }
                else
                {
                    tempdata = new string[count];
                    RobotFuncCallLog2.CopyTo(RobotFuncCallLog2.Count - count, tempdata, 0, count);
                }
            }

            return tempdata;
        }


        private void RobotPosiRecord_Add(RobotPositionRecordData tempdata)
        {
            lock (lockObject_RobotPosiRecord)
            {
                RobotPosiRecord.Add(tempdata);

                if (RobotPosiRecord.Count > 2000)
                {
                    RobotPosiRecord.RemoveAt(0);
                }
            }
        }

        public RobotPositionRecordData[] RobotPosiRecord_ReadBlock(int count)
        {
            RobotPositionRecordData[] tempdata;

            lock (lockObject_RobotPosiRecord)
            {

                if (RobotPosiRecord.Count < count)
                {
                    tempdata = new RobotPositionRecordData[RobotPosiRecord.Count];
                    RobotPosiRecord.CopyTo(0, tempdata, 0, RobotPosiRecord.Count);
                }
                else
                {
                    tempdata = new RobotPositionRecordData[count];
                    RobotPosiRecord.CopyTo(RobotPosiRecord.Count - count, tempdata, 0, count);
                }

            }

            return tempdata;
        }


        //에러이벤트 받아오는 함수
        void event_handler_callback_func_ERROR1(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "에러이벤트 1";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_ERROR2(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "에러이벤트 2";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_ERROR3(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "에러이벤트 3";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_ERROR4(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "에러이벤트 4";
            RobotEventLog_Add(tempevt);
        }


        //버튼이벤트 받아오는 함수
        void event_handler_callback_func_BUTTON1(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "버튼이벤트 1";
            RobotEventLog_Add(tempevt);

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_PUSHED)
            {
                ChangeEMGState(1);
            }else if(event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_RELEASED)
            {
                ChangeEMGState(0);
            }


            
        }
        void event_handler_callback_func_BUTTON2(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "버튼이벤트 2";
            RobotEventLog_Add(tempevt);

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_PUSHED)
            {
                ChangeEMGState(1);
            }
            else if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_RELEASED)
            {
                ChangeEMGState(0);
            }
        }
        void event_handler_callback_func_BUTTON3(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "버튼이벤트 3";
            RobotEventLog_Add(tempevt);

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_PUSHED)
            {
                ChangeEMGState(1);
            }
            else if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_RELEASED)
            {
                ChangeEMGState(0);
            }

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_PWR_PUSHED)
            {
                ChangePWRState(1);
            }
        }
        void event_handler_callback_func_BUTTON4(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "버튼이벤트 4";
            RobotEventLog_Add(tempevt);

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_PUSHED)
            {
                ChangeEMGState(1);
            }
            else if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_RELEASED)
            {
                ChangeEMGState(0);
            }

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_PWR_PUSHED)
            {
                ChangePWRState(1);
            }
        }
        void event_handler_callback_func_BUTTON5(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "버튼이벤트 5";
            RobotEventLog_Add(tempevt);

            if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_PUSHED)
            {
                ChangeEMGState(1);
            }
            else if (event_subgrp == (uint)CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED.CLINK_EVENT_SUBGRP_CONTROL_BOX_BUTTON_CHANGED_EMG_RELEASED)
            {
                ChangeEMGState(0);
            }
        }

        //모션이벤트 받아오는 함수
        void event_handler_callback_func_MOTION1(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 1";
            RobotEventLog_Add(tempevt);
            //if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;
        }
        void event_handler_callback_func_MOTION2(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 2";
            RobotEventLog_Add(tempevt);
            //if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;
        }
        void event_handler_callback_func_MOTION3(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 3";
            RobotEventLog_Add(tempevt);
            //if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;
        }
        void event_handler_callback_func_MOTION4(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 4";
            RobotEventLog_Add(tempevt);
            //if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;
        }
        void event_handler_callback_func_MOTION5(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 5 - "+ event_sender_id.ToString() + " - "+ motionCompleteCheckID.ToString();
            RobotEventLog_Add(tempevt);

            if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;

        }
        void event_handler_callback_func_MOTION6(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 6";
            RobotEventLog_Add(tempevt);
            //if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;
        }
        void event_handler_callback_func_MOTION7(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "모션이벤트 7";
            RobotEventLog_Add(tempevt);
            //if (event_sender_id == motionCompleteCheckID) motionCompleteCheckFlag = true;
        }

        //충돌감지이벤트 받아오는 함수
        void event_handler_callback_func_COLLISION1(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "충돌감지 이벤트 1";
            RobotEventLog_Add(tempevt);

            if (    (event_subgrp == (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_JOINT)
                || (event_subgrp == (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_TCP)    )
            {
                ChangeCollisionState();
            }

        }
        void event_handler_callback_func_COLLISION2(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "충돌감지 이벤트 2";
            RobotEventLog_Add(tempevt);

            if ((event_subgrp == (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_JOINT)
                || (event_subgrp == (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_TCP))
            {
                ChangeCollisionState();
            }
        }
        void event_handler_callback_func_COLLISION3(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "충돌감지 이벤트 3";
            RobotEventLog_Add(tempevt);

            if ((event_subgrp == (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_JOINT)
                || (event_subgrp == (uint)CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED.CLINK_EVENT_SUBGRP_ROBOT_COLLISION_DETECTED_TCP))
            {
                ChangeCollisionState();
            }
        }

        //안전관련이벤트 받아오는 함수
        void event_handler_callback_func_SAFETY1(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 1";
            RobotEventLog_Add(tempevt);

            SafetyViolateState();
        }
        void event_handler_callback_func_SAFETY2(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 2";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SAFETY3(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 3";
            RobotEventLog_Add(tempevt);

            SafetyViolateState();
        }
        void event_handler_callback_func_SAFETY4(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 4";
            RobotEventLog_Add(tempevt);

            SafetyViolateState();
        }
        void event_handler_callback_func_SAFETY5(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 5";
            RobotEventLog_Add(tempevt);

            SafetyViolateState();
        }
        void event_handler_callback_func_SAFETY6(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 6";
            RobotEventLog_Add(tempevt);

            SafetyViolateState();
        }
        void event_handler_callback_func_SAFETY7(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "세이프티위반 이벤트 7";
            RobotEventLog_Add(tempevt);

            SafetyViolateState();
        }

        //사양관련 이벤트 받아오는 함수
        void event_handler_callback_func_SPEC1(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 1";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SPEC2(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 2";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SPEC3(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 3";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SPEC4(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 4";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SPEC5(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 5";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SPEC6(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 6";
            RobotEventLog_Add(tempevt);
        }
        void event_handler_callback_func_SPEC7(uint event_grp, uint event_subgrp, uint event_sender_id, int reserve01, int reserve02, int reserve03, int reserve04, int reserve05)
        {
            RobotEventData tempevt = new RobotEventData();
            tempevt.eventMainGroup = event_grp;
            tempevt.eventSubGroup = event_subgrp;
            tempevt.eventTime = DateTime.Now;
            tempevt.eventComment = "스펙 이벤트 7";
            RobotEventLog_Add(tempevt);
        }



        //외부에서 에러리셋 호출. 이상해제 버튼에 해당함
        public void RobotErrorReset()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;

            //아직 비상정지 상태이면 실행 안함
            if (RobotMonitoringData.moni_RobotEmergencyState == 1) return; 

            if (RobotControlThreadSeq == 0)
            {
                RobotControlErrorClearFlag = true;
            }
        }

        //외부에서 서보온 호출
        public void RobotServoOn()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;

            if (RobotControlThreadSeq == 2)
            {
                RobotControlServoOnFlag = true;
                AlwaysServoOn = true;
            }
        }

        //외부에서 서보 오프 호출
        public void RobotServoOff()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;

            AlwaysServoOn = false;
            RobotControlServoOffFlag = true;
        }

        //외부에서 일시정지 호출
        public void RobotPause()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;


            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotPause(), robot_pause(robotID, 0.2f)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_pause(robotID, 0.2f);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "일시정지 호출");
            }

            Arc_Off();
        }

        //외부에서 재시작 호출
        public void RobotResume()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotResume(), robot_resume(robotID)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_resume(robotID);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "재시작 호출");
            }
        }

        //외부에서 정지 호출
        public void RobotStop()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotStop(), robot_stop(robotID, 0.2f)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_stop(robotID, 0.2f);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "모션정지 호출");

                if ((RobotControlThreadSeq >= 100) || (RobotControlThreadSeq < 200))
                {
                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 종료");
                    RobotControlThreadSeq = 15;
                }
                Arc_Off();

            }
            

        }

        //외부에서 용접시작 호출 리턴 1:성공 
        public int WeldStart(WeldInformation wdata)
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;

            //로봇이 정지해 있는 상태가 아니면 실행 안함
            int tempi = 0;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldStart(WeldInformation wdata), robot_state_moving_get(robotID, out tempi)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((tempi != (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE) && (tempi != (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPED))
                {
                    return 2;
                }
            }
            else
            {
                return 0;
            }
            
            if (RobotControlThreadSeq != 15) return 3;


            WeldData = (WeldInformation)wdata.Clone();
            RobotControlWeldStartFlag = true;

            return 1;

        }


        //외부에서 응급정지 호출
        public void RobotEMGStop()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotEMGStop(), robot_emergency_stop(robotID, 0.2f)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_emergency_stop(robotID, 0.2f);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "모션 응급정지 호출");
            }
        }


        //외부에서 직접교시 온 호출
        public int RobotDirectTeachingOn()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;


            //로봇 서보온 후 대기상태가 아니면 실행 안함
            if (RobotControlThreadSeq != 15) return 0;


            //로봇이 정지해 있는 상태가 아니면 실행 안함
            int tempi = 0;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDirectTeachingOn(), robot_state_moving_get(robotID, out tempi)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if ((tempi != (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE) && (tempi != (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPED))
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }

            //직접교시 실행
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDirectTeachingOn(), robot_direct_teaching_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON)");
            caRetVal = clinkCs.robot_direct_teaching_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "직접교시 실행");
                RobotControlDirectTeachingOnFlag = true;
                return 1;
            }
            else
            {
                return 0;
            }
        }


        //외부에서 직접교시 오프 호출
        public int RobotDirectTeachingOff()
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;



            //직접교시가 실행중이 아니라면 종료
            int tempi = 0;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDirectTeachingOff(), robot_direct_teaching_switch_get(robotID, out tempi)");
            CLINK_API_RESULT caRetVal = clinkCs.robot_direct_teaching_switch_get(robotID, out tempi);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (tempi == (int)CLINK_SWITCH.CLINK_SWITCH_OFF)
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDirectTeachingOff(), robot_direct_teaching_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF)");
            caRetVal = clinkCs.robot_direct_teaching_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "직접교시 종료");
                RobotControlDirectTeachingOffFlag = true;
                return 1;
            }
            else
            {
                return 0;
            }
        }


        void MotionCompleteCheckStart(uint MotionID)
        {
            motionCompleteCheckID = MotionID;
            motionCompleteCheckFlag = false;
        }

        bool MotionCompleteCheck()
        {
            return motionCompleteCheckFlag;
        }




        //로봇 컨트롤 로그
        void RobotControlLogAdd(string tempstr)
        {
            RobotControlStr_Add(tempstr);
            
        }


        //로봇 컨트롤시퀀스
        void RobotControlThreadFuc()
        {
            DateTime TimeRecord = new DateTime();
            CLINK_API_RESULT caRetVal;
            float[] TempPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            int tempi = 0;
            RobotPositionRecordData tempPositionRecord;

            while (RobotControlThreadContinue)
            {

                RobotControlEventCheck();
                

                switch (RobotControlThreadSeq)
                {
                    case 0:
                        //에러상태임. 사용자가 에러해제 버튼을 눌러서 상태를 1로 바뀔 때 까지 대기상태임

                        if ((AlwaysErrorReset == true) && (RobotMonitoringData.moni_RobotEmergencyState == 0))
                        {
                            tempi = (int)(DateTime.Now - ErrorTime_Coll).Ticks / 10000;
                            if (tempi > 5000)
                            {   
                                ErrorState_Coll = false;
                            }

                            tempi = (int)(DateTime.Now - ErrorTime_Safety).Ticks / 10000;
                            if (tempi > 5000)
                            {
                                ErrorState_Safety = false;
                            }

                            tempi = (int)(DateTime.Now - ErrorTime_EMGRel).Ticks / 10000;
                            if (tempi > 17000)
                            {
                                ErrorState_EMGRel = false;
                            }

                            if((ErrorState_Coll == false) &&(ErrorState_Safety == false) &&(ErrorState_EMGRel == false))
                            {
                                RobotControlThreadSeq = 1;
                            }


                        }

                        break;

                    case 1:
                        //사용자가 RobotErrorReset() 함수를 호출하면 시스템에러 리셋 시도. 성공하면 상태2로 변경
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq1, system_reset()");
                        caRetVal = clinkCs.system_reset();
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "에러 리셋 성공");
                            RobotControlThreadSeq = 2;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "에러 리셋 실패. 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }
                        break;

                    case 2:
                        //아무것도 안함. 사용자가 서보온 버튼을 눌러서 상태를 3으로 바뀔 때 까지 대기상태임
                        if(AlwaysServoOn == true)
                        {
                            RobotControlThreadSeq = 3;
                        }
                        break;

                    case 3:
                        //최대속도설정
                        Thread.Sleep(200);

                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq3, robot_safety_limit_tcp_speed_max_set(robotID, RobotControlParameter_TCPMaxSpeed)");
                        caRetVal = clinkCs.robot_safety_limit_tcp_speed_max_set(robotID, RobotControlParameter_TCPMaxSpeed);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "최대속도 설정 완료");
                            RobotControlThreadSeq = 4;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "최대속도 설정 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }

                        break;

                    case 4:
                        //속도펙터설정
                        Thread.Sleep(200);

                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq4, robot_speed_factor_set(robotID, RobotControlParameter_SpeedFactor)");
                        caRetVal = clinkCs.robot_speed_factor_set(robotID, RobotControlParameter_SpeedFactor);
                        if ((caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK) || (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_ROBOT_CUR_SPEED_FACTOR_AND_GIVEN_FACTOR_IS_SAME))
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "속도팩터 설정 완료");
                            RobotControlThreadSeq = 5;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "속도팩터 설정 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }
                        break;

                    case 5:
                        //바운더리설정 그냥 지나감

                        RobotControlThreadSeq = 6;

                        break;

                    case 6:
                        //툴 무게설정
                        Thread.Sleep(200);

                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq6, robot_tcp_payload_set(robotID, RobotControlParameter_ToolWeight)");
                        caRetVal = clinkCs.robot_tcp_payload_set(robotID, RobotControlParameter_ToolWeight);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "툴무게 설정 완료");
                            RobotControlThreadSeq = 7;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "툴무게 설정 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }
                        break;

                    case 7:
                        //툴 무게중심설정
                        Thread.Sleep(200);

                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq7, robot_tcp_center_of_mass_set()");
                        caRetVal = clinkCs.robot_tcp_center_of_mass_set(robotID, RobotControlParameter_ToolMassCenterX, RobotControlParameter_ToolMassCenterY, RobotControlParameter_ToolMassCenterZ);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "툴 무게중심 설정 완료");
                            RobotControlThreadSeq = 8;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "툴 무게중심 설정 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }

                        break;

                    case 8:
                        //로봇 설치정보 설정
                        Thread.Sleep(400);
                        caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_NO_SUPPORT;

                        if (RobotControlParameter_MountType == 0)
                        {
                            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq8, robot_installation_mount_set(CLINK_INSTALLATION_MOUNT_FLOOR)");
                            caRetVal = clinkCs.robot_installation_mount_set(robotID, CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_FLOOR, RobotControlParameter_MountAngleRx, RobotControlParameter_MountAngleRy);
                        }
                        else if (RobotControlParameter_MountType == 1)
                        {
                            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq8, robot_installation_mount_set(CLINK_INSTALLATION_MOUNT_WALL)");
                            caRetVal = clinkCs.robot_installation_mount_set(robotID, CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_WALL, RobotControlParameter_MountAngleRx, RobotControlParameter_MountAngleRy);
                        }
                        else if (RobotControlParameter_MountType == 2)
                        {
                            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq8, robot_installation_mount_set(CLINK_INSTALLATION_MOUNT_CEILING)");
                            caRetVal = clinkCs.robot_installation_mount_set(robotID, CLINK_INSTALLATION_MOUNT.CLINK_INSTALLATION_MOUNT_CEILING, RobotControlParameter_MountAngleRx, RobotControlParameter_MountAngleRy);
                        }

                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "설치정보 설정 완료");
                            RobotControlThreadSeq = 9;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "설치정보 설정 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }

                        break;

                    case 9:
                        //로봇 TCP 설정
                        Thread.Sleep(200);

                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq9, robot_tcp_from_flange_set()");
                        caRetVal = clinkCs.robot_tcp_from_flange_set(robotID, RobotControlParameter_TCP[0], RobotControlParameter_TCP[1], RobotControlParameter_TCP[2], RobotControlParameter_TCP[3], RobotControlParameter_TCP[4], RobotControlParameter_TCP[5]);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "TCP 설정 완료");
                            RobotControlThreadSeq = 10;
                            TimeRecord = DateTime.Now;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "TCP 설정 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }

                        break;

                    case 10:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 300)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 11;
                        }

                        break;

                    case 11:
                        //로봇 툴전원설정


                        Thread.Sleep(300);

                        float tempf = 0;
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq12, robot_tool_power_voltage_current_get()");
                        caRetVal = clinkCs.robot_tool_power_voltage_current_get(robotID, out tempi, out tempf);
                        if (tempi != 1000054024)
                        {
                            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq12, robot_tool_power_voltage_set()");
                            caRetVal = clinkCs.robot_tool_power_voltage_set(robotID, CLINK_TOOL_IO_POWER_VOLTAGE_OPTION.CLINK_TOOL_POWER_VOLTAGE_OPTION_24, (char)0);
                            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "Tool IO 전원 출력 완료");
                                Thread.Sleep(200);
                                RobotControlThreadSeq = 12;
                            }
                            else
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "Tool IO 전원 출력 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                                RobotControlThreadSeq = -1;
                            }
                        }
                        else
                        {
                            RobotControlThreadSeq = 12;
                        }
                        
                        Thread.Sleep(100);
                        break;

                    case 12:
                        //로봇 서보온

                        Thread.Sleep(300);

                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq11, robot_servo_switch_set()");
                        caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if (BootingFlag == false)
                            {
                                //최초 서보온이면 서보 오프후 다시 서보온함
                                BootingFlag = true;
                                Thread.Sleep(500);
                                caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
                                Thread.Sleep(500);
                                caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
                            }
                            else
                            {
                                //최초 서보온이 아니면 대기상태로 
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "서보온 완료");
                                RobotControlThreadSeq = 15;
                            }
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "서보온 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }

                        break;

                    case 15:
                        //사용자 모션명령 대기

                        //조그모션명령 들어왔는지 체크
                        int tempint = 0;
                        for (int i = 0; i < 24; i++) tempint = tempint + RobotJogMotionCommand[i];
                        if (tempint > 0)
                        {
                            int resulti = RobotJogMotionRun();
                            if (resulti == 1)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "조그모션 실행");
                                RobotControlThreadSeq = 20;
                            }
                        }





                        break;

                    case 20:
                        //모션 완료 대기
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq20, robot_state_moving_get()");
                        caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if (tempi == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "모션 완료");
                                RobotControlThreadSeq = 15;
                            }
                            else if (tempi == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_STOPPED)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "모션 정지");
                                RobotControlThreadSeq = 15;
                            }
                        }

                        break;

                    case 40:
                        //서보 오프 수행
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq40, robot_servo_switch_set()");
                        caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "서보 오프 완료");
                            RobotControlThreadSeq = 41;
                            TimeRecord = DateTime.Now;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "서보 오프 실패 에러코드-" + Enum.GetName(typeof(CLINK_API_RESULT), caRetVal));
                            RobotControlThreadSeq = -1;
                        }

                        break;

                    case 41:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 500)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 2;
                        }

                        break;

                    case 50:
                        //직접교시 실행 중.. 완료 대기

                        break;



                    case 99:
                        //와이어 역인칭
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 400)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            Wire_IInching_Off();
                            RobotControlThreadSeq = 101;
                        }
                        break;



                    case 100:
                        //용접시퀀스 시작
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 시퀀스 시작");

                        //용접 시퀀스에 사용될 변수 초기화
                        WeldInitPosiCount = 0;
                        WeldEndPosiCount = 0;
                        WeldMainCount = 0;

                        TimeRecord = DateTime.Now;
                        if (WeldData.ArcOnFlag)
                        {
                            Wire_IInching_On();
                            RobotControlThreadSeq = 99;
                        }
                        else
                        {
                            RobotControlThreadSeq = 101;
                        }

                        break;

                    case 101:
                        //용접 접근경로 시작
                        if (WeldData.InitCondition.GetStartPositionCount() != 0)
                        {
                            //접근경로가 있으면
                            TempPose[0] = WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).f1;
                            TempPose[1] = WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).f2;
                            TempPose[2] = WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).f3;
                            TempPose[3] = WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).f4;
                            TempPose[4] = WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).f5;
                            TempPose[5] = WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).f6;
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접시작포즈 " + Convert.ToString(WeldInitPosiCount + 1) + "번째 접근시작");

                            if (WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).PoseType == 1)
                            {
                                if (1 != Move_Joint(TempPose, 20))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접시작포즈 " + Convert.ToString(WeldInitPosiCount + 1) + "번째 접근 실패.");
                                    RobotControlThreadSeq = 199;
                                }
                            }else if (WeldData.InitCondition.GetStartPosition(WeldInitPosiCount).PoseType == 2)
                            {
                                if (1 != Move_TCP(TempPose, 200))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접시작포즈 " + Convert.ToString(WeldInitPosiCount + 1) + "번째 접근 실패.");
                                    RobotControlThreadSeq = 199;
                                }
                            }
                            TimeRecord = DateTime.Now;
                            RobotControlThreadSeq = 102;
                        }
                        else
                        {//접근경로가 없으면 바로 용접단계로 넘어감
                            RobotControlThreadSeq = 105;
                        }
                        break;

                    case 102:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 103;
                        }

                        break;

                    case 103:
                        //WeldInitPosiCount 번째 용접 접근 완료 대기
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq103, robot_state_moving_get()");
                        caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if (tempi == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접시작포즈 " + Convert.ToString(WeldInitPosiCount + 1) + "번째 접근완료");
                                WeldInitPosiCount++;
                                if (WeldInitPosiCount < WeldData.InitCondition.GetStartPositionCount())
                                {//아직 이동할 경로가 더 남아있다면 시퀀스 101로 돌아감
                                    RobotControlThreadSeq = 101;
                                }
                                else
                                {//전부 이동했으면 시퀀스 104로 진행
                                    RobotControlThreadSeq = 104;
                                    TimeRecord = DateTime.Now;
                                }

                            }
                        }
                        break;

                    case 104:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 105;
                        }
                        break;

                    case 105:
                        //용접 시작위치로 이동
                        RobotPoseData temppose = WeldData.GetMainCondition(0).GetStartPose();
                        TempPose[0] = temppose.f1;
                        TempPose[1] = temppose.f2;
                        TempPose[2] = temppose.f3;
                        TempPose[3] = temppose.f4;
                        TempPose[4] = temppose.f5;
                        TempPose[5] = temppose.f6;
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 시작위치로 이동 시작");

                        if (1 != Move_TCP(TempPose, 200))
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 시작위치로 이동 실패.");
                            RobotControlThreadSeq = 199;
                        }
                        TimeRecord = DateTime.Now;
                        RobotControlThreadSeq = 106;
                        break;

                    case 106:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 107;
                            TimeRecord = DateTime.Now;
                        }
                        break;

                    case 107:
                        //용접 시작점 이동 완료 대기
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq107, robot_state_moving_get()");
                        caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if (tempi == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 시작위치 이동 완료");
                                RobotControlThreadSeq = 108;
                            }
                        }
                        break;

                    case 108:
                        //가스 토출 시작
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "보호가스 선토출 시작");

                        Gas_On();
                        TimeRecord = DateTime.Now;
                        RobotControlThreadSeq = 109;

                        break;

                    case 109:
                        //가스토출 완료 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > (int)(WeldData.InitCondition.GasPreTime * 1000))
                        {   //지정된 시간 이상 가스를 토출했으면 다음으로 넘어감
                            RobotControlThreadSeq = 110;
                        }
                        break;

                    case 110:
                        //초기아크 시작
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "초기 아크 시작");

                        //용접경로 저장변수 초기화
                        WeldingPathRecord.Clear();
                        WeldingSinglePath = new ActualWeldingPathRecord();

                        if (WeldData.ArcOnFlag)
                        {
                            Arc_On((float)WeldData.InitCondition.WeldStartVol, (float)WeldData.InitCondition.WeldStartAmp);
                        }

                        TimeRecord = DateTime.Now;
                        RobotControlThreadSeq = 111;

                        break;

                    case 111:
                        //초기 아크시간 완료 대기
                        InitArcDetect.Insert(0,RobotMonitoringData.moni_RobotIOValueAI[0]);
                        if (InitArcDetect.Count > 100) InitArcDetect.Remove(100);

                         tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > (int)(WeldData.InitCondition.WeldStartTime * 1000))
                        {   //지정된 시간 이상 아크를 튀겼으면 다음으로 넘어감

                            //if (WeldData.ArcOnFlag)
                            //{//아크온 설정일때 초기아크 켜졌는지 검사
                            //    double tempd = 0;
                            //    for (int i = 0; i < 25; i++) tempd = tempd + InitArcDetect[i];
                            //    tempd = tempd / 25;

                            //    if (tempd > 1)
                            //    {//초기아크시간동안 아크가 제대로 켜졋다면
                            //        RobotControlThreadSeq = 112;
                            //    }
                            //    else
                            //    {//아크가 발생하지 않으면 아크 끄고 용접시퀀스 종료
                            //        Arc_Off(); //용접모션을 실행 할 수 없으면 아크 끔
                            //        RobotControlThreadSeq = 125;
                            //    }
                            //}
                            //else
                            //{//아크온이 아니라면 용접모션으로 진행
                            //    RobotControlThreadSeq = 112;
                            //}

                            RobotControlThreadSeq = 112;
                        }
                        break;

                    case 112:
                        //WeldMainCount 번째 용접 수행
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + Convert.ToString(WeldMainCount + 1) + "번째 용접 시작");

                        //Move_TCP(WeldData.MainCondition[WeldMainCount].PathEndPosition.tofloat(), 200);

                        if (WeldData.ArcOnFlag)
                        {
                            Arc_On((float)WeldData.GetMainCondition(WeldMainCount).WelVol, (float)WeldData.GetMainCondition(WeldMainCount).WeldAmp);
                        }

                        if (1 == Welding_Move_TCP(WeldData.GetMainCondition(WeldMainCount).GetMidPose().ToPoseArray(), WeldData.GetMainCondition(WeldMainCount).GetEndPose().ToPoseArray(),
                                            (float)(WeldData.GetMainCondition(WeldMainCount).WeldSpd / 6), WeldData.GetMainCondition(WeldMainCount).PathType,
                                            WeldData.GetMainCondition(WeldMainCount).Weaving, (float)WeldData.GetMainCondition(WeldMainCount).WeavLength,
                                            (float)WeldData.GetMainCondition(WeldMainCount).WeavHz, (float)WeldData.GetMainCondition(WeldMainCount).WeavLeftStopTime,
                                            (float)WeldData.GetMainCondition(WeldMainCount).WeavRightStopTime, WeldData.GetMainCondition(WeldMainCount).ArcSen,
                                            (float)WeldData.GetMainCondition(WeldMainCount).ArcSenHFactor, (float)WeldData.GetMainCondition(WeldMainCount).ArcSenVFactor,
                                            (float)WeldData.GetMainCondition(WeldMainCount).ArcSenHMaxdL, (float)WeldData.GetMainCondition(WeldMainCount).ArcSenVMaxdL,
                                            (float)WeldData.GetMainCondition(WeldMainCount).ArcSenHOncedL, (float)WeldData.GetMainCondition(WeldMainCount).ArcSenVOncedL,
                                            (float)WeldData.GetMainCondition(WeldMainCount).ArcSenWeightedFactorLeft, (float)WeldData.GetMainCondition(WeldMainCount).ArcSenWeightedFactorRight, 
                                            (float)WeldData.GetMainCondition(WeldMainCount).ArcSenTimeShift))
                        {
                            TimeRecord = DateTime.Now;
                            RobotControlThreadSeq = 113;

                            MotionCompleteCheckStart(motionCmdID_Weld);
                        }
                        else
                        {
                            Arc_Off(); //용접모션을 실행 할 수 없으면 아크 끔
                            RobotControlThreadSeq = 125;
                        }

                        //용접 시작점, 시작시간 저장
                        WeldingSinglePath.StartPose = new RobotPoseData(2, 100, RobotMonitoringData.moni_RobotTCPActualPose[0], RobotMonitoringData.moni_RobotTCPActualPose[1], 
                                                                                RobotMonitoringData.moni_RobotTCPActualPose[2], RobotMonitoringData.moni_RobotTCPActualPose[3], 
                                                                                RobotMonitoringData.moni_RobotTCPActualPose[4], RobotMonitoringData.moni_RobotTCPActualPose[5]);
                        WeldingSinglePath.StartTime = DateTime.Now;

                        break;

                    case 113:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 114;
                        }

                        break;

                    case 114:
                        //WeldMainCount 번째 용접완료 대기

                        if (MotionCompleteCheck())
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접시작포즈 " + Convert.ToString(WeldMainCount + 1) + "번째 용접 완료");
                            WeldMainCount++;
                            if (WeldMainCount < WeldData.GetMainConditionCount())
                            {//용접패스가 더 남아있다면 일정시간 대기 후 다음용접 실행

                                if (WeldData.ArcOnFlag)
                                {
                                    Arc_On((float)8, (float)60);
                                    //Arc_Off();
                                }


                                RobotControlThreadSeq = 115;
                                TimeRecord = DateTime.Now;
                            }
                            else
                            {//전부 용접했으면 시퀀스 115로 진행
                                RobotControlThreadSeq = 116;
                                TimeRecord = DateTime.Now;
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "크레이터 용접 시작");


                                if (WeldData.ArcOnFlag)
                                {
                                    Arc_On((float)WeldData.EndCondition.WeldEndVol, (float)WeldData.EndCondition.WeldEndAmp);
                                }


                            }
                            
                            //용접 종료점, 종료시간 저장
                            WeldingSinglePath.EndPose = new RobotPoseData(2, 100, RobotMonitoringData.moni_RobotTCPActualPose[0], RobotMonitoringData.moni_RobotTCPActualPose[1],
                                                                                    RobotMonitoringData.moni_RobotTCPActualPose[2], RobotMonitoringData.moni_RobotTCPActualPose[3],
                                                                                    RobotMonitoringData.moni_RobotTCPActualPose[4], RobotMonitoringData.moni_RobotTCPActualPose[5]);
                            WeldingSinglePath.EndTime = DateTime.Now;
                            WeldingPathRecord.Add((ActualWeldingPathRecord)WeldingSinglePath.Clone());
                            WeldingSinglePath = new ActualWeldingPathRecord();
                        }
                        else
                        {   //용접중인 경우 1초에 한번씩 중간경로 저장
                            if((DateTime.Now.Ticks/10000000) != (MidPathLastRecordTime.Ticks / 10000000) )
                            {
                                //이전에 저장했던 시간에서 1초 지난경우 다시 경로저장
                                tempPositionRecord = new RobotPositionRecordData();
                                tempPositionRecord.RecordTime = DateTime.Now;
                                tempPositionRecord.ActualPosition = new RobotPoseData(2, 100, RobotMonitoringData.moni_RobotTCPActualPose[0], RobotMonitoringData.moni_RobotTCPActualPose[1],
                                                                                    RobotMonitoringData.moni_RobotTCPActualPose[2], RobotMonitoringData.moni_RobotTCPActualPose[3],
                                                                                    RobotMonitoringData.moni_RobotTCPActualPose[4], RobotMonitoringData.moni_RobotTCPActualPose[5]);
                                if(Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz-1)<=0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal1Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 1.5) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal1_5Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 2) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal2Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 2.5) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal2_5Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 3) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal3Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 3.5) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal3_5Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 4) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal4Hz.Clone();
                                }
                                else if (Math.Abs((float)WeldData.GetMainCondition(WeldMainCount).WeavHz - 4.5) <= 0.25)
                                {
                                    tempPositionRecord.WeavingMiddlePosition = (RobotPoseData)CenterCal4_5Hz.Clone();
                                }
                                WeldingSinglePath.MidPath.Add((RobotPositionRecordData)tempPositionRecord.Clone());
                                MidPathLastRecordTime = DateTime.Now;
                            }

                        }


                        break;

                    case 115:
                        //다음 용접라인이 있을 경우 일정시간 대기 후 다음라인 실행
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 150)
                        {   //지정된 시간 이상 경과하면 아크 끄고 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 112;
                        }

                        break;

                    case 116:
                        //크레이터 시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > (int)(WeldData.EndCondition.WeldEndTime * 1000))
                        {   //지정된 시간 이상 경과하면 아크 끄고 다음 시퀀스로 넘어감
                            //아크 끔
                            Arc_Off();
                            RobotControlThreadSeq = 117;
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "크레이터 용접 종료");
                        }

                        break;

                    case 117:
                        //토치방향 Z-로 일정거리 후진
                        if(1!=RobotToolBackMotionRun((float)WeldData.EndCondition.WeldEndLength))
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "일정거리 후진 실패");
                            RobotControlThreadSeq = 199;
                        }
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "일정거리 후진");

                        RobotControlThreadSeq = 118;
                        TimeRecord = DateTime.Now;

                        break;

                    case 118:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 119;
                        }

                        break;

                    case 119:
                        //후진 완료 대기
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq119, robot_state_moving_get()");
                        caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if (tempi == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "가스 후출 대기");
                                RobotControlThreadSeq = 120;
                            }
                        }

                        break;

                    case 120:
                        //가스 후출시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldData.EndCondition.GasPostTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            Gas_Off();
                            RobotControlThreadSeq = 121;
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "가스 후출 완료");
                        }

                        break;

                    case 121:

                        if (WeldData.EndCondition.GetEndPositionCount() != 0)
                        {
                            //용접 종료경로 실행
                            TempPose[0] = WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).f1;
                            TempPose[1] = WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).f2;
                            TempPose[2] = WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).f3;
                            TempPose[3] = WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).f4;
                            TempPose[4] = WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).f5;
                            TempPose[5] = WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).f6;
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접종료포즈 " + Convert.ToString(WeldEndPosiCount + 1) + "번째 접근시작");

                            if (WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).PoseType == 1)
                            {
                                if (1 != Move_Joint(TempPose, 20))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접종료포즈 이동 실패.");
                                    RobotControlThreadSeq = 199;
                                }
                            }else if (WeldData.EndCondition.GetEndPosition(WeldEndPosiCount).PoseType == 2)
                            {
                                if (1 != Move_TCP(TempPose, 200))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접종료포즈 이동 실패.");
                                    RobotControlThreadSeq = 199;
                                }
                            }
                            TimeRecord = DateTime.Now;
                            RobotControlThreadSeq = 122;
                        }
                        else
                        {
                            RobotControlThreadSeq = 124;
                        }
                        break;

                    case 122:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 123;
                        }

                        break;

                    case 123:
                        //WeldEndPosiCount 번째 용접 종료위치 완료 대기
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq123, robot_state_moving_get()");
                        caRetVal = clinkCs.robot_state_moving_get(robotID, out tempi);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            if (tempi == (int)CLINK_ROBOT_MOVING_STATE.CLINK_ROBOT_MOVING_STATE_IDLE)
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접종료포즈 " + Convert.ToString(WeldEndPosiCount + 1) + "번째 접근완료");
                                WeldEndPosiCount++;
                                if (WeldEndPosiCount < WeldData.EndCondition.GetEndPositionCount())
                                {//아직 이동할 경로가 더 남아있다면 시퀀스 101로 돌아감
                                    RobotControlThreadSeq = 121;
                                }
                                else
                                {//전부 이동했으면 시퀀스 124로 진행
                                    RobotControlThreadSeq = 124;
                                    TimeRecord = DateTime.Now;
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 완료");
                                }

                            }
                        }
                        break;

                    case 124:
                        //용접 종료. 상위에서 시퀸스를 15로 바꿔주거나 또는 일정시간 후 자동으로 바뀜
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000) RobotControlThreadSeq = 15;

                        break;

                    case 125:
                        //용접 수행중 모션 안나옴 에러 발생

                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접 경로 이상. 용접 정지");
                        Arc_Off();
                        RobotControlThreadSeq = 199;

                        break;

                    case 199:
                        //용접시퀀스 수행 중 에러발생. 상위에서 체크하고 시퀸스를 15로 바꿔주거나 또는 일정시간 후 자동으로 바뀜
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000) RobotControlThreadSeq = 15;


                        break;

                    case 200:
                        //터치센싱시퀀스 시작
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "터치센싱 시퀀스 시작");
                        TouchCount = 0;
                        RobotControlThreadSeq = 201;
                        break;

                    case 201:
                        //터치센서 켬
                        TouchSensing_On();
                        TimeRecord = DateTime.Now;
                        RobotControlThreadSeq = 202;
                        break;

                    case 202:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > WeldInitPosiWaitTime)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 203;
                        }

                        break;

                    case 203:
                        //터치센서 신호가 들어오는지 체크. 처음부터 들어오면 오류임
                        if (TouchSensingCheck()==1)
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "터치센싱 시작 에러. 처음부터 신호 들어옴");
                            //RobotControlThreadSeq = 290;
                            RobotControlThreadSeq = 204;
                        }
                        else
                        {
                            RobotControlThreadSeq = 204;
                        }
                        break;


                    case 204:
                        //TouchCount번째 터치 무브 시작
                        if (TouchData.Count != 0)
                        {
                            TouchMoveLimitCheck(TouchData[TouchCount]);

                            if(1!=Move_Dir(TouchData[TouchCount].In_Length, TouchData[TouchCount].In_Speed, TouchData[TouchCount].In_coord, TouchData[TouchCount].In_X, TouchData[TouchCount].In_Y, TouchData[TouchCount].In_Z))
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치센싱 시작 에러. 모션실행 실패");
                                RobotControlThreadSeq = 290;
                            }
                            else
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치센싱 모션 시작");
                                MotionCompleteCheckStart(motionCmdID_TCP);
                                TimeRecord = DateTime.Now;
                                RobotControlThreadSeq = 205;
                            }
                        }
                        break;

                    case 205:
                        //신호 들어오는지 체크함
                        if (TouchSensingCheck() == 1)
                        {
                            //신호가 들어오면 로봇을 멈추고 현재 위치 읽음
                            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotControlThreadFuc() seq205, robot_stop()");
                            caRetVal = clinkCs.robot_stop(robotID, 0.05f);
                            RobotPoseData tempPose = new RobotPoseData();
                            Cur_position(out tempPose.f1, out tempPose.f2, out tempPose.f3, out tempPose.f4, out tempPose.f5, out tempPose.f6);
                            TouchPosition.Add(tempPose);
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치 성공");

                            TimeRecord = DateTime.Now;
                            RobotControlThreadSeq = 206;
                        }
                        else if(MotionCompleteCheck())
                        {
                            //신호가 들어오지 않고 모션이 종료되면
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치실패. 모션 완료될 때 까지 감지 안됨");
                            RobotControlThreadSeq = 290;
                        }else if(((int)(DateTime.Now - TimeRecord).Ticks / 10000)>60000)
                        {
                            //15초 이상 모션도 종료 안되고 감지신호도 안들어오면
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치실패. 일정시간 이상 감지 안됨");
                            RobotControlThreadSeq = 290;
                        }

                        break;

                    case 206:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 500)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 207;
                        }
                        break;

                    case 207:
                        //반대방향 복귀
                        if (1 != Move_Dir(TouchData[TouchCount].Out_Length, TouchData[TouchCount].Out_Speed, TouchData[TouchCount].Out_coord, TouchData[TouchCount].Out_X, TouchData[TouchCount].Out_Y, TouchData[TouchCount].Out_Z))
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치센싱 복귀 에러. 모션실행 실패");
                            RobotControlThreadSeq = 290;
                        }
                        else
                        {
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치센싱 복귀모션 시작");
                            MotionCompleteCheckStart(motionCmdID_TCP);
                            TimeRecord = DateTime.Now;
                            RobotControlThreadSeq = 208;
                        }

                        break;

                    case 208:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 100)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 209;
                        }
                        break;

                    case 209:
                        //백 모션 종료되고 다음 터치데이터가 있는 경우 다음터치 실행. 없는경우 터치완료 단계로 넘어감
                        if (MotionCompleteCheck())
                        {

                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (TouchCount + 1).ToString() + "번째 터치센싱 완료");

                            TouchCount++;
                            if (TouchCount < TouchData.Count)
                            {//아직 이동할 경로가 더 남아있다면 시퀀스 204로 돌아감
                                RobotControlThreadSeq = 204;
                            }
                            else
                            {//전부 이동했으면 시퀀스 124로 진행
                                RobotControlThreadSeq = 280;
                                TimeRecord = DateTime.Now;
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "터치센싱 종료");
                                TouchSensing_Off();
                            }

                        }

                        break;

                    case 280:
                        //터치센싱 성공 대기. 상위에서 시퀸스를 15로 바꿔주거나 또는 일정시간 후 자동으로 바뀜
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000) RobotControlThreadSeq = 15;

                        break;

                    case 290:
                        //터치센싱 실패
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "터치센싱 실패");
                        TimeRecord = DateTime.Now;
                        RobotControlThreadSeq = 291;
                        break;

                    case 291:
                        //터치센싱 실패 대기. 상위에서 시퀸스를 15로 바꿔주거나 또는 일정시간 후 자동으로 바뀜
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000)RobotControlThreadSeq = 15;
                        break;

                    case 300:
                        //로봇 연속이동 시퀸스 시작
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "로봇 연속이동 시퀀스 시작");
                        RobotMoveCount = 0;
                        RobotControlThreadSeq = 301;
                        break;

                    case 301:
                        //로봇 연속이동 시퀸스 시작
                        if (RobotPoseArray.Count != 0)
                        {
                            if (RobotPoseArray[RobotMoveCount].PoseType == 1)
                            {
                                if (1 != Move_Joint(RobotPoseArray[RobotMoveCount].ToPoseArray(), RobotPoseArray[RobotMoveCount].Speed))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패");
                                    RobotControlThreadSeq = 309;
                                }
                                else
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 시작");
                                    RobotControlThreadSeq = 302;
                                    MotionCompleteCheckStart(motionCmdID_Jog);
                                    TimeRecord = DateTime.Now;
                                }
                            }
                            else if (RobotPoseArray[RobotMoveCount].PoseType == 2)
                            {
                                if (1 != Move_TCP(RobotPoseArray[RobotMoveCount].ToPoseArray(), RobotPoseArray[RobotMoveCount].Speed))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패");
                                    RobotControlThreadSeq = 309;
                                }
                                else
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 시작");
                                    RobotControlThreadSeq = 302;
                                    MotionCompleteCheckStart(motionCmdID_TCP);
                                    TimeRecord = DateTime.Now;
                                }
                            }
                            else if (RobotPoseArray[RobotMoveCount].PoseType == 3)
                            {
                                double tempd = RobotPoseArray[RobotMoveCount].f1 * RobotPoseArray[RobotMoveCount].f1 + RobotPoseArray[RobotMoveCount].f2 * RobotPoseArray[RobotMoveCount].f2 + RobotPoseArray[RobotMoveCount].f3 * RobotPoseArray[RobotMoveCount].f3;
                                double templength = Math.Sqrt(tempd);

                                if (1 != Move_Dir((float)templength, RobotPoseArray[RobotMoveCount].Speed, 1, RobotPoseArray[RobotMoveCount].f1, RobotPoseArray[RobotMoveCount].f2, RobotPoseArray[RobotMoveCount].f3)) 
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패");
                                    RobotControlThreadSeq = 309;
                                }
                                else
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 시작");
                                    RobotControlThreadSeq = 302;
                                    MotionCompleteCheckStart(motionCmdID_TCP);
                                    TimeRecord = DateTime.Now;
                                }
                            }
                            else if (RobotPoseArray[RobotMoveCount].PoseType == 4)
                            {
                                double tempd = RobotPoseArray[RobotMoveCount].f1 * RobotPoseArray[RobotMoveCount].f1 + RobotPoseArray[RobotMoveCount].f2 * RobotPoseArray[RobotMoveCount].f2 + RobotPoseArray[RobotMoveCount].f3 * RobotPoseArray[RobotMoveCount].f3;
                                double templength = Math.Sqrt(tempd);

                                if (1 != Move_Dir((float)templength, RobotPoseArray[RobotMoveCount].Speed, 2, RobotPoseArray[RobotMoveCount].f1, RobotPoseArray[RobotMoveCount].f2, RobotPoseArray[RobotMoveCount].f3)) 
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패");
                                    RobotControlThreadSeq = 309;
                                }
                                else
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 시작");
                                    RobotControlThreadSeq = 302;
                                    MotionCompleteCheckStart(motionCmdID_TCP);
                                    TimeRecord = DateTime.Now;
                                }
                            }
                            else if (RobotPoseArray[RobotMoveCount].PoseType == 5)
                            {
                                if (1 != Move_Rotation(RobotPoseArray[RobotMoveCount].Speed, RobotPoseArray[RobotMoveCount].f4, RobotPoseArray[RobotMoveCount].f5, RobotPoseArray[RobotMoveCount].f6))
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패");
                                    RobotControlThreadSeq = 309;
                                }
                                else
                                {
                                    RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 시작");
                                    RobotControlThreadSeq = 302;
                                    MotionCompleteCheckStart(motionCmdID_TCP);
                                    TimeRecord = DateTime.Now;
                                }
                            }
                            else
                            {
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패. 잘못된 포즈타입");
                                RobotControlThreadSeq = 309;
                            }

                        }

                        break;

                    case 302:
                        //일정시간 대기
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 200)
                        {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                            RobotControlThreadSeq = 303;
                            TimeRecord = DateTime.Now;
                        }
                        break;

                    case 303:
                        //로봇모션 완료 대기
                        if (MotionCompleteCheck())
                        {

                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 완료");

                            RobotMoveCount++;
                            if (RobotMoveCount < RobotPoseArray.Count)
                            {//아직 이동할 경로가 더 남아있다면 시퀀스 301로 돌아감
                                RobotControlThreadSeq = 301;
                            }
                            else
                            {//전부 이동했으면 시퀀스 311로 진행
                                RobotControlThreadSeq = 311;
                                TimeRecord = DateTime.Now;
                                RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "연속이동 종료");
                            }

                        }
                        else if (((int)(DateTime.Now - TimeRecord).Ticks / 10000) > 30000)
                        {
                            //30초 이상 모션도 종료 신호가 들어오지 않으면
                            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + (RobotMoveCount + 1).ToString() + "번째 연속이동 실패. 일정시간 이상 종료 안됨");
                            RobotControlThreadSeq = 309;
                        }

                        break;

                    case 309:
                        //연속이동 실패
                        TimeRecord = DateTime.Now;
                        RobotControlThreadSeq = 310;
                        break;

                    case 310:
                        //연속이동 실패 대기. 상위에서 시퀸스를 15로 바꿔주거나 또는 일정시간 후 자동으로 바뀜
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000) RobotControlThreadSeq = 15;
                        break;

                    case 311:
                        //연속이동 성공 대기. 상위에서 시퀸스를 15로 바꿔주거나 또는 일정시간 후 자동으로 바뀜
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000) RobotControlThreadSeq = 15;
                        break;

                    case 1000:
                        //비상정지 
                        //caRetVal = clinkCs.robot_emergency_stop(robotID, 0.1F);
                        //caRetVal = clinkCs.robot_servo_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
                        //if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        //{
                        //}
                        
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "비상정지 발생");
                        RobotControlThreadSeq = 1099;
                        TimeRecord = DateTime.Now;
                        break;

                    case 1001:
                        //충돌감지 
                        ErrorState_Coll = true;
                        ErrorTime_Coll = DateTime.Now;
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "충돌 발생");
                        RobotControlThreadSeq = 1099;
                        TimeRecord = DateTime.Now;
                        break;

                    case 1002:
                        //안전설정 위반
                        ErrorState_Safety = true;
                        ErrorTime_Safety = DateTime.Now;
                        RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "세이프티 위반");
                        RobotControlThreadSeq = 1099;
                        TimeRecord = DateTime.Now;
                        break;

                    case 1099:
                        //메인스레드에서 에러 감지 대기. 상태 인식하고 0으로 바꿔줘야 함
                        tempi = (int)(DateTime.Now - TimeRecord).Ticks / 10000;
                        if (tempi > 1000) RobotControlThreadSeq = 0;
                        break;

                    default:
                        break;

                }


                RobotDOSet();
                


                RobotControlThreadRunTime = DateTime.Now;
                
                //시퀀스 상태에 변화가 없으면 10ms 쉼
                //if ((RobotControlThreadSeqB == RobotControlThreadSeq) && (RobotControlThreadSeqB!=205))
                //{
                    Thread.Sleep(20);
                //}
                RobotControlThreadSeqB = RobotControlThreadSeq;
            }
        }

        //플래그 확인하고 로봇 출력 조작하는 부분
        void RobotDOSet()
        {
            if (RobotInitState != 100) return;


            uint u = 0;
            CLINK_API_RESULT caRetVal;

            for(int i=0; i<8; i++)
            {
                if(RobotBoxDOToggleFlag[i]==true)
                {
                    RobotBoxDOToggleFlag[i] = false;
                    u = (uint)((RobotMonitoringData.moni_RobotIOValueDO>>i) % 2);
                    if (u == 0)
                    {
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDOSet() Toggle0, control_box_io_digital_output_set()");
                        caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, (uint)i, 1);
                    }
                    else
                    {
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDOSet() Toggle1, control_box_io_digital_output_set()");
                        caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, (uint)i, 0);
                    }
                }

                if (RobotBoxDOOutFlag[i] == 0)
                {
                    RobotBoxDOOutFlag[i] = 2;
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDOSet() Out0, control_box_io_digital_output_set()");
                    caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, (uint)i, 0);
                }
                else if (RobotBoxDOOutFlag[i] == 1)
                {
                    RobotBoxDOOutFlag[i] = 2;
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotDOSet() Out1, control_box_io_digital_output_set()");
                    caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, (uint)i, 1);
                }
                else
                {
                    RobotBoxDOOutFlag[i] = 2;
                }
            }

        }


        //조그 명령에 따라 조깅모션 수행. 리턴 0:실행실패, 1:실행완료
        int RobotJogMotionRun()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;
            float MaxTCPLength = 20; // 20mm
            float MaxTCPVel = 200;  // 200mm/s
            float MaxTCPAngle = 5; // 5dgr
            float MaxTCPAngleVel = 20;  // 20dgr/s
            float MaxJointAngle = 5; // 5dgr
            float MaxJointVel = 20;  // 20dgr/s

            for (int i = 0; i < 6; i++)
            {
                if (RobotJogMotionCommand[i] == 1)
                {
                    //1~6축 마이너스 조그 지령일 때
                    
                    float Vel = MaxJointVel * ((float)RobotJogJointVel / 10);      // 최대 20deg/s 
                    float Angle = MaxJointAngle * ((float)RobotJogJointAngle / 10);// 최대 5도

                    float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
                    float[] NewJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };

                    //현재값 가져옴
                    for (uint count=0; count < 6; count++)
                    {
                        float f;
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 마이너스 축조그, robot_joint_angle_actual_get(robotID, count, out f), count="+count.ToString());
                        caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            NowJointAngle[count] = f;
                            NewJointAngle[count] = f;
                        }
                        else
                        {
                            return 0;
                        }
                    }

                    //종료위치 생성 및 리미트 체크
                    NewJointAngle[i] = NewJointAngle[i] - Angle;
                    if(RobotJointLimitCheck(NewJointAngle) != 1)
                    {//리미트 제한에 걸린다면
                        return 0;
                    }
                    
                    //조인트 모션 수행
                    int resulti = JointMotion_Run(NowJointAngle, NewJointAngle, Vel);
                    if (resulti == 0) return 0; //조인트무브 실행에 실패하면 0 리턴

                    return 1;

                }
            }


            for (int i = 0; i < 6; i++)
            {
                if (RobotJogMotionCommand[6+i] == 1)
                {
                    //1~6축 플러스 조그 지령일 때

                    float Vel = MaxJointVel * ((float)RobotJogJointVel / 10);      // 최대 20deg/s 
                    float Angle = MaxJointAngle * ((float)RobotJogJointAngle / 10);// 최대 5도

                    float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
                    float[] NewJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };

                    //현재값 가져옴
                    for (uint count = 0; count < 6; count++)
                    {
                        float f;
                        RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 플러스 축조그, robot_joint_angle_actual_get(robotID, count, out f), count=" + count.ToString());
                        caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                        if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                        {
                            NowJointAngle[count] = f;
                            NewJointAngle[count] = f;
                        }
                        else
                        {
                            return 0;
                        }
                    }

                    //종료위치 생성 및 리미트 체크
                    NewJointAngle[i] = NewJointAngle[i] + Angle;
                    if (RobotJointLimitCheck(NewJointAngle) != 1)
                    {//리미트 제한에 걸린다면
                        return 0;
                    }

                    //조인트 모션 수행
                    int resulti = JointMotion_Run(NowJointAngle, NewJointAngle, Vel);
                    if (resulti == 0) return 0; //조인트무브 실행에 실패하면 0 리턴

                    return 1;
                }
            }

            int Jogi = 0;
            for(int i=12; i<24; i++)
            {
                if (RobotJogMotionCommand[i] == 1) Jogi = i;
            }

            if ((Jogi == 12) || (Jogi == 13) || (Jogi == 14) || (Jogi == 18) || (Jogi == 19) || (Jogi == 20))
            {
                //TCP 직선이동 조깅일 때
                //선형보간 방식으로 이동함. 리미트체크는 수행

                float Vel = MaxTCPVel * ((float)RobotJogTCPVel / 10);      // 최대 200mm/s 
                float Length = MaxTCPLength * ((float)RobotJogTCPLength / 10);// 최대 5mm

                float[] NowJointActualAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
                //관절각도 현재값 가져옴
                for (uint count = 0; count < 6; count++)
                {
                    float f;
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 직교직선조그, robot_joint_angle_actual_get(robotID, count, out f), count=" + count.ToString());
                    caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        NowJointActualAngle[count] = f;
                    }
                    else
                    {
                        return 0;
                    }
                }

                float f1, f2, f3, f4, f5, f6;
                float[] NowTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
                float[] NewTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
                //TCP포즈 현재값 가져옴
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 직교직선조그, robot_tcp_pose_actual_get()");
                caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NowTCPActualPose, 0);
                    new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NewTCPActualPose, 0);
                }
                else
                {
                    return 0;
                }


                if (RobotJogTCPCoord == 1)//베이스좌표계 이동일 때
                {
                    //종료위치 계산
                    if (Jogi < 15)
                    {//마이너스 방향 일 때
                        NewTCPActualPose[Jogi - 12] = NewTCPActualPose[Jogi - 12] - Length;
                    }
                    else
                    {//플러스 방향 일 때
                        NewTCPActualPose[Jogi - 18] = NewTCPActualPose[Jogi - 18] + Length;
                    }
                }
                else if (RobotJogTCPCoord == 2)
                {//툴좌표계 이동일 때

                    float tempX, tempY, tempZ;
                    tempX = NewTCPActualPose[0];
                    tempY = NewTCPActualPose[1];
                    tempZ = NewTCPActualPose[2];

                    if (Jogi == 12)
                    {//Rx-방향
                        RobotToolTranslation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 1, -1 * Length, out tempX, out tempY, out tempZ);
                    }
                    else if (Jogi == 13)
                    {//Ry-방향
                        RobotToolTranslation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 2, -1 * Length, out tempX, out tempY, out tempZ);
                    }
                    else if (Jogi == 14)
                    {//Rz-방향
                        RobotToolTranslation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 3, -1 * Length, out tempX, out tempY, out tempZ);
                    }
                    else if (Jogi == 18)
                    {//Rx+방향
                        RobotToolTranslation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 1, Length, out tempX, out tempY, out tempZ);
                    }
                    else if (Jogi == 19)
                    {//Ry+방향
                        RobotToolTranslation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 2, Length, out tempX, out tempY, out tempZ);
                    }
                    else if (Jogi == 20)
                    {//Rz+방향
                        RobotToolTranslation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 3, Length, out tempX, out tempY, out tempZ);
                    }

                    NewTCPActualPose[0] = NewTCPActualPose[0]+tempX;
                    NewTCPActualPose[1] = NewTCPActualPose[1]+tempY;
                    NewTCPActualPose[2] = NewTCPActualPose[2]+tempZ;

                }

                //목표 TCP에 해당하는 조인트앵글 계산
                float[] rstAngle = new float[6];
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 직교직선조그, robot_joint_angle_from_tcp_pose_get()");
                caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, NewTCPActualPose[0], NewTCPActualPose[1], NewTCPActualPose[2], NewTCPActualPose[3], NewTCPActualPose[4], NewTCPActualPose[5], 6, NowJointActualAngle, rstAngle);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }


                //선형보간 종료지점이 관절 범위 안쪽인지 체크함
                if (RobotJointLimitCheck(rstAngle) != 1)
                {//리미트 제한에 걸린다면
                    return 0;
                }

                //3축 펼쳐짐 체크
                if ((-RobotControlParameter_JointAngle3TCPModeNotUse < rstAngle[2]) && (RobotControlParameter_JointAngle3TCPModeNotUse > rstAngle[2]))
                {
                    return 0;
                }

                //선형보간 이동
                int resulti = LinearMotion_Run(NowTCPActualPose, NowTCPActualPose, NewTCPActualPose, Vel, 1, 1);
                if (resulti == 0) return 0; //조인트무브 실행에 실패하면 0 리턴

                return 1;

            }
            else
            {
                //TCP 회전 조깅일 때
                //목표 포즈로 축좌표 얻어내서 조인트모션 방식으로 이동함. 리미트체크 수행

                float Vel = MaxTCPAngleVel * ((float)RobotJogTCPVel / 10);      // 최대 20dgr/s 
                float Ang = MaxTCPAngle * ((float)RobotJogTCPLength / 10);// 최대 5dgr

                float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
                //관절각도 현재값 가져옴
                for (uint count = 0; count < 6; count++)
                {
                    float f;
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 직교회전조그, robot_joint_angle_actual_get()");
                    caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                    if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        NowJointAngle[count] = f;
                    }
                    else
                    {
                        return 0;
                    }
                }

                float f1, f2, f3, f4, f5, f6;
                float[] NowTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
                //TCP포즈 현재값 가져옴
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 직교회전조그, robot_tcp_pose_actual_get()");
                caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NowTCPActualPose, 0);
                }
                else
                {
                    return 0;
                }

                //종료위치 계산

                if (RobotJogTCPCoord == 1)//베이스좌표계 이동일 때
                {
                    //if (Jogi < 18)
                    //{//마이너스 방향 일 때
                    //    NowTCPActualPose[Jogi - 12] = NowTCPActualPose[Jogi - 12] - Ang;
                    //}
                    //else
                    //{//플러스 방향 일 때
                    //    NowTCPActualPose[Jogi - 18] = NowTCPActualPose[Jogi - 18] + Ang;
                    //}


                    float tempRx, tempRy, tempRz;
                    tempRx = NowTCPActualPose[3];
                    tempRy = NowTCPActualPose[4];
                    tempRz = NowTCPActualPose[5];

                    if (Jogi == 15)
                    {//Rx-방향
                        RobotBaseRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 1, 0, 0, -1 * Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 16)
                    {//Ry-방향
                        RobotBaseRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 0, 1, 0, -1 * Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 17)
                    {//Rz-방향
                        RobotBaseRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 0, 0, 1, -1 * Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 21)
                    {//Rx+방향
                        RobotBaseRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 1, 0, 0, Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 22)
                    {//Ry+방향
                        RobotBaseRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 0, 1, 0, Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 23)
                    {//Rz+방향
                        RobotBaseRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 0, 0, 1, Ang, out tempRx, out tempRy, out tempRz);
                    }

                    NowTCPActualPose[3] = tempRx;
                    NowTCPActualPose[4] = tempRy;
                    NowTCPActualPose[5] = tempRz;

                }else if (RobotJogTCPCoord == 2)
                {//툴좌표계 이동일 때
                    float tempRx, tempRy, tempRz;
                    tempRx = NowTCPActualPose[3];
                    tempRy = NowTCPActualPose[4];
                    tempRz = NowTCPActualPose[5];

                    if (Jogi ==15)
                    {//Rx-방향
                        RobotToolRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 1, -1*Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 16)
                    {//Ry-방향
                        RobotToolRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 2, -1 * Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 17)
                    {//Rz-방향
                        RobotToolRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 3, -1 * Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 21)
                    {//Rx+방향
                        RobotToolRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 1, Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 22)
                    {//Ry+방향
                        RobotToolRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 2, Ang, out tempRx, out tempRy, out tempRz);
                    }
                    else if (Jogi == 23)
                    {//Rz+방향
                        RobotToolRotation(NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], 3, Ang, out tempRx, out tempRy, out tempRz);
                    }

                    NowTCPActualPose[3] = tempRx;
                    NowTCPActualPose[4] = tempRy;
                    NowTCPActualPose[5] = tempRz;
                }

                //목표 TCP에 해당하는 조인트앵글 계산
                float[] rstAngle = new float[NUM_OF_ROBOT_JOINTS];
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotJogMotionRun() 직교회전조그, robot_joint_angle_from_tcp_pose_get()");
                caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, NowTCPActualPose[0], NowTCPActualPose[1], NowTCPActualPose[2], NowTCPActualPose[3], NowTCPActualPose[4], NowTCPActualPose[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, rstAngle);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                //선형보간 종료지점이 관절 범위 안쪽인지 체크함
                if (RobotJointLimitCheck(rstAngle) != 1)
                {//리미트 제한에 걸린다면
                    return 0;
                }

                //조인트 모션 수행
                int resulti = JointMotion_Run(NowJointAngle, rstAngle, Vel);
                if (resulti == 1)
                {

                }
                else
                {
                    return 0; //조인트무브 실행에 실패하면 0 리턴
                }

                return 1;
            }

            

        }

        //조인트 리미트 검사. 리턴 1:정상구동범위임
        int RobotJointLimitCheck(float[] joint_angle)
        {
            //조인트 관절각이 관절 범위 안쪽인지 체크함
            bool tempb = true;
            if ((RobotControlParameter_JointAngle1Min > joint_angle[0]) || (RobotControlParameter_JointAngle1Max < joint_angle[0])) tempb = false;
            if ((RobotControlParameter_JointAngle2Min > joint_angle[1]) || (RobotControlParameter_JointAngle2Max < joint_angle[1])) tempb = false;
            if ((RobotControlParameter_JointAngle3Min > joint_angle[2]) || (RobotControlParameter_JointAngle3Max < joint_angle[2])) tempb = false;
            if ((RobotControlParameter_JointAngle4Min > joint_angle[3]) || (RobotControlParameter_JointAngle4Max < joint_angle[3])) tempb = false;
            if ((RobotControlParameter_JointAngle5Min > joint_angle[4]) || (RobotControlParameter_JointAngle5Max < joint_angle[4])) tempb = false;
            if ((RobotControlParameter_JointAngle6Min > joint_angle[5]) || (RobotControlParameter_JointAngle6Max < joint_angle[5])) tempb = false;
            if (tempb == false)
            { //특정축이 관절범위 벗어남. 조그 수행 안함.
                return 0;
            }

            return 1;
        }


        //로봇 조인트 모션 추가하고 실행함. 내부에서만 사용
        //입력 - 시작, 종료, 속도
        //리턴값 0:실행실패, 1:실행성공
        int JointMotion_Run(float[] start_joint_angle, float[] end_joint_angle, float vel)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            if (JointMotion_Add(start_joint_angle, end_joint_angle, vel) != 1)
            {
                return 0;
            }


            // 로봇 이동 명령
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Run(), motion_command_queue_flush()");
            caRetVal = clinkCs.motion_command_queue_flush();
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            return 1;


        }


        //로봇 조인트 모션 추가만함. 내부에서만 사용
        //입력 - 시작, 종료, 속도
        //리턴값 0:실행실패, 1:실행성공
        int JointMotion_Add(float[] start_joint_angle, float[] end_joint_angle, float vel)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //시작 위치 지정
            for (uint i = 0; i < 6; i++)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_robot_joint_angle_start_set()");
                caRetVal = clinkCs.motion_command_robot_joint_angle_start_set(motionCmdID_Jog, i, start_joint_angle[i]);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    ;
                }
                else
                {
                    return 0;
                }
            }

            //종료 위치 지정
            for (uint i = 0; i < 6; i++)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_robot_joint_angle_end_set()");
                caRetVal = clinkCs.motion_command_robot_joint_angle_end_set(motionCmdID_Jog, i, end_joint_angle[i]);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    ;
                }
                else
                {
                    return 0;
                }
            }



            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_speed_max_set()");
            caRetVal = clinkCs.motion_command_speed_max_set(motionCmdID_Jog, vel);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_acc_max_set()");
            caRetVal = clinkCs.motion_command_acc_max_set(motionCmdID_Jog, RobotControlParameter_JointAcc);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_dec_max_set()");
            caRetVal = clinkCs.motion_command_dec_max_set(motionCmdID_Jog, RobotControlParameter_JointDec);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_jerk_percentage_set()");
            caRetVal = clinkCs.motion_command_jerk_percentage_set(motionCmdID_Jog, RobotControlParameter_JointJerk);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // motion command queue에 명령 추가
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "JointMotion_Add(), motion_command_queue_add()");
            caRetVal = clinkCs.motion_command_queue_add(motionCmdID_Jog);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
            }
            else
            {
                return 0;
            }

            return 1;
        }



        //로봇 TCP모션 추가하고 실행함. 내부에서만 사용
        //입력 - 시작, 중간(원호보간에만 사용), 종료, 속도, 보간방식(1:직선, 2:내접원, 3:외접원, 4:구), 좌표계(1:base, 2:tool)
        //리턴값 0:실행실패, 1:실행성공
        int LinearMotion_Run(float[] start_pose, float[] mid_pose, float[] end_pose,float vel, int interp, int coord)
        {

            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            if(LinearMotion_Add(start_pose, mid_pose, end_pose, vel, interp, coord)!=1)
            {
                return 0;
            }

            // 로봇 이동 명령
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Run(), motion_command_queue_flush()");
            caRetVal = clinkCs.motion_command_queue_flush();
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            return 1;
        }


        //로봇 TCP모션 추가만함. 내부에서만 사용
        //입력 - 시작, 중간(원호보간에만 사용), 종료, 속도, 보간방식(1:직선, 2:내접원, 3:외접원, 4:구), 좌표계(1:base, 2:tool)
        //리턴값 0:실행실패, 1:실행성공
        int LinearMotion_Add(float[] start_pose, float[] mid_pose, float[] end_pose, float vel, int interp, int coord)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //시작포즈 지정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_position_start_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_position_start_set(motionCmdID_TCP, start_pose[0], start_pose[1], start_pose[2]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_orientation_start_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_start_set(motionCmdID_TCP, start_pose[3], start_pose[4], start_pose[5]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //중간포즈 지정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_position_mid_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_position_mid_set(motionCmdID_TCP, mid_pose[0], mid_pose[1], mid_pose[2]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //종료포즈 설정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_position_end_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_position_end_set(motionCmdID_TCP, end_pose[0], end_pose[1], end_pose[2]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_orientation_end_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_end_set(motionCmdID_TCP, end_pose[3], end_pose[4], end_pose[5]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //좌표계 선택
            if (coord == 1)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_coordination_set(CLINK_REF_COORDINATE_BASE)");
                caRetVal = clinkCs.motion_command_robot_tcp_coordination_set(motionCmdID_TCP, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_BASE);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }
            else if (coord == 2)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_coordination_set(CLINK_REF_COORDINATE_TCP)");
                caRetVal = clinkCs.motion_command_robot_tcp_coordination_set(motionCmdID_TCP, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_TCP);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }


            //보간방식 선택
            if (interp == 1)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_interpolator_set(CLINK_INTERPOLATOR_LINEAR)");
                caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_TCP, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_LINEAR);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }
            else if (interp == 2)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_interpolator_set(CLINK_INTERPOLATOR_CIRCULAR)");
                caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_TCP, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_CIRCULAR);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }
            else if (interp == 3)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_interpolator_set(CLINK_INTERPOLATOR_ARC)");
                caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_TCP, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_ARC);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }
            else if (interp == 4)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_robot_tcp_interpolator_set(CLINK_INTERPOLATOR_CIRCLE)");
                caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_TCP, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_CIRCLE);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }

            // MAX command speed
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_speed_max_set()");
            caRetVal = clinkCs.motion_command_speed_max_set(motionCmdID_TCP, vel);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // MAX accelaration
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_acc_max_set()");
            caRetVal = clinkCs.motion_command_acc_max_set(motionCmdID_TCP, RobotControlParameter_TCPAcc);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // MAX decelaration
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_dec_max_set()");
            caRetVal = clinkCs.motion_command_dec_max_set(motionCmdID_TCP, RobotControlParameter_TCPDec);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // Jerk percentage
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_jerk_percentage_set()");
            caRetVal = clinkCs.motion_command_jerk_percentage_set(motionCmdID_TCP, RobotControlParameter_TCPJerk);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            // motion command queue에 명령 추가
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "LinearMotion_Add(), motion_command_queue_add()");
            caRetVal = clinkCs.motion_command_queue_add(motionCmdID_TCP);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            return 1;

        }

        /// <summary>
        /// 외부에서 로봇 Joint 모션명령 내릴 때 쓰는 함수. 로봇컨트롤상태가 사용자명령대기(15) 일때만 작동함
        /// </summary>
        /// <param name="end_joint_angle">각 축 목표 각도</param>
        /// <param name="vel">각 축 속도. 단위 dgr/s, 최대 20</param>
        /// <returns>1:정상실행, 2:컨트롤시퀀스 상태가 명령대기가 아님, 3:목표가 구동범위를 벗어남 0:원인을 알수없는 실행실패</returns>
        public int RobotMove_Joint(float[] end_joint_angle, float vel)
        {
            if (RobotControlThreadSeq != 15) return 2;
            
            int res = Move_Joint(end_joint_angle, vel);

            if (res == 1)
            {
                RobotControlManualMoveFlag = true;
            }
            return res;
        }

        /// <summary>
        /// 로봇 Joint 모션명령 내릴 때 쓰는 함수.
        /// </summary>
        /// <param name="end_joint_angle">각 축 목표 각도</param>
        /// <param name="vel">각 축 속도. 단위 dgr/s, 최대 20</param>
        /// <returns>1:정상실행, 2:컨트롤시퀀스 상태가 명령대기가 아님, 3:목표가 구동범위를 벗어남 0:원인을 알수없는 실행실패</returns>
        int Move_Joint(float[] end_joint_angle, float vel)
        {
            //종료위치 리미트 체크
            if (RobotJointLimitCheck(end_joint_angle) != 1)
            {//리미트 제한에 걸린다면
                return 3;
            }


            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;
            float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };

            //현재값 가져옴
            for (uint count = 0; count < 6; count++)
            {
                float f;
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Move_Joint(), robot_joint_angle_actual_get() count="+count.ToString());
                caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    NowJointAngle[count] = f;
                }
                else
                {
                    return 0;
                }
            }

            //조인트 모션 수행
            int resulti = JointMotion_Run(NowJointAngle, end_joint_angle, vel);
            if (resulti == 1)
            {
            }
            else
            {
                return 0; //조인트무브 실행에 실패하면 0 리턴
            }

            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "Joint모션 실행");
            return 1;
        }

        /// <summary>
        /// 외부에서 로봇 TCP모션명령 내릴 때 쓰는 함수. 로봇컨트롤상태가 사용자명령대기(15) 일때만 Move_TCP 호출.
        /// </summary>
        /// <param name="end_TCP_Pose">TCP 목표 좌표</param>
        /// <param name="vel">TCP 선속도. 단위 mm/s, 최대 250</param>
        /// <returns>1:정상실행, 2:컨트롤시퀀스 상태가 명령대기가 아님, 3:목표가 구동범위를 벗어남 0:원인을 알수없는 실행실패</returns>
        public int RobotMove_TCP(float[] end_TCP_Pose, float vel)
        {
            if (RobotControlThreadSeq != 15) return 2;

            int res = Move_TCP(end_TCP_Pose, vel);

            if (res == 1)
            {
                RobotControlManualMoveFlag = true;
            }
            return res;
        }

        /// <summary>
        /// 로봇 TCP모션명령 내릴 때 쓰는 함수. 
        /// </summary>
        /// <param name="end_TCP_Pose">TCP 목표 좌표</param>
        /// <param name="vel">TCP 선속도. 단위 mm/s, 최대 250</param>
        /// <returns>1:정상실행, 2:컨트롤시퀀스 상태가 명령대기가 아님, 3:목표가 구동범위를 벗어남 0:원인을 알수없는 실행실패</returns>
        int Move_TCP(float[] end_TCP_Pose, float vel)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            float f1, f2, f3, f4, f5, f6;
            float[] NowTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            float[] NewTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            //TCP포즈 현재값 가져옴
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Move_TCP(), robot_tcp_pose_actual_get()");
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NowTCPActualPose, 0);
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NewTCPActualPose, 0);
            }
            else
            {
                return 0;
            }


            float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
            float[] NewJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };

            //현재값 가져옴
            for (uint count = 0; count < 6; count++)
            {
                float f;
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Move_TCP(), robot_joint_angle_actual_get() count="+count.ToString());
                caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    NowJointAngle[count] = f;
                }
                else
                {
                    return 0;
                }
            }

            //이동거리 계산
            double dx = end_TCP_Pose[0] - NowTCPActualPose[0];
            double dy = end_TCP_Pose[1] - NowTCPActualPose[1];
            double dz = end_TCP_Pose[2] - NowTCPActualPose[2];
            double MoveLength = Math.Sqrt(dx * dx + dy * dy + dz * dz);


            if (MoveLength > 200)
            {
                int Count = (int)((MoveLength / 200) + 1);
                float[] MidTCPPose = new float[6] { 0, 0, 0, 0, 0, 0 };
                float[] MidJointAngle1 = new float[6] { 0, 0, 0, 0, 0, 0 };
                float[] MidJointAngle2 = new float[6] { 0, 0, 0, 0, 0, 0 };
                MidJointAngle1[0] = NowJointAngle[0];
                MidJointAngle1[1] = NowJointAngle[1];
                MidJointAngle1[2] = NowJointAngle[2];
                MidJointAngle1[3] = NowJointAngle[3];
                MidJointAngle1[4] = NowJointAngle[4];
                MidJointAngle1[5] = NowJointAngle[5];

                for (int i = 1; i < Count + 1; i++)
                {
                    MidTCPPose[0] = NowTCPActualPose[0] + (end_TCP_Pose[0] - NowTCPActualPose[0]) * ((float)i / (float)Count);
                    MidTCPPose[1] = NowTCPActualPose[1] + (end_TCP_Pose[1] - NowTCPActualPose[1]) * ((float)i / (float)Count);
                    MidTCPPose[2] = NowTCPActualPose[2] + (end_TCP_Pose[2] - NowTCPActualPose[2]) * ((float)i / (float)Count);
                    MidTCPPose[3] = NowTCPActualPose[3] + (end_TCP_Pose[3] - NowTCPActualPose[3]) * ((float)i / (float)Count);
                    MidTCPPose[4] = NowTCPActualPose[4] + (end_TCP_Pose[4] - NowTCPActualPose[4]) * ((float)i / (float)Count);
                    MidTCPPose[5] = NowTCPActualPose[5] + (end_TCP_Pose[5] - NowTCPActualPose[5]) * ((float)i / (float)Count);

                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Move_TCP(), robot_joint_angle_from_tcp_pose_get()");
                    caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, MidTCPPose[0], MidTCPPose[1], MidTCPPose[2], MidTCPPose[3], MidTCPPose[4], MidTCPPose[5], NUM_OF_ROBOT_JOINTS, MidJointAngle1, MidJointAngle2);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }

                    MidJointAngle1[0] = MidJointAngle2[0];
                    MidJointAngle1[1] = MidJointAngle2[1];
                    MidJointAngle1[2] = MidJointAngle2[2];
                    MidJointAngle1[3] = MidJointAngle2[3];
                    MidJointAngle1[4] = MidJointAngle2[4];
                    MidJointAngle1[5] = MidJointAngle2[5];
                }

                NewJointAngle[0] = MidJointAngle2[0];
                NewJointAngle[1] = MidJointAngle2[1];
                NewJointAngle[2] = MidJointAngle2[2];
                NewJointAngle[3] = MidJointAngle2[3];
                NewJointAngle[4] = MidJointAngle2[4];
                NewJointAngle[5] = MidJointAngle2[5];
            }
            else
            {
                //목표 TCP에 해당하는 조인트앵글 계산
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Move_TCP(), robot_joint_angle_from_tcp_pose_get()");
                caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, end_TCP_Pose[0], end_TCP_Pose[1], end_TCP_Pose[2], end_TCP_Pose[3], end_TCP_Pose[4], end_TCP_Pose[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, NewJointAngle);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }

            //종료위치 리미트 체크
            if (RobotJointLimitCheck(NewJointAngle) != 1)
            {//리미트 제한에 걸린다면
                return 3;
            }

            //주어진 속도와 이동거리로 대략적인 이동시간 계산
            double dTime = MoveLength / vel;

            //최대 조인트 각도변화 계산
            double MaxJointAngleDelta = 0;
            for (int i = 0; i < 6; i++)
            {
                double tempd = Math.Abs(NewJointAngle[i] - NowJointAngle[i]);
                if (MaxJointAngleDelta < tempd) MaxJointAngleDelta = tempd;
            }

            //최대로 움직여야하는 조인트 각속도 계산
            double dJointAngleVel = MaxJointAngleDelta / dTime;


            if (MoveLength > 1.5)
            {
                //1.5mm 이상 이동하라는 명령 일 때

                float newvel;
                if (dJointAngleVel < 30)
                {
                    //각속도가 30dgr/s보다 작을 경우 지정된 속도로 선형모션 수행
                    newvel = vel;
                }
                else
                {
                    //각속도가 30dgr/s보다 클 경우 속도를 적절하게 낮추고 선형모션 수행
                    newvel = (float)(vel * (30 / dJointAngleVel));
                }

                //선형보간 이동
                int resulti = LinearMotion_Run(NowTCPActualPose, NowTCPActualPose, end_TCP_Pose, newvel, 1, 1);
                if (resulti == 1)
                {
                }
                else
                {
                    return 0; //조인트무브 실행에 실패하면 0 리턴
                }


            }
            else
            {
                //TCP 변화가 1.5mm 이내일 때 선형모션으로 구동하면 조인트쪽에 과도한 속도,가속도 걸림
                //일단 Tool Z방향으로 1.5mm 뒤로 뺀 뒤 다시 실행함

                if (dJointAngleVel < 30)
                {
                    //선형보간 이동
                    int resulti = LinearMotion_Run(NowTCPActualPose, NowTCPActualPose, end_TCP_Pose, vel, 1, 1);
                    if (resulti == 1)
                    {
                    }
                    else
                    {
                        return 0; //조인트무브 실행에 실패하면 0 리턴
                    }
                }
                else
                {
                    float tempX, tempY, tempZ;
                    tempX = NewTCPActualPose[0];
                    tempY = NewTCPActualPose[1];
                    tempZ = NewTCPActualPose[2];

                    RobotToolTranslation(NewTCPActualPose[3], NewTCPActualPose[4], NewTCPActualPose[5], 3, 5, out tempX, out tempY, out tempZ);

                    NewTCPActualPose[0] = NewTCPActualPose[0] + tempX;
                    NewTCPActualPose[1] = NewTCPActualPose[1] + tempY;
                    NewTCPActualPose[2] = NewTCPActualPose[2] + tempZ;


                    float[] rstAngle = new float[NUM_OF_ROBOT_JOINTS];
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Move_TCP(), robot_joint_angle_from_tcp_pose_get()");
                    caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, NewTCPActualPose[0], NewTCPActualPose[1], NewTCPActualPose[2], NewTCPActualPose[3], NewTCPActualPose[4], NewTCPActualPose[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, rstAngle);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }


                    //뒤로 빼는 모션 추가

                    if (JointMotion_Add(NowJointAngle, rstAngle, 10) != 1)
                    {
                        return 0;
                    }

                    float newvel;
                    //각속도가 30dgr/s보다 클 경우 속도를 적절하게 낮추고 선형모션 수행
                    newvel = (float)(vel * (30 / dJointAngleVel));

                    if (newvel < 0.01) newvel = 0.01f;


                    //회전모션 실행
                    int resulti = LinearMotion_Run(NewTCPActualPose, NewTCPActualPose, end_TCP_Pose, newvel, 1, 1);
                    if (resulti == 1)
                    {
                        
                    }
                    else
                    {
                        return 0; //조인트무브 실행에 실패하면 0 리턴
                    }
                }

            }

            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "TCP모션 실행");
            return 1;

        }


        public int RobotMove_Dir(float distance, float vel, int coord, float VectorX, float VectorY, float VectorZ)
        {
            if (RobotControlThreadSeq != 15) return 2;


            int res = Move_Dir(distance, vel, coord, VectorX, VectorY, VectorZ);

            if (res == 1)
            {
                RobotControlManualMoveFlag = true;
            }
            return res;

        }

        //각도 변화 없이 위치만 상대좌표로 이동하는 함수
        int Move_Dir(float distance, float vel, int coord, float VectorX, float VectorY, float VectorZ)
        {
            if (coord == 1)
            {//베이스 좌표계 방향일 때
                //지정된 벡터를 단위벡터로 변환하고 거리 곱함
                float dx, dy, dz;
                double tempf;
                tempf = Math.Sqrt(VectorX * VectorX + VectorY * VectorY + VectorZ * VectorZ);
                dx = (float)(distance * ((VectorX) / (tempf)));
                dy = (float)(distance * ((VectorY) / (tempf)));
                dz = (float)(distance * ((VectorZ) / (tempf)));

                float Pos_x, Pos_y, Pos_z, Ort_x, Ort_y, Ort_z;
                Cur_position(out Pos_x, out Pos_y, out Pos_z, out Ort_x, out Ort_y, out Ort_z);
                float[] move_point = { Pos_x + dx, Pos_y + dy, Pos_z + dz, Ort_x, Ort_y, Ort_z };

                return Move_TCP(move_point, vel);


            }
            else if (coord == 2)
            {//툴 좌표계 방향일 때

                float dTx, dTy, dTz;
                double tempf;
                tempf = Math.Sqrt(VectorX * VectorX + VectorY * VectorY + VectorZ * VectorZ);
                dTx = (float)(distance * ((VectorX) / (tempf)));
                dTy = (float)(distance * ((VectorY) / (tempf)));
                dTz = (float)(distance * ((VectorZ) / (tempf)));

                float Pos_x, Pos_y, Pos_z, Ort_x, Ort_y, Ort_z;
                Cur_position(out Pos_x, out Pos_y, out Pos_z, out Ort_x, out Ort_y, out Ort_z);

                double[] outMatrix;
                MakeXYZAngleToRMatrix(Ort_x, Ort_y, Ort_z, out outMatrix);

                float dx, dy, dz;

                dx = (float)(dTx * outMatrix[0] + dTy * outMatrix[1] + dTz * outMatrix[2]);
                dy = (float)(dTx * outMatrix[3] + dTy * outMatrix[4] + dTz * outMatrix[5]);
                dz = (float)(dTx * outMatrix[6] + dTy * outMatrix[7] + dTz * outMatrix[8]);

                float[] move_point = { Pos_x + dx, Pos_y + dy, Pos_z + dz, Ort_x, Ort_y, Ort_z };
                return Move_TCP(move_point, vel);

            }
            else
            {
                return 0;
            }


        }

        //TCP 위치변화 없이 로봇의 Rx, Ry, Rz만 변경하는 함수
        int Move_Rotation(float vel, float Rx, float Ry, float Rz)
        {
            float Pos_x, Pos_y, Pos_z, Ort_x, Ort_y, Ort_z;
            Cur_position(out Pos_x, out Pos_y, out Pos_z, out Ort_x, out Ort_y, out Ort_z);

            float[] move_point = { Pos_x, Pos_y, Pos_z, Rx, Ry, Rz };
            return Move_TCP(move_point, vel);

        }

        

        /// <summary>
        /// 용접모션 명령을 내릴 때 쓰는 함수. 
        /// </summary>
        /// <param name="mid_pose">TCP 중간 좌표(베이스 좌표계)</param>
        /// <param name="end_pose">TCP 목표 좌표(베이스 좌표계)</param>
        /// <param name="vel">TCP 선속도. 단위 mm/s, 최대 250</param>
        /// <param name="interp">보간 방식. 1:선형 2:원호</param>
        /// <param name="weav_type">위빙 타입. 0:위빙안함 1:지그재그 2:사인파</param>
        /// <param name="weav_width">위빙 폭</param>
        /// <param name="weav_freq">위빙 주파수</param>
        /// <param name="delay_left">좌 멈춤 시간</param>
        /// <param name="delay_right">우 멈춤 시간</param>
        /// <param name="arc_sensing_Hcoef">좌우 보정 계수</param>
        /// <param name="arc_sensing_Vcoef">상하 보정 계수</param>
        /// <param name="arc_sensing_limit">좌우 보정 1주기 상한치</param>
        /// <param name="arc_sensing_time_shift">아크 센싱 데이터 지연 값</param>
        /// <returns>1:정상실행, 0:원인을 알수없는 실행실패</returns>
        int Welding_Move_TCP(float[] mid_pose, float[] end_pose, float vel, int interp, int weav_type, float weav_width, float weav_freq,
            float delay_left, float delay_right, int arc_sensing, float arc_sensing_Hcoef, float arc_sensing_Vcoef, float arc_sensing_Hlimit, float arc_sensing_Vlimit,
            float arc_sensing_HOnce, float arc_sensing_VOnce, float arc_sensing_LWeightedFactor, float arc_sensing_RWeightedFactor, float arc_sensing_time_shift)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            float f1, f2, f3, f4, f5, f6;
            float[] NowTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            float[] NewTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            //TCP포즈 현재값 가져옴
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Welding_Move_TCP(), robot_tcp_pose_actual_get()");
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NowTCPActualPose, 0);
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NewTCPActualPose, 0);
            }
            else
            {
                return 0;
            }


            float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
            float[] NewJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };

            //현재값 가져옴
            for (uint count = 0; count < 6; count++)
            {
                float f;
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Welding_Move_TCP(), robot_joint_angle_actual_get() count="+count.ToString());
                caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    NowJointAngle[count] = f;
                }
                else
                {
                    return 0;
                }
            }
            
            //이동거리 계산
            double dx = end_pose[0] - NowTCPActualPose[0];
            double dy = end_pose[1] - NowTCPActualPose[1];
            double dz = end_pose[2] - NowTCPActualPose[2];
            double MoveLength = Math.Sqrt(dx * dx + dy * dy + dz * dz);


            //if (MoveLength > 200)
            //{
            //    int Count = (int)((MoveLength / 200) + 1);
            //    float[] MidTCPPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            //    float[] MidJointAngle1 = new float[6] { 0, 0, 0, 0, 0, 0 };
            //    float[] MidJointAngle2 = new float[6] { 0, 0, 0, 0, 0, 0 };
            //    MidJointAngle1[0] = NowJointAngle[0];
            //    MidJointAngle1[1] = NowJointAngle[1];
            //    MidJointAngle1[2] = NowJointAngle[2];
            //    MidJointAngle1[3] = NowJointAngle[3];
            //    MidJointAngle1[4] = NowJointAngle[4];
            //    MidJointAngle1[5] = NowJointAngle[5];

            //    for (int i = 1; i < Count + 1; i++)
            //    {
            //        MidTCPPose[0] = NowTCPActualPose[0] + (end_pose[0] - NowTCPActualPose[0]) * ((float)i / (float)Count);
            //        MidTCPPose[1] = NowTCPActualPose[1] + (end_pose[1] - NowTCPActualPose[1]) * ((float)i / (float)Count);
            //        MidTCPPose[2] = NowTCPActualPose[2] + (end_pose[2] - NowTCPActualPose[2]) * ((float)i / (float)Count);
            //        MidTCPPose[3] = NowTCPActualPose[3] + (end_pose[3] - NowTCPActualPose[3]) * ((float)i / (float)Count);
            //        MidTCPPose[4] = NowTCPActualPose[4] + (end_pose[4] - NowTCPActualPose[4]) * ((float)i / (float)Count);
            //        MidTCPPose[5] = NowTCPActualPose[5] + (end_pose[5] - NowTCPActualPose[5]) * ((float)i / (float)Count);

            //        caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, MidTCPPose[0], MidTCPPose[1], MidTCPPose[2], MidTCPPose[3], MidTCPPose[4], MidTCPPose[5], NUM_OF_ROBOT_JOINTS, MidJointAngle1, MidJointAngle2);
            //        if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //        {
            //            return 0;
            //        }

            //        MidJointAngle1[0] = MidJointAngle2[0];
            //        MidJointAngle1[1] = MidJointAngle2[1];
            //        MidJointAngle1[2] = MidJointAngle2[2];
            //        MidJointAngle1[3] = MidJointAngle2[3];
            //        MidJointAngle1[4] = MidJointAngle2[4];
            //        MidJointAngle1[5] = MidJointAngle2[5];
            //    }

            //    NewJointAngle[0] = MidJointAngle2[0];
            //    NewJointAngle[1] = MidJointAngle2[1];
            //    NewJointAngle[2] = MidJointAngle2[2];
            //    NewJointAngle[3] = MidJointAngle2[3];
            //    NewJointAngle[4] = MidJointAngle2[4];
            //    NewJointAngle[5] = MidJointAngle2[5];
            //}
            //else
            //{
            //    //목표 TCP에 해당하는 조인트앵글 계산
            //    caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, end_pose[0], end_pose[1], end_pose[2], end_pose[3], end_pose[4], end_pose[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, NewJointAngle);
            //    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        return 0;
            //    }
            //}

            ////종료위치 리미트 체크
            //if (RobotJointLimitCheck(NewJointAngle) != 1)
            //{//리미트 제한에 걸린다면
            //    return 3;
            //}

            //주어진 속도와 이동거리로 대략적인 이동시간 및 선속 계산
            double dTime = MoveLength / vel;
            if (weav_type == 0) { weav_width = 0; }
            double newMoveLength = Math.Sqrt(MoveLength * MoveLength + (dTime * weav_freq * weav_width) * (dTime * weav_freq * weav_width) * 4);
            double maxVel = newMoveLength / dTime;

            //최대 조인트 각도변화 계산
            double MaxJointAngleDelta = 0;
            for (int i = 0; i < 6; i++)
            {
                double tempd = Math.Abs(NewJointAngle[i] - NowJointAngle[i]);
                if (MaxJointAngleDelta < tempd) MaxJointAngleDelta = tempd;
            }

            //최대로 움직여야하는 조인트 각속도 계산
            double dJointAngleVel = MaxJointAngleDelta / dTime;

            ////위빙동작시 최대선속을 초과할 때 --> 선속을 줄이면 안됨. 나중에 필요하면 주파수나 위빙폭을 줄여서 맞추도록 구현
            //if (maxVel > RobotControlParameter_TCPMaxSpeed)
            //{
            //    float newVel = (float)(MoveLength * RobotControlParameter_TCPMaxSpeed * 0.95 / newMoveLength);
            //    vel = newVel;
            //}

            if (MoveLength > 1.5)
            {
                //1.5mm 이상 이동하라는 명령 일 때

                float newvel;
                if (dJointAngleVel < 80)
                {
                    //각속도가 80dgr/s보다 작을 경우 지정된 속도로 선형모션 수행
                    newvel = vel;
                }
                else
                {
                    //각속도가 80dgr/s보다 클 경우 속도를 적절하게 낮추고 선형모션 수행
                    newvel = (float)(vel * (80 / dJointAngleVel));
                }
                //선형보간 이동
                int resulti = WeldingMotion_Run(NowTCPActualPose, mid_pose, end_pose, vel, interp, weav_type, weav_width, weav_freq,
                    delay_left, delay_right, arc_sensing, arc_sensing_Hcoef, arc_sensing_Vcoef, arc_sensing_Hlimit, arc_sensing_Vlimit,
                    arc_sensing_HOnce, arc_sensing_VOnce, arc_sensing_LWeightedFactor, arc_sensing_RWeightedFactor, arc_sensing_time_shift);
                if (resulti == 1)
                {
                }
                else
                {
                    return 0; //조인트무브 실행에 실패하면 0 리턴
                }


            }
            else
            {
                //TCP 변화가 1.5mm 이내일 때 선형모션으로 구동하면 조인트쪽에 과도한 속도,가속도 걸림
                //일단 Tool Z방향으로 1.5mm 뒤로 뺀 뒤 다시 실행함

                if (dJointAngleVel < 100)
                {
                    //선형보간 이동
                    int resulti = WeldingMotion_Run(NowTCPActualPose, mid_pose, end_pose, vel, interp, weav_type, weav_width, weav_freq,
                    delay_left, delay_right, arc_sensing, arc_sensing_Hcoef, arc_sensing_Vcoef, arc_sensing_Hlimit, arc_sensing_Vlimit,
                    arc_sensing_HOnce, arc_sensing_VOnce, arc_sensing_LWeightedFactor, arc_sensing_RWeightedFactor, arc_sensing_time_shift);
                    if (resulti == 1)
                    {
                    }
                    else
                    {
                        return 0; //조인트무브 실행에 실패하면 0 리턴
                    }
                }
                else
                {
                    float tempX, tempY, tempZ;
                    tempX = NewTCPActualPose[0];
                    tempY = NewTCPActualPose[1];
                    tempZ = NewTCPActualPose[2];

                    RobotToolTranslation(NewTCPActualPose[3], NewTCPActualPose[4], NewTCPActualPose[5], 3, -1.5f, out tempX, out tempY, out tempZ);

                    NewTCPActualPose[0] = NewTCPActualPose[0] + tempX;
                    NewTCPActualPose[1] = NewTCPActualPose[1] + tempY;
                    NewTCPActualPose[2] = NewTCPActualPose[2] + tempZ;


                    float[] rstAngle = new float[NUM_OF_ROBOT_JOINTS];
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Welding_Move_TCP(), robot_joint_angle_from_tcp_pose_get()");
                    caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, NewTCPActualPose[0], NewTCPActualPose[1], NewTCPActualPose[2], NewTCPActualPose[3], NewTCPActualPose[4], NewTCPActualPose[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, rstAngle);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }


                    //뒤로 빼는 모션 추가

                    if (JointMotion_Add(NowJointAngle, rstAngle, 10) != 1)
                    {
                        return 0;
                    }

                    float newvel;
                    //각속도가 100dgr/s보다 클 경우 속도를 적절하게 낮추고 선형모션 수행
                    newvel = (float)(vel * (1 / dJointAngleVel));


                    //회전모션 실행
                    int resulti = WeldingMotion_Run(NowTCPActualPose, mid_pose, end_pose, vel, interp, weav_type, weav_width, weav_freq,
                    delay_left, delay_right, arc_sensing, arc_sensing_Hcoef, arc_sensing_Vcoef, arc_sensing_Hlimit, arc_sensing_Vlimit,
                    arc_sensing_HOnce, arc_sensing_VOnce, arc_sensing_LWeightedFactor, arc_sensing_RWeightedFactor, arc_sensing_time_shift);
                    if (resulti == 1)
                    {

                    }
                    else
                    {
                        return 0; //조인트무브 실행에 실패하면 0 리턴
                    }
                }

            }

            RobotControlLogAdd(DateTime.Now.ToString("HH:mm:ss.fff-") + "용접모션 실행");
            return 1;

        }

        /// <summary>
        /// 위빙, 아크센싱을 포함한 용접 모션을 만들 때 쓰는 함수. 
        /// </summary>
        /// <param name="start_pose">TCP 시작 좌표(베이스 좌표계)</param>
        /// <param name="mid_pose">TCP 중간 좌표(베이스 좌표계)</param>
        /// <param name="end_pose">TCP 목표 좌표(베이스 좌표계)</param>
        /// <param name="vel">TCP 선속도. 단위 mm/s, 최대 250</param>
        /// <param name="interp">보간 방식. 1:선형 2:원호</param>
        /// <param name="weav_type">위빙 타입. 0:위빙안함 1:지그재그 2:사인파</param>
        /// <param name="weav_width">위빙 폭</param>
        /// <param name="weav_freq">위빙 주파수</param>
        /// <param name="delay_left">좌 멈춤 시간</param>
        /// <param name="delay_right">우 멈춤 시간</param>
        /// <param name="arc_sensing">아크센싱 유무</param>
        /// <param name="arc_sensing_Hcoef">좌우 보정 계수</param>
        /// <param name="arc_sensing_Vcoef">상하 보정 계수</param>
        /// <param name="arc_sensing_limit">좌우 보정 1주기 상한치</param>
        /// <param name="arc_sensing_time_shift">아크 센싱 데이터 지연 값</param>
        /// <returns>1:정상실행, 0:원인을 알수없는 실행실패</returns>
        int WeldingMotion_Add(float[] start_pose, float[] mid_pose, float[] end_pose, float vel, int interp, int weav_type, float weav_width, float weav_freq,
            float delay_left, float delay_right, int arc_sensing, float arc_sensing_Hcoef, float arc_sensing_Vcoef, float arc_sensing_Hlimit, float arc_sensing_Vlimit,
            float arc_sensing_HOnce, float arc_sensing_VOnce, float arc_sensing_LWeightedFactor, float arc_sensing_RWeightedFactor, float arc_sensing_time_shift)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //시작포즈 지정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_position_start_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_position_start_set(motionCmdID_Weld, start_pose[0], start_pose[1], start_pose[2]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_orientation_start_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_start_set(motionCmdID_Weld, start_pose[3], start_pose[4], start_pose[5]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //중간포즈 지정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_position_mid_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_position_mid_set(motionCmdID_Weld, mid_pose[0], mid_pose[1], mid_pose[2]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //종료포즈 설정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_position_end_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_position_end_set(motionCmdID_Weld, end_pose[0], end_pose[1], end_pose[2]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_orientation_end_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_orientation_end_set(motionCmdID_Weld, end_pose[3], end_pose[4], end_pose[5]);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //좌표계 설정
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_coordination_set()");
            caRetVal = clinkCs.motion_command_robot_tcp_coordination_set(motionCmdID_Weld, CLINK_REF_COORDINATE.CLINK_REF_COORDINATE_BASE);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            //보간방식 선택
            if (interp == 1)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_interpolator_set(CLINK_INTERPOLATOR_LINEAR)");
                caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_Weld, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_LINEAR);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }
            else if (interp == 2)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_interpolator_set(CLINK_INTERPOLATOR_ARC)");
                caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_Weld, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_ARC);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
            }
            //else if (interp == 3)
            //{
            //    caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_Weld, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_ARC);
            //    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        return 0;
            //    }
            //}
            //else if (interp == 4)
            //{
            //    caRetVal = clinkCs.motion_command_robot_tcp_interpolator_set(motionCmdID_Weld, CLINK_INTERPOLATOR.CLINK_INTERPOLATOR_CIRCLE);
            //    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            //    {
            //        return 0;
            //    }
            //}

            // MAX command speed
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_speed_max_set()");
            caRetVal = clinkCs.motion_command_speed_max_set(motionCmdID_Weld, vel);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // MAX accelaration
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_acc_max_set()");
            caRetVal = clinkCs.motion_command_acc_max_set(motionCmdID_Weld, RobotControlParameter_TCPAcc);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // MAX decelaration
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_dec_max_set()");
            caRetVal = clinkCs.motion_command_dec_max_set(motionCmdID_Weld, RobotControlParameter_TCPDec);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            // Jerk percentage
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_jerk_percentage_set()");
            caRetVal = clinkCs.motion_command_jerk_percentage_set(motionCmdID_Weld, RobotControlParameter_TCPJerk);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            
            //---------------------------------------------------------------------
            // 용접을 위한 parameter 설정
            //---------------------------------------------------------------------
            if (weav_type == 1 || weav_type == 2)
            {
                if (weav_type == 1)
                {
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_weaving_pattern_set(CLINK_WELDING_WEAVING_PATTERN_ZIGZAG)");
                    caRetVal = clinkCs.motion_command_robot_tcp_welding_weaving_pattern_set(motionCmdID_Weld, CLINK_WELDING_WEAVING_PATTERN.CLINK_WELDING_WEAVING_PATTERN_ZIGZAG);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }
                }
                else if (weav_type == 2)
                {
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_weaving_pattern_set(CLINK_WELDING_WEAVING_PATTERN_SINE_WAVE)");
                    caRetVal = clinkCs.motion_command_robot_tcp_welding_weaving_pattern_set(motionCmdID_Weld, CLINK_WELDING_WEAVING_PATTERN.CLINK_WELDING_WEAVING_PATTERN_SINE_WAVE);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }
                }

                // 진폭
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_amplitude_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_amplitude_set(motionCmdID_Weld, weav_width * 0.5);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_right_amplitude_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_right_amplitude_set(motionCmdID_Weld, weav_width * 0.5);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 주파수
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_frequency_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_frequency_set(motionCmdID_Weld, weav_freq);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // Arc Sensing 상태
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_arc_sensing_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_arc_sensing_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_ON);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 진폭의 끝에서 머무는 시간
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_stop_settling_time_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_stop_settling_time_set(motionCmdID_Weld, delay_left);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_right_stop_settling_time_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_right_stop_settling_time_set(motionCmdID_Weld, delay_right);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_weaving_motion_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_weaving_motion_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_ON);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 아크센싱 IO 설정
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_arc_sensing_sensor_input_number_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_arc_sensing_sensor_input_number_set(motionCmdID_Weld, 0);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 아크센싱 데이터 시프트
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_sensor_input_delay_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_sensor_input_delay_set(motionCmdID_Weld, arc_sensing_time_shift);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 좌우 보정 ON
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_ON);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 좌우 보정 시작 주기
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_start_period_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_start_period_set(motionCmdID_Weld, 5);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                if ((arc_sensing == 1) || (arc_sensing == 3))
                {
                    // 아크센싱 좌우 보정 계수
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_distance_coefficient_set()");
                    caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_distance_coefficient_set(motionCmdID_Weld, arc_sensing_Hcoef);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }
                }
                else
                {
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_distance_coefficient_set()");
                    caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_distance_coefficient_set(motionCmdID_Weld, 0.0f);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }
                }

                // 아크센싱 좌우 보정 상한 (총)
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_distance_limit_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_distance_limit_set(motionCmdID_Weld, arc_sensing_Hlimit);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 아크센싱 좌우 보정 상한(1주기)
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_distance_limit_per_period_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_distance_limit_per_period_set(motionCmdID_Weld, arc_sensing_HOnce);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 상하 보정 ON
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_ON);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 상하 보정 시작 주기
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_start_period_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_start_period_set(motionCmdID_Weld, 10);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 상하 보정 기준값 기록 시작 주기
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_record_start_period_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_record_start_period_set(motionCmdID_Weld, 5);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                if ((arc_sensing == 2) || (arc_sensing == 3))
                {
                    // 상하 보정 계수
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_distance_coefficient_set()");
                    caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_distance_coefficient_set(motionCmdID_Weld, arc_sensing_Vcoef);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }
                }
                else
                {
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_distance_coefficient_set()");
                    caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_distance_coefficient_set(motionCmdID_Weld, 0.0f);
                    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                    {
                        return 0;
                    }
                }

                // 상하 보정 상한 (총)
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_distance_limit_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_distance_limit_set(motionCmdID_Weld, arc_sensing_Vlimit);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }
                
                // 상하 보정 상한 (1회)
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_distance_limit_per_period_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_distance_limit_per_period_set(motionCmdID_Weld, arc_sensing_VOnce);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 왼쪽 센서 가중치
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_weighted_factor_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_weighted_factor_set(motionCmdID_Weld, arc_sensing_LWeightedFactor);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 오른쪽 센서 가중치
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_right_weighted_factor_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_right_weighted_factor_set(motionCmdID_Weld, arc_sensing_RWeightedFactor);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }



            }
            else
            {
                //위빙 안할때

                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_weaving_motion_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_weaving_motion_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_OFF);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 좌우 보정 Off
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_left_right_trace_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_left_right_trace_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_OFF);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }

                // 상하 보정 Off
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_robot_tcp_welding_top_down_trace_switch_set()");
                caRetVal = clinkCs.motion_command_robot_tcp_welding_top_down_trace_switch_set(motionCmdID_Weld, CLINK_SWITCH.CLINK_SWITCH_OFF);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    return 0;
                }


            }

            // motion command queue에 명령 추가
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Add(), motion_command_queue_add()");
            caRetVal = clinkCs.motion_command_queue_add(motionCmdID_Weld);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            return 1;
        }

        /// <summary>
        /// 용접 모션 추가하고 실행함. 내부에서만 사용. 
        /// </summary>
        /// <param name="start_pose">TCP 시작 좌표(베이스 좌표계)</param>
        /// <param name="mid_pose">TCP 중간 좌표(베이스 좌표계)</param>
        /// <param name="end_pose">TCP 목표 좌표(베이스 좌표계)</param>
        /// <param name="vel">TCP 선속도. 단위 mm/s, 최대 250</param>
        /// <param name="interp">보간 방식. 1:선형 2:원호</param>
        /// <param name="weav_type">위빙 타입. 0:위빙안함 1:지그재그 2:사인파</param>
        /// <param name="weav_width">위빙 폭</param>
        /// <param name="weav_freq">위빙 주파수</param>
        /// <param name="delay_left">좌 멈춤 시간</param>
        /// <param name="delay_right">우 멈춤 시간</param>
        /// <param name="arc_sensing_Hcoef">좌우 보정 계수</param>
        /// <param name="arc_sensing_Vcoef">상하 보정 계수</param>
        /// <param name="arc_sensing_limit">좌우 보정 1주기 상한치</param>
        /// <param name="arc_sensing_time_shift">아크 센싱 데이터 지연 값</param>
        /// <returns>1:정상실행, 0:원인을 알수없는 실행실패</returns>
        int WeldingMotion_Run(float[] start_pose, float[] mid_pose, float[] end_pose, float vel, int interp, int weav_type, float weav_width, float weav_freq,
            float delay_left, float delay_right, int arc_sensing, float arc_sensing_Hcoef, float arc_sensing_Vcoef, float arc_sensing_Hlimit, float arc_sensing_Vlimit,
            float arc_sensing_HOnce, float arc_sensing_VOnce, float arc_sensing_LWeightedFactor, float arc_sensing_RWeightedFactor, float arc_sensing_time_shift)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            if (WeldingMotion_Add(start_pose, mid_pose, end_pose, vel, interp, weav_type, weav_width, weav_freq,
                delay_left, delay_right, arc_sensing, arc_sensing_Hcoef, arc_sensing_Vcoef, arc_sensing_Hlimit, arc_sensing_Vlimit,
                arc_sensing_HOnce, arc_sensing_VOnce, arc_sensing_LWeightedFactor, arc_sensing_RWeightedFactor, arc_sensing_time_shift) != 1)
            {
                return 0;
            }

            // 로봇 이동 명령
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "WeldingMotion_Run(), motion_command_queue_flush()");
            caRetVal = clinkCs.motion_command_queue_flush();
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }


            return 1;
        }

        /// <summary>
        /// 터치센싱 시퀀스를 실행하도록 외부에서 호출하는 함수.
        /// </summary>
        /// <param name="distance">터치센싱을 위해 각 방향으로 진행하는 거리</param>
        /// <param name="vel">터치센싱 진행 속도</param>
        /// <param name="direction"></param>
        public int TouchSensingStart(List<TouchSensingData> TempTouchData)
        {
            if (RobotControlThreadSeq != 15) return 0;

            TouchData.Clear();
            TouchPosition.Clear();

            for (int i = 0; i < TempTouchData.Count; i++ )
            {
                TouchData.Add((TouchSensingData)(TempTouchData[i].Clone()));
            }

            RobotControlTouchSensingFlag = true;

            return 1;

        }

        //터치센싱 하는 거리가 도달 가능한지 체크한 뒤 안된다면 가능한 범위까지 움직이도록 거리를 바꿈
        void TouchMoveLimitCheck(TouchSensingData touchdata)
        {
            float Length = 20;

            float distance = touchdata.In_Length;
            float vel = touchdata.In_Speed;
            int coord = touchdata.In_coord;
            float VectorX = touchdata.In_X;
            float VectorY = touchdata.In_Y;
            float VectorZ = touchdata.In_Z;

            int DivCount = (int)(distance / Length + 1);
            float DivLength = distance / DivCount;

            int OKCount = 1;
            
            //현재 로봇 위치값 읽기
            float Pos_x, Pos_y, Pos_z, Ort_x, Ort_y, Ort_z;
            Cur_position(out Pos_x, out Pos_y, out Pos_z, out Ort_x, out Ort_y, out Ort_z);

            float[] NowJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };
            float[] NewJointAngle = new float[6] { 0, 0, 0, 0, 0, 0 };

            //현재값 가져옴
            for (uint count = 0; count < 6; count++)
            {
                float f;
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TouchMoveLimitCheck(), robot_joint_angle_actual_get() count=" + count.ToString());
                CLINK_API_RESULT caRetVal = clinkCs.robot_joint_angle_actual_get(robotID, count, out f);
                if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
                {
                    NowJointAngle[count] = f;
                }
                else
                {
                    return;
                }
            }



            if (coord == 1)
            {//베이스 좌표계 방향일 때
                //지정된 벡터를 단위벡터로 변환하고 거리 곱함
                float dx, dy, dz;
                double tempf;
                tempf = Math.Sqrt(VectorX * VectorX + VectorY * VectorY + VectorZ * VectorZ);

                for(int i=1; i<= DivCount; i++)
                {
                    dx = (float)((DivLength* i) * ((VectorX) / (tempf)));
                    dy = (float)((DivLength * i) * ((VectorY) / (tempf)));
                    dz = (float)((DivLength * i) * ((VectorZ) / (tempf)));

                    float[] move_point = { Pos_x + dx, Pos_y + dy, Pos_z + dz, Ort_x, Ort_y, Ort_z };

                    //목표 TCP에 해당하는 조인트앵글 계산
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TouchMoveLimitCheck(), robot_joint_angle_from_tcp_pose_get()");
                    CLINK_API_RESULT caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, move_point[0], move_point[1], move_point[2], move_point[3], move_point[4], move_point[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, NewJointAngle);
                    if ((caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK) && (RobotJointLimitCheck(NewJointAngle) == 1))
                    {
                        OKCount = i;
                    }
                }
            }
            else if (coord == 2)
            {//툴 좌표계 방향일 때

                float dTx, dTy, dTz;
                double tempf;
                tempf = Math.Sqrt(VectorX * VectorX + VectorY * VectorY + VectorZ * VectorZ);

                for (int i = 1; i <= DivCount; i++)
                {
                    dTx = (float)((DivLength * i) * ((VectorX) / (tempf)));
                    dTy = (float)((DivLength * i) * ((VectorY) / (tempf)));
                    dTz = (float)((DivLength * i) * ((VectorZ) / (tempf)));
                    
                    double[] outMatrix;
                    MakeXYZAngleToRMatrix(Ort_x, Ort_y, Ort_z, out outMatrix);

                    float dx, dy, dz;

                    dx = (float)(dTx * outMatrix[0] + dTy * outMatrix[1] + dTz * outMatrix[2]);
                    dy = (float)(dTx * outMatrix[3] + dTy * outMatrix[4] + dTz * outMatrix[5]);
                    dz = (float)(dTx * outMatrix[6] + dTy * outMatrix[7] + dTz * outMatrix[8]);

                    float[] move_point = { Pos_x + dx, Pos_y + dy, Pos_z + dz, Ort_x, Ort_y, Ort_z };

                    //목표 TCP에 해당하는 조인트앵글 계산
                    RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TouchMoveLimitCheck(), robot_joint_angle_from_tcp_pose_get()");
                    CLINK_API_RESULT caRetVal = clinkCs.robot_joint_angle_from_tcp_pose_get(robotID, move_point[0], move_point[1], move_point[2], move_point[3], move_point[4], move_point[5], NUM_OF_ROBOT_JOINTS, NowJointAngle, NewJointAngle);
                    if ((caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK) && (RobotJointLimitCheck(NewJointAngle) == 1))
                    {
                        OKCount = i;
                    }
                }

            }
            else
            {
                return;
            }

            touchdata.In_Length = DivLength * OKCount;

            return;

        }

        //로봇 연속모션용 함수
        public int RobotContinuousMoveStart(List<RobotPoseData> TempPoseData)
        {
            if (RobotControlThreadSeq != 15) return 0;

            RobotPoseArray.Clear();

            for (int i = 0; i < TempPoseData.Count; i++)
            {
                RobotPoseArray.Add((RobotPoseData)(TempPoseData[i].Clone()));
            }

            RobotControlContinuousMoveFlag = true;

            return 1;

        }


        /// <summary>
        /// 터치센서 유닛에서 디지털 IO 신호를 받아오는 함수.
        /// 부재 접촉시 터치센싱 기능 종료 후 1 반환.
        /// 부재 미접촉시 0반환.
        /// </summary>
        int TouchSensingCheck()
        {
            uint ioVal;
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            // io check
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TouchSensingCheck(), control_box_io_digital_input_get()");
            caRetVal = clinkCs.control_box_io_digital_input_get(ctrlBoxID, TouchSensorIO, out ioVal);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                if (ioVal == 1)
                {
                    return 1; //신호 들어옴
                }
                else
                {
                    return 2; //신호 안들어옴
                }

            }
            else
            {
                return 0; //통신 실패
            }

            //////터치센싱임시
            //if (tempTouchSensingIO == 1)
            //{
            //    return 1; //신호 들어옴
            //}
            //else
            //{
            //    return 2; //신호 안들어옴
            //}
            //////터치센싱임시

        }
        ////터치센싱임시
        public int tempTouchSensingIO = 0;
        ////터치센싱임시



        /// <summary>
        /// 터치센싱 유닛을 작동시키는 함수.
        /// </summary>
        public int TouchSensing_On()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TouchSensing_On(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, TouchSensorIO, 1);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 터치센싱 유닛을 종료시키는 함수.
        /// </summary>
        public int TouchSensing_Off()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TouchSensing_Off(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, TouchSensorIO, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 현재 로봇의 위치를 확인하고 반환하는 함수.
        /// </summary>
        public int Cur_position(out float Pos_x, out float Pos_y, out float Pos_z, out float Ort_x, out float Ort_y, out float Ort_z)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Cur_position(), robot_tcp_pose_actual_get()");
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out Pos_x, out Pos_y, out Pos_z, out Ort_x, out Ort_y, out Ort_z);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            
            return 1;
        }

        //용접기 선형화 식
        public float Arc_AmpToAnalog(float amp)
        {
            ////return 0.0214f * amp - 1.5025f;//1
            //return 0.0287f * amp - 4.6632f;//2
            return (RefAmpIO_2 - RefAmpIO_1) / (WeldAmp_2 - WeldAmp_1) * (amp - WeldAmp_1) + RefAmpIO_1;
        }
        public float Arc_AnalogToAmp(float analog)
        {
            return (WeldAmp_2 - WeldAmp_1) / (RefAmpIO_2 - RefAmpIO_1) * (analog - RefAmpIO_1) + WeldAmp_1;
        }
        public float Arc_VolToAnalog(float vol)
        {
            ////return 0.2661f * vol - 0.8946f;//1
            //return 0.5093f * vol - 7.798f;//2
            return (RefVoltIO_2 - RefVoltIO_1) / (WeldVolt_2 - WeldVolt_1) * (vol - WeldVolt_1) + RefVoltIO_1;
        }
        public float Arc_AnalogToVol(float analog)
        {
            return (WeldVolt_2 - WeldVolt_1) / (RefVoltIO_2 - RefVoltIO_1) * (analog - RefVoltIO_1) + WeldVolt_1;
        }


        //현재 전압 전류 읽거나 씀
        public int Arc_AmpSet(float amp)
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;

            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_AmpSet(), control_box_io_analog_output_set()");
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, CurIO, Arc_AmpToAnalog(amp + WeldOffsetA));
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }
        public int Arc_AmpRead(out float amp)
        {
            amp = 0;
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;

            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            float analog;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_AmpRead(), control_box_io_analog_output_get()");
            caRetVal = clinkCs.control_box_io_analog_output_get(ctrlBoxID, CurIO, out analog);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            amp = Arc_AnalogToAmp(analog);
            return 1;
        }
        public int Arc_VolSet(float vol)
        {
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;

            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_VolSet(), control_box_io_analog_output_set()");
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, VolIO, Arc_VolToAnalog(vol + WeldOffsetV));
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }
        public int Arc_VolRead(out float vol)
        {
            vol = 0;
            //로봇 접속 이전에 호출되면 실행 안함
            if (RobotInitState != 100) return 0;

            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            float analog;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_VolRead(), control_box_io_analog_output_get()");
            caRetVal = clinkCs.control_box_io_analog_output_get(ctrlBoxID, VolIO, out analog);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }

            vol = Arc_AnalogToVol(analog);
            return 1;
        }


        /// <summary>
        /// 아크를 발생시키는 함수.
        /// </summary>
        /// <param name="vol">전압(V)</param>
        /// <param name="amp">전류(A)</param>
        public int Arc_On(float vol, float amp)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //---------------------------------------------------------------------
            //  Voltage, Current set
            //---------------------------------------------------------------------

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_On(,), control_box_io_analog_output_set(VolIO)");
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, VolIO, Arc_VolToAnalog(vol + WeldOffsetV));
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            //Thread.Sleep(100);

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_On(,), control_box_io_analog_output_set(CurIO)");
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, CurIO, Arc_AmpToAnalog(amp + WeldOffsetA)); //  cur / 100F  //  (cur-58F)/29.7F
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            //Thread.Sleep(100);

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_On(,), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, ArcSwitchIO, 1);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 아크를 발생시키는 함수. 기존 전압전류 그대로 아크온만 함
        /// </summary>
        public int Arc_On()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_On(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, ArcSwitchIO, 1);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 아크를 종료시키는 함수.
        /// </summary>
        public int Arc_Off()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            //---------------------------------------------------------------------
            //  Voltage, Current set
            //---------------------------------------------------------------------

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_Off(), control_box_io_analog_output_set(VolIO)");
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, VolIO, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            //Thread.Sleep(100);


            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_Off(), control_box_io_analog_output_set(CurIO)");
            caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, CurIO, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            //Thread.Sleep(100);

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Arc_Off(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, ArcSwitchIO, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 가스 토출을 실행하는 함수.
        /// </summary>
        public int Gas_On()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Gas_On(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, GasIO, 1);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        /// <summary>
        /// 가스 토출을 종료하는 함수.
        /// </summary>
        public int Gas_Off()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Gas_Off(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, GasIO, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }


        //와이어 정인칭 온
        public int Wire_FInching_On()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Wire_FInching_On(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, 3, 1);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        //와이어 정인칭 오프
        public int Wire_FInching_Off()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Wire_FInching_Off(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, 3, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }


        //와이어 역인칭 온
        public int Wire_IInching_On()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Wire_IInching_On(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, 4, 1);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }


        //와이어 역인칭 오프
        public int Wire_IInching_Off()
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "Wire_IInching_Off(), control_box_io_digital_output_set()");
            caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, 4, 0);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                return 0;
            }
            return 1;
        }

        
        int RobotToolBackMotionRun(float length)
        {
            CLINK_API_RESULT caRetVal = CLINK_API_RESULT.CLINK_API_RESULT_OK;

            float f1, f2, f3, f4, f5, f6;
            float[] NowTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            float[] NewTCPActualPose = new float[6] { 0, 0, 0, 0, 0, 0 };
            //TCP포즈 현재값 가져옴
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotToolBackMotionRun(), robot_tcp_pose_actual_get()");
            caRetVal = clinkCs.robot_tcp_pose_actual_get(robotID, out f1, out f2, out f3, out f4, out f5, out f6);
            if (caRetVal == CLINK_API_RESULT.CLINK_API_RESULT_OK)
            {
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NowTCPActualPose, 0);
                new float[] { f1, f2, f3, f4, f5, f6 }.CopyTo(NewTCPActualPose, 0);
            }
            else
            {
                return 0;
            }


            float tempX, tempY, tempZ;
            tempX = NewTCPActualPose[0];
            tempY = NewTCPActualPose[1];
            tempZ = NewTCPActualPose[2];

            RobotToolTranslation(NewTCPActualPose[3], NewTCPActualPose[4], NewTCPActualPose[5], 3, -1*length, out tempX, out tempY, out tempZ);

            NewTCPActualPose[0] = NewTCPActualPose[0] + tempX;
            NewTCPActualPose[1] = NewTCPActualPose[1] + tempY;
            NewTCPActualPose[2] = NewTCPActualPose[2] + tempZ;

            int resulti = LinearMotion_Run(NowTCPActualPose, NowTCPActualPose, NewTCPActualPose, 200, 1, 1);
            if (resulti == 1)
            {

            }
            else
            {
                return 0; //실행에 실패하면 0 리턴
            }


            return 1;
        }





        //외부에서 시퀀스 상태를 바꿔줄 경우 체크
        void RobotControlEventCheck()
        {

            if (RobotControlManualMoveFlag)
            {
                RobotControlThreadSeq = 20;
                Thread.Sleep(100); //모션커멘드 날린 뒤 실제 실행하기까지 시간이 걸림. 슬립 안해도 구동에 문제는 없는데 상태 인식에 문제가 생김.
                RobotControlManualMoveFlag = false;
            }
            else if (RobotControlErrorClearFlag)
            {
                RobotControlThreadSeq = 1;
                RobotControlErrorClearFlag = false;
            }
            else if (RobotControlServoOnFlag)
            {
                RobotControlThreadSeq = 3;
                RobotControlServoOnFlag = false;
            }
            else if (RobotControlServoOffFlag)
            {
                RobotControlThreadSeq = 40;
                RobotControlServoOffFlag = false;
            }
            else if (RobotControlDirectTeachingOnFlag)
            {
                RobotControlThreadSeq = 50;
                RobotControlDirectTeachingOnFlag = false;
            }
            else if (RobotControlDirectTeachingOffFlag)
            {
                RobotControlThreadSeq = 15;
                RobotControlDirectTeachingOffFlag = false;
            }
            else if (RobotControlWeldStartFlag)
            {
                RobotControlThreadSeq = 100;
                RobotControlWeldStartFlag = false;
            }
            else if (RobotControlTouchSensingFlag)
            {
                RobotControlThreadSeq = 200;
                RobotControlTouchSensingFlag = false;
            }
            else if (RobotControlContinuousMoveFlag)
            {
                RobotControlThreadSeq = 300;
                RobotControlContinuousMoveFlag = false;
            }
            
            
            //에러플래그 체크. 모션플래그체크 뒤에 실행. 혹시 모션플래그와 에러플래그가 동시에 발생 한 경우 모션플래그는 무시하기 위해
            if (RobotControlEMGFlag)
            {
                RobotControlThreadSeq = 1000;
                RobotControlEMGFlag = false;
                Arc_Off();
            }
            else if (RobotControlCollisionFlag)
            {
                RobotControlThreadSeq = 1001;
                RobotControlCollisionFlag = false;
                Arc_Off();
            }
            else if (RobotControlSafetyVioFlag)
            {
                RobotControlThreadSeq = 1002;
                RobotControlSafetyVioFlag = false;
                Arc_Off();
            }
            else if (RobotControlPWRFlag)
            {
                RobotControlPWRFlag = false;
                RobotStop();
            }
            
        }

        //비상정지버튼 이벤트 처리함수 비상정지가 발생한 경우 인자 1, 비상정지가 풀린 경우 인자 0
        void ChangeEMGState(int onoff)
        {
            if (onoff == 1)
            {
                RobotControlEMGFlag = true;
            }
            else if (onoff == 0)
            {
                ErrorState_EMGRel  = true;
                ErrorTime_EMGRel = DateTime.Now;
            }
        }

        //충돌이벤트 발생하면 로봇컨트롤시퀀스를 0으로 바꿔줌
        void ChangeCollisionState()
        {
            RobotControlCollisionFlag = true;
        }
        
        //안전설정 위반하면 호출됨.
        void SafetyViolateState()
        {
            RobotControlSafetyVioFlag = true;
        }


        //로봇 전원버튼이 눌린경우. 눌리면 로봇 정지신호 날림 인자 1, 비상정지가 풀린 경우 인자 0
        void ChangePWRState(int onoff)
        {
            if (onoff == 1)
            {
                RobotControlPWRFlag = true;
            }
        }

        //툴 좌표계로 회전하기 위한 Rx, Ry, Rz 계산하는 함수
        //현재 각도와 회전축(1:Tool X축, 2:Tool Y축, 3:Tool Z축), 회전각도(dgree)를 입력하면 
        //지정된 회전축과 회전각도 만큼 회전하기 위한 Rx, Ry, Rz를 넣어줌
        //리턴 0:실패, 1:성공
        public int RobotToolRotation(float inRx, float inRy, float inRz, int Axis, float Angle, out float outRx, out float outRy, out float outRz)
        {
            outRx = 0;
            outRy = 0;
            outRz = 0;

            if ((Axis != 1) && (Axis != 2) && (Axis != 3)) return 0;

            double[] initMatrix, RMatrix, outMatrix;

            //현재 로봇각도를 회전매트릭스로 변환함
            MakeXYZAngleToRMatrix(inRx, inRy, inRz, out initMatrix);

            //회전하고자 하는 축과 각도로 회전시키는 매트릭스 계산
            if(Axis == 1)
            {
                MakeAxisAndAngleToRMatrix(initMatrix[0], initMatrix[3], initMatrix[6], Angle, out RMatrix);
            }
            else if (Axis == 2)
            {
                MakeAxisAndAngleToRMatrix(initMatrix[1], initMatrix[4], initMatrix[7], Angle, out RMatrix);
            }
            else
            {
                MakeAxisAndAngleToRMatrix(initMatrix[2], initMatrix[5], initMatrix[8], Angle, out RMatrix);
            }

            //매트릭스를 곱해서 로봇매트릭스를 회전시킴 
            MakeMatrixMul(RMatrix, initMatrix, out outMatrix);

            //로봇매트릭스를 로봇각도로 다시 변환함
            double tempa, tempb, tempr;
            tempb = Math.Atan2(-outMatrix[6], Math.Sqrt(outMatrix[0] * outMatrix[0] + outMatrix[3] * outMatrix[3]));
            tempa = Math.Atan2(outMatrix[3]/Math.Cos(tempb), outMatrix[0] / Math.Cos(tempb));
            tempr = Math.Atan2(outMatrix[7] / Math.Cos(tempb), outMatrix[8] / Math.Cos(tempb));

            outRz = (float)(tempa * (180 / Math.PI));
            outRy = (float)(tempb * (180 / Math.PI));
            outRx = (float)(tempr * (180 / Math.PI));

            return 1;
        }

        
        /// <summary>
        /// 초기자세 Rx,Ry,Rz를 지정된 회전축, 회전각으로 회전시킨 Rx, Ry, Rz 계산하는 함수
        /// </summary>
        /// <param name="inRx">초기 Rx</param>
        /// <param name="inRy">초기 Ry</param>
        /// <param name="inRz">초기 Rz</param>
        /// <param name="AxisX">회전축 벡터 X</param>
        /// <param name="AxisY">회전축 벡터 Y</param>
        /// <param name="AxisZ">회전축 벡터 Z</param>
        /// <param name="Angle">회전각</param>
        /// <param name="outRx">회전된 결과 Rx</param>
        /// <param name="outRy">회전된 결과 Ry</param>
        /// <param name="outRz">회전된 결과 Rz</param>
        /// <returns></returns>
        public int RobotBaseRotation(float inRx, float inRy, float inRz, float AxisX, float AxisY, float AxisZ, float Angle, out float outRx, out float outRy, out float outRz)
        {
            outRx = 0;
            outRy = 0;
            outRz = 0;

            //입력된 회전축 벡터를 노말라이즈함
            double M = Math.Sqrt(AxisX * AxisX + AxisY * AxisY + AxisZ * AxisZ);
            double X = AxisX / M;
            double Y = AxisY / M;
            double Z = AxisZ / M;

            double[] initMatrix, RMatrix, outMatrix;

            //현재 로봇각도를 회전매트릭스로 변환함
            MakeXYZAngleToRMatrix(inRx, inRy, inRz, out initMatrix);

            //회전하고자 하는 축과 각도로 회전시키는 매트릭스 계산
            MakeAxisAndAngleToRMatrix(X, Y, Z, Angle, out RMatrix);

            //매트릭스를 곱해서 로봇매트릭스를 회전시킴 
            MakeMatrixMul(RMatrix, initMatrix, out outMatrix);

            //로봇매트릭스를 로봇각도로 다시 변환함
            double tempa, tempb, tempr;
            tempb = Math.Atan2(-outMatrix[6], Math.Sqrt(outMatrix[0] * outMatrix[0] + outMatrix[3] * outMatrix[3]));
            tempa = Math.Atan2(outMatrix[3] / Math.Cos(tempb), outMatrix[0] / Math.Cos(tempb));
            tempr = Math.Atan2(outMatrix[7] / Math.Cos(tempb), outMatrix[8] / Math.Cos(tempb));

            outRz = (float)(tempa * (180 / Math.PI));
            outRy = (float)(tempb * (180 / Math.PI));
            outRx = (float)(tempr * (180 / Math.PI));

            return 1;
        }


        //롤피치요를 회전행렬로 바꿔줌. 배열 순서대로 a11 a12 a13 a21 a22 a23 a31 a32 a33
        public void MakeXYZAngleToRMatrix(float inRx, float inRy, float inRz, out double[] Matrix)
        {
            Matrix = new double[9];
            double r = Math.PI * (inRx / 180.0);
            double b = Math.PI * (inRy / 180.0);
            double a = Math.PI * (inRz / 180.0);

            Matrix[0] = Math.Cos(a) * Math.Cos(b);
            Matrix[1] = Math.Cos(a) * Math.Sin(b) * Math.Sin(r) - Math.Sin(a) * Math.Cos(r);
            Matrix[2] = Math.Cos(a) * Math.Sin(b) * Math.Cos(r) + Math.Sin(a) * Math.Sin(r);
            Matrix[3] = Math.Sin(a) * Math.Cos(b);
            Matrix[4] = Math.Sin(a) * Math.Sin(b) * Math.Sin(r) + Math.Cos(a) * Math.Cos(r);
            Matrix[5] = Math.Sin(a) * Math.Sin(b) * Math.Cos(r) - Math.Cos(a) * Math.Sin(r);
            Matrix[6] = -Math.Sin(b);
            Matrix[7] = Math.Cos(b) * Math.Sin(r);
            Matrix[8] = Math.Cos(b) * Math.Cos(r);
            
        }


        /// <summary>
        /// 지정된 회전축으로 각도만큼 회전시키는 회전행렬 만들어주는 함수
        /// </summary>
        /// <param name="Vx">회전축 벡터 X</param>
        /// <param name="Vy">회전축 벡터 Y</param>
        /// <param name="Vz">회전축 벡터 Z</param>
        /// <param name="Angle">회전 각도</param>
        /// <param name="Matrix">계산한 회전행렬</param>
        void MakeAxisAndAngleToRMatrix(double Vx, double Vy, double Vz, double Angle, out double[] Matrix)
        {
            //입력된 회전축 벡터를 노말라이즈함
            double M = Math.Sqrt(Vx * Vx + Vy * Vy + Vz * Vz);
            Vx = Vx / M;
            Vy = Vy / M;
            Vz = Vz / M;

            Matrix = new double[9];
            double a = Math.PI * (Angle / 180.0);
            double w = Math.Cos(a / 2);
            double x = Math.Sin(a / 2) * Vx;
            double y = Math.Sin(a / 2) * Vy;
            double z = Math.Sin(a / 2) * Vz;

            Matrix[0] = 1-2*y*y-2*z*z;
            Matrix[1] = 2*x*y-2*w*z;
            Matrix[2] = 2*x*z+2*w*y;
            Matrix[3] = 2*x * y +2 * w * z;
            Matrix[4] = 1-2 * x * x - 2 * z * z;
            Matrix[5] = 2 * y * z-2 * w * x;
            Matrix[6] = 2 * x * z -2 * w * y;
            Matrix[7] = 2 * y * z+2 * w * x;
            Matrix[8] = 1-2 * x * x-2 * y * y;

        }

        /// <summary>
        /// 행렬곱 수행
        /// </summary>
        /// <param name="Matrix1">첫번째 행렬</param>
        /// <param name="Matrix2">두번째 행렬</param>
        /// <param name="Matrix3">계산 결과</param>
        void MakeMatrixMul(double[] Matrix1, double[] Matrix2, out double[] Matrix3)
        {
            Matrix3 = new double[9];

            Matrix3[0] = Matrix1[0] * Matrix2[0] + Matrix1[1] * Matrix2[3] + Matrix1[2] * Matrix2[6];
            Matrix3[1] = Matrix1[0] * Matrix2[1] + Matrix1[1] * Matrix2[4] + Matrix1[2] * Matrix2[7];
            Matrix3[2] = Matrix1[0] * Matrix2[2] + Matrix1[1] * Matrix2[5] + Matrix1[2] * Matrix2[8];
            Matrix3[3] = Matrix1[3] * Matrix2[0] + Matrix1[4] * Matrix2[3] + Matrix1[5] * Matrix2[6];
            Matrix3[4] = Matrix1[3] * Matrix2[1] + Matrix1[4] * Matrix2[4] + Matrix1[5] * Matrix2[7];
            Matrix3[5] = Matrix1[3] * Matrix2[2] + Matrix1[4] * Matrix2[5] + Matrix1[5] * Matrix2[8];
            Matrix3[6] = Matrix1[6] * Matrix2[0] + Matrix1[7] * Matrix2[3] + Matrix1[8] * Matrix2[6];
            Matrix3[7] = Matrix1[6] * Matrix2[1] + Matrix1[7] * Matrix2[4] + Matrix1[8] * Matrix2[7];
            Matrix3[8] = Matrix1[6] * Matrix2[2] + Matrix1[7] * Matrix2[5] + Matrix1[8] * Matrix2[8];

        }
        

        /// <summary>
        /// 툴 좌표계로 이동하기 위한 X, Y, Z 계산하는 함수.
        /// 현재 TCP각도와 좌표축(1:TCP X축, 2:TCP Y축, 3:TCP Z축), 이동거리(mm)를 입력하면 지정된 좌표축으로 지정거리만큼 이동하기 위한 dX, dY, dZ를 계산
        /// </summary>
        /// <param name="inRx">초기각도 Rx (TCP 좌표계 계산용도)</param>
        /// <param name="inRy">초기각도 Ry (TCP 좌표계 계산용도)</param>
        /// <param name="inRz">초기각도 Rz (TCP 좌표계 계산용도)</param>
        /// <param name="Axis">이동할 축(1:TCP X축, 2:TCP Y축, 3:TCP Z축)</param>
        /// <param name="Length">이동 거리</param>
        /// <param name="outX">지정된 TCP축, 이동거리로 움직이기 위한 베이스좌표계 기준 X값</param>
        /// <param name="outY">지정된 TCP축, 이동거리로 움직이기 위한 베이스좌표계 기준 Y값</param>
        /// <param name="outZ">지정된 TCP축, 이동거리로 움직이기 위한 베이스좌표계 기준 Z값</param>
        /// <returns>0:실패, 1:성공</returns>
        int RobotToolTranslation(float inRx, float inRy, float inRz, int Axis, float Length, out float outX, out float outY, out float outZ)
        {
            outX = 0;
            outY = 0;
            outZ = 0;

            if ((Axis != 1) && (Axis != 2) && (Axis != 3)) return 0;

            double[] initMatrix;

            //현재 로봇각도를 회전매트릭스로 변환함
            MakeXYZAngleToRMatrix(inRx, inRy, inRz, out initMatrix);

            //이동하고자 하는 축에 따라 이동거리 계산해서 리턴
            if (Axis == 1)
            {
                outX = (float)(Length * initMatrix[0]);
                outY = (float)(Length * initMatrix[3]);
                outZ = (float)(Length * initMatrix[6]);
            }
            else if (Axis == 2)
            {
                outX = (float)(Length * initMatrix[1]);
                outY = (float)(Length * initMatrix[4]);
                outZ = (float)(Length * initMatrix[7]);
            }
            else
            {
                outX = (float)(Length * initMatrix[2]);
                outY = (float)(Length * initMatrix[5]);
                outZ = (float)(Length * initMatrix[8]);
            }


            return 1;
        }

        //로봇 박스 DO 출력값을 읽어 반대로 전환하는 함수 리턴 0:성공, 1:실패, 2:로봇접속중이 아님
        public int RobotBoxDOToggle(int ioNum)
        {
            if (RobotInitState != 100) return 2;

            RobotBoxDOToggleFlag[ioNum] = true;
            //uint u = 0;
            //CLINK_API_RESULT caRetVal = clinkCs.control_box_io_digital_output_get(ctrlBoxID, (uint)ioNum, out u);
            //if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;

            //u = (uint)RobotMonitoringData.moni_RobotIOValueDO % 2;

            //if (u==0)
            //{
            //    caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, (uint)ioNum, 1);
            //    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;
            //}
            //else
            //{
            //    caRetVal = clinkCs.control_box_io_digital_output_set(ctrlBoxID, (uint)ioNum, 0);
            //    if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;
            //}

            return 0;

        }

        //로봇 툴 DO출력값을 읽어 반대로 전환하는 함수
        public int RobotToolDOToggle(int ioNum)
        {
            if (RobotInitState != 100) return 2;

            uint u = 0;
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotToolDOToggle(), robot_tool_io_digital_output_get()");
            CLINK_API_RESULT caRetVal = clinkCs.robot_tool_io_digital_output_get(robotID, (uint)ioNum, out u);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;

            if (u == 0)
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotToolDOToggle(), robot_tool_io_digital_output_set(1)");
                clinkCs.robot_tool_io_digital_output_set(robotID, (uint)ioNum, 1);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;
            }
            else
            {
                RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotToolDOToggle(), robot_tool_io_digital_output_set(0)");
                clinkCs.robot_tool_io_digital_output_set(robotID, (uint)ioNum, 0);
                if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;
            }

            return 0;
        }

        //로봇 박스 아날로그출력
        public int RobotBoxAO(int ioNum, float value)
        {
            if (RobotInitState != 100) return 2;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotBoxAO(), control_box_io_analog_output_set()");
            CLINK_API_RESULT caRetVal = clinkCs.control_box_io_analog_output_set(ctrlBoxID, (uint)ioNum, value);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;

            return 0;
        }

        //로봇 툴 아날로그출력
        public int RobotToolAO(int ioNum, float value)
        {
            if (RobotInitState != 100) return 2;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotToolAO(), robot_tool_io_analog_output_set()");
            CLINK_API_RESULT caRetVal = clinkCs.robot_tool_io_analog_output_set(robotID, (uint)ioNum, value);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;

            return 0;
        }

        //로봇 안전스위치 온
        public int RobotSafetySwitchOn()
        {
            if (RobotInitState != 100) return 2;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotSafetySwitchOn(), robot_safety_limit_switch_set()");
            CLINK_API_RESULT caRetVal = clinkCs.robot_safety_limit_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_ON);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;

            return 0;
        }

        //로봇 안전스위치 오프
        public int RobotSafetySwitchOff()
        {
            if (RobotInitState != 100) return 2;

            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "RobotSafetySwitchOff(), robot_safety_limit_switch_set()");
            CLINK_API_RESULT caRetVal = clinkCs.robot_safety_limit_switch_set(robotID, CLINK_SWITCH.CLINK_SWITCH_OFF);
            if (caRetVal != CLINK_API_RESULT.CLINK_API_RESULT_OK) return 1;

            return 0;
        }

        /// <summary>
        /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// TCP 계산
        /// </summary>
        public float[] TCPCalculation(float[] x, float[] y, float[] z, float[] rx, float[] ry, float[] rz)
        {
            RobotFuncCallLog1_Add(DateTime.Now.ToString("HH:mm:ss.fff-") + "TCPCalculation(), robot_tcp_from_flange_multiple_position_set()");
            CLINK_API_RESULT caRetVal = clinkCs.robot_tcp_from_flange_multiple_position_set(robotID, 5, x, y, z, rx, ry, rz);
            float _x, _y, _z, _rx, _ry, _rz;
            caRetVal = clinkCs.robot_tcp_from_flange_get(robotID, out _x, out _y, out _z, out _rx, out _ry, out _rz);
            return new float[] { _x, _y, _z, _rx, _ry, _rz };
        }

        //터치 위치에 오프셋 더해서 결과 가져오는 함수
        public RobotPoseData GetTouchPose_1th(double offset_x, double offset_y, double offset_z)
        {
            RobotPoseData tempRobotPose = (RobotPoseData)TouchPosition[0].Clone();
            tempRobotPose.f1 = (float)(tempRobotPose.f1 + offset_x);
            tempRobotPose.f2 = (float)(tempRobotPose.f2 + offset_y);
            tempRobotPose.f3 = (float)(tempRobotPose.f3 + offset_z);
            return (RobotPoseData)tempRobotPose.Clone();
        }
        public RobotPoseData GetTouchPose_2th(double offset_x, double offset_y, double offset_z)
        {
            RobotPoseData tempRobotPose = (RobotPoseData)TouchPosition[1].Clone();
            tempRobotPose.f1 = (float)(tempRobotPose.f1 + offset_x);
            tempRobotPose.f2 = (float)(tempRobotPose.f2 + offset_y);
            tempRobotPose.f3 = (float)(tempRobotPose.f3 + offset_z);
            return (RobotPoseData)tempRobotPose.Clone();
        }
        public RobotPoseData GetTouchPose_3th(double offset_x, double offset_y, double offset_z)
        {
            RobotPoseData tempRobotPose = (RobotPoseData)TouchPosition[2].Clone();
            tempRobotPose.f1 = (float)(tempRobotPose.f1 + offset_x);
            tempRobotPose.f2 = (float)(tempRobotPose.f2 + offset_y);
            tempRobotPose.f3 = (float)(tempRobotPose.f3 + offset_z);
            return (RobotPoseData)tempRobotPose.Clone();
        }

        /// <summary>
        /// 시작위치와 종료위치를 입력으로 받아 방향벡터와 길이를 구해주는 함수
        /// </summary>
        /// <param name="StartPose">시작위치</param>
        /// <param name="EndPose">종료위치</param>
        /// <param name="dirX">단위방향벡터 x</param>
        /// <param name="dirY">단위방향벡터 y</param>
        /// <param name="dirZ">단위방향벡터 z</param>
        /// <param name="Length">시작-종료 거리</param>
        public void RobotStartEndToDirCal(RobotPoseData StartPose, RobotPoseData EndPose, out double dirX, out double dirY, out double dirZ, out double Length)
        {
            dirX = EndPose.f1 - StartPose.f1;
            dirY = EndPose.f2 - StartPose.f2;
            dirZ = EndPose.f3 - StartPose.f3;
            Length = Math.Sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ);
            dirX = dirX / Length;
            dirY = dirY / Length;
            dirZ = dirZ / Length;
        }

        /// <summary>
        /// 로봇 포즈를 입력으로 받아 포즈의 Rx, Ry, Rz 값으로 툴의 Z방향벡터를 계산하는 함수
        /// </summary>
        /// <param name="RobotPose">계산할 로봇포즈 (베이스좌표계데이터)</param>
        /// <param name="dirX">TCP Z축 방향의 단위벡터 x</param>
        /// <param name="dirY">TCP Z축 방향의 단위벡터 y</param>
        /// <param name="dirZ">TCP Z축 방향의 단위벡터 z</param>
        public void RobotPoseToTooldirCal(RobotPoseData RobotPose, out double dirX, out double dirY, out double dirZ)
        {
            double[] initMatrix;
            MakeXYZAngleToRMatrix(RobotPose.f4, RobotPose.f5, RobotPose.f6, out initMatrix);
            dirX = initMatrix[2];
            dirY = initMatrix[5];
            dirZ = initMatrix[8];
        }

        /// <summary>
        /// 벡터 외적 계산함수
        /// </summary>
        /// <param name="FirstX">첫번째 벡터 X</param>
        /// <param name="FirstY">첫번째 벡터 Y</param>
        /// <param name="FirstZ">첫번째 벡터 Z</param>
        /// <param name="SecondX">두번째 벡터 X</param>
        /// <param name="SecondY">두번째 벡터 Y</param>
        /// <param name="SecondZ">두번째 벡터 Z</param>
        /// <param name="resultX">외적 결과벡터 X</param>
        /// <param name="resultY">외적 결과벡터 Y</param>
        /// <param name="resultZ">외적 결과벡터 Z</param>
        public void VectorCrossProduct(double FirstX, double FirstY, double FirstZ, double SecondX, double SecondY, double SecondZ, out double resultX, out double resultY, out double resultZ)
        {
            resultX = FirstY * SecondZ - FirstZ * SecondY;
            resultY = FirstZ * SecondX - FirstX * SecondZ;
            resultZ = FirstX * SecondY - FirstY * SecondX;
        }

        /// <summary>
        /// 시작포즈, 종료포즈, 오프셋, 중간자세포즈 입력하면 시작점에서 오프셋만큼 떨어진 위치에 중간자세를 가지는 로봇포즈데이터 만들어서 리턴
        /// </summary>
        /// <param name="SPose">시작포즈. 위치정보만 사용</param>
        /// <param name="EPose">종료포즈. 위치정보만 사용</param>
        /// <param name="Offset">시작점에서 떨어진 거리</param>
        /// <param name="Angle">중간포즈. 회전정보만 사용</param>
        /// <returns>중간포즈 계산 결과</returns>
        public RobotPoseData CalcMiddleposeStartoffset(RobotPoseData SPose, RobotPoseData EPose, double Offset, RobotPoseData Angle)
        {
            RobotPoseData temppose = new RobotPoseData();
            double tempd1 = EPose.f1 - SPose.f1;
            double tempd2 = EPose.f2 - SPose.f2;
            double tempd3 = EPose.f3 - SPose.f3;
            double WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));
            temppose.f1 = (float)(SPose.f1 + tempd1 / WeldLength * Offset);
            temppose.f2 = (float)(SPose.f2 + tempd2 / WeldLength * Offset);
            temppose.f3 = (float)(SPose.f3 + tempd3 / WeldLength * Offset);
            temppose.f4 = Angle.f4;
            temppose.f5 = Angle.f5;
            temppose.f6 = Angle.f6;
            return temppose;
        }

        public RobotPoseData CalcMiddleposeStartoffset(RobotPoseData SPose, RobotPoseData EPose, double Offset, double Angle1, double Angle2, double Angle3)
        {
            RobotPoseData temppose = new RobotPoseData();
            double tempd1 = EPose.f1 - SPose.f1;
            double tempd2 = EPose.f2 - SPose.f2;
            double tempd3 = EPose.f3 - SPose.f3;
            double WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));
            temppose.f1 = (float)(SPose.f1 + tempd1 / WeldLength * Offset);
            temppose.f2 = (float)(SPose.f2 + tempd2 / WeldLength * Offset);
            temppose.f3 = (float)(SPose.f3 + tempd3 / WeldLength * Offset);
            temppose.f4 = (float)Angle1;
            temppose.f5 = (float)Angle2;
            temppose.f6 = (float)Angle3;
            return temppose;
        }

        /// <summary>
        /// 시작포즈, 종료포즈, 오프셋, 중간자세포즈 입력하면 종료점에서 오프셋만큼 떨어진 위치에 중간자세를 가지는 로봇포즈데이터 만들어서 리턴
        /// </summary>
        /// <param name="SPose">시작포즈. 위치정보만 사용</param>
        /// <param name="EPose">종료포즈. 위치정보만 사용</param>
        /// <param name="Offset">종료점에서 떨어진 거리</param>
        /// <param name="Angle">중간포즈. 회전정보만 사용</param>
        /// <returns>중간포즈 계산 결과</returns>
        public RobotPoseData CalcMiddleposeEndoffset(RobotPoseData SPose, RobotPoseData EPose, double Offset, RobotPoseData Angle)
        {
            RobotPoseData temppose = new RobotPoseData();
            double tempd1 = EPose.f1 - SPose.f1;
            double tempd2 = EPose.f2 - SPose.f2;
            double tempd3 = EPose.f3 - SPose.f3;
            double WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));
            temppose.f1 = (float)(EPose.f1 - tempd1 / WeldLength * Offset);
            temppose.f2 = (float)(EPose.f2 - tempd2 / WeldLength * Offset);
            temppose.f3 = (float)(EPose.f3 - tempd3 / WeldLength * Offset);
            temppose.f4 = Angle.f4;
            temppose.f5 = Angle.f5;
            temppose.f6 = Angle.f6;
            return temppose;
        }

        //세 점으로 이루어진 원호 중심 계산하는 함수
        public void CalcCircleCenter(double[] p0, double[] p1, double[] p2, out double[] pResult)
        {
            double[] vector0, vector1, normalVector;
            double x, x0, x1, x2, x3, y, y0, y1, y2, y3, z, z0, z1, z2, z3, r;
            pResult = new double[3] { 0, 0, 0 };

            x1 = p0[0]; x2 = p1[0]; x3 = p2[0];
            y1 = p0[1]; y2 = p1[1]; y3 = p2[1];
            z1 = p0[2]; z2 = p1[2]; z3 = p2[2];

            vector0 = new double[] { x1 - x2, y1 - y2, z1 - z2 };
            vector1 = new double[] { x2 - x3, y2 - y3, z2 - z3 };
            NormalVectorCalculation(vector0, vector1, out normalVector);

            double a1, a2, a3, b1, b2, b3, c1, c2, c3, d1, d2, d3;
            a1 = x1 - x2; b1 = y1 - y2; c1 = z1 - z2;
            a2 = x2 - x3; b2 = y2 - y3; c2 = z2 - z3;
            a3 = x3 - x1; b3 = y3 - y1; c3 = z3 - z1;
            a3 = normalVector[0]; b3 = normalVector[1]; c3 = normalVector[2];
            d1 = (x1 * x1 - x2 * x2 + y1 * y1 - y2 * y2 + z1 * z1 - z2 * z2) / 2;
            d2 = (x2 * x2 - x3 * x3 + y2 * y2 - y3 * y3 + z2 * z2 - z3 * z3) / 2;
            d3 = (x3 * x3 - x1 * x1 + y3 * y3 - y1 * y1 + z3 * z3 - z1 * z1) / 2;
            d3 = a3 * x1 + b3 * y1 + c3 * z1;

            double[,] A = new double[3, 3]; double[,] InvA;
            A[0, 0] = a1; A[0, 1] = a2; A[0, 2] = a3;
            A[1, 0] = b1; A[1, 1] = b2; A[1, 2] = b3;
            A[2, 0] = c1; A[2, 1] = c2; A[2, 2] = c3;
            int result = 0;

            result = Inv3D(A, out InvA);
            
            x = InvA[0, 0] * d1 + InvA[1, 0] * d2 + InvA[2, 0] * d3;
            y = InvA[0, 1] * d1 + InvA[1, 1] * d2 + InvA[2, 1] * d3;
            z = InvA[0, 2] * d1 + InvA[1, 2] * d2 + InvA[2, 2] * d3;

        }

        //3*3 매트릭스 역행렬 만드는 함수
        public int Inv3D(double[,] array, out double[,] result)
        {
            result = new double[3, 3];
            try
            {
                double det = array[0, 0] * array[1, 1] * array[2, 2] + array[0, 1] * array[1, 2] * array[2, 0] + array[0, 2] * array[1, 0] * array[2, 1]
                            - array[0, 0] * array[1, 2] * array[2, 1] - array[0, 1] * array[1, 0] * array[2, 2] - array[0, 2] * array[1, 1] * array[2, 0];
                if (det != 0)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            result[j, i] = (array[(i + 1) % 3, (j + 1) % 3] * array[(i + 2) % 3, (j + 2) % 3] - array[(i + 2) % 3, (j + 1) % 3] * array[(i + 1) % 3, (j + 2) % 3]) / det;
                        }
                    }
                    return 1;
                }
                else { return -1; }
            }
            catch
            {
                return 0;
            }
        }

        public void NormalVectorCalculation(double[] vector1, double[] vector2, out double[] normalVector)
        {
            normalVector = new double[] { vector1[1] * vector2[2] - vector1[2] * vector2[1], vector1[2] * vector2[0] - vector1[0] * vector2[2], vector1[0] * vector2[1] - vector1[1] * vector2[0] };
            double l = Math.Sqrt(normalVector[0] * normalVector[0] + normalVector[1] * normalVector[1] + normalVector[2] * normalVector[2]);
            for (int i = 0; i < 3; i++)
            {
                normalVector[i] = normalVector[i] / l;
            }
            UnitVector(normalVector, out normalVector);
        }

        public void UnitVector(double[] vector, out double[] unitVector)
        {
            double x, y, z, l;
            l = Math.Sqrt(vector[0] * vector[0] + vector[1] * vector[1] + vector[2] * vector[2]);
            x = vector[0] / l;
            y = vector[1] / l;
            z = vector[2] / l;
            unitVector = new double[] { x, y, z };
        }

        //입력된 벡터를 지정된 회전축과 각도만큼 회전시키는 함수. 각도단위는 디그리
        public void CalcVectorRotation(double inVx, double inVy, double inVz, double AxisX, double AxisY, double AxisZ, double Angle, out double outVx, out double outVy, out double outVz)
        {
            double[] RMatrix;

            //회전하고자 하는 축과 각도로 회전시키는 매트릭스 계산
            MakeAxisAndAngleToRMatrix(AxisX, AxisZ, AxisZ, Angle, out RMatrix);

            outVx = RMatrix[0] * inVx + RMatrix[1] * inVy + RMatrix[2] * inVz;
            outVy = RMatrix[3] * inVx + RMatrix[4] * inVy + RMatrix[5] * inVz;
            outVz = RMatrix[6] * inVx + RMatrix[7] * inVy + RMatrix[8] * inVz;
        }

        public List<ActualWeldingPathRecord> GetLastWeldingPath()
        {
            List<ActualWeldingPathRecord> tempdata = new List<ActualWeldingPathRecord>();

            for (int i = 0; i < WeldingPathRecord.Count; i++)
            {
                tempdata.Add((ActualWeldingPathRecord)WeldingPathRecord[i].Clone());
            }

            return tempdata;
        }


    }
}