﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.IO;
using System.IO.Ports;

namespace OpenBlockWeldingRobot
{

    class DataEX_AdvantechIO
    {
        public int test;

        //여기에 데이터교환 필요한 변수 정의

        //상태변수
        public byte IOModuleStatus;

        public DateTime[] IOModuleCommTime = new DateTime[8];      //마지막 통신 성공 시간

        //DO 출력 변수. 메인스레드에서 여기에 값을 쓰면 스레드에서 IO출력으로 내보냄
        public int[] IOModuleOutputData = new int[64];  //0:해당포트 출력 끊음, 1:해당포트 출력 내보냄 

        //DI 모니터링 변수. 스레드에서 통신으로 받아온 값을 여기에 씀. 메인스레드에서 읽어감
        public int[] IOModuleMonitoringDI = new int[64];  //0:해당포트 입력 없음, 1:해당포트에 입력 들어오고있음

        //DO 모니터링 변수. 스레드에서 통신으로 받아온 값을 여기에 씀. 메인스레드에서 읽어감
        public int[] IOModuleMonitoringDO = new int[64];  //0:해당포트 입력 없음, 1:해당포트에 입력 들어오고있음

        public DataEX_AdvantechIO()
        {
            for (int i = 0; i < 8; i++) IOModuleCommTime[i] = DateTime.Now;

            for(int i=0;i<64;i++)
            {
                IOModuleOutputData[i] = 0;
                IOModuleMonitoringDI[i] = 0;
                IOModuleMonitoringDO[i] = 0;
            }

        }


    }




    class ThreadClass_AdvantechIO
    {
        public DataEX_AdvantechIO IOModuleData;
        public Thread IOthread;
        private bool threadContinue;

        //시퀀스 상태변수
        public string IOCommunicationSeq = "초기화-시작";
        //초기화 로그
        public StringBuilder IOInitLog = new StringBuilder();

        SerialPort IOModuleSerialPort;

        //포트번호
        string PortName;
        //통신속도
        int BaudRate;


        int InitTryCount = 0;
        int MaxInitTryCount = 10;

        int TransmissionTimeInterval = 10; //시리얼 명령어를 전송하고 다음 명령어 전송할 때 까지 시간간격 회신 시간까지 고려하여 적당하게 넣어야 함 단위 ms


        public string tempmonistr1, tempmonistr2, tempmonistr3;



        //생성자 1
        //public ThreadClass_AdvantechIO()
        //{

        //}

        //생성자 2
        public ThreadClass_AdvantechIO(DataEX_AdvantechIO atemp, string COMname, int COMspeed)
        {
            IOModuleData = atemp;
            IOModuleSerialPort = new SerialPort();

            PortName = COMname;
            BaudRate = COMspeed;

            //스래드클래스의 함수를 스래드로 돌림
            IOthread = new Thread(new ThreadStart(threadfunc));
            IOthread.Start();
        }


        //스레드 함수
        public void threadfunc()
        {
            threadContinue = true;
            char[] txdata, rxdata, tempchar;
            string tempstr;
            byte tempb1, tempb2;
            byte[] tempbarr = { 0};
            int tempi = 0;

            while (threadContinue)
            {
                //여기에 통신관련 코드 구현
                
                switch (IOCommunicationSeq)
                {
                    case "시작대기":
                        //초기상태. 아무것도 안함
                        break;

                    case "초기화-시작":
                        //외부에서 "접속시작-0" 단계로 바꾸면 접속절차 시작함
                        IOInitLog.Clear();
                        IOInitLog.AppendLine("IO모듈-초기화 시작");
                        IOInitLog.AppendLine("IO모듈-통신포트 생성 시작");
                        
                        //IOModuleSerialPort.PortName = "COM1";
                        //IOModuleSerialPort.BaudRate = 38400;
                        IOModuleSerialPort.PortName = PortName;
                        IOModuleSerialPort.BaudRate = BaudRate;
                        IOModuleSerialPort.Parity = Parity.None;
                        IOModuleSerialPort.StopBits = StopBits.One;
                        IOModuleSerialPort.DataBits = 8;
                        IOModuleSerialPort.Handshake = Handshake.None;
                        IOModuleSerialPort.RtsEnable = true;
                        IOModuleSerialPort.DtrEnable = true;


                        try
                        {
                            IOModuleSerialPort.Open();
                            IOInitLog.AppendLine("IO모듈-통신포트 생성 성공");

                            IOInitLog.AppendLine("IO모듈-1번모듈 점검 시작");
                            txdata = new char[]{ '$', '0', '1', '6', '\r' };
                            IOModuleSerialPort.Write(txdata, 0, 5);
                            InitTryCount = 0;

                            IOCommunicationSeq = "초기화-1번모듈 통신테스트 시작";
                        }
                        catch
                        {
                            IOInitLog.AppendLine("IO모듈-통신포트 생성 실패");
                            IOCommunicationSeq = "초기화-실패";
                        }


                        break;

                    case "초기화-1번모듈 통신테스트 시작":
                        //1번모듈에서 값 회신이 왔는지 체크함

                        tempi = CommunicationTest(1);

                        if(tempi==1)
                        {
                            IOInitLog.AppendLine("IO모듈-1번모듈 점검 성공");
                            IOInitLog.AppendLine("IO모듈-2번모듈 점검 시작");

                            txdata = new char[] { '$', '0', '2', '6', '\r' };
                            IOModuleSerialPort.Write(txdata, 0, 5);
                            InitTryCount = 0;
                            IOCommunicationSeq = "초기화-2번모듈 통신테스트 시작";

                            //IOCommunicationSeq = "메인반복-시작";
                            break;
                        }
                        else if(tempi==2)
                        {
                            IOInitLog.AppendLine("IO모듈-1번모듈 점검 실패");
                            IOCommunicationSeq = "초기화-실패";

                            //IOCommunicationSeq = "메인반복-시작";
                            break;
                        }
                        else if(tempi == 3)
                        {
                            break;
                        }
                        
                        break;

                    case "초기화-2번모듈 통신테스트 시작":
                        //2번모듈에서 값 회신이 왔는지 체크함

                        tempi = CommunicationTest(2);

                        if (tempi == 1)
                        {
                            IOInitLog.AppendLine("IO모듈-2번모듈 점검 성공");
                            IOInitLog.AppendLine("IO모듈-초기화 성공");
                            IOCommunicationSeq = "메인반복-시작";

                            break;
                        }
                        else if (tempi == 2)
                        {
                            IOInitLog.AppendLine("IO모듈-2번모듈 점검 실패");
                            IOCommunicationSeq = "초기화-실패";

                            break;
                        }
                        else if (tempi == 3)
                        {
                            break;
                        }

                        break;

                    case "초기화-실패":
                        
                        break;

                    case "메인반복-시작":
                        

                        IOCommunicationSeq = "메인반복-#1 모니터링";
                        break;

                    case "메인반복-#1 모니터링":
                        //#2 지령회신 처리한 다음 #1 모니터링요청 날림

                        //회신처리
                        rxdata = IOModuleSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length == 2)
                        {
                            if((rxdata[0]=='>')&& (rxdata[0] == '\r'))
                            {
                                //이전패킷 정상처리됨

                            }else
                            {
                                //통신이 안되거나 비정상처리됨
                            }
                        }
                        else
                        {
                            //통신이 안되거나 비정상처리됨
                        }
                        

                        //패킷전송
                        txdata = new char[] { '$', '0', '1', '6', '\r' };
                        IOModuleSerialPort.Write(txdata, 0, 5);

                        IOCommunicationSeq = "메인반복-#1 지령";
                        break;

                    case "메인반복-#1 지령":
                        //#1 모니터링회신 처리한 다음 #1 지령 날림

                        //회신처리
                        rxdata = IOModuleSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length == 8)
                        {
                            if ((rxdata[0] == '!') && (rxdata[5] == '0') && (rxdata[6] == '0') && (rxdata[7] == '\r'))
                            {
                                try
                                {
                                    tempb1 = Convert.ToByte(rxdata[1].ToString() + rxdata[2].ToString(), 16);
                                    tempb2 = Convert.ToByte(rxdata[3].ToString() + rxdata[4].ToString(), 16);

                                    tempmonistr2 = rxdata[1].ToString() + rxdata[2].ToString();
                                    tempmonistr3 = rxdata[3].ToString() + rxdata[4].ToString();


                                    for (int i=0; i<8; i++)
                                    {
                                        if(tempb1%2==1) IOModuleData.IOModuleMonitoringDO[i] = 1;else IOModuleData.IOModuleMonitoringDO[i] = 0;
                                        tempb1 = (byte)(tempb1 / 2);

                                        if (tempb2 % 2 == 1) IOModuleData.IOModuleMonitoringDI[i] = 1; else IOModuleData.IOModuleMonitoringDI[i] = 0;
                                        tempb2 = (byte)(tempb2 / 2);
                                    }
                                }
                                catch
                                {

                                }
                            }
                        }
                        

                        //패킷전송
                        tempbarr[0] = 0;
                        for (int i=0; i<8; i++)
                        {
                            if(IOModuleData.IOModuleOutputData[i]==1)
                            {
                                tempbarr[0] = (byte)(tempbarr[0] + (1 << i));
                            }
                        }
                        tempchar = BitConverter.ToString(tempbarr).ToCharArray();
                        txdata = new char[] { '#', '0', '1', '0', '0', tempchar[0], tempchar[1], '\r' };
                        IOModuleSerialPort.Write(txdata, 0, 8);

                        tempmonistr1 = tempchar[0].ToString()+ tempchar[1].ToString();

                        IOCommunicationSeq = "메인반복-#2 모니터링";
                        break;

                    case "메인반복-#2 모니터링":
                        //#1 지령회신 처리한 다음 #2 모니터링요청 날림

                        //회신처리
                        rxdata = IOModuleSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length == 2)
                        {
                            if ((rxdata[0] == '>') && (rxdata[0] == '\r'))
                            {
                                //이전패킷 정상처리됨

                            }
                            else
                            {
                                //통신이 안되거나 비정상처리됨
                            }
                        }
                        else
                        {
                            //통신이 안되거나 비정상처리됨
                        }


                        //패킷전송
                        txdata = new char[] { '$', '0', '2', '6', '\r' };
                        IOModuleSerialPort.Write(txdata, 0, 5);

                        IOCommunicationSeq = "메인반복-#2 지령";
                        break;

                    case "메인반복-#2 지령":
                        //#2 모니터링회신 처리한 다음 #2 지령 날림

                        //회신처리
                        rxdata = IOModuleSerialPort.ReadExisting().ToCharArray();

                        if (rxdata.Length == 8)
                        {
                            if ((rxdata[0] == '!') && (rxdata[5] == '0') && (rxdata[6] == '0') && (rxdata[7] == '\r'))
                            {
                                try
                                {
                                    tempb1 = Convert.ToByte(rxdata[1].ToString() + rxdata[2].ToString(), 16);
                                    tempb2 = Convert.ToByte(rxdata[3].ToString() + rxdata[4].ToString(), 16);

                                    for (int i = 0; i < 8; i++)
                                    {
                                        if (tempb1 % 2 == 1) IOModuleData.IOModuleMonitoringDO[i + 8] = 1; else IOModuleData.IOModuleMonitoringDO[i + 8] = 0;
                                        tempb1 = (byte)(tempb1 / 2);

                                        if (tempb2 % 2 == 1) IOModuleData.IOModuleMonitoringDI[i + 8] = 1; else IOModuleData.IOModuleMonitoringDI[i + 8] = 0;
                                        tempb2 = (byte)(tempb2 / 2);
                                    }
                                }
                                catch
                                {

                                }
                            }
                        }



                        //패킷전송
                        tempbarr[0] = 0;
                        for (int i = 0; i < 8; i++)
                        {
                            if (IOModuleData.IOModuleOutputData[i+8] == 1)
                            {
                                tempbarr[0] = (byte)(tempbarr[0] + (1 << i));
                            }
                        }
                        tempchar = BitConverter.ToString(tempbarr).ToCharArray();
                        txdata = new char[] { '#', '0', '2', '0', '0', tempchar[0], tempchar[1], '\r' };
                        IOModuleSerialPort.Write(txdata, 0, 8);

                        IOCommunicationSeq = "메인반복-#1 모니터링";
                        break;

                    default:
                        break;

                }

                Thread.Sleep(TransmissionTimeInterval);


                
            }
        }

        //스레드 종료 호출
        public void threadStop()
        {
            threadContinue = false;
        }

        //io모듈 테스트하는 함수임. 1:통신성공, 2:통신실패, 3:테스트계속
        int CommunicationTest(int ID)
        {
            char[] txdata, rxdata;
            byte tempb1, tempb2;
            InitTryCount++;

            //통신값이 들어왔는지 체크함
            rxdata = IOModuleSerialPort.ReadExisting().ToCharArray();

            if (rxdata.Length != 8)
            {
                if(InitTryCount>MaxInitTryCount)
                {
                    return 2;
                }
                else
                {
                    txdata = new char[] { '$', '0', '1', '6', '\r' };
                    IOModuleSerialPort.Write(txdata, 0, 5);
                    return 3;
                }
            }

            if ((rxdata[0] != '!') || (rxdata[5] != '0') || (rxdata[6] != '0') || (rxdata[7] != '\r'))
            {
                if (InitTryCount > MaxInitTryCount)
                {
                    return 2;
                }
                else
                {
                    txdata = new char[] { '$', '0', '1', '6', '\r' };
                    IOModuleSerialPort.Write(txdata, 0, 5);
                    return 3;
                }
            }

            try
            {
                tempb1 = Convert.ToByte(rxdata[1].ToString() + rxdata[2].ToString(), 16);
                tempb2 = Convert.ToByte(rxdata[3].ToString() + rxdata[4].ToString(), 16);
            }
            catch
            {
                if (InitTryCount > MaxInitTryCount)
                {
                    return 2;
                }
                else
                {
                    txdata = new char[] { '$', '0', '1', '6', '\r' };
                    IOModuleSerialPort.Write(txdata, 0, 5);
                    return 3;
                }
            }

            //통신 성공
            return 1;

        }


    }
}
