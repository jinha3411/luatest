﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//추가된 네임스페이스
using System.Threading;
using System.IO;

namespace OpenBlockWeldingRobot
{
    //메인 Form1 클래스의 파샬클래스
    //메인클래스 공동작업이 필요 한 경우 동시에 동일한 파일 수정하는것을 막기위해 만들었음.
    //여기에는 주로 자동용접시퀀스 관련해서 작성
    public partial class Form1
    {
        //제어용 변수들

        byte[] WorkClientIP = new byte[4];                           ////현재 작업지령 내린 클라이언트 IP
        ushort WorkClientPort;                                       ////현재 작업지령 내린 클라이언트 포트
        string WorkClientID;                                         ////현재 작업지령 내린 클라이언트 ID
        public DateTime WorkClient_LastReqTime = DateTime.Now;
        
        RobotWeldAngle tempAngle = new RobotWeldAngle();


        //자동작업용 변수들     
        RobotPoseData RDP_TCP_BACK = new RobotPoseData(3, 50, -1, 0, 0, 0, 0, 0);

        //RobotPoseData RDP_TCP_Left1 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_TCP_Left2 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_TCP_Left3 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_TCP_Right1 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_TCP_Right2 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_TCP_Right3 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_TCP_Middle1 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        RobotPoseData RDP_TCP_Middle2 = new RobotPoseData(2, 100, 700, -80, 100, -135, 0, -90);
        //RobotPoseData RDP_TCP_Middle3 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Left1 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Left2 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Left3 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Right1 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Right2 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Right3 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        //RobotPoseData RDP_Joint_Middle1 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);
        RobotPoseData RDP_Joint_Middle2 = new RobotPoseData(1, 20, -0.9, -84.9, -102.4, -82.7, 90.0, -0.9);
        //RobotPoseData RDP_Joint_Middle3 = new RobotPoseData(1, 20, -3, -120, -147, 76, 91, -2);

        //와이어컷팅용 자세. RDP_Joint_WireCut0 -> RDP_Joint_WireCut1 -> RDP_TCP_WireCut2 -> RDP_TCP_WireCut3 순서로 움직임
        //RDP_TCP_WireCut2, RDP_TCP_WireCut3 자세는 설정에 저장되어있는값 불러옴
        RobotPoseData RDP_TCP_WireCut2 = new RobotPoseData(2, 100, 185.8, -222.5, 70.4, 177.4, -7.7, -80.5);  //설정값에 저장된 데이터로 갱신됨
        RobotPoseData RDP_TCP_WireCut3 = new RobotPoseData(2, 100, 167.3, -115.1, 38.9, 173.4, -0.4, -82.3);  //설정값에 저장된 데이터로 갱신됨
        RobotPoseData RDP_Joint_WireCut0 = new RobotPoseData(1, 20, -1.7, -82.5, -84.9, -120.6, 82.9, 4.8);
        RobotPoseData RDP_Joint_WireCut1 = new RobotPoseData(1, 20, -9.8, -81.3, -81.9, -151.8, 70.8, -7.9);

        //TCP 확인용 자세. RDP_Joint_Home0 -> RDP_Joint_Home1 -> RDP_TCP_Home2 순서로 움직임
        //RDP_TCP_Home2 자세는 설정에 저장되어있는값 불러옴
        RobotPoseData RDP_TCP_Home2 = new RobotPoseData(2, 100, 272.1, -107.6, 75.6, -178.2, -2.0, -66.8);  //설정값에 저장된 데이터로 갱신됨
        RobotPoseData RDP_Joint_Home0 = new RobotPoseData(1, 20, -1.7, -82.5, -84.9, -120.6, 82.9, 4.8);
        RobotPoseData RDP_Joint_Home1 = new RobotPoseData(1, 20, 4.5, -83.4, -79.7, -148.2, 76.0, -12.5);

        //아래보기-위보기 전환용 중간경로. 0이 아래보기, 3가 위보기
        RobotPoseData RDP_TCP_DirChange0 = new RobotPoseData(2, 100, 677, -88, 61.7, -134.7, -2.2, -93.8);
        RobotPoseData RDP_TCP_DirChange1 = new RobotPoseData(2, 100, 704.5, -103.9, 219.4, -95.1, 2.2, -94.9);
        RobotPoseData RDP_TCP_DirChange2 = new RobotPoseData(2, 100, 565.4, -103.2, 676.2, -46, 5.7, -91);
        RobotPoseData RDP_TCP_DirChange3 = new RobotPoseData(2, 100, 672, -113.8, 458.7, -37.2, -2.5, -97);
        RobotPoseData RDP_Joint_DirChange0 = new RobotPoseData(1, 20, 2.6, -80.2, -112.6, -77.2, 87.7, 6.4);
        RobotPoseData RDP_Joint_DirChange1 = new RobotPoseData(1, 20, 0.8, -79.4, -157.1, 6.4, 88, 5.8);
        RobotPoseData RDP_Joint_DirChange2 = new RobotPoseData(1, 20, 1, -86.6, -157, 62.6, 88.1, 5.8);
        RobotPoseData RDP_Joint_DirChange3 = new RobotPoseData(1, 20, -1.2, -154.8, -130.5, 113.2, 84.5, -3.3);

        //로봇 작업용 기본자세
        RobotPoseData RDP_TCP_LCP_B = new RobotPoseData(2, 100, 740, 0, 440, 135, -15, 90);
        RobotPoseData RDP_TCP_LCP_LB = new RobotPoseData(2, 100, 740, 50, 440, 135, -45, 90);
        RobotPoseData RDP_TCP_LCP_L = new RobotPoseData(2, 100, 740, 100, 440, -135, -90, 0);
        RobotPoseData RDP_TCP_LCP_LU = new RobotPoseData(2, 100, 740, 100, 440, -45, -45, -90);
        RobotPoseData RDP_TCP_U_L = new RobotPoseData(2, 100, 760, 100, 440, -46, -10.5, -79.3);
        RobotPoseData RDP_TCP_L_U = new RobotPoseData(2, 100, 700, 130, 220, -80, 0, -45);
        RobotPoseData RDP_TCP_L = new RobotPoseData(2, 100, 700, 130, 210, -90, 0, -45);
        RobotPoseData RDP_TCP_L_B = new RobotPoseData(2, 100, 700, 130, 180, -100, 0, -45);
        RobotPoseData RDP_TCP_L_BB = new RobotPoseData(2, 100, 700, 130, 140, -110, 0, -45.0);
        //RobotPoseData RDP_TCP_BL = new RobotPoseData(2, 100, 700.0, 130.0, 100.1, -135.2, 25.4, -74.7); //예각용
        //RobotPoseData RDP_TCP_BL = new RobotPoseData(2, 100, 700.0, 130.0, 100.0, -125.3, 30.0, -54.7); //45도
        RobotPoseData RDP_TCP_BL = new RobotPoseData(2, 100, 663.3, 137.6, 110.8, -125.4, 4.0, -48.4); //45도
        //RobotPoseData RDP_TCP_B_L = new RobotPoseData(2, 100, 700, 0, 100, -134, 10.5, -79.3); //15도 회전
        //RobotPoseData RDP_TCP_B_L = new RobotPoseData(2, 100, 700.0, 0.0, 100.0, -133.2, 14.0, -75.6); //20도 회전
        RobotPoseData RDP_TCP_B_L = new RobotPoseData(2, 100, 700.0, 0.0, 100.0, -130.9, 20.7, -67.8); //30도 회전
        RobotPoseData RDP_TCP_B = new RobotPoseData(2, 100, 700, -70, 100, -135, 0, -90);
        RobotPoseData RDP_TCP_B_RR = new RobotPoseData(2, 100, 700, -230.1, 100, -129.3, -23.9, -116.3);
        RobotPoseData RDP_TCP_BR = new RobotPoseData(2, 100, 700.0, -290.5, 100.3, -127.2, -34.7, -121.1);
        RobotPoseData RDP_TCP_R_BB = new RobotPoseData(2, 100, 720, -320, 100, -110, 0, -135);
        RobotPoseData RDP_TCP_R_B = new RobotPoseData(2, 100, 720, -320, 120, -100, 0, -135);
        RobotPoseData RDP_TCP_R = new RobotPoseData(2, 100, 720, -320, 220, -90, 0, -135);
        RobotPoseData RDP_TCP_R_U = new RobotPoseData(2, 100, 760, -320, 260, -80, 0, -135);
        RobotPoseData RDP_TCP_U_RR = new RobotPoseData(2, 100, 760, -260, 500, -45, 30, -90);
        RobotPoseData RDP_TCP_RCP_RU = new RobotPoseData(2, 100, 740, -260, 440, -45, 45, -90);
        RobotPoseData RDP_TCP_RCP_R = new RobotPoseData(2, 100, 740, -260, 440, -45, 89, -90);
        RobotPoseData RDP_TCP_RCP_RB = new RobotPoseData(2, 100, 740, -260, 440, 135, 45, 90);
        RobotPoseData RDP_TCP_RCP_B = new RobotPoseData(2, 100, 740, -290, 440, 135, 15, 90);

        RobotPoseData RDP_Joint_LCP_B = new RobotPoseData(1, 20, 38.4, -79.6, -101.8, 1.4, 51.6, -165);
        RobotPoseData RDP_Joint_LCP_LB = new RobotPoseData(1, 20, 21.6, -80.5, -104.8, 5.3, 68.4, -135);
        RobotPoseData RDP_Joint_LCP_L = new RobotPoseData(1, 20, 3.1, -92.7, -120.9, 33.6, 86.9, -90);
        RobotPoseData RDP_Joint_LCP_LU = new RobotPoseData(1, 20, 4.1, -122.2, -135.3, 77.5, 85.9, -45);
        RobotPoseData RDP_Joint_U_L = new RobotPoseData(1, 20, 8.4, -143.3, -127.3, 89.7, 92.2, -10.6);
        RobotPoseData RDP_Joint_L_U = new RobotPoseData(1, 20, -15.2, -126.1, -125.7, 17.2, 135.3, -45.1);
        RobotPoseData RDP_Joint_L = new RobotPoseData(1, 20, -13.8, -110.4, -123.4, -8.8, 127.2, -49.4);
        RobotPoseData RDP_Joint_L_B = new RobotPoseData(1, 20, -10.9, -103.8, -119.3, -25.5, 118.4, -50.5);
        RobotPoseData RDP_Joint_L_BB = new RobotPoseData(1, 20, -6.9, -103.8, -117.2, -33, 109.4, -49.2);
        //RobotPoseData RDP_Joint_BL = new RobotPoseData(1, 20, -3.1, -98.9, -98.2, -81.7, 113.9, -20.3); //예각용

        //RobotPoseData RDP_Joint_BL = new RobotPoseData(1, 20, -10.4, -112.0, -89.6, -83.8, 117.7, -46.8); //45도

        RobotPoseData RDP_Joint_BL = new RobotPoseData(1, 20, 0.1, -92.4, -106.1, -66.9, 99.3, -40.8); //45도
        //RobotPoseData RDP_Joint_B_L = new RobotPoseData(1, 20, -5.9, -91.1, -100.4, -80.6, 100.4, -16.7); //15도 회전
        //RobotPoseData RDP_Joint_B_L = new RobotPoseData(1, 20, -10.3, -95.5, -98.4, -80.3, 103.5, -24.9); //20도 회전
        RobotPoseData RDP_Joint_B_L = new RobotPoseData(1, 20, -15.8, -104.1, -91.1, -84.6, 108.8, -38.9); //30도 회전
        RobotPoseData RDP_Joint_B = new RobotPoseData(1, 20, 0.5, -83.6, -103.3, -83, 90, 0.5);
        RobotPoseData RDP_Joint_B_RR = new RobotPoseData(1, 20, 17.8, -83, -102, -98, 69, 45.3);
        RobotPoseData RDP_Joint_BR = new RobotPoseData(1, 20, 20.0, -89.3, -98.5, -105.6, 62.6, 54.4);
        RobotPoseData RDP_Joint_R_BB = new RobotPoseData(1, 20, 11.9, -80.8, -140.7, -34.2, 69.3, 54.3);
        RobotPoseData RDP_Joint_R_B = new RobotPoseData(1, 20, 18.7, -86.7, -153.1, -13.1, 59, 59);
        RobotPoseData RDP_Joint_R = new RobotPoseData(1, 20, 24.2, -79.2, -154.7, -16.6, 48.6, 61.8);
        RobotPoseData RDP_Joint_R_U = new RobotPoseData(1, 20, 23.6, -104, -156, 17.4, 40.3, 55.7);
        RobotPoseData RDP_Joint_U_RR = new RobotPoseData(1, 20, -8.3, -150.7, -124.6, 95.3, 98.3, 30);
        RobotPoseData RDP_Joint_RCP_RU = new RobotPoseData(1, 20, 3.9, -148.2, -132.2, 100.4, 86.1, 45);
        RobotPoseData RDP_Joint_RCP_R = new RobotPoseData(1, 20, 31.8, -119, -141.8, 80.8, 58.2, 89);
        RobotPoseData RDP_Joint_RCP_RB = new RobotPoseData(1, 20, 31.1, -86, -125, 31, 58.9, 135);
        RobotPoseData RDP_Joint_RCP_B = new RobotPoseData(1, 20, 13.6, -82.7, -107.9, 10.6, 76.4, 165);


        //용접DB 저장 변수
        Dictionary<string, string> WeldDatabase = new Dictionary<string, string>();


        //셀타입별 변수
        Dictionary<string, int> CellTypeData = new Dictionary<string, int>();
        Dictionary<string, int> CellTypePose = new Dictionary<string, int>();
        RobotPoseData[] RDP_TCP = new RobotPoseData[23];
        RobotPoseData[] RDP_Joint = new RobotPoseData[23];

        //용접셀 정보
        bool LeftWeldFlag = false;
        string CellTypeName_Left = "";
        bool[] WeldLineFlag_Left = new bool[32];
        double[] WeldLineWidth_Left = new double[32];
        double[] WeldLineGap_Left = new double[32];
        double[] WeldCellPara_Left = new double[20];

        bool RightWeldFlag = false;
        string CellTypeName_Right = "";
        bool[] WeldLineFlag_Right = new bool[32];
        double[] WeldLineWidth_Right = new double[32];
        double[] WeldLineGap_Right = new double[32];
        double[] WeldCellPara_Right = new double[20];


        //직접교시점 저장 변수
        RobotPoseData[] AutoWeld_DTPoint_Left_JointPose = new RobotPoseData[32];    //왼쪽셀 직접교시 좌표 축좌표로 기록하는 변수
        RobotPoseData[] AutoWeld_DTPoint_Left_TCPPose = new RobotPoseData[32];      //왼쪽셀 직접교시 좌표 직교좌표로 기록하는 변수

        RobotPoseData[] AutoWeld_DTPoint_Right_JointPose = new RobotPoseData[32];   //오른쪽셀 직접교시 좌표 축좌표로 기록하는 변수
        RobotPoseData[] AutoWeld_DTPoint_Right_TCPPose = new RobotPoseData[32];     //오른쪽셀 직접교시 좌표 직교좌표로 기록하는 변수
        bool[] DTPointLeftOK = new bool[32];
        bool[] DTPointRightOK = new bool[32];

        //터치센싱위치 저장 변수
        RobotPoseData[] AutoWeld_TSPoint_Left_JointPose = new RobotPoseData[32];
        RobotPoseData[] AutoWeld_TSPoint_Left_TCPPose = new RobotPoseData[32];
        RobotPoseData[] AutoWeld_TSPoint_Right_JointPose = new RobotPoseData[32];
        RobotPoseData[] AutoWeld_TSPoint_Right_TCPPose = new RobotPoseData[32];

        //계산된 용접점 저장 변수
        RobotPoseData[] AutoWeld_WedlPoint_Left = new RobotPoseData[32];
        RobotPoseData[] AutoWeld_WedlPoint_Right = new RobotPoseData[32];

        //계산된 연속용접 리스트
        List<WeldInformation> AutoWeld_WeldInformationList = new List<WeldInformation>();

        //오른쪽셀 바닥 0번포인트까지 경로 생성
        List<WeldMainCondition> RightTempLine = new List<WeldMainCondition>();

        //터치센싱 관련 임시좌표들
        RobotPoseData Touchtemp1 = new RobotPoseData();
        RobotPoseData Touchtemp2 = new RobotPoseData();
        RobotPoseData Touchtemp3 = new RobotPoseData();
        RobotPoseData Touchtemp4 = new RobotPoseData();
        RobotPoseData Touchtemp5 = new RobotPoseData();

        //시퀀스 상태변수
        string AutoSequenceState = "대기";

        //직접교시 시퀀스 상태변수
        string AutoDTSubSeq = "대기";
        string AutoDTSubSeq_Buffer = "대기";
        bool AutoDTPoseRecordFlag = false;
        bool AutoDTPoseNextFlag = false;
        bool AutoDTPoseMoveFlag = false;
        bool AutoDTEndFlag = false;

        //터치센싱 시퀀스 상태변수
        bool AutoTSStartFlag = false;
        string AutoTSSubSeq = "대기";

        //터치센싱과 용접 자동으로 진행하는 플래그
        bool AutoTouchAndWeldFlag = false;


        //용접단계 시퀀스 상태변수
        bool AutoWeldStartFlag = false;


        //용접실행 시퀀스에서 사용하는 플래그
        bool AutoWeldSubNextWeldingStopFlag = false;
        bool AutoWeldSubNextWeldingStartFlag = false;

        bool ArcFlag = false;
        int AutoWeldCount = 0;
        string AutoWeldingSubState = "대기";

        //직접교시 OFF 시간 기록하는 변수. 일정시간 대기하기 위해
        DateTime DTOffTime = DateTime.Now;
        DateTime ErrorOccurTime = DateTime.Now;
        DateTime finchingTime = DateTime.Now;
        DateTime cut1 = DateTime.Now;
        DateTime cut2 = DateTime.Now;
        
        List<List<ActualWeldingPathRecord>> AutoWeldingPathRecord_ALL = new List<List<ActualWeldingPathRecord>>();
        List<ActualWeldingPathRecord> AutoWeldingPathRecord_Single = new List<ActualWeldingPathRecord>();

        int AutoWeldSub_TotalLineCount = 0;
        double AutoWeldSub_TotalLineLength = 0;
        double AutoWeldSub_TotalWeldTime = 0;
        int AutoWeldSub_NowLineCount = 0;
        double AutoWeldSub_LeftNowLineLength = 0;
        double AutoWeldSub_LeftNowWeldTime = 0;
        double AutoWeldSub_LeftTotalLineLength = 0;
        double AutoWeldSub_LeftTotalWeldTime = 0;


        //셀정보 기록하는 함수. 일단 셀이름별 직접교시점 개수 저장
        void CellDataRecord()
        {
            //셀 타입별로 용접라인 개수 저장. 나중에 꺼내쓰기 위해
            //검색키는 "[셀ID]_ WeldLine"
            CellTypeData.Add("ST1_WeldLine", 2);
            CellTypeData.Add("ST2_WeldLine", 2);
            CellTypeData.Add("ST3_WeldLine", 1);
            CellTypeData.Add("ST3+CP3F_WeldLine", 3);
            CellTypeData.Add("ST3+CP4F_WeldLine", 3);
            CellTypeData.Add("ST4_WeldLine", 1);
            CellTypeData.Add("ST5_WeldLine", 2);
            CellTypeData.Add("ST1+CP1F_WeldLine", 3);
            CellTypeData.Add("ST1+CP1B_WeldLine", 2);
            CellTypeData.Add("ST1+CP2F_WeldLine", 3);
            CellTypeData.Add("ST1+CP2B_WeldLine", 2);
            CellTypeData.Add("ST2+CP1F_WeldLine", 3);
            CellTypeData.Add("ST2+CP1B_WeldLine", 2);
            CellTypeData.Add("ST2+CP2F_WeldLine", 3);
            CellTypeData.Add("ST2+CP2B_WeldLine", 2);
            CellTypeData.Add("ST3+CP3B_WeldLine", 2);
            CellTypeData.Add("ST3+CP4B_WeldLine", 2);
            CellTypeData.Add("ST4+CP3F_WeldLine", 3);
            CellTypeData.Add("ST4+CP3B_WeldLine", 2);
            CellTypeData.Add("ST4+CP4F_WeldLine", 3);
            CellTypeData.Add("ST4+CP4B_WeldLine", 2);
            CellTypeData.Add("ST4+CP5F_WeldLine", 3);
            CellTypeData.Add("ST4+CP5B_WeldLine", 2);
            CellTypeData.Add("ST4+CP6F_WeldLine", 3);
            CellTypeData.Add("ST4+CP6B_WeldLine", 2);
            CellTypeData.Add("ST5+CP7F_WeldLine", 3);
            CellTypeData.Add("ST5+CP7B_WeldLine", 2);
            CellTypeData.Add("ST3+CP8F_WeldLine", 3);
            CellTypeData.Add("ST3+CP9F_WeldLine", 3);
            CellTypeData.Add("ST3+CP9B_WeldLine", 2);
            CellTypeData.Add("ST4+CP9B_WeldLine", 2);
            CellTypeData.Add("ST3+CP10F_WeldLine", 3);
            CellTypeData.Add("ST4+CP11F_WeldLine", 3);
            CellTypeData.Add("ST4+CP12F_WeldLine", 3);

            //셀 타입별로 교시포인트 개수 저장. 나중에 꺼내쓰기 위해
            //검색키는 "[셀ID]_DTPoint"
            CellTypeData.Add("ST1_DTPoint", 2);
            CellTypeData.Add("ST2_DTPoint", 3);
            CellTypeData.Add("ST3_DTPoint", 1);
            CellTypeData.Add("ST3+CP3F_DTPoint", 5);
            CellTypeData.Add("ST3+CP4F_DTPoint", 6);
            CellTypeData.Add("ST4_DTPoint", 1);
            CellTypeData.Add("ST5_DTPoint", 3);
            CellTypeData.Add("ST1+CP1F_DTPoint", 4);
            CellTypeData.Add("ST1+CP1B_DTPoint", 2);
            CellTypeData.Add("ST1+CP2F_DTPoint", 4);
            CellTypeData.Add("ST1+CP2B_DTPoint", 2);
            CellTypeData.Add("ST2+CP1F_DTPoint", 3);
            CellTypeData.Add("ST2+CP1B_DTPoint", 3);
            CellTypeData.Add("ST2+CP2F_DTPoint", 4);
            CellTypeData.Add("ST2+CP2B_DTPoint", 3);
            CellTypeData.Add("ST3+CP3B_DTPoint", 3);
            CellTypeData.Add("ST3+CP4B_DTPoint", 3);
            CellTypeData.Add("ST4+CP3F_DTPoint", 5);
            CellTypeData.Add("ST4+CP3B_DTPoint", 3);
            CellTypeData.Add("ST4+CP4F_DTPoint", 6);
            CellTypeData.Add("ST4+CP4B_DTPoint", 3);
            CellTypeData.Add("ST4+CP5F_DTPoint", 5);
            CellTypeData.Add("ST4+CP5B_DTPoint", 3);
            CellTypeData.Add("ST4+CP6F_DTPoint", 6);
            CellTypeData.Add("ST4+CP6B_DTPoint", 3);
            CellTypeData.Add("ST5+CP7F_DTPoint", 5);
            CellTypeData.Add("ST5+CP7B_DTPoint", 2);
            CellTypeData.Add("ST3+CP8F_DTPoint", 5);
            CellTypeData.Add("ST3+CP9F_DTPoint", 6);
            CellTypeData.Add("ST3+CP9B_DTPoint", 4);
            CellTypeData.Add("ST4+CP9B_DTPoint", 4);
            CellTypeData.Add("ST3+CP10F_DTPoint", 6);
            CellTypeData.Add("ST4+CP11F_DTPoint", 4);
            CellTypeData.Add("ST4+CP12F_DTPoint", 5);

            //로봇의 디폴트 포즈 저장
            RDP_TCP[0] = TCP_LCP_B();
            RDP_TCP[1] = TCP_LCP_LB();
            RDP_TCP[2] = TCP_LCP_L();
            RDP_TCP[3] = TCP_LCP_LU();
            RDP_TCP[4] = TCP_U_L();
            RDP_TCP[5] = TCP_L_U();
            RDP_TCP[6] = TCP_L();
            RDP_TCP[7] = TCP_L_B();
            RDP_TCP[8] = TCP_L_BB();
            RDP_TCP[9] = TCP_BL();
            RDP_TCP[10] = TCP_B_L();
            RDP_TCP[11] = TCP_B();
            RDP_TCP[12] = TCP_B_RR();
            RDP_TCP[13] = TCP_BR();
            RDP_TCP[14] = TCP_R_BB();
            RDP_TCP[15] = TCP_R_B();
            RDP_TCP[16] = TCP_R();
            RDP_TCP[17] = TCP_R_U();
            RDP_TCP[18] = TCP_U_RR();
            RDP_TCP[19] = TCP_RCP_RU();
            RDP_TCP[20] = TCP_RCP_R();
            RDP_TCP[21] = TCP_RCP_RB();
            RDP_TCP[22] = TCP_RCP_B();

            RDP_Joint[0] = Joint_LCP_B();
            RDP_Joint[1] = Joint_LCP_LB();
            RDP_Joint[2] = Joint_LCP_L();
            RDP_Joint[3] = Joint_LCP_LU();
            RDP_Joint[4] = Joint_U_L();
            RDP_Joint[5] = Joint_L_U();
            RDP_Joint[6] = Joint_L();
            RDP_Joint[7] = Joint_L_B();
            RDP_Joint[8] = Joint_L_BB();
            RDP_Joint[9] = Joint_BL();
            RDP_Joint[10] = Joint_B_L();
            RDP_Joint[11] = Joint_B();
            RDP_Joint[12] = Joint_B_RR();
            RDP_Joint[13] = Joint_BR();
            RDP_Joint[14] = Joint_R_BB();
            RDP_Joint[15] = Joint_R_B();
            RDP_Joint[16] = Joint_R();
            RDP_Joint[17] = Joint_R_U();
            RDP_Joint[18] = Joint_U_RR();
            RDP_Joint[19] = Joint_RCP_RU();
            RDP_Joint[20] = Joint_RCP_R();
            RDP_Joint[21] = Joint_RCP_RB();
            RDP_Joint[22] = Joint_RCP_B();



            //셀 타입의 직접교시번호에 해당하는 준비자세 미리 저장해놓음
            //검색키 "[셀ID]_[직접교시번호]_[L/R]"
            //ST1
            CellTypePose.Add("ST1_L0", 9);
            CellTypePose.Add("ST1_L1", 5);
            CellTypePose.Add("ST1_R0", 13);
            CellTypePose.Add("ST1_R1", 17);

            //ST2
            CellTypePose.Add("ST2_L0", 10);
            CellTypePose.Add("ST2_L1", 7);
            CellTypePose.Add("ST2_L2", 5);
            CellTypePose.Add("ST2_R0", 12);
            CellTypePose.Add("ST2_R1", 15);
            CellTypePose.Add("ST2_R2", 17);
            //ST3
            CellTypePose.Add("ST3_L0", 10);
            CellTypePose.Add("ST3_R0", 12);


            //ST3+CP3F
            CellTypePose.Add("ST3+CP3F_L0", 9);
            CellTypePose.Add("ST3+CP3F_L1", 9);
            CellTypePose.Add("ST3+CP3F_L2", 2);
            CellTypePose.Add("ST3+CP3F_L3", 1);
            CellTypePose.Add("ST3+CP3F_L4", 0);
            CellTypePose.Add("ST3+CP3F_L5", 5);
            CellTypePose.Add("ST3+CP3F_R0", 13);
            CellTypePose.Add("ST3+CP3F_R1", 13);
            CellTypePose.Add("ST3+CP3F_R2", 20);
            CellTypePose.Add("ST3+CP3F_R3", 21);
            CellTypePose.Add("ST3+CP3F_R4", 22);
            CellTypePose.Add("ST3+CP3F_R5", 17);

            //ST3+CP4F
            CellTypePose.Add("ST3+CP4F_L0", 10);
            CellTypePose.Add("ST3+CP4F_L1", 8);
            CellTypePose.Add("ST3+CP4F_L2", 6);
            CellTypePose.Add("ST3+CP4F_L3", 7);
            CellTypePose.Add("ST3+CP4F_L4", 2);
            CellTypePose.Add("ST3+CP4F_L5", 0);
            CellTypePose.Add("ST3+CP4F_L6", 0);
            CellTypePose.Add("ST3+CP4F_R0", 12);
            CellTypePose.Add("ST3+CP4F_R1", 14);
            CellTypePose.Add("ST3+CP4F_R2", 16);
            CellTypePose.Add("ST3+CP4F_R3", 15);
            CellTypePose.Add("ST3+CP4F_R4", 20);
            CellTypePose.Add("ST3+CP4F_R5", 21);
            CellTypePose.Add("ST3+CP4F_R6", 22);


            //ST3+CP8F
            CellTypePose.Add("ST3+CP8F_L0", 9);
            CellTypePose.Add("ST3+CP8F_L1", 9);
            CellTypePose.Add("ST3+CP8F_L2", 2);//6
            CellTypePose.Add("ST3+CP8F_L3", 1);
            //CellTypePose.Add("ST3+CP8F_L4", 0);
            CellTypePose.Add("ST3+CP8F_L4", 5);
            //CellTypePose.Add("ST3+CP8F_L5", 5);
            CellTypePose.Add("ST3+CP8F_R0", 13);
            CellTypePose.Add("ST3+CP8F_R1", 13);
            CellTypePose.Add("ST3+CP8F_R2", 16);
            CellTypePose.Add("ST3+CP8F_R3", 21);
            //CellTypePose.Add("ST3+CP8F_R4", 22);
            CellTypePose.Add("ST3+CP8F_R4", 17);
            //CellTypePose.Add("ST3+CP8F_R5", 17);




            ////왼쪽
            //CellTypePose.Add("ST1_L0", 7);
            //CellTypePose.Add("ST1_L1", 4);
            //CellTypePose.Add("ST2_L0", 7);
            //CellTypePose.Add("ST2_L1", 4);
            //CellTypePose.Add("ST3_L0", 8);
            //CellTypePose.Add("ST4_L0", 8);
            //CellTypePose.Add("ST5_L0", 7);
            //CellTypePose.Add("ST5_L1", 4);
            //CellTypePose.Add("ST1+CP1F_L0", 9);
            //CellTypePose.Add("ST1+CP1F_L1", 9);
            //CellTypePose.Add("ST1+CP1F_L2", 9);
            //CellTypePose.Add("ST1+CP1F_L3", 9);
            //CellTypePose.Add("ST1+CP1B_L0", 9);
            //CellTypePose.Add("ST1+CP1B_L1", 9);
            //CellTypePose.Add("ST1+CP2F_L0", 9);
            //CellTypePose.Add("ST1+CP2F_L1", 9);
            //CellTypePose.Add("ST1+CP2F_L2", 9);
            //CellTypePose.Add("ST1+CP2F_L3", 9);
            //CellTypePose.Add("ST1+CP2B_L0", 9);
            //CellTypePose.Add("ST1+CP2B_L1", 9);

            //CellTypePose.Add("ST2+CP1F_L0", 7);
            //CellTypePose.Add("ST2+CP1F_L1", 3);
            //CellTypePose.Add("ST2+CP1F_L2", 0);

            //CellTypePose.Add("ST2+CP1B_L0", 9);
            //CellTypePose.Add("ST2+CP1B_L1", 9);
            //CellTypePose.Add("ST2+CP2F_L0", 9);
            //CellTypePose.Add("ST2+CP2F_L1", 9);
            //CellTypePose.Add("ST2+CP2F_L2", 9);
            //CellTypePose.Add("ST2+CP2F_L3", 9);
            //CellTypePose.Add("ST2+CP2B_L0", 9);
            //CellTypePose.Add("ST2+CP2B_L1", 9);
            //CellTypePose.Add("ST2+CP3F_L0", 9);
            //CellTypePose.Add("ST2+CP3F_L1", 9);
            //CellTypePose.Add("ST2+CP3F_L2", 9);
            //CellTypePose.Add("ST2+CP3F_L3", 9);
            //CellTypePose.Add("ST3+CP3B_L0", 9);
            //CellTypePose.Add("ST3+CP3B_L1", 9);
            //CellTypePose.Add("ST3+CP3B_L2", 9);

            //CellTypePose.Add("ST3+CP4F_L0", 9);
            //CellTypePose.Add("ST3+CP4F_L1", 6);
            //CellTypePose.Add("ST3+CP4F_L2", 6);
            //CellTypePose.Add("ST3+CP4F_L3", 6);
            //CellTypePose.Add("ST3+CP4F_L4", 6);

            //CellTypePose.Add("ST3+CP4B_L0", 9);
            //CellTypePose.Add("ST3+CP4B_L1", 9);
            //CellTypePose.Add("ST3+CP4B_L2", 9);
            //CellTypePose.Add("ST4+CP3F_L0", 9);
            //CellTypePose.Add("ST4+CP3F_L1", 9);
            //CellTypePose.Add("ST4+CP3F_L2", 9);
            //CellTypePose.Add("ST4+CP3F_L3", 9);
            //CellTypePose.Add("ST4+CP3B_L0", 9);
            //CellTypePose.Add("ST4+CP3B_L1", 9);
            //CellTypePose.Add("ST4+CP3B_L2", 9);
            //CellTypePose.Add("ST4+CP4F_L0", 9);
            //CellTypePose.Add("ST4+CP4F_L1", 9);
            //CellTypePose.Add("ST4+CP4F_L2", 9);
            //CellTypePose.Add("ST4+CP4F_L3", 9);
            //CellTypePose.Add("ST4+CP4F_L4", 9);
            //CellTypePose.Add("ST4+CP4B_L0", 9);
            //CellTypePose.Add("ST4+CP4B_L1", 9);
            //CellTypePose.Add("ST4+CP4B_L2", 9);
            //CellTypePose.Add("ST4+CP5F_L0", 9);
            //CellTypePose.Add("ST4+CP5F_L1", 9);
            //CellTypePose.Add("ST4+CP5F_L2", 9);
            //CellTypePose.Add("ST4+CP5F_L3", 9);
            //CellTypePose.Add("ST4+CP5B_L0", 9);
            //CellTypePose.Add("ST4+CP5B_L1", 9);
            //CellTypePose.Add("ST4+CP5B_L2", 9);
            //CellTypePose.Add("ST4+CP6F_L0", 9);
            //CellTypePose.Add("ST4+CP6F_L1", 9);
            //CellTypePose.Add("ST4+CP6F_L2", 9);
            //CellTypePose.Add("ST4+CP6F_L3", 9);
            //CellTypePose.Add("ST4+CP6F_L4", 9);
            //CellTypePose.Add("ST4+CP6B_L0", 9);
            //CellTypePose.Add("ST4+CP6B_L1", 9);
            //CellTypePose.Add("ST4+CP6B_L2", 9);
            //CellTypePose.Add("ST5+CP7F_L0", 9);
            //CellTypePose.Add("ST5+CP7F_L1", 9);
            //CellTypePose.Add("ST5+CP7F_L2", 9);
            //CellTypePose.Add("ST5+CP7F_L3", 9);
            //CellTypePose.Add("ST5+CP7B_L0", 9);
            //CellTypePose.Add("ST5+CP7B_L1", 9);
            ////오른쪽
            //CellTypePose.Add("ST1_R0", 11);
            //CellTypePose.Add("ST1_R1", 14);
            //CellTypePose.Add("ST2_R0", 11);
            //CellTypePose.Add("ST2_R1", 14);
            //CellTypePose.Add("ST3_R0", 10);
            //CellTypePose.Add("ST4_R0", 10);
            //CellTypePose.Add("ST5_R0", 11);
            //CellTypePose.Add("ST5_R1", 14);
            //CellTypePose.Add("ST1+CP1F_R0", 9);
            //CellTypePose.Add("ST1+CP1F_R1", 9);
            //CellTypePose.Add("ST1+CP1F_R2", 9);
            //CellTypePose.Add("ST1+CP1F_R3", 9);
            //CellTypePose.Add("ST1+CP1B_R0", 9);
            //CellTypePose.Add("ST1+CP1B_R1", 9);
            //CellTypePose.Add("ST1+CP2F_R0", 9);
            //CellTypePose.Add("ST1+CP2F_R1", 9);
            //CellTypePose.Add("ST1+CP2F_R2", 9);
            //CellTypePose.Add("ST1+CP2F_R3", 9);
            //CellTypePose.Add("ST1+CP2B_R0", 9);
            //CellTypePose.Add("ST1+CP2B_R1", 9);

            //CellTypePose.Add("ST2+CP1F_R0", 11);
            //CellTypePose.Add("ST2+CP1F_R1", 15);
            //CellTypePose.Add("ST2+CP1F_R2", 18);

            //CellTypePose.Add("ST2+CP1B_R0", 9);
            //CellTypePose.Add("ST2+CP1B_R1", 9);
            //CellTypePose.Add("ST2+CP2F_R0", 9);
            //CellTypePose.Add("ST2+CP2F_R1", 9);
            //CellTypePose.Add("ST2+CP2F_R2", 9);
            //CellTypePose.Add("ST2+CP2F_R3", 9);
            //CellTypePose.Add("ST2+CP2B_R0", 9);
            //CellTypePose.Add("ST2+CP2B_R1", 9);
            //CellTypePose.Add("ST2+CP3F_R0", 9);
            //CellTypePose.Add("ST2+CP3F_R1", 9);
            //CellTypePose.Add("ST2+CP3F_R2", 9);
            //CellTypePose.Add("ST2+CP3F_R3", 9);
            //CellTypePose.Add("ST3+CP3B_R0", 9);
            //CellTypePose.Add("ST3+CP3B_R1", 9);
            //CellTypePose.Add("ST3+CP3B_R2", 9);

            //CellTypePose.Add("ST3+CP4F_R0", 9);
            //CellTypePose.Add("ST3+CP4F_R1", 12);
            //CellTypePose.Add("ST3+CP4F_R2", 12);
            //CellTypePose.Add("ST3+CP4F_R3", 12);
            //CellTypePose.Add("ST3+CP4F_R4", 12);

            //CellTypePose.Add("ST3+CP4B_R0", 9);
            //CellTypePose.Add("ST3+CP4B_R1", 9);
            //CellTypePose.Add("ST3+CP4B_R2", 9);
            //CellTypePose.Add("ST4+CP3F_R0", 9);
            //CellTypePose.Add("ST4+CP3F_R1", 9);
            //CellTypePose.Add("ST4+CP3F_R2", 9);
            //CellTypePose.Add("ST4+CP3F_R3", 9);
            //CellTypePose.Add("ST4+CP3B_R0", 9);
            //CellTypePose.Add("ST4+CP3B_R1", 9);
            //CellTypePose.Add("ST4+CP3B_R2", 9);
            //CellTypePose.Add("ST4+CP4F_R0", 9);
            //CellTypePose.Add("ST4+CP4F_R1", 9);
            //CellTypePose.Add("ST4+CP4F_R2", 9);
            //CellTypePose.Add("ST4+CP4F_R3", 9);
            //CellTypePose.Add("ST4+CP4F_R4", 9);
            //CellTypePose.Add("ST4+CP4B_R0", 9);
            //CellTypePose.Add("ST4+CP4B_R1", 9);
            //CellTypePose.Add("ST4+CP4B_R2", 9);
            //CellTypePose.Add("ST4+CP5F_R0", 9);
            //CellTypePose.Add("ST4+CP5F_R1", 9);
            //CellTypePose.Add("ST4+CP5F_R2", 9);
            //CellTypePose.Add("ST4+CP5F_R3", 9);
            //CellTypePose.Add("ST4+CP5B_R0", 9);
            //CellTypePose.Add("ST4+CP5B_R1", 9);
            //CellTypePose.Add("ST4+CP5B_R2", 9);
            //CellTypePose.Add("ST4+CP6F_R0", 9);
            //CellTypePose.Add("ST4+CP6F_R1", 9);
            //CellTypePose.Add("ST4+CP6F_R2", 9);
            //CellTypePose.Add("ST4+CP6F_R3", 9);
            //CellTypePose.Add("ST4+CP6F_R4", 9);
            //CellTypePose.Add("ST4+CP6B_R0", 9);
            //CellTypePose.Add("ST4+CP6B_R1", 9);
            //CellTypePose.Add("ST4+CP6B_R2", 9);
            //CellTypePose.Add("ST5+CP7F_R0", 9);
            //CellTypePose.Add("ST5+CP7F_R1", 9);
            //CellTypePose.Add("ST5+CP7F_R2", 9);
            //CellTypePose.Add("ST5+CP7F_R3", 9);
            //CellTypePose.Add("ST5+CP7B_R0", 9);
            //CellTypePose.Add("ST5+CP7B_R1", 9);



        }

        //용접조건파일 읽기
        void WeldDatabaseLoad()
        {
            DatabaseLoad_2F();
            DatabaseLoad_3F();
            DatabaseLoad_4F();
        }

        //자세별 용접조건파일 읽는 함수
        void DatabaseLoad_2F()
        {
            string FilePath = @"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Init\WeldingCondition_2F.txt";
            string[] readdata, readsplitdata;
            string[] tempstrarr = new string[19];
            string instr = "";
            string outstr = "";

            //파일이 있는지 검사한 뒤 없으면 함수 종료
            if (new FileInfo(@FilePath).Exists == false) return;

            //모든 줄 읽어오기
            readdata = File.ReadAllLines(@FilePath);

            //각 줄에대해서 각각 수행
            foreach (string str in readdata)
            {
                //컴마로 분할한 뒤 항목이 19개가 아니면 해당 줄은 처리 안함
                readsplitdata = str.Trim().Split(',');
                if (readsplitdata.Length != 19) continue;

                //각 항목에 대해
                bool OKFlag = true;
                for (int i = 0; i < 19; i++)
                {
                    if (i < 4)
                    {//앞에 4개는 정수로 변환이 되는지 체크하고 저장함
                        try
                        {
                            tempstrarr[i] = Convert.ToInt32(readsplitdata[i].Trim()).ToString();
                        }
                        catch
                        {
                            OKFlag = false;
                        }
                    }
                    else if (i == 4)
                    {//다섯번째 값은 B,P,F 셋중에 하나인지 체크
                        tempstrarr[i] = readsplitdata[i].Trim();
                        if ((tempstrarr[i] != "B") && (tempstrarr[i] != "P") && (tempstrarr[i] != "F") && (tempstrarr[i] != "S1") && (tempstrarr[i] != "S2") && (tempstrarr[i] != "S3")) OKFlag = false;
                    }
                    else
                    {//나머지는 실수로 변환이 되는지 체크하고 저장

                        try
                        {
                            if (i == 17)
                            {
                                tempstrarr[i] = Convert.ToInt32(readsplitdata[i].Trim()).ToString();
                            }
                            else
                            {
                                tempstrarr[i] = Convert.ToSingle(readsplitdata[i].Trim()).ToString("0.00");
                            }
                        }
                        catch
                        {
                            OKFlag = false;
                        }
                    }
                }

                //전부 문제 없으면 문자열 키와 값으로 변환한 뒤 중복키가 있는지 체크하고 딕셔너리에 저장
                if (OKFlag == true)
                {
                    outstr = "";
                    instr = "2F," + tempstrarr[0] + "," + tempstrarr[1] + "," + tempstrarr[2] + "," + tempstrarr[3] + "," + tempstrarr[4];
                    for (int i = 5; i < 18; i++) outstr = outstr + tempstrarr[i] + ",";
                    outstr = outstr + tempstrarr[18];
                    if (WeldDatabase.ContainsKey(instr) == false) WeldDatabase.Add(instr, outstr);
                }
            }
        }
        void DatabaseLoad_3F()
        {
            string FilePath = @"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Init\WeldingCondition_3F.txt";
            string[] readdata, readsplitdata;
            string[] tempstrarr = new string[19];
            string instr = "";
            string outstr = "";

            //파일이 있는지 검사한 뒤 없으면 함수 종료
            if (new FileInfo(@FilePath).Exists == false) return;

            //모든 줄 읽어오기
            readdata = File.ReadAllLines(@FilePath);

            //각 줄에대해서 각각 수행
            foreach (string str in readdata)
            {
                //컴마로 분할한 뒤 항목이 19개가 아니면 해당 줄은 처리 안함
                readsplitdata = str.Trim().Split(',');
                if (readsplitdata.Length != 19) continue;

                //각 항목에 대해
                bool OKFlag = true;
                for (int i = 0; i < 19; i++)
                {
                    if (i < 4)
                    {//앞에 4개는 정수로 변환이 되는지 체크하고 저장함
                        try
                        {
                            tempstrarr[i] = Convert.ToInt32(readsplitdata[i].Trim()).ToString();
                        }
                        catch
                        {
                            OKFlag = false;
                        }
                    }
                    else if (i == 4)
                    {//다섯번째 값은 B,P,F 셋중에 하나인지 체크
                        tempstrarr[i] = readsplitdata[i].Trim();
                        if ((tempstrarr[i] != "B") && (tempstrarr[i] != "P") && (tempstrarr[i] != "F") && (tempstrarr[i] != "S1") && (tempstrarr[i] != "S2") && (tempstrarr[i] != "S3")) OKFlag = false;
                    }
                    else
                    {//나머지는 실수로 변환이 되는지 체크하고 저장
                        try
                        {
                            if (i == 17)
                            {
                                tempstrarr[i] = Convert.ToInt32(readsplitdata[i].Trim()).ToString();
                            }
                            else
                            {
                                tempstrarr[i] = Convert.ToSingle(readsplitdata[i].Trim()).ToString("0.00");
                            }
                        }
                        catch
                        {
                            OKFlag = false;
                        }
                    }
                }

                //전부 문제 없으면 문자열 키와 값으로 변환한 뒤 중복키가 있는지 체크하고 딕셔너리에 저장
                if (OKFlag == true)
                {
                    outstr = "";
                    instr = "3F," + tempstrarr[0] + "," + tempstrarr[1] + "," + tempstrarr[2] + "," + tempstrarr[3] + "," + tempstrarr[4];
                    for (int i = 5; i < 18; i++) outstr = outstr + tempstrarr[i] + ",";
                    outstr = outstr + tempstrarr[18];
                    if (WeldDatabase.ContainsKey(instr) == false) WeldDatabase.Add(instr, outstr);
                }
            }
        }
        void DatabaseLoad_4F()
        {
            string FilePath = @"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Init\WeldingCondition_4F.txt";
            string[] readdata, readsplitdata;
            string[] tempstrarr = new string[19];
            string instr = "";
            string outstr = "";

            //파일이 있는지 검사한 뒤 없으면 함수 종료
            if (new FileInfo(@FilePath).Exists == false) return;

            //모든 줄 읽어오기
            readdata = File.ReadAllLines(@FilePath);

            //각 줄에대해서 각각 수행
            foreach (string str in readdata)
            {
                //컴마로 분할한 뒤 항목이 19개가 아니면 해당 줄은 처리 안함
                readsplitdata = str.Trim().Split(',');
                if (readsplitdata.Length != 19) continue;

                //각 항목에 대해
                bool OKFlag = true;
                for (int i = 0; i < 19; i++)
                {
                    if (i < 4)
                    {//앞에 4개는 정수로 변환이 되는지 체크하고 저장함
                        try
                        {
                            tempstrarr[i] = Convert.ToInt32(readsplitdata[i].Trim()).ToString();
                        }
                        catch
                        {
                            OKFlag = false;
                        }
                    }
                    else if (i == 4)
                    {//다섯번째 값은 B,P,F 셋중에 하나인지 체크
                        tempstrarr[i] = readsplitdata[i].Trim();
                        if ((tempstrarr[i] != "B") && (tempstrarr[i] != "P") && (tempstrarr[i] != "F")) OKFlag = false;
                    }
                    else
                    {//나머지는 실수로 변환이 되는지 체크하고 저장
                        try
                        {
                            if (i == 17)
                            {
                                tempstrarr[i] = Convert.ToInt32(readsplitdata[i].Trim()).ToString();
                            }
                            else
                            {
                                tempstrarr[i] = Convert.ToSingle(readsplitdata[i].Trim()).ToString("0.00");
                            }
                        }
                        catch
                        {
                            OKFlag = false;
                        }
                    }
                }

                //전부 문제 없으면 문자열 키와 값으로 변환한 뒤 중복키가 있는지 체크하고 딕셔너리에 저장
                if (OKFlag == true)
                {
                    outstr = "";
                    instr = "4F," + tempstrarr[0] + "," + tempstrarr[1] + "," + tempstrarr[2] + "," + tempstrarr[3] + "," + tempstrarr[4];
                    for (int i = 5; i < 18; i++) outstr = outstr + tempstrarr[i] + ",";
                    outstr = outstr + tempstrarr[18];
                    if (WeldDatabase.ContainsKey(instr) == false) WeldDatabase.Add(instr, outstr);
                }
            }
        }


        //로봇 기본자세 호출용 함수
        RobotPoseData TCP_BACK() { return (RobotPoseData)RDP_TCP_BACK.Clone(); }
        //RobotPoseData TCP_Left1() { return (RobotPoseData)RDP_TCP_Left1.Clone(); }
        //RobotPoseData TCP_Left2() { return (RobotPoseData)RDP_TCP_Left2.Clone(); }
        //RobotPoseData TCP_Left3() { return (RobotPoseData)RDP_TCP_Left3.Clone(); }
        //RobotPoseData TCP_Right1() { return (RobotPoseData)RDP_TCP_Right1.Clone(); }
        //RobotPoseData TCP_Right2() { return (RobotPoseData)RDP_TCP_Right2.Clone(); }
        //RobotPoseData TCP_Right3() { return (RobotPoseData)RDP_TCP_Right3.Clone(); }
        //RobotPoseData TCP_Middle1() { return (RobotPoseData)RDP_TCP_Middle1.Clone(); }
        RobotPoseData TCP_Middle2() { return (RobotPoseData)RDP_TCP_Middle2.Clone(); }
        //RobotPoseData TCP_Middle3() { return (RobotPoseData)RDP_TCP_Middle3.Clone(); }
        //RobotPoseData Joint_Left1() { return (RobotPoseData)RDP_Joint_Left1.Clone(); }
        //RobotPoseData Joint_Left2() { return (RobotPoseData)RDP_Joint_Left2.Clone(); }
        //RobotPoseData Joint_Left3() { return (RobotPoseData)RDP_Joint_Left3.Clone(); }
        //RobotPoseData Joint_Right1() { return (RobotPoseData)RDP_Joint_Right1.Clone(); }
        //RobotPoseData Joint_Right2() { return (RobotPoseData)RDP_Joint_Right2.Clone(); }
        //RobotPoseData Joint_Right3() { return (RobotPoseData)RDP_Joint_Right3.Clone(); }
        //RobotPoseData Joint_Middle1() { return (RobotPoseData)RDP_Joint_Middle1.Clone(); }
        RobotPoseData Joint_Middle2() { return (RobotPoseData)RDP_Joint_Middle2.Clone(); }
        //RobotPoseData Joint_Middle3() { return (RobotPoseData)RDP_Joint_Middle3.Clone(); }
        RobotPoseData TCP_WireCut2() { return (RobotPoseData)RDP_TCP_WireCut2.Clone(); }
        RobotPoseData TCP_WireCut3() { return (RobotPoseData)RDP_TCP_WireCut3.Clone(); }
        RobotPoseData Joint_WireCut0() { return (RobotPoseData)RDP_Joint_WireCut0.Clone(); }
        RobotPoseData Joint_WireCut1() { return (RobotPoseData)RDP_Joint_WireCut1.Clone(); }
        RobotPoseData TCP_Home2() { return (RobotPoseData)RDP_TCP_Home2.Clone(); }
        RobotPoseData Joint_Home0() { return (RobotPoseData)RDP_Joint_Home0.Clone(); }
        RobotPoseData Joint_Home1() { return (RobotPoseData)RDP_Joint_Home1.Clone(); }
        RobotPoseData TCP_DirChange0() { return (RobotPoseData)RDP_TCP_DirChange0.Clone(); }
        RobotPoseData TCP_DirChange1() { return (RobotPoseData)RDP_TCP_DirChange1.Clone(); }
        RobotPoseData TCP_DirChange2() { return (RobotPoseData)RDP_TCP_DirChange2.Clone(); }
        RobotPoseData TCP_DirChange3() { return (RobotPoseData)RDP_TCP_DirChange3.Clone(); }
        RobotPoseData Joint_DirChange0() { return (RobotPoseData)RDP_Joint_DirChange0.Clone(); }
        RobotPoseData Joint_DirChange1() { return (RobotPoseData)RDP_Joint_DirChange1.Clone(); }
        RobotPoseData Joint_DirChange2() { return (RobotPoseData)RDP_Joint_DirChange2.Clone(); }
        RobotPoseData Joint_DirChange3() { return (RobotPoseData)RDP_Joint_DirChange3.Clone(); }


        RobotPoseData TCP_LCP_B() { return (RobotPoseData)RDP_TCP_LCP_B.Clone(); }
        RobotPoseData TCP_LCP_LB() { return (RobotPoseData)RDP_TCP_LCP_LB.Clone(); }
        RobotPoseData TCP_LCP_L() { return (RobotPoseData)RDP_TCP_LCP_L.Clone(); }
        RobotPoseData TCP_LCP_LU() { return (RobotPoseData)RDP_TCP_LCP_LU.Clone(); }
        RobotPoseData TCP_U_L() { return (RobotPoseData)RDP_TCP_U_L.Clone(); }
        RobotPoseData TCP_L_U() { return (RobotPoseData)RDP_TCP_L_U.Clone(); }
        RobotPoseData TCP_L() { return (RobotPoseData)RDP_TCP_L.Clone(); }
        RobotPoseData TCP_L_B() { return (RobotPoseData)RDP_TCP_L_B.Clone(); }
        RobotPoseData TCP_L_BB() { return (RobotPoseData)RDP_TCP_L_BB.Clone(); }
        RobotPoseData TCP_BL() { return (RobotPoseData)RDP_TCP_BL.Clone(); }
        RobotPoseData TCP_B_L() { return (RobotPoseData)RDP_TCP_B_L.Clone(); }
        RobotPoseData TCP_B() { return (RobotPoseData)RDP_TCP_B.Clone(); }
        RobotPoseData TCP_B_RR() { return (RobotPoseData)RDP_TCP_B_RR.Clone(); }
        RobotPoseData TCP_BR() { return (RobotPoseData)RDP_TCP_BR.Clone(); }
        RobotPoseData TCP_R_BB() { return (RobotPoseData)RDP_TCP_R_BB.Clone(); }
        RobotPoseData TCP_R_B() { return (RobotPoseData)RDP_TCP_R_B.Clone(); }
        RobotPoseData TCP_R() { return (RobotPoseData)RDP_TCP_R.Clone(); }
        RobotPoseData TCP_R_U() { return (RobotPoseData)RDP_TCP_R_U.Clone(); }
        RobotPoseData TCP_U_RR() { return (RobotPoseData)RDP_TCP_U_RR.Clone(); }
        RobotPoseData TCP_RCP_RU() { return (RobotPoseData)RDP_TCP_RCP_RU.Clone(); }
        RobotPoseData TCP_RCP_R() { return (RobotPoseData)RDP_TCP_RCP_R.Clone(); }
        RobotPoseData TCP_RCP_RB() { return (RobotPoseData)RDP_TCP_RCP_RB.Clone(); }
        RobotPoseData TCP_RCP_B() { return (RobotPoseData)RDP_TCP_RCP_B.Clone(); }

        RobotPoseData Joint_LCP_B() { return (RobotPoseData)RDP_Joint_LCP_B.Clone(); }
        RobotPoseData Joint_LCP_LB() { return (RobotPoseData)RDP_Joint_LCP_LB.Clone(); }
        RobotPoseData Joint_LCP_L() { return (RobotPoseData)RDP_Joint_LCP_L.Clone(); }
        RobotPoseData Joint_LCP_LU() { return (RobotPoseData)RDP_Joint_LCP_LU.Clone(); }
        RobotPoseData Joint_U_L() { return (RobotPoseData)RDP_Joint_U_L.Clone(); }
        RobotPoseData Joint_L_U() { return (RobotPoseData)RDP_Joint_L_U.Clone(); }
        RobotPoseData Joint_L() { return (RobotPoseData)RDP_Joint_L.Clone(); }
        RobotPoseData Joint_L_B() { return (RobotPoseData)RDP_Joint_L_B.Clone(); }
        RobotPoseData Joint_L_BB() { return (RobotPoseData)RDP_Joint_L_BB.Clone(); }
        RobotPoseData Joint_BL() { return (RobotPoseData)RDP_Joint_BL.Clone(); }
        RobotPoseData Joint_B_L() { return (RobotPoseData)RDP_Joint_B_L.Clone(); }
        RobotPoseData Joint_B() { return (RobotPoseData)RDP_Joint_B.Clone(); }
        RobotPoseData Joint_B_RR() { return (RobotPoseData)RDP_Joint_B_RR.Clone(); }
        RobotPoseData Joint_BR() { return (RobotPoseData)RDP_Joint_BR.Clone(); }
        RobotPoseData Joint_R_BB() { return (RobotPoseData)RDP_Joint_R_BB.Clone(); }
        RobotPoseData Joint_R_B() { return (RobotPoseData)RDP_Joint_R_B.Clone(); }
        RobotPoseData Joint_R() { return (RobotPoseData)RDP_Joint_R.Clone(); }
        RobotPoseData Joint_R_U() { return (RobotPoseData)RDP_Joint_R_U.Clone(); }
        RobotPoseData Joint_U_RR() { return (RobotPoseData)RDP_Joint_U_RR.Clone(); }
        RobotPoseData Joint_RCP_RU() { return (RobotPoseData)RDP_Joint_RCP_RU.Clone(); }
        RobotPoseData Joint_RCP_R() { return (RobotPoseData)RDP_Joint_RCP_R.Clone(); }
        RobotPoseData Joint_RCP_RB() { return (RobotPoseData)RDP_Joint_RCP_RB.Clone(); }
        RobotPoseData Joint_RCP_B() { return (RobotPoseData)RDP_Joint_RCP_B.Clone(); }


        void AutoSequence()
        {
            int tempi = 0;
            switch (AutoSequenceState)
            {
                case "대기":
                 
                    break;
                case "셀용접-시작":
                    AutoSequenceState = "셀용접-직접교시 시작";

                    //직접교시 기록내역 초기화
                    for (int i = 0; i < 32; i++)
                    {
                        DTPointLeftOK[i] = false;
                        DTPointRightOK[i] = false;
                    }

                    break;
                case "셀용접-셀정보 입력대기":

                    break;
                case "셀용접-직접교시 시작":
                    MainLog_Add("셀용접-직접교시 시작.");
                    AutoDTSubSeq = "시작";
                    AutoSequenceState = "셀용접-직접교시 완료대기";
                    break;
                case "셀용접-직접교시 완료대기":

                    DirectTeachingSeq();

                    if (AutoDTSubSeq == "직접교시 완료")
                    {
                        DTDataSave();
                        AutoTSStartFlag = false;
                        AutoSequenceState = "셀용접-터치센싱 시작대기";
                    }
                    else if (AutoDTSubSeq == "직접교시 실패")
                    {
                        //직접교시 실패처리. 직접교시 시작상태로 돌아감
                        AutoSequenceState = "셀용접-직접교시 시작";
                        AutoDTSubSeq = "대기";
                    }

                    break;
                case "셀용접-터치센싱 시작대기":

                    if (AutoTSStartFlag == true)
                    {
                        AutoSequenceState = "셀용접-터치센싱 와이어컷팅 시작";
                        AutoTSStartFlag = false;
                    }

                    if (AutoTouchAndWeldFlag == true)
                    {
                        AutoSequenceState = "셀용접-터치센싱 와이어컷팅 시작";
                    }

                    break;
                case "셀용접-터치센싱 와이어컷팅 시작":

                    WirecutState = "와이어컷-이동";
                    AutoSequenceState = "셀용접-터치센싱 와이어컷팅 완료대기";
                    break;
                case "셀용접-터치센싱 와이어컷팅 완료대기":

                    Wirecutting();

                    if (WirecutState == "와이어컷-완료")
                    {
                        AutoSequenceState = "셀용접-왼쪽터치센싱 시작";
                    }
                    else if (WirecutState == "와이어컷-실패")
                    {
                        AutoSequenceState = "셀용접-터치센싱 시작대기";
                    }

                    break;
                case "셀용접-왼쪽터치센싱 시작":

                    if (LeftWeldFlag == true)
                    {
                        AutoSequenceState = "셀용접-왼쪽 " + CellTypeName_Left + " 터치센싱 중";
                        AutoTSSubSeq = "시작";
                    }
                    else
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    break;
                case "셀용접-왼쪽 ST1 터치센싱 중":
                case "셀용접-왼쪽 ST1+CP1B 터치센싱 중":
                case "셀용접-왼쪽 ST1+CP2B 터치센싱 중":
                    TouchSeq_ST1(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST2 터치센싱 중":
                case "셀용접-왼쪽 ST5 터치센싱 중":
                case "셀용접-왼쪽 ST2+CP1B 터치센싱 중":
                case "셀용접-왼쪽 ST2+CP2B 터치센싱 중":
                case "셀용접-왼쪽 ST3+CP4B 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP4B 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP6B 터치센싱 중":
                case "셀용접-왼쪽 ST5+CP7B 터치센싱 중":
                    TouchSeq_ST2(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST3 터치센싱 중":
                case "셀용접-왼쪽 ST4 터치센싱 중":
                    TouchSeq_ST3(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-왼쪽 ST1+CP1F 터치센싱 중":
                    //TouchSeq_ST1_CP1F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-왼쪽 ST1+CP2F 터치센싱 중":
                    //TouchSeq_ST1_CP2F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;


                case "셀용접-왼쪽 ST2+CP1F 터치센싱 중":
                    TouchSeq_ST2_CP1F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-왼쪽 ST2+CP2F 터치센싱 중":
                    //TouchSeq_ST2_CP2F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;


                case "셀용접-왼쪽 ST3+CP3F 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP3F 터치센싱 중":
                    TouchSeq_ST3_CP3F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST3+CP3B 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP3B 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP5B 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP9B 터치센싱 중":
                    TouchSeq_ST3_CP3B(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST3+CP4F 터치센싱 중":
                case "셀용접-왼쪽 ST4+CP4F 터치센싱 중":
                    TouchSeq_ST3_CP4F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;


                case "셀용접-왼쪽 ST4+CP5F 터치센싱 중":
                    TouchSeq_ST4_CP5F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST4+CP6F 터치센싱 중":
                    TouchSeq_ST4_CP6F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST4+CP11F 터치센싱 중":
                    TouchSeq_ST4_CP11F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST4+CP12F 터치센싱 중":
                    TouchSeq_ST4_CP12F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST5+CP7F 터치센싱 중":
                    //TouchSeq_ST5_CP7F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-왼쪽 ST3+CP8F 터치센싱 중":
                    TouchSeq_ST3_CP8F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST3+CP9F 터치센싱 중":
                    TouchSeq_ST3_CP9F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST3+CP9B 터치센싱 중":
                    TouchSeq_ST3_CP9B(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-왼쪽 ST3+CP10F 터치센싱 중":
                    TouchSeq_ST3_CP10F(0);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-오른쪽터치센싱 시작";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽터치센싱 시작":

                    if (RightWeldFlag == true)
                    {
                        AutoSequenceState = "셀용접-오른쪽 " + CellTypeName_Right + " 터치센싱 중";
                        AutoTSSubSeq = "시작";
                    }
                    else
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                  
                    break;
                case "셀용접-오른쪽 ST1 터치센싱 중":
                case "셀용접-오른쪽 ST1+CP1B 터치센싱 중":
                case "셀용접-오른쪽 ST1+CP2B 터치센싱 중":
                    TouchSeq_ST1(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST2 터치센싱 중":
                case "셀용접-오른쪽 ST5 터치센싱 중":
                case "셀용접-오른쪽 ST2+CP1B 터치센싱 중":
                case "셀용접-오른쪽 ST2+CP2B 터치센싱 중":
                case "셀용접-오른쪽 ST3+CP4B 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP4B 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP6B 터치센싱 중":
                case "셀용접-오른쪽 ST5+CP7B 터치센싱 중":
                    TouchSeq_ST2(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST3 터치센싱 중":
                case "셀용접-오른쪽 ST4 터치센싱 중":
                    TouchSeq_ST3(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;


                case "셀용접-오른쪽 ST1+CP1F 터치센싱 중":
                    //TouchSeq_ST1_CP1F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST1+CP2F 터치센싱 중":
                    //TouchSeq_ST1_CP2F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST2+CP1F 터치센싱 중":
                    TouchSeq_ST2_CP1F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST2+CP2F 터치센싱 중":
                    //TouchSeq_ST2_CP2F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST3+CP3F 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP3F 터치센싱 중":
                    TouchSeq_ST3_CP3F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST3+CP4F 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP4F 터치센싱 중":
                    TouchSeq_ST3_CP4F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST3+CP3B 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP3B 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP5B 터치센싱 중":
                case "셀용접-오른쪽 ST4+CP9B 터치센싱 중":
                    TouchSeq_ST3_CP3B(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;


                case "셀용접-오른쪽 ST4+CP5F 터치센싱 중":
                    TouchSeq_ST4_CP5F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST4+CP6F 터치센싱 중":
                    TouchSeq_ST4_CP6F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST4+CP11F 터치센싱 중":
                    TouchSeq_ST4_CP11F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST4+CP12F 터치센싱 중":
                    TouchSeq_ST4_CP12F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST5+CP7F 터치센싱 중":
                    //TouchSeq_ST5_CP7F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;

                case "셀용접-오른쪽 ST3+CP8F 터치센싱 중":
                    TouchSeq_ST3_CP8F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST3+CP9F 터치센싱 중":
                    TouchSeq_ST3_CP9F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST3+CP9B 터치센싱 중":
                    TouchSeq_ST3_CP9B(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-오른쪽 ST3+CP10F 터치센싱 중":
                    TouchSeq_ST3_CP10F(1);
                    if (AutoTSSubSeq == "터치시퀀스 성공")
                    {
                        AutoSequenceState = "셀용접-터치센싱 완료";
                    }
                    else if (AutoTSSubSeq == "터치시퀀스 실패")
                    {   //터치센싱 실패처리
                        AutoSequenceState = "셀용접-터치센싱 실패";
                        ErrorOccurTime = DateTime.Now;
                    }
                    break;
                case "셀용접-터치센싱 실패":

                    //일정시간 대기
                    tempi = (int)(DateTime.Now - ErrorOccurTime).Ticks / 10000;
                    if (tempi > 3000)
                    {   //지정된 시간 이상 터치센싱 시작 대기상태로 넘어감
                        AutoTSStartFlag = false;
                        AutoTouchAndWeldFlag = false;
                        AutoTSSubSeq = "대기";
                        AutoSequenceState = "셀용접-터치센싱 시작대기";
                    }

                    break;
                case "셀용접-터치센싱 완료":

                    //용접시작 플래그 초기화 후 용접시작대기 전환
                    TouchDataSave();
                    AutoWeldStartFlag = false;
                    AutoSequenceState = "셀용접-용접시작대기";
                    AutoTSSubSeq = "대기";

                    break;
                case "셀용접-용접시작대기":

                    if (AutoWeldStartFlag == true)
                    {
                        AutoSequenceState = "셀용접-용접시작";
                        AutoWeldStartFlag = false;
                    }

                    if (AutoTouchAndWeldFlag == true)
                    {
                        AutoSequenceState = "셀용접-용접시작";
                        AutoTouchAndWeldFlag = false;
                    }

                    break;
                case "셀용접-용접시작":

                    if (MakeAutoWeldInformation() == 1)
                    {
                        AutoWeldCalcInfo_Total(); //생성된 용접모션에서 용접정보(용접선 개수, 용접길이, 용접시간) 계산

                        AutoSequenceState = "셀용접-용접완료대기";
                        AutoWeldingSubState = "시작";
                        AutoWeldCount = 0;
                    }
                    else
                    {
                        AutoSequenceState = "셀용접-용접실패";
                    }
                    break;
                case "셀용접-용접완료대기":

                    AutoWeldingSubSeq();

                    AutoWeldCalcInfo_Left(); //용접 수행 중 남아있는 용접정보(용접선 개수, 용접길이, 용접시간) 계산


                    if (AutoWeldingSubState == "연속용접 성공")
                    {
                        AutoSequenceState = "셀용접-용접완료";
                    }
                    else if (AutoWeldingSubState == "연속용접 실패")
                    {
                        AutoSequenceState = "셀용접-용접실패";
                        ErrorOccurTime = DateTime.Now;
                    }



                    break;
                case "셀용접-용접완료":

                    break;
                case "셀용접-용접실패":

                    //일정시간 대기
                    tempi = (int)(DateTime.Now - ErrorOccurTime).Ticks / 10000;
                    if (tempi > 3000)
                    {   //지정된 시간 이상 셀용접 시작 대기상태로 넘어감
                        AutoSequenceState = "셀용접-용접시작대기";
                    }
                    break;


                default:
                    break;
            }


        }

        //직접교시점 왼쪽변수 해당 카운트에 저장
        void DTLeftPoseRecord(int count)
        {
            AutoWeld_DTPoint_Left_JointPose[count].PoseType = 1;
            AutoWeld_DTPoint_Left_JointPose[count].Speed = 10;
            AutoWeld_DTPoint_Left_JointPose[count].f1 = RobotDataEX.moni_RobotJointActualAngle[0];
            AutoWeld_DTPoint_Left_JointPose[count].f2 = RobotDataEX.moni_RobotJointActualAngle[1];
            AutoWeld_DTPoint_Left_JointPose[count].f3 = RobotDataEX.moni_RobotJointActualAngle[2];
            AutoWeld_DTPoint_Left_JointPose[count].f4 = RobotDataEX.moni_RobotJointActualAngle[3];
            AutoWeld_DTPoint_Left_JointPose[count].f5 = RobotDataEX.moni_RobotJointActualAngle[4];
            AutoWeld_DTPoint_Left_JointPose[count].f6 = RobotDataEX.moni_RobotJointActualAngle[5];

            AutoWeld_DTPoint_Left_TCPPose[count].PoseType = 2;
            AutoWeld_DTPoint_Left_TCPPose[count].Speed = 100;
            AutoWeld_DTPoint_Left_TCPPose[count].f1 = RobotDataEX.moni_RobotTCPActualPose[0];
            AutoWeld_DTPoint_Left_TCPPose[count].f2 = RobotDataEX.moni_RobotTCPActualPose[1];
            AutoWeld_DTPoint_Left_TCPPose[count].f3 = RobotDataEX.moni_RobotTCPActualPose[2];
            AutoWeld_DTPoint_Left_TCPPose[count].f4 = RobotDataEX.moni_RobotTCPActualPose[3];
            AutoWeld_DTPoint_Left_TCPPose[count].f5 = RobotDataEX.moni_RobotTCPActualPose[4];
            AutoWeld_DTPoint_Left_TCPPose[count].f6 = RobotDataEX.moni_RobotTCPActualPose[5];
        }

        //직접교시점 오른쪽변수 해당 카운트에 저장
        void DTRightPoseRecord(int count)
        {
            AutoWeld_DTPoint_Right_JointPose[count].PoseType = 1;
            AutoWeld_DTPoint_Right_JointPose[count].Speed = 10;
            AutoWeld_DTPoint_Right_JointPose[count].f1 = RobotDataEX.moni_RobotJointActualAngle[0];
            AutoWeld_DTPoint_Right_JointPose[count].f2 = RobotDataEX.moni_RobotJointActualAngle[1];
            AutoWeld_DTPoint_Right_JointPose[count].f3 = RobotDataEX.moni_RobotJointActualAngle[2];
            AutoWeld_DTPoint_Right_JointPose[count].f4 = RobotDataEX.moni_RobotJointActualAngle[3];
            AutoWeld_DTPoint_Right_JointPose[count].f5 = RobotDataEX.moni_RobotJointActualAngle[4];
            AutoWeld_DTPoint_Right_JointPose[count].f6 = RobotDataEX.moni_RobotJointActualAngle[5];

            AutoWeld_DTPoint_Right_TCPPose[count].PoseType = 2;
            AutoWeld_DTPoint_Right_TCPPose[count].Speed = 100;
            AutoWeld_DTPoint_Right_TCPPose[count].f1 = RobotDataEX.moni_RobotTCPActualPose[0];
            AutoWeld_DTPoint_Right_TCPPose[count].f2 = RobotDataEX.moni_RobotTCPActualPose[1];
            AutoWeld_DTPoint_Right_TCPPose[count].f3 = RobotDataEX.moni_RobotTCPActualPose[2];
            AutoWeld_DTPoint_Right_TCPPose[count].f4 = RobotDataEX.moni_RobotTCPActualPose[3];
            AutoWeld_DTPoint_Right_TCPPose[count].f5 = RobotDataEX.moni_RobotTCPActualPose[4];
            AutoWeld_DTPoint_Right_TCPPose[count].f6 = RobotDataEX.moni_RobotTCPActualPose[5];
        }

        //직접교시점 기록이 완료되었는지 체크하는 함수. 하나라도 기록이 안되어있으면 false 반환
        bool DTCompleteCheck(int LeftCount, int RightCount)
        {
            bool temp = true;

            for (int i = 0; i < LeftCount; i++)
            {
                if (DTPointLeftOK[i] == false) temp = false;
            }

            for (int i = 0; i < RightCount; i++)
            {
                if (DTPointRightOK[i] == false) temp = false;
            }

            return temp;

        }

        //직접교시 시퀀스에서 왼쪽교시 단계일때 하는일
        void DTLeftCheck(int count)
        {
            //좌우 선택된 셀 타입에 대한 티칭포인트 개수 가져옴
            int DTLeftCount;
            if (LeftWeldFlag == true)
            {
                string tempstr = CellTypeName_Left + "_DTPoint";
                DTLeftCount = CellTypeData[tempstr];
            }
            else
            {
                DTLeftCount = 0;
            }

            int DTRightCount;
            if (RightWeldFlag == true)
            {
                string tempstr = CellTypeName_Right + "_DTPoint";
                DTRightCount = CellTypeData[tempstr];
            }
            else
            {
                DTRightCount = 0;
            }

            //기록 요청이 들어올 경우 현재위치 기록
            if (AutoDTPoseRecordFlag == true)
            {
                //현재위치 기록
                DTLeftPoseRecord(count);
                DTPointLeftOK[count] = true;
                AutoDTPoseRecordFlag = false;
            }

            //다음번호 요청이 들어올 경우 다음번호로 변경
            if (AutoDTPoseNextFlag == true)
            {
                //티칭개수 비교
                if (DTLeftCount - 1 > count)
                {
                    AutoDTSubSeq = "L" + (count + 1).ToString() + " 티칭대기";
                }
                else if (DTRightCount != 0)
                {
                    AutoDTSubSeq = "R0 티칭대기";
                }
                AutoDTPoseNextFlag = false;
            }

            //현재위치 기본자세로 이동 요청이 들어올 경우 현재 시퀀스 상태를 버퍼에 저장한 다음 기본자세 이동시퀀스로 변경함. 이동 완료하고 원복 위해
            if (AutoDTPoseMoveFlag == true)
            {
                AutoDTSubSeq_Buffer = AutoDTSubSeq;
                AutoDTSubSeq = "기본자세이동 시작";

                AutoDTPoseMoveFlag = false;
            }

            //직접교시 완료요청이 들어올 경우 기록점이 빠진곳 없는지 체크하고 완료처리
            if (AutoDTEndFlag == true)
            {
                if (DTCompleteCheck(DTLeftCount, DTRightCount) == true)
                {
                    AutoDTSubSeq = "직접교시 완료";
                    RobotCommclass.RobotDirectTeachingOff();
                }
                AutoDTEndFlag = false;
            }

            if (AutoTouchAndWeldFlag == true)
            {
                if (DTCompleteCheck(DTLeftCount, DTRightCount) == true)
                {
                    AutoDTSubSeq = "직접교시 완료";
                    RobotCommclass.RobotDirectTeachingOff();
                }
                else
                {
                    AutoTouchAndWeldFlag = false;
                }
            }
        }

        //직접교시 시퀀스에서 오른쪽교시 단계일때 하는일
        void DTRightCheck(int count)
        {
            //좌우 선택된 셀 타입에 대한 티칭포인트 개수 가져옴
            int DTLeftCount;
            if (LeftWeldFlag == true)
            {
                DTLeftCount = CellTypeData[CellTypeName_Left + "_DTPoint"];
            }
            else
            {
                DTLeftCount = 0;
            }

            int DTRightCount;
            if (RightWeldFlag == true)
            {
                DTRightCount = CellTypeData[CellTypeName_Right + "_DTPoint"];
            }
            else
            {
                DTRightCount = 0;
            }

            //기록 요청이 들어올 경우 현재위치 기록
            if (AutoDTPoseRecordFlag == true)
            {
                //현재위치 기록
                DTRightPoseRecord(count);
                DTPointRightOK[count] = true;
                AutoDTPoseRecordFlag = false;
            }

            //다음번호 요청이 들어올 경우 다음번호로 변경
            if (AutoDTPoseNextFlag == true)
            {
                //티칭개수 비교
                if (DTRightCount - 1 > count) AutoDTSubSeq = "R" + (count + 1).ToString() + " 티칭대기";
                AutoDTPoseNextFlag = false;
            }

            //현재위치 기본자세로 이동 요청이 들어올 경우 현재 시퀀스 상태를 버퍼에 저장한 다음 기본자세 이동시퀀스로 변경함. 이동 완료하고 원복 위해
            if (AutoDTPoseMoveFlag == true)
            {
                AutoDTSubSeq_Buffer = AutoDTSubSeq;
                AutoDTSubSeq = "기본자세이동 시작";

                AutoDTPoseMoveFlag = false;
            }

            //직접교시 완료요청이 들어올 경우 기록점이 빠진곳 없는지 체크하고 완료처리
            if (AutoDTEndFlag == true)
            {
                RobotCommclass.RobotDirectTeachingOff();
                if (DTCompleteCheck(DTLeftCount, DTRightCount) == true) AutoDTSubSeq = "직접교시 완료";
                AutoDTEndFlag = false;
            }

            if (AutoTouchAndWeldFlag == true)
            {
                RobotCommclass.RobotDirectTeachingOff();
                if (DTCompleteCheck(DTLeftCount, DTRightCount) == true) AutoDTSubSeq = "직접교시 완료";
            }
        }

        //직접교시 시퀀스
        void DirectTeachingSeq()
        {
            string tempstr = "";
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            int tempi = 0;
            int InitPoseIndex = 0;
            int TargetPoseIndex = 0;

            switch (AutoDTSubSeq)
            {
                case "대기":

                    break;
                case "시작":

                    if (LeftWeldFlag == true)
                    {
                        AutoDTSubSeq = "L0 티칭대기";
                    }
                    else
                    {
                        AutoDTSubSeq = "R0 티칭대기";
                    }
                    break;

                case "L0 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(0);
                    break;

                case "L1 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(1);
                    break;

                case "L2 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(2);
                    break;

                case "L3 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(3);
                    break;

                case "L4 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(4);
                    break;

                case "L5 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(5);
                    break;

                case "L6 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(6);
                    break;

                case "L7 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(7);
                    break;

                case "L8 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(8);
                    break;

                case "L9 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(9);
                    break;

                case "L10 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(10);
                    break;

                case "L11 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(11);
                    break;

                case "L12 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(12);
                    break;

                case "L13 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(13);
                    break;

                case "L14 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(14);
                    break;

                case "L15 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(15);
                    break;

                case "L16 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(16);
                    break;

                case "L17 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(17);
                    break;

                case "L18 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(18);
                    break;

                case "L19 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(19);
                    break;

                case "L20 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(20);
                    break;

                case "L21 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(21);
                    break;

                case "L22 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(22);
                    break;

                case "L23 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(23);
                    break;

                case "L24 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(24);
                    break;

                case "L25 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(25);
                    break;

                case "L26 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(26);
                    break;

                case "L27 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(27);
                    break;

                case "L28 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(28);
                    break;

                case "L29 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(29);
                    break;

                case "L30 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(30);
                    break;

                case "L31 티칭대기":
                    //위치기록 플래그 체크
                    DTLeftCheck(31);
                    break;

                case "R0 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(0);
                    break;

                case "R1 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(1);
                    break;

                case "R2 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(2);
                    break;

                case "R3 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(3);
                    break;

                case "R4 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(4);
                    break;

                case "R5 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(5);
                    break;

                case "R6 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(6);
                    break;

                case "R7 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(7);
                    break;

                case "R8 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(8);
                    break;

                case "R9 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(9);
                    break;

                case "R10 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(10);
                    break;

                case "R11 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(11);
                    break;

                case "R12 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(12);
                    break;

                case "R13 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(13);
                    break;

                case "R14 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(14);
                    break;

                case "R15 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(15);
                    break;

                case "R16 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(16);
                    break;

                case "R17 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(17);
                    break;

                case "R18 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(18);
                    break;

                case "R19 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(19);
                    break;

                case "R20 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(20);
                    break;

                case "R21 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(21);
                    break;

                case "R22 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(22);
                    break;

                case "R23 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(23);
                    break;

                case "R24 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(24);
                    break;

                case "R25 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(25);
                    break;

                case "R26 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(26);
                    break;

                case "R27 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(27);
                    break;

                case "R28 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(28);
                    break;

                case "R29 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(29);
                    break;

                case "R30 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(30);
                    break;

                case "R31 티칭대기":
                    //위치기록 플래그 체크
                    DTRightCheck(31);
                    break;

                case "직접교시 완료":

                    break;
                case "직접교시 실패":

                    break;
                case "기본자세이동 시작":

                    //직접교시 끄기
                    RobotCommclass.RobotDirectTeachingOff();
                    DTOffTime = DateTime.Now;
                    AutoDTSubSeq = "기본자세이동 직접교시종료대기";

                    break;
                case "기본자세이동 직접교시종료대기":

                    //일정시간 대기
                    tempi = (int)(DateTime.Now - DTOffTime).Ticks / 10000;
                    if (tempi > 500)
                    {   //지정된 시간 이상 경과하면 다음 시퀀스로 넘어감
                        AutoDTSubSeq = "기본자세이동 모션명령";
                    }

                    break;
                case "기본자세이동 모션명령":

                    tempstr = "";
                    tempstr = CellTypeName_Left + "_" + AutoDTSubSeq_Buffer.Split(' ')[0];
                    TargetPoseIndex = CellTypePose[tempstr];
                    InitPoseIndex = FindCloseRDPIndex(RobotDataEX.moni_RobotTCPActualPose[0], RobotDataEX.moni_RobotTCPActualPose[1], RobotDataEX.moni_RobotTCPActualPose[2], RobotDataEX.moni_RobotTCPActualPose[3], RobotDataEX.moni_RobotTCPActualPose[4], RobotDataEX.moni_RobotTCPActualPose[5]);
                    tempRobotPoseArr.Add(TCP_BACK());


                    //if(TargetPoseIndex > InitPoseIndex)
                    //{
                    //    for (int i = InitPoseIndex; i <= TargetPoseIndex; i++) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                    //}
                    //else if(TargetPoseIndex < InitPoseIndex)
                    //{
                    //    for (int i = InitPoseIndex; i >= TargetPoseIndex; i--) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                    //}


                    string[] tempstrarr = textBox_TestMovePose.Text.Split(',');
                    List<int> movepose = new List<int>();
                    try
                    {
                        foreach (string str in tempstrarr) movepose.Add(Convert.ToInt32(str));
                    }
                    catch
                    {
                        return;
                    }


                    if (TargetPoseIndex > InitPoseIndex)
                    {
                        tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[InitPoseIndex].Clone());

                        for (int i = InitPoseIndex + 1; i < TargetPoseIndex; i++)
                        {
                            foreach (int j in movepose) if (i == j) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                        }

                        tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[TargetPoseIndex].Clone());
                    }
                    else if (TargetPoseIndex < InitPoseIndex)
                    {
                        tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[InitPoseIndex].Clone());

                        for (int i = InitPoseIndex + 1; i > TargetPoseIndex; i--)
                        {
                            foreach (int j in movepose) if (i == j) tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[i].Clone());
                        }

                        tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[TargetPoseIndex].Clone());
                    }
                    else
                    {
                    }




                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add(AutoDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 시작.");
                        AutoDTSubSeq = "기본자세이동 완료대기";

                    }
                    else
                    {
                        MainLog_Add(AutoDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 시작실패.");
                        AutoDTSubSeq = "기본자세이동 실패";
                    }
                    break;
                case "기본자세이동 완료대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add(AutoDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 성공.");
                        AutoDTSubSeq = "기본자세이동 성공";
                    }
                    else if (RobotCommclass.RobotControlThreadSeq == 310)
                    {//연속이동 시퀀스 실패
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add(AutoDTSubSeq_Buffer.Split(' ')[0] + "자세 기본위치이동 실패.");
                        AutoDTSubSeq = "기본자세이동 실패";
                    }

                    break;
                case "기본자세이동 성공":

                    //직접교시 켜기
                    RobotCommclass.RobotDirectTeachingOn();
                    AutoDTSubSeq = AutoDTSubSeq_Buffer;
                    break;
                case "기본자세이동 실패":

                    AutoDTSubSeq = AutoDTSubSeq_Buffer;
                    break;
                default:
                    break;
            }

        }



        //ST1 셀타입용 터치센싱 시퀀스. 인자 0:왼쪽, 1:오른쪽
        void TouchSeq_ST1(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();

            double tempd1, tempd2;

            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST1타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST1타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST1타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST1타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_BL()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_BR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":


                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                            , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                            , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), TCP_L_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[2] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), TCP_R_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[2] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
        }

        void TouchSeq_ST2(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();

            double tempd1, tempd2;
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST2타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST2타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST2타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST2타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                            //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                         , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                           , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
        }

        //ST3 셀타입용 터치센싱 시퀀스. 인자 0:왼쪽, 1:오른쪽
        void TouchSeq_ST3(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();
            double tempd1, tempd2;
            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_Middle2());                                                            //첫번째 경유점
                        tempRobotPoseArr.Add(TCP_B_L());                                                              //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0].f1, AutoWeld_TSPoint_Left_TCPPose[0].f2, AutoWeld_TSPoint_Left_TCPPose[0].f3+10, TCP_B_L()));   //터치위치
                        //tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_B()));   //터치위치

                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_Middle2());                                                            //첫번째 경유점
                        tempRobotPoseArr.Add(TCP_B_RR());                                                             //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0].f1, AutoWeld_TSPoint_Right_TCPPose[0].f2, AutoWeld_TSPoint_Right_TCPPose[0].f3+10, TCP_B_RR())); //터치위치
                        //tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_B())); //터치위치

                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장

                  
                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_1th(0, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_1th(0, 0, 0);
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                                                                                //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_B_L()));   //터치위치
                        //tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_B()));   //터치위치

                    }
                    else
                    {//오른쪽
                        
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_B_RR())); //터치위치
                        //tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_B())); //터치위치

                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "1번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;

                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장

                    

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_1th(0, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_1th(0, 0, 0);
                        }

                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":


                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                            , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                            , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[2] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 0, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[2] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 0, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;




                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_B_L());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
        }



        //ST2_CP1F 셀타입용 터치센싱 시퀀스. 인자 0:왼쪽, 1:오른쪽
        void TouchSeq_ST2_CP1F(int dir)
        {/*
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();
            double tempd1, tempd2;
            float f1, f2, f3, f4, f5, f6;

            switch (TouchSensingSubSeq)
            {
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST2+CP1F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST2+CP1F타입 터치센싱 시작.");
                    TouchSensingSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽 0,1,2,4,5번 부터 계산. 나머지는 터치센싱 결과로 다시 계산함
                        MainLog_Add("왼쪽 ST2+CP1F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[5].f2 = AutoWeld_TSPoint_Left_TCPPose[2].f2;
                    }
                    else
                    {//오른쪽 0,1,2,4,5번 부터 계산. 나머지는 터치센싱 결과로 다시 계산함
                        MainLog_Add("오른쪽 ST2+CP1F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[5].f2 = AutoWeld_TSPoint_Right_TCPPose[2].f2;
                    }
                    TouchSensingSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());                                          //첫번째 경유점
                        tempRobotPoseArr.Add((RobotPoseData)RDP_Joint[7].Clone());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], RDP_TCP[7]));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());                                          //첫번째 경유점
                        tempRobotPoseArr.Add((RobotPoseData)RDP_Joint[11].Clone());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], RDP_TCP[11]));    //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "0번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }

                    break;
                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;
                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                    TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -1, 0, 1));

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "0번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }

                    break;
                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[0] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[0] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], RDP_TCP[7]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], RDP_TCP[11]));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "1번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 1, 0, 30, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, -1, 0, 30, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "1번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[1] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[1] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "2번 터치점 위치이동 시작";
                    }

                    break;
                case "2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RDP_TCP[3]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RDP_TCP[15]));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "2번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "2번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;
                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 1, 0, 10, 20, 1, 0, -1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 50, 20, 1, -3, -3, -1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, -1, 0, 10, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 50, 20, 1, -3, 3, -1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "2번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[2].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            tempRobotPose.f2 = tempRobotPose.f2 + 10;
                            AutoWeld_WedlPoint_Left[2] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[2].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            tempRobotPose.f2 = tempRobotPose.f2 - 10;
                            AutoWeld_WedlPoint_Right[2] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        //3번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[2].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            tempRobotPose.f2 = RobotCommclass.TouchPosition[0].f2;
                            AutoWeld_WedlPoint_Left[3] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[2].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            tempRobotPose.f2 = RobotCommclass.TouchPosition[0].f2;
                            AutoWeld_WedlPoint_Right[3] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -50, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());
                        tempRobotPoseArr.Add((RobotPoseData)RDP_Joint[1].Clone());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[4], RDP_TCP[0]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -50, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());
                        tempRobotPoseArr.Add((RobotPoseData)RDP_Joint[18].Clone());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[4], RDP_TCP[18]));
                    }



                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "4번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -3, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -3, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "4번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //4번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[6] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[6] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;
                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], RDP_TCP[0]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], RDP_TCP[18]));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "5번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -3, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -3, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "5번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //5번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[5] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[5] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        //3,6,7번 터치센싱 위치 계산
                        if (dir == 0)
                        {//왼쪽
                            //계산점 3,5로 칼라플레이트 원호 지름계산
                            tempd1 = AutoWeld_WedlPoint_Left[5].f3 - AutoWeld_WedlPoint_Left[3].f3;

                            //3,6,7번 좌표 계산
                            f1 = (float)(AutoWeld_WedlPoint_Left[5].f1 - 30);
                            f2 = (float)(AutoWeld_WedlPoint_Left[5].f2 - tempd1 / 2 - 20);
                            f3 = (float)(AutoWeld_WedlPoint_Left[5].f3 - tempd1 / 2);
                            AutoWeld_TSPoint_Left_TCPPose[3] = new RobotPoseData(2, 100, f1, f2, f3, 0, 0, 0);

                            f1 = (float)(AutoWeld_WedlPoint_Left[5].f1 - 30);
                            f2 = (float)(AutoWeld_WedlPoint_Left[5].f2 - tempd1 / 4);
                            f3 = (float)(AutoWeld_WedlPoint_Left[5].f3 + 10);
                            AutoWeld_TSPoint_Left_TCPPose[6] = new RobotPoseData(2, 100, f1, f2, f3, 0, 0, 0);

                            f1 = (float)(AutoWeld_WedlPoint_Left[3].f1 - 30);
                            f2 = (float)(AutoWeld_WedlPoint_Left[3].f2 - tempd1 / 4);
                            f3 = (float)(AutoWeld_WedlPoint_Left[3].f3 - 10);
                            AutoWeld_TSPoint_Left_TCPPose[7] = new RobotPoseData(2, 100, f1, f2, f3, 0, 0, 0);

                        }
                        else
                        {//오른쪽
                            //계산점 3,5로 칼라플레이트 원호 지름계산
                            tempd1 = AutoWeld_WedlPoint_Right[5].f3 - AutoWeld_WedlPoint_Right[3].f3;

                            //3,6,7번 좌표 계산
                            f1 = (float)(AutoWeld_WedlPoint_Right[5].f1 - 30);
                            f2 = (float)(AutoWeld_WedlPoint_Right[5].f2 - tempd1 / 2 - 20);
                            f3 = (float)(AutoWeld_WedlPoint_Right[5].f3 - tempd1 / 2);
                            AutoWeld_TSPoint_Right_TCPPose[3] = new RobotPoseData(2, 100, f1, f2, f3, 0, 0, 0);

                            f1 = (float)(AutoWeld_WedlPoint_Right[5].f1 - 30);
                            f2 = (float)(AutoWeld_WedlPoint_Right[5].f2 - tempd1 / 4);
                            f3 = (float)(AutoWeld_WedlPoint_Right[5].f3 + 10);
                            AutoWeld_TSPoint_Right_TCPPose[6] = new RobotPoseData(2, 100, f1, f2, f3, 0, 0, 0);

                            f1 = (float)(AutoWeld_WedlPoint_Right[3].f1 - 30);
                            f2 = (float)(AutoWeld_WedlPoint_Right[3].f2 - tempd1 / 4);
                            f3 = (float)(AutoWeld_WedlPoint_Right[3].f3 - 10);
                            AutoWeld_TSPoint_Right_TCPPose[7] = new RobotPoseData(2, 100, f1, f2, f3, 0, 0, 0);
                        }

                        TouchSensingSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;
                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[6], RDP_TCP[1]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[6], RDP_TCP[17]));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "6번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -3, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, -1, 30, 20, 1, -3, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "6번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //6번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[7] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[7] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[3], RDP_TCP[1]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[3], RDP_TCP[17]));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "3번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;
                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 1, 0, 30, 20, 1, -3, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, -1, 0, 30, 20, 1, -3, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "3번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //3번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[4] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[4] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "7번 터치점 위치이동 시작";
                    }

                    break;
                case "7번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[7], RDP_TCP[3]));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(3, 100, -30, 0, 0, 0, 0, 0));     //뒤로 30mm 후진
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[7], RDP_TCP[15]));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("7번 터치점 위치이동 시작.");
                        TouchSensingSubSeq = "7번 터치점 위치이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("7번 터치점 위치이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "7번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 터치점 위치이동 완료.");
                        TouchSensingSubSeq = "7번위치 터치센싱 시작";
                    }

                    break;
                case "7번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 30, 20, 1, -3, 0, -1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(50, 10, 1, 0, 0, 1, 30, 20, 1, -3, 0, -1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("7번 위치 터치센싱 시작.");
                        TouchSensingSubSeq = "7번위치 터치센싱 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("7번 위치 터치센싱 시작 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }


                    break;
                case "7번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 위치 터치센싱 완료.");

                        //7번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Left[8] = (RobotPoseData)tempRobotPose.Clone();
                        }
                        else
                        {//오른쪽
                            tempRobotPose = (RobotPoseData)RobotCommclass.TouchPosition[1].Clone();
                            tempRobotPose.f1 = tempRobotPose.f1 + 10;
                            AutoWeld_WedlPoint_Right[8] = (RobotPoseData)tempRobotPose.Clone();
                        }

                        TouchSensingSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[3].Clone());
                        tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add((RobotPoseData)RDP_TCP[15].Clone());
                        tempRobotPoseArr.Add((RobotPoseData)RobotMiddlePose2.Clone());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        TouchSensingSubSeq = "종료위치 이동 완료 대기";

                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        TouchSensingSubSeq = "터치시퀀스 실패";

                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        TouchSensingSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }


            */

        }



        //ST3+CP3F 셀타입용 터치센싱 시퀀스. 인자 0:왼쪽, 1:오른쪽

        void TouchSeq_ST3_CP3F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();

            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP3F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP3F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP3F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_JointPose[7].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[7].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP3F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_JointPose[7].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[7].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                      //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_BL()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_BR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":


                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[6].f1, AutoWeld_WedlPoint_Left[6].f2, AutoWeld_WedlPoint_Left[6].f3
                            , AutoWeld_WedlPoint_Left[5].f1, AutoWeld_WedlPoint_Left[5].f2, AutoWeld_WedlPoint_Left[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[6].f1, AutoWeld_WedlPoint_Right[6].f2, AutoWeld_WedlPoint_Right[6].f3
                            , AutoWeld_WedlPoint_Right[5].f1, AutoWeld_WedlPoint_Right[5].f2, AutoWeld_WedlPoint_Right[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), TCP_L_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), TCP_R_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_BL().f4, TCP_BL().f5, TCP_BL().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[3], RRx, RRy, RRz));


                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_BR().f4, TCP_BR().f5, TCP_BR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[3], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_3th(10, 20, 0);
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_3th(10, 20, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;

                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Left[2].f1 - 30, AutoWeld_WedlPoint_Left[2].f2 + 20, AutoWeld_WedlPoint_Left[2].f3 + 30, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Right[2].f1 - 30, AutoWeld_WedlPoint_Right[2].f2 - 20, AutoWeld_WedlPoint_Right[2].f3 + 30, RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Left[3].f2 = AutoWeld_WedlPoint_Left[2].f2;
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Right[3].f2 = AutoWeld_WedlPoint_Right[2].f2;
                        }

                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;

                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], TCP_LCP_L()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], TCP_RCP_R()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;
                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7], RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "6번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "6번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "7번 터치점 위치이동 시작";
                    }

                    break;
                case "7번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장

                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7].f1, AutoWeld_TSPoint_Left_TCPPose[7].f2 + 15, AutoWeld_TSPoint_Left_TCPPose[7].f3, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7].f1, AutoWeld_TSPoint_Right_TCPPose[7].f2 - 15, AutoWeld_TSPoint_Right_TCPPose[7].f3, RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("7번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "7번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("7번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "7번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "7번위치 터치센싱 시작";
                    }

                    break;
                case "7번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("7번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "7번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("7번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "7번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 위치 터치센싱 완료.");

                        //6번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[8] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[8] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LB(), TCP_LCP_LB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_L(), TCP_LCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LU(), TCP_LCP_LU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_L(), TCP_U_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L(), TCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_B(), TCP_L_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RB(), TCP_RCP_RB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_R(), TCP_RCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RU(), TCP_RCP_RU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_RR(), TCP_U_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R(), TCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_B(), TCP_R_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }

        void TouchSeq_ST3_CP3B(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP3B타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP3B타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP3B타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);

                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP3B타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);

                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);

                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                        //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_BL()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_BR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":


                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                            , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                            , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), TCP_L_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), TCP_R_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2].f1, AutoWeld_TSPoint_Left_TCPPose[2].f2+60, AutoWeld_TSPoint_Left_TCPPose[2].f3, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2].f1, AutoWeld_TSPoint_Right_TCPPose[2].f2-60, AutoWeld_TSPoint_Right_TCPPose[2].f3, RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;
                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        //TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        //TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }
                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                       
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                        
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }

                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;

                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }

        //ST3+CP3F 셀타입용 터치센싱 시퀀스. 인자 0:왼쪽, 1:오른쪽
        void TouchSeq_ST3_CP4F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP4F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP4F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP4F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP4F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_L());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽

                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        
                        tempRobotPoseArr.Add(TCP_R());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, 0, -1, 0));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                         , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                           , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;

                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[3], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[3], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;
                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //3번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[4], TCP_LCP_L()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[4], TCP_RCP_R()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;
                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[5], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[5], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;
                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[6].f1, AutoWeld_TSPoint_Left_TCPPose[6].f2 + 15, AutoWeld_TSPoint_Left_TCPPose[6].f3, TCP_LCP_LB()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[6].f1, AutoWeld_TSPoint_Right_TCPPose[6].f2 + 15, AutoWeld_TSPoint_Right_TCPPose[6].f3, TCP_RCP_RB()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "6번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "6번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //6번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LB(), TCP_LCP_LB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_L(), TCP_LCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LU(), TCP_LCP_LU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_L(), TCP_U_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RB(), TCP_RCP_RB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_R(), TCP_RCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RU(), TCP_RCP_RU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_RR(), TCP_U_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }

        void TouchSeq_ST3_CP8F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();

            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP8F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP8F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP8F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_JointPose[7].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[7].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP8F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_JointPose[7].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[7].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                     //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_BL()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_BR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":


                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[6].f1, AutoWeld_WedlPoint_Left[6].f2, AutoWeld_WedlPoint_Left[6].f3
                            , AutoWeld_WedlPoint_Left[5].f1, AutoWeld_WedlPoint_Left[5].f2, AutoWeld_WedlPoint_Left[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[6].f1, AutoWeld_WedlPoint_Right[6].f2, AutoWeld_WedlPoint_Right[6].f3
                            , AutoWeld_WedlPoint_Right[5].f1, AutoWeld_WedlPoint_Right[5].f2, AutoWeld_WedlPoint_Right[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), TCP_L_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), TCP_R_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_BL().f4, TCP_BL().f5, TCP_BL().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[3], RRx, RRy, RRz));


                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_BR().f4, TCP_BR().f5, TCP_BR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[3], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_3th(10, 20, 0);
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_3th(10, 20, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;

                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Left[2].f1 - 30, AutoWeld_WedlPoint_Left[2].f2 + 20, AutoWeld_WedlPoint_Left[2].f3 + 30, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Right[2].f1 - 30, AutoWeld_WedlPoint_Right[2].f2 - 20, AutoWeld_WedlPoint_Right[2].f3 + 30, RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Left[3].f2 = AutoWeld_WedlPoint_Left[2].f2;
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Right[3].f2 = AutoWeld_WedlPoint_Right[2].f2;
                        }

                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;

                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], TCP_LCP_L()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], TCP_RCP_R()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;
                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7], RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "6번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "6번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "7번 터치점 위치이동 시작";
                    }

                    break;
                case "7번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장

                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7].f1, AutoWeld_TSPoint_Left_TCPPose[7].f2 + 15, AutoWeld_TSPoint_Left_TCPPose[7].f3, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7].f1, AutoWeld_TSPoint_Right_TCPPose[7].f2 - 15, AutoWeld_TSPoint_Right_TCPPose[7].f3, RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("7번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "7번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("7번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "7번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "7번위치 터치센싱 시작";
                    }

                    break;
                case "7번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("7번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "7번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("7번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "7번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 위치 터치센싱 완료.");

                        //6번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[8] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[8] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LB(), TCP_LCP_LB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_L(), TCP_LCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LU(), TCP_LCP_LU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_L(), TCP_U_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L(), TCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_B(), TCP_L_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RB(), TCP_RCP_RB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_R(), TCP_RCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RU(), TCP_RCP_RU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_RR(), TCP_U_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R(), TCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_B(), TCP_R_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }

        void TouchSeq_ST4_CP5F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();

            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP3F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP3F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP3F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);

                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP3F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                       //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_BL()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_BR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":

                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[6].f1, AutoWeld_WedlPoint_Left[6].f2, AutoWeld_WedlPoint_Left[6].f3
                            , AutoWeld_WedlPoint_Left[5].f1, AutoWeld_WedlPoint_Left[5].f2, AutoWeld_WedlPoint_Left[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[6].f1, AutoWeld_WedlPoint_Right[6].f2, AutoWeld_WedlPoint_Right[6].f3
                            , AutoWeld_WedlPoint_Right[5].f1, AutoWeld_WedlPoint_Right[5].f2, AutoWeld_WedlPoint_Right[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), TCP_L_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), TCP_R_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_BL().f4, TCP_BL().f5, TCP_BL().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[3], RRx, RRy, RRz));


                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_BR().f4, TCP_BR().f5, TCP_BR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[3], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_3th(10, 20, 0);
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_3th(10, 20, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;

                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Left[2].f1 - 30, AutoWeld_WedlPoint_Left[2].f2 + 20, AutoWeld_WedlPoint_Left[2].f3 + 30, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Right[2].f1 - 30, AutoWeld_WedlPoint_Right[2].f2 - 20, AutoWeld_WedlPoint_Right[2].f3 + 30, RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Left[3].f2 = AutoWeld_WedlPoint_Left[2].f2;
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Right[3].f2 = AutoWeld_WedlPoint_Right[2].f2;
                        }

                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;

                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], TCP_LCP_L()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], TCP_RCP_R()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;

                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7], RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "6번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "6번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "7번 터치점 위치이동 시작";
                    }

                    break;


                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LB(), TCP_LCP_LB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_L(), TCP_LCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LU(), TCP_LCP_LU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_L(), TCP_U_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L(), TCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_B(), TCP_L_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RB(), TCP_RCP_RB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_R(), TCP_RCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RU(), TCP_RCP_RU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_RR(), TCP_U_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R(), TCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_B(), TCP_R_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }
        void TouchSeq_ST4_CP6F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();

            double tempd1, tempd2;
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST4_CP6F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST4_CP6F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST4_CP6F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST4_CP6F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                          //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                         , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                           , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(Joint_L_U());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[3], TCP_L_B()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(Joint_R_U());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[3], TCP_R_B()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "3번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }

                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[4], TCP_LCP_L()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[4], TCP_RCP_R()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "4번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;

                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }

                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;
                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "5번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;

                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
        }
        void TouchSeq_ST4_CP11F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();

            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST4+CP11F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST4+CP11F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP3F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        //AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        // AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);

                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP3F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        //AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        //AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                        //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_BL()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_BR()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번위치 터치센싱 시작";
                    }

                    break;
                case "각도계산 및 2번위치 터치센싱 시작":


                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[6].f1, AutoWeld_WedlPoint_Left[6].f2, AutoWeld_WedlPoint_Left[6].f3
                            , AutoWeld_WedlPoint_Left[5].f1, AutoWeld_WedlPoint_Left[5].f2, AutoWeld_WedlPoint_Left[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[6].f1, AutoWeld_WedlPoint_Right[6].f2, AutoWeld_WedlPoint_Right[6].f3
                            , AutoWeld_WedlPoint_Right[5].f1, AutoWeld_WedlPoint_Right[5].f2, AutoWeld_WedlPoint_Right[5].f3);
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), TCP_L_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Left[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, 20, 0), RRx, RRy, RRz);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), TCP_R_BB());
                            RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                            AutoWeld_WedlPoint_Right[4] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_1th(20, -20, 0), RRx, RRy, RRz);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_BL().f4, TCP_BL().f5, TCP_BL().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[3], RRx, RRy, RRz));


                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_BR().f4, TCP_BR().f5, TCP_BR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[3], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_3th(10, 20, 0);
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_3th(10, 20, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;

                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Left[2].f1 - 30, AutoWeld_WedlPoint_Left[2].f2 + 20, AutoWeld_WedlPoint_Left[2].f3 + 30, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Right[2].f1 - 30, AutoWeld_WedlPoint_Right[2].f2 - 20, AutoWeld_WedlPoint_Right[2].f3 + 30, RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Left[3].f2 = AutoWeld_WedlPoint_Left[2].f2;
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Right[3].f2 = AutoWeld_WedlPoint_Right[2].f2;
                        }

                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;

                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], TCP_L_U()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], TCP_R_U()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;


                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L(), TCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_B(), TCP_L_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R(), TCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_B(), TCP_R_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }
        void TouchSeq_ST4_CP12F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tempRobotPose = new RobotPoseData();

            double tempd1, tempd2;
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST4_CP12F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST4_CP12F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST4_CP6F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST4_CP6F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                        //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                         , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                           , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(Joint_L_U());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[3], TCP_L_B()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(Joint_R_U());                                         //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[3], TCP_R_B()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "3번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }

                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[4], TCP_LCP_L()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[4], TCP_RCP_R()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "4번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;

                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }

                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;

                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(TCP_Middle2());
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }
        }
        void TouchSeq_ST3_CP9F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();

            float RRx, RRy, RRz;
            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP9F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP9F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP9F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_JointPose[7].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[7].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP9F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_JointPose[7].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[7].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                        //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[6].f1, AutoWeld_WedlPoint_Left[6].f2, AutoWeld_WedlPoint_Left[6].f3
                         , AutoWeld_WedlPoint_Left[5].f1, AutoWeld_WedlPoint_Left[5].f2, AutoWeld_WedlPoint_Left[5].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[6].f1, AutoWeld_WedlPoint_Right[6].f2, AutoWeld_WedlPoint_Right[6].f3
                           , AutoWeld_WedlPoint_Right[5].f1, AutoWeld_WedlPoint_Right[5].f2, AutoWeld_WedlPoint_Right[5].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[4] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[4] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_BL().f4, TCP_BL().f5, TCP_BL().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[3], RRx, RRy, RRz));


                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_BR().f4, TCP_BR().f5, TCP_BR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[3], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;

                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));

                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_3th(10, 20, 0);
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_3th(10, 20, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_3th(10, -20, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;

                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Left[2].f1 - 30, AutoWeld_WedlPoint_Left[2].f2 + 20, AutoWeld_WedlPoint_Left[2].f3 + 30, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_WedlPoint_Right[2].f1 - 30, AutoWeld_WedlPoint_Right[2].f2 - 20, AutoWeld_WedlPoint_Right[2].f3 + 30, RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Left[3].f2 = AutoWeld_WedlPoint_Left[2].f2;
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                            AutoWeld_WedlPoint_Right[3].f2 = AutoWeld_WedlPoint_Right[2].f2;
                        }

                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;

                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[5], TCP_LCP_L()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[5], TCP_RCP_R()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽

                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);

                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;
                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7], RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "6번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "6번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[7] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "7번 터치점 위치이동 시작";
                    }

                    break;
                case "7번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장

                    if (dir == 0)
                    {//왼쪽

                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[7].f1, AutoWeld_TSPoint_Left_TCPPose[7].f2 + 15, AutoWeld_TSPoint_Left_TCPPose[7].f3, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽

                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[7].f1, AutoWeld_TSPoint_Right_TCPPose[7].f2 - 15, AutoWeld_TSPoint_Right_TCPPose[7].f3, RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("7번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "7번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("7번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "7번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "7번위치 터치센싱 시작";
                    }

                    break;
                case "7번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("7번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "7번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("7번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "7번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("7번 위치 터치센싱 완료.");

                        //6번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[8] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[8] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LB(), TCP_LCP_LB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_L(), TCP_LCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LU(), TCP_LCP_LU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_L(), TCP_U_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L(), TCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_B(), TCP_L_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RB(), TCP_RCP_RB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_R(), TCP_RCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RU(), TCP_RCP_RU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_RR(), TCP_U_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R(), TCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_B(), TCP_R_B()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }
        void TouchSeq_ST3_CP9B(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP9B타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP9B타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP9B타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[3]);

                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP9B타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);

                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);

                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);

                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L_U()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R_U());                                                        //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R_U()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, 0, -1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));        //두번째 터치모션 터치결과는 RobotCommclass.TouchPosition[1]에 저장
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_L_U());
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = new RobotPoseData(2, 100, RobotCommclass.GetTouchPose_2th(20, 0, 0), TCP_R_U());
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 20, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                         , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                           , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[4] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[4] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;
                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2].f1, AutoWeld_TSPoint_Left_TCPPose[2].f2+60, AutoWeld_TSPoint_Left_TCPPose[2].f3, RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2].f1, AutoWeld_TSPoint_Right_TCPPose[2].f1-60, AutoWeld_TSPoint_Right_TCPPose[2].f3, RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;
                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        //TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        //TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 20, 20, 1, 0, 1, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }
                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    tempRobotPoseArr.Add(TCP_BACK());
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz));
                    }


                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }

                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;

                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }
        void TouchSeq_ST3_CP10F(int dir)
        {
            List<RobotPoseData> tempRobotPoseArr = new List<RobotPoseData>();
            List<TouchSensingData> TempTouchDataArr = new List<TouchSensingData>();
            RobotPoseData tP = new RobotPoseData();
            float RRx, RRy, RRz;

            switch (AutoTSSubSeq)
            {
                case "대기":
                    //대기상태
                    break;
                case "시작":
                    if (dir == 0) MainLog_Add("왼쪽 ST3+CP10F타입 터치센싱 시작."); else MainLog_Add("오른쪽 ST3+CP10F타입 터치센싱 시작.");
                    AutoTSSubSeq = "터치센싱 위치 계산";
                    break;
                case "터치센싱 위치 계산":
                    if (dir == 0)
                    {//왼쪽
                        MainLog_Add("왼쪽 ST3+CP10F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Left_JointPose[0].Copy(AutoWeld_DTPoint_Left_JointPose[0]);
                        AutoWeld_TSPoint_Left_JointPose[1].Copy(AutoWeld_DTPoint_Left_JointPose[1]);
                        AutoWeld_TSPoint_Left_JointPose[2].Copy(AutoWeld_DTPoint_Left_JointPose[2]);
                        AutoWeld_TSPoint_Left_JointPose[3].Copy(AutoWeld_DTPoint_Left_JointPose[3]);
                        AutoWeld_TSPoint_Left_JointPose[4].Copy(AutoWeld_DTPoint_Left_JointPose[4]);
                        AutoWeld_TSPoint_Left_JointPose[5].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_JointPose[6].Copy(AutoWeld_DTPoint_Left_JointPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[0].Copy(AutoWeld_DTPoint_Left_TCPPose[0]);
                        AutoWeld_TSPoint_Left_TCPPose[1].Copy(AutoWeld_DTPoint_Left_TCPPose[1]);
                        AutoWeld_TSPoint_Left_TCPPose[2].Copy(AutoWeld_DTPoint_Left_TCPPose[2]);
                        AutoWeld_TSPoint_Left_TCPPose[3].Copy(AutoWeld_DTPoint_Left_TCPPose[3]);
                        AutoWeld_TSPoint_Left_TCPPose[4].Copy(AutoWeld_DTPoint_Left_TCPPose[4]);
                        AutoWeld_TSPoint_Left_TCPPose[5].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                        AutoWeld_TSPoint_Left_TCPPose[6].Copy(AutoWeld_DTPoint_Left_TCPPose[5]);
                    }
                    else
                    {//오른쪽
                        MainLog_Add("오른쪽 ST3+CP10F타입 터치센싱 위치 계산.");
                        AutoWeld_TSPoint_Right_JointPose[0].Copy(AutoWeld_DTPoint_Right_JointPose[0]);
                        AutoWeld_TSPoint_Right_JointPose[1].Copy(AutoWeld_DTPoint_Right_JointPose[1]);
                        AutoWeld_TSPoint_Right_JointPose[2].Copy(AutoWeld_DTPoint_Right_JointPose[2]);
                        AutoWeld_TSPoint_Right_JointPose[3].Copy(AutoWeld_DTPoint_Right_JointPose[3]);
                        AutoWeld_TSPoint_Right_JointPose[4].Copy(AutoWeld_DTPoint_Right_JointPose[4]);
                        AutoWeld_TSPoint_Right_JointPose[5].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_JointPose[6].Copy(AutoWeld_DTPoint_Right_JointPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[0].Copy(AutoWeld_DTPoint_Right_TCPPose[0]);
                        AutoWeld_TSPoint_Right_TCPPose[1].Copy(AutoWeld_DTPoint_Right_TCPPose[1]);
                        AutoWeld_TSPoint_Right_TCPPose[2].Copy(AutoWeld_DTPoint_Right_TCPPose[2]);
                        AutoWeld_TSPoint_Right_TCPPose[3].Copy(AutoWeld_DTPoint_Right_TCPPose[3]);
                        AutoWeld_TSPoint_Right_TCPPose[4].Copy(AutoWeld_DTPoint_Right_TCPPose[4]);
                        AutoWeld_TSPoint_Right_TCPPose[5].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                        AutoWeld_TSPoint_Right_TCPPose[6].Copy(AutoWeld_DTPoint_Right_TCPPose[5]);
                    }
                    AutoTSSubSeq = "0번 터치점 위치이동 시작";
                    break;
                case "0번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(TCP_B());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[0], TCP_L()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(TCP_B_RR());
                        tempRobotPoseArr.Add(TCP_R_BB());
                        tempRobotPoseArr.Add(TCP_R());                                                        //두번째 경유점
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[0], TCP_R()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("0번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "0번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "0번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "0번위치 터치센싱 시작";
                    }

                    break;

                case "0번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, 0, -1, 0));

                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, 0, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("0번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "0번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("0번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }
                    break;

                case "0번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("0번 위치 터치센싱 완료.");

                        //0번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[0] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[0] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }

                        AutoTSSubSeq = "1번 터치점 위치이동 시작";
                    }

                    break;
                case "1번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[1], TCP_L_B()));       //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[1], TCP_R_B()));     //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("1번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "1번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "1번위치 터치센싱 시작";
                    }

                    break;
                case "1번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("1번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "1번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("1번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "1번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("1번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[1] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "각도계산 및 2번 터치점 위치이동 시작";
                    }

                    break;
                case "각도계산 및 2번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempAngle.RobotWeldAngleLeft(AutoWeld_WedlPoint_Left[0].f1, AutoWeld_WedlPoint_Left[0].f2, AutoWeld_WedlPoint_Left[0].f3
                         , AutoWeld_WedlPoint_Left[1].f1, AutoWeld_WedlPoint_Left[1].f2, AutoWeld_WedlPoint_Left[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_L().f4, TCP_B_L().f5, TCP_B_L().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[2], RRx, RRy, RRz));     //첫번째 터치위치
                    }
                    else
                    {//오른쪽
                        tempAngle.RobotWeldAngleRight(AutoWeld_WedlPoint_Right[0].f1, AutoWeld_WedlPoint_Right[0].f2, AutoWeld_WedlPoint_Right[0].f3
                           , AutoWeld_WedlPoint_Right[1].f1, AutoWeld_WedlPoint_Right[1].f2, AutoWeld_WedlPoint_Right[1].f3);
                        RobotCommclass.RobotBaseRotation(TCP_B_RR().f4, TCP_B_RR().f5, TCP_B_RR().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[2], RRx, RRy, RRz)); //첫번째 터치위치
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("2번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "2번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;

                case "2번 터치점 위치이동 완료 대기":
                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "2번위치 터치센싱 시작";
                    }

                    break;

                case "2번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();
                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽

                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, -1, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 20, 20, 1, -1, 0, 0));        //첫번째 터치모션 터치결과는 RobotCommclass.TouchPosition[0]에 저장
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 1, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("2번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "2번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("2번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;


                case "2번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("2번 위치 터치센싱 완료.");


                        //2번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[2] = RobotCommclass.GetTouchPose_2th(20, 0, 0);
                        }
                        AutoTSSubSeq = "3번 터치점 위치이동 시작";
                    }

                    break;

                case "3번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[3], TCP_L_B()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[3], TCP_R_B()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("3번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "3번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "3번위치 터치센싱 시작";
                    }

                    break;
                case "3번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("3번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "3번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("3번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "3번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("3번 위치 터치센싱 완료.");

                        //3번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[3] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "4번 터치점 위치이동 시작";
                    }

                    break;
                case "4번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Left_TCPPose[4], TCP_LCP_L()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 100, AutoWeld_TSPoint_Right_TCPPose[4], TCP_RCP_R()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("4번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "4번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "4번위치 터치센싱 시작";
                    }

                    break;
                case "4번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, 1, 0, 50, 20, 1, -1, -1, 0));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 0, -1, 0, 50, 20, 1, -1, 1, 0));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("4번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "4번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("4번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "4번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("4번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[4] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "5번 터치점 위치이동 시작";
                    }

                    break;
                case "5번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        RobotCommclass.RobotBaseRotation(TCP_LCP_LB().f4, TCP_LCP_LB().f5, TCP_LCP_LB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[5], RRx, RRy, RRz));
                    }
                    else
                    {//오른쪽
                        RobotCommclass.RobotBaseRotation(TCP_RCP_RB().f4, TCP_RCP_RB().f5, TCP_RCP_RB().f6, 0, 1, 0, (float)(tempAngle.Ry * 180 / (2 * Math.PI) - 45), out RRx, out RRy, out RRz);

                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[5], RRx, RRy, RRz));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("5번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "5번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "5번위치 터치센싱 시작";
                    }

                    break;
                case "5번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("5번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "5번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("5번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "5번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("5번 위치 터치센싱 완료.");

                        //1번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[5] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[5] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "6번 터치점 위치이동 시작";
                    }

                    break;
                case "6번 터치점 위치이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();
                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Left_TCPPose[6].f1, AutoWeld_TSPoint_Left_TCPPose[6].f2 + 15, AutoWeld_TSPoint_Left_TCPPose[6].f3, TCP_LCP_LB()));
                    }
                    else
                    {//오른쪽
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, AutoWeld_TSPoint_Right_TCPPose[6].f1, AutoWeld_TSPoint_Right_TCPPose[6].f2 + 15, AutoWeld_TSPoint_Right_TCPPose[6].f3, TCP_RCP_RB()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("6번 터치점 위치이동 시작.");
                        AutoTSSubSeq = "6번 터치점 위치이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 터치점 위치이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번 터치점 위치이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 터치점 위치이동 완료.");
                        AutoTSSubSeq = "6번위치 터치센싱 시작";
                    }

                    break;
                case "6번위치 터치센싱 시작":
                    TempTouchDataArr.Clear();

                    //터치경로 저장
                    if (dir == 0)
                    {//왼쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }
                    else
                    {//오른쪽
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, 1, 0, 0, 10, 20, 1, -1, 0, 0));
                        TempTouchDataArr.Add(new TouchSensingData(100, 10, 1, tempAngle.xmove(tempAngle.Ry), 0, -1, 50, 20, 1, -1, 0, 1));
                    }

                    //로봇 연속터치시퀀스 실행
                    if (1 == RobotCommclass.TouchSensingStart(TempTouchDataArr))
                    {
                        MainLog_Add("6번 위치 터치센싱 시작.");
                        AutoTSSubSeq = "6번위치 터치센싱 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("6번 위치 터치센싱 시작 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }


                    break;
                case "6번위치 터치센싱 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 280)
                    {//연속터치 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        MainLog_Add("6번 위치 터치센싱 완료.");

                        //6번 계산점 계산
                        if (dir == 0)
                        {//왼쪽
                            AutoWeld_WedlPoint_Left[6] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        else
                        {//오른쪽
                            AutoWeld_WedlPoint_Right[6] = RobotCommclass.GetTouchPose_2th(10, 0, 0);
                        }
                        AutoTSSubSeq = "종료위치 이동 시작";
                    }

                    break;
                case "종료위치 이동 시작":
                    //이동경로 초기화
                    tempRobotPoseArr.Clear();

                    //이동경로 저장
                    if (dir == 0)
                    {//왼쪽
                        //    tempRobotPoseArr.Add(TCP_BACK());
                        //    tempRobotPoseArr.Add(TCP_LCP_L());
                        //    tempRobotPoseArr.Add(TCP_LCP_LU());
                        //    tempRobotPoseArr.Add(TCP_U_L());
                        //    tempRobotPoseArr.Add(TCP_L_U());
                        //    tempRobotPoseArr.Add(TCP_L_BB());
                        //    tempRobotPoseArr.Add(TCP_B_L());
                        //    tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LB(), TCP_LCP_LB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_L(), TCP_LCP_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_LCP_LU(), TCP_LCP_LU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_L(), TCP_U_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_U(), TCP_L_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_L_BB(), TCP_L_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_L(), TCP_B_L()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }
                    else
                    {//오른쪽
                        //tempRobotPoseArr.Add(TCP_BACK());
                        //tempRobotPoseArr.Add(TCP_RCP_R());
                        //tempRobotPoseArr.Add(TCP_RCP_RU());
                        //tempRobotPoseArr.Add(TCP_U_RR());
                        //tempRobotPoseArr.Add(TCP_R_U());
                        //tempRobotPoseArr.Add(TCP_R_BB());
                        //tempRobotPoseArr.Add(TCP_B_RR());
                        //tempRobotPoseArr.Add(TCP_Middle2());
                        tempRobotPoseArr.Add(TCP_BACK());
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RB(), TCP_RCP_RB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_R(), TCP_RCP_R()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_RCP_RU(), TCP_RCP_RU()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_U_RR(), TCP_U_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_U(), TCP_R_U()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_R_BB(), TCP_R_BB()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_B_RR(), TCP_B_RR()));
                        tempRobotPoseArr.Add(new RobotPoseData(2, 50, TCP_Middle2(), TCP_Middle2()));
                    }

                    //로봇 연속이동 실행
                    if (1 == RobotCommclass.RobotContinuousMoveStart(tempRobotPoseArr))
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 시작");
                        AutoTSSubSeq = "종료위치 이동 완료 대기";
                    }
                    else
                    {
                        MainLog_Add("로봇 터치종료위치로 이동 실패.");
                        AutoTSSubSeq = "터치시퀀스 실패";
                    }

                    break;
                case "종료위치 이동 완료 대기":

                    if (RobotCommclass.RobotControlThreadSeq == 311)
                    {//연속이동 시퀀스 성공
                        RobotCommclass.RobotControlThreadSeq = 15;
                        if (dir == 0) MainLog_Add("왼쪽 터치센싱 완료."); else MainLog_Add("오른쪽 터치센싱 완료.");
                        AutoTSSubSeq = "터치시퀀스 성공";
                    }

                    break;
                case "터치시퀀스 성공":


                    break;
                case "터치시퀀스 실패":


                    break;

                default:
                    break;
            }

        }


        //터치센싱한 데이터와 각장,갭정보로 용접정보 생성 리턴0:실패, 리턴1:성공
        int MakeAutoWeldInformation()
        {
            //기존 용접정보 삭제
            AutoWeld_WeldInformationList.Clear();

            if (LeftWeldFlag == true)
            {
                //왼쪽 셀 용접라인 만듬
                switch (CellTypeName_Left)
                {
                    case "ST1":
                    case "ST1+CP1B":
                    case "ST1+CP2B":
                        if (MakeWeldInfo_ST1(0) != 1) return 0;
                        break;
                    case "ST2":
                    case "ST5":
                    case "ST2+CP1B":
                    case "ST2+CP2B":
                    case "ST3+CP4B":
                    case "ST4+CP4B":
                    case "ST4+CP6B":
                    case "ST5+CP7B":
                        if (MakeWeldInfo_ST2(0) != 1) return 0;
                        break;
                    case "ST3":
                    case "ST4":
                        if (MakeWeldInfo_ST3(0) != 1) return 0;
                        break;
                    case "ST1+CP1F":

                        break;
                    case "ST1+CP2F":

                        break;

                    case "ST2+CP1F":
                        if (MakeWeldInfo_ST2_CP1F(0) != 1) return 0;
                        break;

                    case "ST2+CP2F":

                        break;
                    case "ST3+CP3F":
                    case "ST4+CP3F":
                        if (MakeWeldInfo_ST3_CP3F(0) != 1) return 0;
                        break;
                    case "ST3+CP3B":
                    case "ST4+CP3B":
                    case "ST4+CP5B":
                    case "ST4+CP9B":
                    case "ST3+CP9B":
                        if (MakeWeldInfo_ST3_CP3B(0) != 1) return 0;
                        break;
                    case "ST3+CP4F":
                    case "ST4+CP4F":
                        if (MakeWeldInfo_ST3_CP4F(0) != 1) return 0;
                        break;
                    case "ST4+CP5F":
                        if (MakeWeldInfo_ST4_CP5F(0) != 1) return 0;

                        break;
                    case "ST4+CP6F":
                        if (MakeWeldInfo_ST4_CP6F(0) != 1) return 0;

                        break;
                    case "ST4+CP11F":
                        if (MakeWeldInfo_ST4_CP11F(0) != 1) return 0;
                        break;
                    case "ST4+CP12F":
                        if (MakeWeldInfo_ST4_CP12F(0) != 1) return 0;
                        break;
                    case "ST5+CP7F":

                        break;
                    case "ST3+CP8F":
                        if (MakeWeldInfo_ST3_CP8F(0) != 1) return 0;
                        break;
                    case "ST3+CP9F":
                        if (MakeWeldInfo_ST3_CP9F(0) != 1) return 0;
                        break;
                    case "ST3+CP10F":
                        if (MakeWeldInfo_ST3_CP10F(0) != 1) return 0;
                        break;
                    default:
                        break;
                }
            }


            if (RightWeldFlag == true)
            {
                //오른쪽 셀 용접라인 만듬
                switch (CellTypeName_Right)
                {
                    case "ST1":
                    case "ST1+CP1B":
                    case "ST1+CP2B":
                        if (MakeWeldInfo_ST1(1) != 1) return 0;
                        break;
                    case "ST2":
                    case "ST5":
                    case "ST2+CP1B":
                    case "ST2+CP2B":
                    case "ST3+CP4B":
                    case "ST4+CP4B":
                    case "ST4+CP6B":
                    case "ST5+CP7B":
                        if (MakeWeldInfo_ST2(1) != 1) return 0;
                        break;
                    case "ST3":
                    case "ST4":
                        if (MakeWeldInfo_ST3(1) != 1) return 0;
                        break;
                    case "ST1+CP1F":

                        break;
                    case "ST1+CP2F":

                        break;

                    case "ST2+CP1F":
                        if (MakeWeldInfo_ST2_CP1F(1) != 1) return 0;
                        break;

                    case "ST2+CP2F":

                        break;
                    case "ST3+CP3F":
                    case "ST4+CP3F":
                        if (MakeWeldInfo_ST3_CP3F(1) != 1) return 0;
                        break;
                    case "ST3+CP3B":
                    case "ST4+CP3B":
                    case "ST4+CP5B":
                    case "ST4+CP9B":
                    case "ST3+CP9B":
                        if (MakeWeldInfo_ST3_CP3B(1) != 1) return 0;
                        break;

                    case "ST3+CP4F":
                    case "ST4+CP4F":
                        if (MakeWeldInfo_ST3_CP4F(1) != 1) return 0;
                        break;
                    case "ST4+CP5F":
                        if (MakeWeldInfo_ST4_CP5F(1) != 1) return 0;
                        break;
                    case "ST4+CP6F":
                        if (MakeWeldInfo_ST4_CP6F(1) != 1) return 0;

                        break;
                    case "ST4+CP11F":
                        if (MakeWeldInfo_ST4_CP11F(1) != 1) return 0;
                        break;
                    case "ST5+CP7F":

                        break;
                    case "ST3+CP8F":
                        if (MakeWeldInfo_ST3_CP8F(1) != 1) return 0;
                        break;
                    case "ST3+CP9F":
                        if (MakeWeldInfo_ST3_CP9F(1) != 1) return 0;
                        break;
                    case "ST3+CP10F":
                        if (MakeWeldInfo_ST3_CP10F(1) != 1) return 0;
                        break;
                    default:
                        break;
                }
            }


            string value = "";
            if (Read_InitSetting_KeyValue("WeldingOrder", ref value))
            {
                if (value == "0") AutoWeld_WeldInformationList.Reverse();
            }




            return 1;

        }


        //오른쪽셀 바닥라인 용접 시작점이 0번이 아닌경우 시작-0번까지 용접라인 만들어서 RightTempLine에 추가
        string MakeRightsideToZeroPointLine()
        {
            RobotPoseData tempRobotPose = new RobotPoseData();
            WeldMainCondition tempmaincon = new WeldMainCondition();
            RightTempLine.Clear();


            string anglepara = "";
            string arcsenpara = "";

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;

            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            if (RightWeldFlag == true)
            {
                switch (CellTypeName_Right)
                {
                    case "ST1":
                        //만들필요없음
                        break;
                    case "ST2":
                        //만들필요없음
                        break;
                    case "ST3":
                        //만들필요없음
                        break;
                    case "ST4":
                        //만들필요없음
                        break;
                    case "ST5":
                        //만들필요없음
                        break;
                    case "ST1+CP1F":
                        //만들필요없음
                        break;
                    case "ST1+CP1B":
                        //만들필요없음
                        break;
                    case "ST1+CP2F":
                        //만들필요없음
                        break;
                    case "ST1+CP2B":
                        //만들필요없음
                        break;
                    case "ST2+CP1F":
                        //만들필요없음
                        break;
                    case "ST2+CP1B":
                        //만들필요없음
                        break;
                    case "ST2+CP2F":
                        //만들필요없음
                        break;
                    case "ST2+CP2B":
                        //만들필요없음
                        break;
                    case "ST3+CP3F":
                    case "ST3+CP8F":
                    case "ST3+CP9F":
                    case "ST3+CP10F":
                    case "ST4+CP5F":
                    case "ST4+CP11F":
                        tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[4], AutoWeld_WedlPoint_Right[4], AutoWeld_WedlPoint_Right[3]);
                        RightTempLine.Add((WeldMainCondition)tempmaincon.Clone());

                        //오른쪽 0번점에서 왼쪽 0번점 방향으로 10mm 이동시킨 점 계산
                        tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2], 10, TCP_B_RR());
                        tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[3], tempRobotPose);
                        RightTempLine.Add((WeldMainCondition)tempmaincon.Clone());
                        anglepara = "P,S1,";
                        arcsenpara = "1,3,";
                        break;
                    case "ST3+CP3B":
                    case "ST3+CP9B":
                        //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                        Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                        pathnum = Convert.ToInt32(tempstr1);

                        //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                        DefaultWeldInformation = new WeldInformation();
                        tempmaincon = new WeldMainCondition();

                        tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[4], AutoWeld_WedlPoint_Right[4], AutoWeld_WedlPoint_Right[3]);
                        DefaultWeldInformation.AddMainCondition(tempmaincon);


                        //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                        for (int i = 0; i < pathnum; i++)
                        {
                            ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, "P", "1", OffsetH + i * 5, OffsetH + i * 5,0,0,1);
                            tempweldinformation.ArcOnFlag = ArcFlag;
                            tempweldinformation.ContinueFlag = true;
                            if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                            tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                            tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                            tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                            tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                            tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                            //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                            string tempstr = "";
                            Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                            if (tempstr == "1")
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                            else if (tempstr == "0")
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                if (IMUclass.RobotRx < -5)
                                {
                                    AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                                }
                                else
                                {
                                    AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                                }
                            }
                        }

                        break;
                    case "ST3+CP4F":
                        //만들필요없음
                        break;
                    case "ST3+CP4B":
                        //만들필요없음
                        break;

                    case "ST4+CP3F":

                        break;
                    case "ST4+CP3B":

                        break;
                    case "ST4+CP4F":
                        //만들필요없음
                        break;
                    case "ST4+CP4B":
                        //만들필요없음
                        break;

                    case "ST4+CP5B":

                        break;
                    case "ST4+CP6F":
                        //만들필요없음
                        break;
                    case "ST4+CP6B":
                        //만들필요없음
                        break;
                    case "ST5+CP7F":
                        //만들필요없음
                        break;
                    case "ST5+CP7B":
                        //만들필요없음
                        break;

                    default:
                        break;
                }
            }



            return anglepara + "-" + arcsenpara;
        }


        //계산점으로 용접인포메이션리스트 만드는 함수. 인자 0:왼쪽셀, 1:오른쪽셀
        int MakeWeldInfo_ST1(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformationL0 = new WeldInformation();
            WeldInformation tempweldinformationL1 = new WeldInformation();
            WeldInformation tempweldinformationR1 = new WeldInformation();
            RobotPoseData tempRobotPose;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);

            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationL0, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "1", para.Split('-')[1] + "P", OffsetH + i * 5, OffsetH + i * 5,0,0,1);
                        tempweldinformationL0.ArcOnFlag = ArcFlag;
                        tempweldinformationL0.ContinueFlag = true;
                        if (i == 0) { tempweldinformationL0.MultipathFlag = false; } else { tempweldinformationL0.MultipathFlag = true; }

                        tempweldinformationL0.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationL0.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformationL0.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationL0.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformationL0.EndCondition.AddEndPosition(Joint_Middle2());

                        

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL0.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformationL0.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformationL0.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL0.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[2], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], tempRobotPose);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose, tempRobotPose, AutoWeld_WedlPoint_Left[2]);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationL1, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "P,P", "",  OffsetV + i * 5, 0,0,-1,0);
                        tempweldinformationL1.ArcOnFlag = ArcFlag;
                        tempweldinformationL1.ContinueFlag = true;
                        if (i == 0) { tempweldinformationL1.MultipathFlag = false; } else { tempweldinformationL1.MultipathFlag = true; }

                        tempweldinformationL1.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationL1.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformationL1.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationL1.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformationL1.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL1.Clone());
                    }
                }
            }

            //오른쪽셀 일때
            if (dir == 1)
            {
                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[2], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], tempRobotPose);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose, tempRobotPose, AutoWeld_WedlPoint_Right[2]);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationR1, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "P,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformationR1.ArcOnFlag = ArcFlag;
                        tempweldinformationR1.ContinueFlag = true;
                        if (i == 0) { tempweldinformationR1.MultipathFlag = false; } else { tempweldinformationR1.MultipathFlag = true; }

                        tempweldinformationR1.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationR1.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformationR1.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationR1.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformationR1.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationR1.Clone());
                    }
                }
            }

            return 1;
        }

        //계산점으로 용접인포메이션리스트 만드는 함수. 인자 0:왼쪽셀, 1:오른쪽셀
        int MakeWeldInfo_ST2(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformationL0 = new WeldInformation();
            WeldInformation tempweldinformationL1 = new WeldInformation();
            WeldInformation tempweldinformationR1 = new WeldInformation();

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);

            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationL0, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "", para.Split('-')[1] + "", i * 5, i * 5,0,0,1);
                        tempweldinformationL0.ArcOnFlag = ArcFlag;
                        tempweldinformationL0.ContinueFlag = true;
                        if (i == 0) { tempweldinformationL0.MultipathFlag = false; } else { tempweldinformationL0.MultipathFlag = true; }

                        tempweldinformationL0.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationL0.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformationL0.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationL0.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformationL0.EndCondition.AddEndPosition(Joint_Middle2());

                        
                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL0.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformationL0.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformationL0.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL0.Clone());
                            }
                        }


                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[2], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], tempRobotPose);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose, tempRobotPose, AutoWeld_WedlPoint_Left[2]);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationL1, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", i * 5, 0, 0, -1, 0);
                        tempweldinformationL1.ArcOnFlag = ArcFlag;
                        tempweldinformationL1.ContinueFlag = true;
                        if (i == 0) { tempweldinformationL1.MultipathFlag = false; } else { tempweldinformationL1.MultipathFlag = true; }

                        tempweldinformationL1.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationL1.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformationL1.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationL1.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformationL1.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL1.Clone());
                    }
                }
            }

            //오른쪽셀 일때
            if (dir == 1)
            {
                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[2], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], tempRobotPose);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose, tempRobotPose, AutoWeld_WedlPoint_Right[2]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationR1, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", i * 5, 0, 0, 1, 0);
                        tempweldinformationR1.ArcOnFlag = ArcFlag;
                        tempweldinformationR1.ContinueFlag = true;
                        if (i == 0) { tempweldinformationR1.MultipathFlag = false; } else { tempweldinformationR1.MultipathFlag = true; }

                        tempweldinformationR1.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationR1.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformationR1.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationR1.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformationR1.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationR1.Clone());
                    }
                }
            }

            return 1;
        }

        //계산점으로 용접인포메이션리스트 만드는 함수. 인자 0:왼쪽셀, 1:오른쪽셀
        int MakeWeldInfo_ST3(int dir)
        {

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformationL0 = new WeldInformation();
            RobotPoseData tempRobotPose;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);

            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);



                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformationL0, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "", para.Split('-')[1] + "", i * 5, i * 5,0,0,1);
                        tempweldinformationL0.ArcOnFlag = ArcFlag;
                        tempweldinformationL0.ContinueFlag = true;
                        if (i == 0) { tempweldinformationL0.MultipathFlag = false; } else { tempweldinformationL0.MultipathFlag = true; }

                        tempweldinformationL0.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformationL0.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformationL0.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformationL0.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformationL0.EndCondition.AddEndPosition(Joint_Middle2());

                        
                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL0.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformationL0.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformationL0.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformationL0.Clone());
                            }
                        }
                    }
                }

            }

            return 1;
        }

        //계산점으로 용접인포메이션리스트 만드는 함수. 인자 0:왼쪽셀, 1:오른쪽셀
        int MakeWeldInfo_ST2_CP1F(int dir)
        {
            /*
            double tempd1;
            double tempd2;
            double tempd3;
            double WeldLength;

            WeldInformation tempweldinformation;

            float tVol = 32;
            float tAmp = 320;
            float tSpd = 70;


            //왼쪽셀일때
            if (dir == 0)
            {
                //오른쪽셀도 용접하는지 체크하고 용접하면 0번 용접선 추가함
                if (RightWeldFlag == true)
                {
                    //시작조건 입력
                    tempweldinformation = new WeldInformation();
                    tempweldinformation.InitCondition = new WeldStartCondition(SGasT, SArcT, SArcV, SArcC);
                    tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RobotMiddlePose2.Clone());
                    tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RDP_Joint[11].Clone());
                    tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)AutoWeld_DTPoint_Right_TCPPose[0].Clone());

                    //메인조건 입력
                    tempd1 = AutoWeld_WedlPoint_Left[0].f1 - AutoWeld_WedlPoint_Right[0].f1;
                    tempd2 = AutoWeld_WedlPoint_Left[0].f2 - AutoWeld_WedlPoint_Right[0].f2;
                    tempd3 = AutoWeld_WedlPoint_Left[0].f3 - AutoWeld_WedlPoint_Right[0].f3;
                    WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));

                    //용접길이가 400보다 짧으면 2단 나눔(절반씩). 그 이상은 3단 나눔(앞 150, 뒤 150, 나머지 중간경로)
                    if (WeldLength < 400)
                    {
                        //우선 중간자세 계산함. 작업각이 45도라면 기준자세 9번 그대로 사용. 45도가 아니라면 y축으로 필요한만큼 회전시켜서 사용
                        float tempX, tempY, tempZ, tempRx, tempRy, tempRz;
                        tempX = (float)(AutoWeld_WedlPoint_Right[0].f1 + 0.5 * tempd1);
                        tempY = (float)(AutoWeld_WedlPoint_Right[0].f2 + 0.5 * tempd2);
                        tempZ = (float)(AutoWeld_WedlPoint_Right[0].f3 + 0.5 * tempd3);
                        RobotCommclass.RobotBaseRotation(RDP_TCP[9].f4, RDP_TCP[9].f5, RDP_TCP[9].f6, 0, 1, 0, (43) - 45, out tempRx, out tempRy, out tempRz);


                        //시작점에서 중간점까지 용접데이터 생성
                        WeldMainCondition tempmaincon1 = new WeldMainCondition();
                        tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                        tempmaincon1.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                        tempmaincon1.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                        tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone();
                        tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone();
                        tempmaincon1.PathEndPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                        tempweldinformation.MainCondition.Add(tempmaincon1);

                        //중간점에서 종료점까지 용접데이터 생성
                        WeldMainCondition tempmaincon2 = new WeldMainCondition();
                        tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                        tempmaincon2.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                        tempmaincon2.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                        tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                        tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                        tempmaincon2.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[0].Clone();
                        tempweldinformation.MainCondition.Add(tempmaincon2);

                    }
                    else
                    {
                        //시작점(오른쪽 점)과 가까운 구분자세 계산. 10번 기준자세 사용
                        float temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz;
                        temp1X = (float)(AutoWeld_WedlPoint_Right[0].f1 + 150 * (tempd1 / WeldLength));
                        temp1Y = (float)(AutoWeld_WedlPoint_Right[0].f2 + 150 * (tempd2 / WeldLength));
                        temp1Z = (float)(AutoWeld_WedlPoint_Right[0].f3 + 150 * (tempd3 / WeldLength));
                        RobotCommclass.RobotBaseRotation(RDP_TCP[10].f4, RDP_TCP[10].f5, RDP_TCP[10].f6, 0, 1, 0, (43) - 45, out temp1Rx, out temp1Ry, out temp1Rz);

                        //종료점(왼쪽 점)과 가까운 구분자세 계산. 8번 기준자세 사용
                        float temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz;
                        temp2X = (float)(AutoWeld_WedlPoint_Left[0].f1 - 150 * (tempd1 / WeldLength));
                        temp2Y = (float)(AutoWeld_WedlPoint_Left[0].f2 - 150 * (tempd2 / WeldLength));
                        temp2Z = (float)(AutoWeld_WedlPoint_Left[0].f3 - 150 * (tempd3 / WeldLength));
                        RobotCommclass.RobotBaseRotation(RDP_TCP[8].f4, RDP_TCP[8].f5, RDP_TCP[8].f6, 0, 1, 0, (43) - 45, out temp2Rx, out temp2Ry, out temp2Rz);

                        //시작점에서 중간점1까지 용접데이터 생성
                        WeldMainCondition tempmaincon1 = new WeldMainCondition();
                        tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                        tempmaincon1.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                        tempmaincon1.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                        tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone();
                        tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[0].Clone();
                        tempmaincon1.PathEndPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                        tempweldinformation.MainCondition.Add(tempmaincon1);

                        //중간점1에서 중간점2까지 용접데이터 생성
                        WeldMainCondition tempmaincon2 = new WeldMainCondition();
                        tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                        tempmaincon2.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                        tempmaincon2.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                        tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                        tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                        tempmaincon2.PathEndPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                        tempweldinformation.MainCondition.Add(tempmaincon2);

                        //중간점2에서 종료점까지 용접데이터 생성
                        WeldMainCondition tempmaincon3 = new WeldMainCondition();
                        tempmaincon3.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                        tempmaincon3.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                        tempmaincon3.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                        tempmaincon3.PathStartPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                        tempmaincon3.PathMidPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                        tempmaincon3.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[0].Clone();
                        tempweldinformation.MainCondition.Add(tempmaincon3);
                    }

                    //종료조건 입력
                    tempweldinformation.EndCondition = new WeldEndCondition(EGasT, EArcT, EArcV, EArcC, EBackL);
                    tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)AutoWeld_DTPoint_Left_TCPPose[0].Clone());
                    tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RDP_TCP[7].Clone());
                    tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RobotMiddlePose2.Clone());

                    tempweldinformation.ArcOnFlag = ArcFlag;

                    AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());

                }

                //1-2-3-4-5 연속용접모션 생성
                //시작조건 입력
                tempweldinformation = new WeldInformation();
                tempweldinformation.InitCondition = new WeldStartCondition(SGasT, SArcT, SArcV, SArcC);
                tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RobotMiddlePose2.Clone());
                tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RDP_Joint[7].Clone());
                tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)AutoWeld_DTPoint_Left_TCPPose[0].Clone());

                //1번 용접선(계산점 1-2경로) 조건생성
                //용접선 길이가 200보다 작으면 두번 나눔. 이상이면 세번 눔
                //두번 나눌때는 자세가 7-6-3, 세번 나눌때는 자세가 7-6-4-3

                tempd1 = AutoWeld_WedlPoint_Left[2].f1 - AutoWeld_WedlPoint_Left[1].f1;
                tempd2 = AutoWeld_WedlPoint_Left[2].f2 - AutoWeld_WedlPoint_Left[1].f2;
                tempd3 = AutoWeld_WedlPoint_Left[2].f3 - AutoWeld_WedlPoint_Left[1].f3;
                WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));

                if (WeldLength < 200)
                {
                    //우선 중간자세 계산함. 작업각이 45도라면 기준자세 9번 그대로 사용. 45도가 아니라면 z축으로 필요한만큼 회전시켜서 사용
                    float tempX, tempY, tempZ, tempRx, tempRy, tempRz;
                    tempX = (float)(AutoWeld_WedlPoint_Left[1].f1 + 0.7 * tempd1);
                    tempY = (float)(AutoWeld_WedlPoint_Left[1].f2 + 0.7 * tempd2);
                    tempZ = (float)(AutoWeld_WedlPoint_Left[1].f3 + 0.7 * tempd3);
                    RobotCommclass.RobotBaseRotation(RDP_TCP[7].f4, RDP_TCP[7].f5, RDP_TCP[7].f6, 0, 0, 1, (43) - 45, out tempRx, out tempRy, out tempRz);


                    //시작점에서 중간점까지 용접데이터 생성
                    WeldMainCondition tempmaincon1 = new WeldMainCondition();
                    tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon1.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon1.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[1].Clone();
                    tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[1].Clone();
                    tempmaincon1.PathEndPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                    tempweldinformation.MainCondition.Add(tempmaincon1);

                    //중간점에서 종료점까지 용접데이터 생성
                    WeldMainCondition tempmaincon2 = new WeldMainCondition();
                    tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon2.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon2.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                    tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                    tempmaincon2.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[2].Clone();
                    tempweldinformation.MainCondition.Add(tempmaincon2);

                }
                else
                {
                    //시작점(계산점 1)과 가까운 구분자세 계산. 6번 기준자세 사용
                    float temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz;
                    temp1X = (float)(AutoWeld_WedlPoint_Left[1].f1 + 100 * (tempd1 / WeldLength));
                    temp1Y = (float)(AutoWeld_WedlPoint_Left[1].f2 + 100 * (tempd2 / WeldLength));
                    temp1Z = (float)(AutoWeld_WedlPoint_Left[1].f3 + 100 * (tempd3 / WeldLength));
                    RobotCommclass.RobotBaseRotation(RDP_TCP[6].f4, RDP_TCP[6].f5, RDP_TCP[6].f6, 0, 1, 0, (43) - 45, out temp1Rx, out temp1Ry, out temp1Rz);

                    //종료점(계산점 2)과 가까운 구분자세 계산. 4번 기준자세 사용
                    float temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz;
                    temp2X = (float)(AutoWeld_WedlPoint_Left[2].f1 - 50 * (tempd1 / WeldLength));
                    temp2Y = (float)(AutoWeld_WedlPoint_Left[2].f2 - 50 * (tempd2 / WeldLength));
                    temp2Z = (float)(AutoWeld_WedlPoint_Left[2].f3 - 50 * (tempd3 / WeldLength));
                    RobotCommclass.RobotBaseRotation(RDP_TCP[4].f4, RDP_TCP[4].f5, RDP_TCP[4].f6, 0, 1, 0, (43) - 45, out temp2Rx, out temp2Ry, out temp2Rz);

                    //시작점에서 중간점1까지 용접데이터 생성
                    WeldMainCondition tempmaincon1 = new WeldMainCondition();
                    tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon1.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon1.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[1].Clone();
                    tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[1].Clone();
                    tempmaincon1.PathEndPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                    tempweldinformation.MainCondition.Add(tempmaincon1);

                    //중간점1에서 중간점2까지 용접데이터 생성
                    WeldMainCondition tempmaincon2 = new WeldMainCondition();
                    tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon2.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon2.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                    tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                    tempmaincon2.PathEndPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                    tempweldinformation.MainCondition.Add(tempmaincon2);

                    //중간점2에서 종료점까지 용접데이터 생성
                    WeldMainCondition tempmaincon3 = new WeldMainCondition();
                    tempmaincon3.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon3.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon3.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon3.PathStartPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                    tempmaincon3.PathMidPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                    tempmaincon3.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[2].Clone();
                    tempweldinformation.MainCondition.Add(tempmaincon3);
                }


                //2번 용접선 조건생성 (p2-p3)
                WeldMainCondition tempmaincon4 = new WeldMainCondition();
                tempmaincon4.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon4.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon4.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon4.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[2].Clone();
                tempmaincon4.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[2].Clone();
                tempmaincon4.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[3].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon4);

                //3번 용접선 조건생성 (원호 p3-p8-p4)
                WeldMainCondition tempmaincon5 = new WeldMainCondition();
                tempmaincon5.WeldSetting(2, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon5.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon5.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon5.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[3].Clone();
                tempmaincon5.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[8].Clone();
                tempmaincon5.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[4].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon5);

                //4번 용접선 조건생성 (원호 p4-p7-p5)
                WeldMainCondition tempmaincon6 = new WeldMainCondition();
                tempmaincon6.WeldSetting(2, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon6.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon6.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon6.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[4].Clone();
                tempmaincon6.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[7].Clone();
                tempmaincon6.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[5].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon6);

                //5번 용접선 조건생성 (p5-p6)
                WeldMainCondition tempmaincon7 = new WeldMainCondition();
                tempmaincon7.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon7.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon7.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon7.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[5].Clone();
                tempmaincon7.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[5].Clone();
                tempmaincon7.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Left[6].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon7);

                //종료조건 입력
                tempweldinformation.EndCondition = new WeldEndCondition(EGasT, EArcT, EArcV, EArcC, EBackL);
                tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RDP_Joint[0].Clone());
                tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RobotMiddlePose1.Clone());
                tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RobotMiddlePose2.Clone());

                tempweldinformation.ArcOnFlag = ArcFlag;

                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());


            }



            //오른쪽셀일때
            if (dir == 1)
            {
                //1-2-3-4-5 연속용접모션 생성
                //시작조건 입력
                tempweldinformation = new WeldInformation();
                tempweldinformation.InitCondition = new WeldStartCondition(SGasT, SArcT, SArcV, SArcC);
                tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RobotMiddlePose2.Clone());
                tempweldinformation.InitCondition.StartPosition.Add((RobotPoseData)RDP_Joint[11].Clone());

                //1번 용접선(계산점 1-2경로) 조건생성
                //용접선 길이가 200보다 작으면 두번 나눔. 이상이면 세번 눔
                //두번 나눌때는 자세가 7-6-3, 세번 나눌때는 자세가 7-6-4-3
                tempd1 = AutoWeld_WedlPoint_Right[2].f1 - AutoWeld_WedlPoint_Right[1].f1;
                tempd2 = AutoWeld_WedlPoint_Right[2].f2 - AutoWeld_WedlPoint_Right[1].f2;
                tempd3 = AutoWeld_WedlPoint_Right[2].f3 - AutoWeld_WedlPoint_Right[1].f3;
                WeldLength = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));

                if (WeldLength < 200)
                {
                    //우선 중간자세 계산함. 작업각이 45도라면 기준자세 9번 그대로 사용. 45도가 아니라면 z축으로 필요한만큼 회전시켜서 사용
                    float tempX, tempY, tempZ, tempRx, tempRy, tempRz;
                    tempX = (float)(AutoWeld_WedlPoint_Right[1].f1 + 0.7 * tempd1);
                    tempY = (float)(AutoWeld_WedlPoint_Right[1].f2 + 0.7 * tempd2);
                    tempZ = (float)(AutoWeld_WedlPoint_Right[1].f3 + 0.7 * tempd3);
                    RobotCommclass.RobotBaseRotation(RDP_TCP[7].f4, RDP_TCP[7].f5, RDP_TCP[7].f6, 0, 0, 1, (43) - 45, out tempRx, out tempRy, out tempRz);


                    //시작점에서 중간점까지 용접데이터 생성
                    WeldMainCondition tempmaincon1 = new WeldMainCondition();
                    tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon1.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon1.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[1].Clone();
                    tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[1].Clone();
                    tempmaincon1.PathEndPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                    tempweldinformation.MainCondition.Add(tempmaincon1);

                    //중간점에서 종료점까지 용접데이터 생성
                    WeldMainCondition tempmaincon2 = new WeldMainCondition();
                    tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon2.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon2.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                    tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, tempX, tempY, tempZ, tempRx, tempRy, tempRz);
                    tempmaincon2.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[2].Clone();
                    tempweldinformation.MainCondition.Add(tempmaincon2);

                }
                else
                {
                    //시작점(계산점 1)과 가까운 구분자세 계산. 6번 기준자세 사용
                    float temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz;
                    temp1X = (float)(AutoWeld_WedlPoint_Right[1].f1 + 100 * (tempd1 / WeldLength));
                    temp1Y = (float)(AutoWeld_WedlPoint_Right[1].f2 + 100 * (tempd2 / WeldLength));
                    temp1Z = (float)(AutoWeld_WedlPoint_Right[1].f3 + 100 * (tempd3 / WeldLength));
                    RobotCommclass.RobotBaseRotation(RDP_TCP[6].f4, RDP_TCP[6].f5, RDP_TCP[6].f6, 0, 1, 0, (43) - 45, out temp1Rx, out temp1Ry, out temp1Rz);

                    //종료점(계산점 2)과 가까운 구분자세 계산. 4번 기준자세 사용
                    float temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz;
                    temp2X = (float)(AutoWeld_WedlPoint_Right[2].f1 - 50 * (tempd1 / WeldLength));
                    temp2Y = (float)(AutoWeld_WedlPoint_Right[2].f2 - 50 * (tempd2 / WeldLength));
                    temp2Z = (float)(AutoWeld_WedlPoint_Right[2].f3 - 50 * (tempd3 / WeldLength));
                    RobotCommclass.RobotBaseRotation(RDP_TCP[4].f4, RDP_TCP[4].f5, RDP_TCP[4].f6, 0, 1, 0, (43) - 45, out temp2Rx, out temp2Ry, out temp2Rz);

                    //시작점에서 중간점1까지 용접데이터 생성
                    WeldMainCondition tempmaincon1 = new WeldMainCondition();
                    tempmaincon1.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon1.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon1.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon1.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[1].Clone();
                    tempmaincon1.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[1].Clone();
                    tempmaincon1.PathEndPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                    tempweldinformation.MainCondition.Add(tempmaincon1);

                    //중간점1에서 중간점2까지 용접데이터 생성
                    WeldMainCondition tempmaincon2 = new WeldMainCondition();
                    tempmaincon2.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon2.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon2.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon2.PathStartPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                    tempmaincon2.PathMidPosition = new RobotPoseData(2, 100, temp1X, temp1Y, temp1Z, temp1Rx, temp1Ry, temp1Rz);
                    tempmaincon2.PathEndPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                    tempweldinformation.MainCondition.Add(tempmaincon2);

                    //중간점2에서 종료점까지 용접데이터 생성
                    WeldMainCondition tempmaincon3 = new WeldMainCondition();
                    tempmaincon3.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                    tempmaincon3.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                    tempmaincon3.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                    tempmaincon3.PathStartPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                    tempmaincon3.PathMidPosition = new RobotPoseData(2, 100, temp2X, temp2Y, temp2Z, temp2Rx, temp2Ry, temp2Rz);
                    tempmaincon3.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[2].Clone();
                    tempweldinformation.MainCondition.Add(tempmaincon3);
                }


                //2번 용접선 조건생성 (p2-p3)
                WeldMainCondition tempmaincon4 = new WeldMainCondition();
                tempmaincon4.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon4.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon4.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon4.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[2].Clone();
                tempmaincon4.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[2].Clone();
                tempmaincon4.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[3].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon4);

                //3번 용접선 조건생성 (원호 p3-p8-p4)
                WeldMainCondition tempmaincon5 = new WeldMainCondition();
                tempmaincon5.WeldSetting(2, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon5.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon5.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon5.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[3].Clone();
                tempmaincon5.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[8].Clone();
                tempmaincon5.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[4].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon5);

                //4번 용접선 조건생성 (원호 p4-p7-p5)
                WeldMainCondition tempmaincon6 = new WeldMainCondition();
                tempmaincon6.WeldSetting(2, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon6.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon6.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon6.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[4].Clone();
                tempmaincon6.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[7].Clone();
                tempmaincon6.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[5].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon6);

                //5번 용접선 조건생성 (p5-p6)
                WeldMainCondition tempmaincon7 = new WeldMainCondition();
                tempmaincon7.WeldSetting(1, tVol, tAmp, tSpd);//보간방식, 전압 전류 스피드 입력
                tempmaincon7.WeavingSetting(1, 4.5, 3, 0, 0);//위빙설정입력
                tempmaincon7.ArcSenSetting(1, 0, 0, 0, 200, 200, 1, 1, 1, 1);//아크센싱설정입력
                tempmaincon7.PathStartPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[5].Clone();
                tempmaincon7.PathMidPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[5].Clone();
                tempmaincon7.PathEndPosition = (RobotPoseData)AutoWeld_WedlPoint_Right[6].Clone();
                tempweldinformation.MainCondition.Add(tempmaincon7);

                //종료조건 입력
                tempweldinformation.EndCondition = new WeldEndCondition(EGasT, EArcT, EArcV, EArcC, EBackL);
                tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RDP_Joint[18].Clone());
                tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RobotMiddlePose1.Clone());
                tempweldinformation.EndCondition.EndPosition.Add((RobotPoseData)RobotMiddlePose2.Clone());

                tempweldinformation.ArcOnFlag = ArcFlag;

                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());


            }
            */
            return 1;

        }


        int MakeWeldInfo_ST3_CP3F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Right[2], 10, TCP_B_L());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[3]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5,0,0,1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        
                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[1], TCP_L_BB());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[4], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[7], AutoWeld_WedlPoint_Left[7], AutoWeld_WedlPoint_Left[8]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[3], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_BB());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[7], AutoWeld_WedlPoint_Right[7], AutoWeld_WedlPoint_Right[8]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }


        int MakeWeldInfo_ST3_CP3B(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5,0,0,1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());
                        
                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }

                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();


                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4], 10, TCP_B_L());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[4]);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, "P", "1", OffsetH + i * 5, OffsetH + i * 5, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());
                        

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[1], TCP_L_BB());
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_BB());

                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }

            }

            return 1;

        }



        int MakeWeldInfo_ST3_CP4F(int dir)
        {

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "", para.Split('-')[1] + "", 0, 0,0,0,1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());


                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[2], 70, TCP_L_B());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", 0, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[4], AutoWeld_WedlPoint_Left[4], AutoWeld_WedlPoint_Left[5]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P,P,P", "", 0, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[2], 70, TCP_R_B());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", 0, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[3], tempRobotPose);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose, tempRobotPose, AutoWeld_WedlPoint_Right[4]);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[4], AutoWeld_WedlPoint_Right[4], AutoWeld_WedlPoint_Right[5]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "P,P,F", "", 0, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }



            return 1;

        }

        int MakeWeldInfo_ST4_CP5F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Right[2], 10, TCP_B_L());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[3]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5, 0, 0, 1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    double a1 = AutoWeld_WedlPoint_Left[1].f1;
                    double b1 = AutoWeld_WedlPoint_Left[1].f2;
                    double c1 = AutoWeld_WedlPoint_Left[1].f3;
                    double a2 = AutoWeld_WedlPoint_Left[0].f1;
                    double b2 = AutoWeld_WedlPoint_Left[0].f2;
                    double c2 = AutoWeld_WedlPoint_Left[0].f3;
                    double a3 = AutoWeld_WedlPoint_Left[7].f1;
                    double b3 = AutoWeld_WedlPoint_Left[7].f2;
                    double c3 = AutoWeld_WedlPoint_Left[7].f3;

                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);
                    temp = (a3 - a4) * (a3 - a4) + (b3 - b4) * (b3 - b4) + (c3 - c4) * (c3 - c4);
                    R = (R + Math.Sqrt(temp)) / 2;

                    tempX = (a2 - a4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempY = (b2 - b4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempZ = (c2 - c4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[1], TCP_L_BB());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[4], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[0], tempRobotPose2, AutoWeld_WedlPoint_Left[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);


                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[3], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    double a1 = AutoWeld_WedlPoint_Right[1].f1;
                    double b1 = AutoWeld_WedlPoint_Right[1].f2;
                    double c1 = AutoWeld_WedlPoint_Right[1].f3;
                    double a2 = AutoWeld_WedlPoint_Right[0].f1;
                    double b2 = AutoWeld_WedlPoint_Right[0].f2;
                    double c2 = AutoWeld_WedlPoint_Right[0].f3;
                    double a3 = AutoWeld_WedlPoint_Right[7].f1;
                    double b3 = AutoWeld_WedlPoint_Right[7].f2;
                    double c3 = AutoWeld_WedlPoint_Right[7].f3;

                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);
                    temp = (a3 - a4) * (a3 - a4) + (b3 - b4) * (b3 - b4) + (c3 - c4) * (c3 - c4);
                    R = (R + Math.Sqrt(temp)) / 2;

                    tempX = (a2 - a4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempY = (b2 - b4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempZ = (c2 - c4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_BB());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[0], tempRobotPose2, AutoWeld_WedlPoint_Right[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }
        int MakeWeldInfo_ST4_CP6F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5, 0, 0, 1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    double a1 = AutoWeld_WedlPoint_Left[3].f1;
                    double b1 = AutoWeld_WedlPoint_Left[3].f2;
                    double c1 = AutoWeld_WedlPoint_Left[3].f3;
                    double a2 = AutoWeld_WedlPoint_Left[4].f1;
                    double b2 = AutoWeld_WedlPoint_Left[4].f2;
                    double c2 = AutoWeld_WedlPoint_Left[4].f3;
                    double a3 = AutoWeld_WedlPoint_Left[5].f1;
                    double b3 = AutoWeld_WedlPoint_Left[5].f2;
                    double c3 = AutoWeld_WedlPoint_Left[5].f3;

                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);
                    temp = (a3 - a4) * (a3 - a4) + (b3 - b4) * (b3 - b4) + (c3 - c4) * (c3 - c4);
                    R = (R + Math.Sqrt(temp)) / 2;

                    tempX = (a2 - a4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempY = (b2 - b4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempZ = (c2 - c4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[3], TCP_L_B());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[4], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[4], tempRobotPose2, AutoWeld_WedlPoint_Left[5]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);


                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[3], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    double a1 = AutoWeld_WedlPoint_Right[3].f1;
                    double b1 = AutoWeld_WedlPoint_Right[3].f2;
                    double c1 = AutoWeld_WedlPoint_Right[3].f3;
                    double a2 = AutoWeld_WedlPoint_Right[4].f1;
                    double b2 = AutoWeld_WedlPoint_Right[4].f2;
                    double c2 = AutoWeld_WedlPoint_Right[4].f3;
                    double a3 = AutoWeld_WedlPoint_Right[5].f1;
                    double b3 = AutoWeld_WedlPoint_Right[5].f2;
                    double c3 = AutoWeld_WedlPoint_Right[5].f3;

                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);
                    temp = (a3 - a4) * (a3 - a4) + (b3 - b4) * (b3 - b4) + (c3 - c4) * (c3 - c4);
                    R = (R + Math.Sqrt(temp)) / 2;

                    tempX = (a2 - a4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempY = (b2 - b4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));
                    tempZ = (c2 - c4) / (Math.Sqrt((a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_B());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[4], tempRobotPose2, AutoWeld_WedlPoint_Right[5]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }
        int MakeWeldInfo_ST4_CP11F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Right[2], 10, TCP_B_L());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[3]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5,0,0,1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[1], TCP_L_BB());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[4], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[3], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_BB());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }
        int MakeWeldInfo_ST4_CP12F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5, 0, 0, 1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[3], TCP_L_B());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[4], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);


                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[3], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_B());
                    //tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }
        int MakeWeldInfo_ST3_CP8F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Right[2], 10, TCP_B_L());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[3]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5, 0, 0, 1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());


                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }

                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {

                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[1], TCP_L_BB());
                    tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0], 70, TCP_L_B());

                    double a1 = AutoWeld_WedlPoint_Left[1].f1;
                    double b1 = AutoWeld_WedlPoint_Left[1].f2;
                    double c1 = AutoWeld_WedlPoint_Left[1].f3;
                    double a2 = AutoWeld_WedlPoint_Left[0].f1;
                    double b2 = AutoWeld_WedlPoint_Left[0].f2;
                    double c2 = AutoWeld_WedlPoint_Left[0].f3;
                    double a3 = AutoWeld_WedlPoint_Left[7].f1;
                    double b3 = AutoWeld_WedlPoint_Left[7].f2;
                    double c3 = AutoWeld_WedlPoint_Left[7].f3;
                    double a5 = AutoWeld_WedlPoint_Left[8].f1;
                    double b5 = AutoWeld_WedlPoint_Left[8].f2;
                    double c5 = AutoWeld_WedlPoint_Left[8].f3;
                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);

                    tempX = (a3 - a5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempY = (b3 - b5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempZ = (c3 - c5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;
                    /*
                    
                    R = ((AutoWeld_WedlPoint_Left[5].f2 - AutoWeld_WedlPoint_Left[4].f2) + (AutoWeld_WedlPoint_Left[5].f3 - AutoWeld_WedlPoint_Left[5].f3)) / 2;
                    R = Math.Sqrt(R * R);

                    tempX = (AutoWeld_WedlPoint_Left[4].f1 + AutoWeld_WedlPoint_Left[5].f1) / 2;
                    tempY = AutoWeld_WedlPoint_Left[5].f2 + R * Math.Cos(45 * Math.PI / 180);
                    tempZ = AutoWeld_WedlPoint_Left[4].f3 + R * Math.Sin(45 * Math.PI / 180);
                    */
                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(2, AutoWeld_WedlPoint_Left[0], tempRobotPose2, AutoWeld_WedlPoint_Left[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[7], AutoWeld_WedlPoint_Left[7], AutoWeld_WedlPoint_Left[8]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P,S1", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());
                        tempweldinformation.InitCondition.AddStartPosition(new RobotPoseData(2, 100, tempRobotPose0.f1 - 20, tempRobotPose0.f2, tempRobotPose0.f3 + 20, tempRobotPose0.f4, tempRobotPose0.f5, tempRobotPose0.f6));


                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_LCP_LU());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_U_L());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L_U());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L_B());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L_BB());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬

                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_BB());
                    tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);

                    double a1 = AutoWeld_WedlPoint_Right[1].f1;
                    double b1 = AutoWeld_WedlPoint_Right[1].f2;
                    double c1 = AutoWeld_WedlPoint_Right[1].f3;
                    double a2 = AutoWeld_WedlPoint_Right[0].f1;
                    double b2 = AutoWeld_WedlPoint_Right[0].f2;
                    double c2 = AutoWeld_WedlPoint_Right[0].f3;
                    double a3 = AutoWeld_WedlPoint_Right[7].f1;
                    double b3 = AutoWeld_WedlPoint_Right[7].f2;
                    double c3 = AutoWeld_WedlPoint_Right[7].f3;
                    double a5 = AutoWeld_WedlPoint_Right[8].f1;
                    double b5 = AutoWeld_WedlPoint_Right[8].f2;
                    double c5 = AutoWeld_WedlPoint_Right[8].f3;
                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, tempX1, tempY1, tempZ1, tempX2, tempY2, tempZ2, tempX3, tempY3, tempZ3, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);

                    tempX1 = (a3 - a5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempY1 = (b3 - b5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempZ1 = (c3 - c5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));

                    tempX2 = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX1;
                    tempY2 = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY1;
                    tempZ2 = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ1;

                    tempX3 = tempX2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    tempY3 = tempY2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    tempZ3 = tempZ2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    temp = Math.Sqrt(tempX3 * tempX3 + tempY3 * tempY3 + tempZ3 * tempZ3);
                    tempX = a4 + R * tempX3;
                    tempY = b4 + R * tempY3;
                    tempZ = c4 + R * tempZ3;

                    /*
                    double tempX, tempY, tempZ, R;
                    R = ((AutoWeld_WedlPoint_Right[5].f2 - AutoWeld_WedlPoint_Right[4].f2) + (AutoWeld_WedlPoint_Right[5].f3 - AutoWeld_WedlPoint_Right[5].f3)) / 2;
                    R = Math.Sqrt(R * R);
                    tempX = (AutoWeld_WedlPoint_Right[4].f1 + AutoWeld_WedlPoint_Right[5].f1) / 2;
                    tempY = AutoWeld_WedlPoint_Right[5].f2 + R * Math.Cos(45 * Math.PI / 180);
                    tempZ = AutoWeld_WedlPoint_Right[4].f3 + R * Math.Sin(45 * Math.PI / 180);
                    */
                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_RCP_RB());

                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(2, AutoWeld_WedlPoint_Right[0], tempRobotPose2, AutoWeld_WedlPoint_Right[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[7], AutoWeld_WedlPoint_Right[7], AutoWeld_WedlPoint_Right[8]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P,S1", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());


                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_RCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_RCP_RU());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_U_RR());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R_U());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R_B());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R_BB());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }

        int MakeWeldInfo_ST3_CP9F(int dir)
        {
            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();
            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Right[2], 10, TCP_B_L());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], tempRobotPose0);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[3]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "P,F,P", para.Split('-')[1] + "1,3,1", OffsetH + i * 5, OffsetH + i * 5,0,0,1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }

                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[3], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {

                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Left[1], TCP_L_BB());
                    tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[0], AutoWeld_WedlPoint_Left[4], 70, TCP_L_B());

                    double a1 = AutoWeld_WedlPoint_Left[1].f1;
                    double b1 = AutoWeld_WedlPoint_Left[1].f2;
                    double c1 = AutoWeld_WedlPoint_Left[1].f3;
                    double a2 = AutoWeld_WedlPoint_Left[0].f1;
                    double b2 = AutoWeld_WedlPoint_Left[0].f2;
                    double c2 = AutoWeld_WedlPoint_Left[0].f3;
                    double a3 = AutoWeld_WedlPoint_Left[7].f1;
                    double b3 = AutoWeld_WedlPoint_Left[7].f2;
                    double c3 = AutoWeld_WedlPoint_Left[7].f3;
                    double a5 = AutoWeld_WedlPoint_Left[8].f1;
                    double b5 = AutoWeld_WedlPoint_Left[8].f2;
                    double c5 = AutoWeld_WedlPoint_Left[8].f3;
                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);

                    tempX = (a3 - a5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempY = (b3 - b5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempZ = (c3 - c5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(2, AutoWeld_WedlPoint_Left[0], tempRobotPose2, AutoWeld_WedlPoint_Left[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[7], AutoWeld_WedlPoint_Left[7], AutoWeld_WedlPoint_Left[8]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P,S1", "", OffsetV + i * 5, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());
                        tempweldinformation.InitCondition.AddStartPosition(new RobotPoseData(2, 100, tempRobotPose0.f1 - 20, tempRobotPose0.f2, tempRobotPose0.f3 + 20, tempRobotPose0.f4, tempRobotPose0.f5, tempRobotPose0.f6));


                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_LCP_LU());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_U_L());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L_U());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L_B());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L_BB());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬

                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6], 70, TCP_L_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[2], AutoWeld_WedlPoint_Left[2], tempRobotPose0);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    tempRobotPose0 = new RobotPoseData(2, 100, AutoWeld_WedlPoint_Right[1], TCP_R_BB());
                    tempRobotPose1 = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[0], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, tempRobotPose1);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);

                    double a1 = AutoWeld_WedlPoint_Right[1].f1;
                    double b1 = AutoWeld_WedlPoint_Right[1].f2;
                    double c1 = AutoWeld_WedlPoint_Right[1].f3;
                    double a2 = AutoWeld_WedlPoint_Right[0].f1;
                    double b2 = AutoWeld_WedlPoint_Right[0].f2;
                    double c2 = AutoWeld_WedlPoint_Right[0].f3;
                    double a3 = AutoWeld_WedlPoint_Right[7].f1;
                    double b3 = AutoWeld_WedlPoint_Right[7].f2;
                    double c3 = AutoWeld_WedlPoint_Right[7].f3;
                    double a5 = AutoWeld_WedlPoint_Right[8].f1;
                    double b5 = AutoWeld_WedlPoint_Right[8].f2;
                    double c5 = AutoWeld_WedlPoint_Right[8].f3;
                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, tempX1, tempY1, tempZ1, tempX2, tempY2, tempZ2, tempX3, tempY3, tempZ3, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);

                    tempX1 = (a3 - a5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempY1 = (b3 - b5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempZ1 = (c3 - c5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));

                    tempX2 = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX1;
                    tempY2 = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY1;
                    tempZ2 = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ1;

                    tempX3 = tempX2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    tempY3 = tempY2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    tempZ3 = tempZ2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    temp = Math.Sqrt(tempX3 * tempX3 + tempY3 * tempY3 + tempZ3 * tempZ3);
                    tempX = a4 + R * tempX3;
                    tempY = b4 + R * tempY3;
                    tempZ = c4 + R * tempZ3;

                    /*
                    double tempX, tempY, tempZ, R;
                    R = ((AutoWeld_WedlPoint_Right[5].f2 - AutoWeld_WedlPoint_Right[4].f2) + (AutoWeld_WedlPoint_Right[5].f3 - AutoWeld_WedlPoint_Right[5].f3)) / 2;
                    R = Math.Sqrt(R * R);
                    tempX = (AutoWeld_WedlPoint_Right[4].f1 + AutoWeld_WedlPoint_Right[5].f1) / 2;
                    tempY = AutoWeld_WedlPoint_Right[5].f2 + R * Math.Cos(45 * Math.PI / 180);
                    tempZ = AutoWeld_WedlPoint_Right[4].f3 + R * Math.Sin(45 * Math.PI / 180);
                    */
                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_RCP_RB());

                    tempmaincon.SetPath(1, tempRobotPose0, tempRobotPose0, AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(2, AutoWeld_WedlPoint_Right[0], tempRobotPose2, AutoWeld_WedlPoint_Right[7]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[7], AutoWeld_WedlPoint_Right[7], AutoWeld_WedlPoint_Right[8]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "B,P,S1", "", OffsetV + i * 5, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());


                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_RCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_RCP_RU());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_U_RR());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R_U());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R_B());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R_BB());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }

            return 1;

        }

        int MakeWeldInfo_ST3_CP10F(int dir)
        {

            string tempstr1 = "";
            int pathnum = 0;

            WeldInformation DefaultWeldInformation;
            WeldMainCondition tempmaincon;
            WeldInformation tempweldinformation = new WeldInformation();

            RobotPoseData tempRobotPose0, tempRobotPose1, tempRobotPose2;

            Read_InitSetting_KeyValue("OffsetH", ref tempstr1);
            double OffsetH = Convert.ToDouble(tempstr1);
            Read_InitSetting_KeyValue("OffsetV", ref tempstr1);
            double OffsetV = Convert.ToDouble(tempstr1);


            //왼쪽셀일때
            if (dir == 0)
            {
                //0번용접선 용접하는지 체크하고 용접하면 추가함
                if ((WeldLineFlag_Left[0] == true) && (RightWeldFlag == true))
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_2F_" + ((int)WeldLineWidth_Left[0]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    //오른쪽에 0번위치 이전에 용접선이 있는지 체크하고 만들어넣음
                    string para = MakeRightsideToZeroPointLine();
                    for (int i = 0; i < RightTempLine.Count; i++) DefaultWeldInformation.AddMainCondition(RightTempLine[i]);

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Right[2], AutoWeld_WedlPoint_Left[2]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "2F", WeldLineWidth_Left[0], WeldLineGap_Left[0], pathnum, i, para.Split('-')[0] + "", para.Split('-')[1] + "", 0, 0, 0, 0, 1);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_B());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());


                        //방향설정 또는 로봇 각도에 따라 용접방향 바꾸는 부분
                        string tempstr = "";
                        Read_InitSetting_KeyValue("HWeldingDir", ref tempstr);
                        if (tempstr == "1")
                        {
                            AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                        }
                        else if (tempstr == "0")
                        {
                            AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                        }
                        else
                        {
                            if (IMUclass.RobotRx < -5)
                            {
                                AutoWeld_WeldInformationList.Add(tempweldinformation.ReverseInfo());
                            }
                            else
                            {
                                AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                            }
                        }
                    }
                }

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[2], 70, TCP_L_B());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[1], AutoWeld_WedlPoint_Left[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[1], WeldLineGap_Left[1], pathnum, i, "B,P", "", 0, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Left[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Left[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();


                    double a1 = AutoWeld_WedlPoint_Left[3].f1;
                    double b1 = AutoWeld_WedlPoint_Left[3].f2;
                    double c1 = AutoWeld_WedlPoint_Left[3].f3;
                    double a2 = AutoWeld_WedlPoint_Left[4].f1;
                    double b2 = AutoWeld_WedlPoint_Left[4].f2;
                    double c2 = AutoWeld_WedlPoint_Left[4].f3;
                    double a3 = AutoWeld_WedlPoint_Left[5].f1;
                    double b3 = AutoWeld_WedlPoint_Left[5].f2;
                    double c3 = AutoWeld_WedlPoint_Left[5].f3;
                    double a5 = AutoWeld_WedlPoint_Left[6].f1;
                    double b5 = AutoWeld_WedlPoint_Left[6].f2;
                    double c5 = AutoWeld_WedlPoint_Left[6].f3;
                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);

                    tempX = (a3 - a5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempY = (b3 - b5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempZ = (c3 - c5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));

                    tempX = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX;
                    tempY = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY;
                    tempZ = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ;

                    tempX = tempX / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempY = tempY / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));
                    tempZ = tempZ / (Math.Sqrt(tempX * tempX + tempY * tempY + tempZ * tempZ));

                    tempX = a4 + R * tempX;
                    tempY = b4 + R * tempY;
                    tempZ = c4 + R * tempZ;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_LCP_LB());

                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[3], AutoWeld_WedlPoint_Left[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(2, AutoWeld_WedlPoint_Left[4], tempRobotPose2, AutoWeld_WedlPoint_Left[5]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[5], AutoWeld_WedlPoint_Left[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Left[2], WeldLineGap_Left[2], pathnum, i, "B,P,P,P", "", 0, 0, 0, -1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }


                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_L());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_L());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


            }


            //오른쪽셀 일때
            if (dir == 1)
            {

                //1번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[1] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[1]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[2], 70, TCP_R_B());
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[1], AutoWeld_WedlPoint_Right[0]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);


                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[1], WeldLineGap_Right[1], pathnum, i, "B,P", "", 0, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }


                //2번용접선 용접하는지 체크하고 용접하면 추가함
                if (WeldLineFlag_Right[2] == true)
                {
                    //해당 각장의 수평용접이 몇패스 용접인지 설정값 불러옴
                    Read_InitSetting_KeyValue("PathNum_3F_" + ((int)WeldLineWidth_Right[2]).ToString() + "mm", ref tempstr1);
                    pathnum = Convert.ToInt32(tempstr1);

                    //본조건 용접 위치데이터만 들어간 용접인포메이션 객체 만듬
                    DefaultWeldInformation = new WeldInformation();
                    tempmaincon = new WeldMainCondition();

                    double a1 = AutoWeld_WedlPoint_Right[3].f1;
                    double b1 = AutoWeld_WedlPoint_Right[3].f2;
                    double c1 = AutoWeld_WedlPoint_Right[3].f3;
                    double a2 = AutoWeld_WedlPoint_Right[4].f1;
                    double b2 = AutoWeld_WedlPoint_Right[4].f2;
                    double c2 = AutoWeld_WedlPoint_Right[4].f3;
                    double a3 = AutoWeld_WedlPoint_Right[5].f1;
                    double b3 = AutoWeld_WedlPoint_Right[5].f2;
                    double c3 = AutoWeld_WedlPoint_Right[5].f3;
                    double a5 = AutoWeld_WedlPoint_Right[6].f1;
                    double b5 = AutoWeld_WedlPoint_Right[6].f2;
                    double c5 = AutoWeld_WedlPoint_Right[6].f3;
                    double a4, b4, c4, t;
                    double tempX, tempY, tempZ, tempX1, tempY1, tempZ1, tempX2, tempY2, tempZ2, tempX3, tempY3, tempZ3, temp, R;

                    t = -((a2 - a1) * (a1 - a3) + (b2 - b1) * (b1 - b3) + (c2 - c1) * (c1 - c3)) / ((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1));
                    a4 = a2 - (t * (a2 - a1) + a1 - a3);
                    b4 = b2 - (t * (b2 - b1) + b1 - b3);
                    c4 = c2 - (t * (c2 - c1) + c1 - c3);
                    temp = (a2 - a4) * (a2 - a4) + (b2 - b4) * (b2 - b4) + (c2 - c4) * (c2 - c4);
                    R = Math.Sqrt(temp);

                    tempX1 = (a3 - a5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempY1 = (b3 - b5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));
                    tempZ1 = (c3 - c5) / (Math.Sqrt((a3 - a5) * (a3 - a5) + (b3 - b5) * (b3 - b5) + (c3 - c5) * (c3 - c5)));

                    tempX2 = (a2 - a1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempX1;
                    tempY2 = (b2 - b1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempY1;
                    tempZ2 = (c2 - c1) / (Math.Sqrt((a2 - a1) * (a2 - a1) + (b2 - b1) * (b2 - b1) + (c2 - c1) * (c2 - c1))) + tempZ1;

                    tempX3 = tempX2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    tempY3 = tempY2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    tempZ3 = tempZ2 / (Math.Sqrt(tempX2 * tempX2 + tempY2 * tempY2 + tempZ2 * tempZ2));
                    temp = Math.Sqrt(tempX3 * tempX3 + tempY3 * tempY3 + tempZ3 * tempZ3);
                    tempX = a4 + R * tempX3;
                    tempY = b4 + R * tempY3;
                    tempZ = c4 + R * tempZ3;

                    tempRobotPose2 = new RobotPoseData(2, 100, tempX, tempY, tempZ, TCP_RCP_RB());
                    //tempRobotPose = RobotCommclass.CalcMiddleposeStartoffset(AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[4], 70, TCP_R_B());
                    //tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[3], tempRobotPose);
                    //DefaultWeldInformation.AddMainCondition(tempmaincon);
                    //tempmaincon.SetPath(1, tempRobotPose, tempRobotPose, AutoWeld_WedlPoint_Right[4]);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[3], AutoWeld_WedlPoint_Right[4]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(2, AutoWeld_WedlPoint_Right[4], tempRobotPose2, AutoWeld_WedlPoint_Right[5]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);
                    tempmaincon.SetPath(1, AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[5], AutoWeld_WedlPoint_Right[6]);
                    DefaultWeldInformation.AddMainCondition(tempmaincon);

                    //용접 인포메이션에 용접DB, 용접설정, 접근경로, 복귀경로 지정
                    for (int i = 0; i < pathnum; i++)
                    {
                        ApplyWeldConAndOffset(DefaultWeldInformation, out tempweldinformation, "3F", WeldLineWidth_Right[2], WeldLineGap_Right[2], pathnum, i, "P,P,F", "", 0, 0, 0, 1, 0);
                        tempweldinformation.ArcOnFlag = ArcFlag;
                        tempweldinformation.ContinueFlag = true;
                        if (i == 0) { tempweldinformation.MultipathFlag = false; } else { tempweldinformation.MultipathFlag = true; }

                        tempweldinformation.InitCondition.AddStartPosition(Joint_Middle2());
                        tempweldinformation.InitCondition.AddStartPosition(TCP_B_RR());

                        tempweldinformation.EndCondition.AddEndPosition(TCP_BACK());
                        tempweldinformation.EndCondition.AddEndPosition(TCP_R());
                        tempweldinformation.EndCondition.AddEndPosition(Joint_Middle2());

                        AutoWeld_WeldInformationList.Add((WeldInformation)tempweldinformation.Clone());
                    }
                }
            }



            return 1;

        }

        void AutoWeldingSubSeq()
        {
            bool NextWeldFlag = true;
            string tempstr1 = "";


            switch (AutoWeldingSubState)
            {
                case "시작":

                    //기존용접경로 삭제
                    AutoWeldingPathRecord_ALL.Clear();
                    AutoWeldingPathRecord_Single.Clear();

                    AutoWeldCount = 0;
                    if (AutoWeld_WeldInformationList.Count > 0)
                    {
                        AutoWeldingSubState = "연속용접 대기";
                    }
                    else
                    {
                        AutoWeldingSubState = "연속용접 실패";
                    }

                    break;

                case "연속용접 대기":
                    //용접 라인이 남아있는 경우 용접을 자동으로 시작하는 설정인지 체크한 후 용접 진행함
                    if (AutoWeld_WeldInformationList.Count > AutoWeldCount)
                    {
                        //설정값 가져옴
                        Read_InitSetting_KeyValue("WeldingAutoManualStart", ref tempstr1);
                        
                        //자동진행 설정 중 하나라도 진행안함이 있으면 자동진행 안함
                        NextWeldFlag = true;
                        if (tempstr1 == "1") NextWeldFlag = false; //설정이 수동진행인 경우
                        if ((AutoWeld_WeldInformationList[AutoWeldCount].MultipathNumber > 1) && (tempstr1 == "2")) NextWeldFlag = false; //다층용접이며 설정이 다층용접일때 수동진행인 경우
                        if ((AutoWeld_WeldInformationList[AutoWeldCount].MultipathNumber == 2) && (tempstr1 == "3")) NextWeldFlag = false; //초층용접 이후이며 설정이 초층용접 이후 멈춤인 경우
                        if (AutoWeld_WeldInformationList[AutoWeldCount].ContinueFlag == false) NextWeldFlag = false; //용접패스설정
                        if (AutoWeldSubNextWeldingStopFlag == true) NextWeldFlag = false; //상위에서 다음 용접 진행안함 눌렀을 경우

                        if (NextWeldFlag == false)
                        {
                            //자동진행 설정으로 용접 안할때 상위에서 수동으로 진행하는 플래그
                            if (AutoWeldSubNextWeldingStartFlag == true)
                            {
                                AutoWeldSubNextWeldingStartFlag = false;
                                AutoWeldSubNextWeldingStopFlag = false;
                                AutoWeldingSubState = "연속용접";
                            }
                        }
                        else
                        {
                            //진행인 경우 다음 용접 진행
                            AutoWeldingSubState = "연속용접";
                        }
                    }
                    else
                    {
                        AutoWeldingSubState = "연속용접 성공";
                    }

                    break;

                case "연속용접":

                    if (MultipathAndArcSensingCheck(AutoWeld_WeldInformationList, AutoWeldCount) == true)
                    {
                        //멀티패스(2,3패스) 이며 초층을 아크센싱 적용한 경우 초층 실제 용접경로에 쉬프트 적용하여 다층용접경로 생성 후 용접
                        RobotCommclass.WeldStart(MakeArcSensingMultiPath(AutoWeld_WeldInformationList,AutoWeldingPathRecord_ALL, AutoWeldCount));
                    }
                    else
                    {
                        //멀티패스가 아니거나 초층에 아크센싱을 사용하지 않은 경우 정해진 경로대로 용접
                        RobotCommclass.WeldStart(AutoWeld_WeldInformationList[AutoWeldCount]);
                    }

                    AutoWeldCount++;
                    AutoWeldingSubState = "연속용접 완료대기";

                    break;

                case "연속용접 완료대기":

                    if (RobotCommclass.RobotControlThreadSeq == 124)
                    {
                        RobotCommclass.RobotControlThreadSeq = 15;
                        AutoWeldingSubState = "연속용접 대기";
                        AutoWeldSubNextWeldingStartFlag = false;

                        //용접경로 저장
                        if (AutoWeldingPathRecord_ALL.Count > AutoWeldCount - 1) AutoWeldingPathRecord_ALL.RemoveAt(AutoWeldingPathRecord_ALL.Count-1);
                        AutoWeldingPathRecord_Single = RobotCommclass.GetLastWeldingPath();
                        AutoWeldingPathRecord_ALL.Add(AutoWeldingPathRecord_Single);

                    }
                    else if (RobotCommclass.RobotControlThreadSeq == 199)
                    {
                        RobotCommclass.RobotControlThreadSeq = 15;
                        AutoWeldingSubState = "연속용접 실패";
                    }

                    break;

                case "연속용접 실패":
                    break;

                case "연속용접 성공":
                    break;

                default:
                    break;
            }

        }

        //주어진 키로 용접조건 찾아서 용접조건객체로 만들어주는 함수 리턴0:실패, 리턴1:성공
        int WeldDBLoad(string key, WeldingCondition weldcon)
        {
            //주어진 키에 해당하는 데이터가 없을때 0 리턴
            if (WeldDatabase.ContainsKey(key) == false) return 0;

            string strdata = WeldDatabase[key];
            string[] strarr = strdata.Split(',');

            try
            {
                weldcon.Vol = Convert.ToDouble(strarr[0]);
                weldcon.Amp = Convert.ToDouble(strarr[1]);
                weldcon.Spd = Convert.ToDouble(strarr[2]);
                weldcon.Offset_WorkAngle = Convert.ToDouble(strarr[3]);
                weldcon.Offset_TravelAngle = Convert.ToDouble(strarr[4]);
                weldcon.Offset_X = Convert.ToDouble(strarr[5]);
                weldcon.Offset_Y = Convert.ToDouble(strarr[6]);
                weldcon.Offset_Z = Convert.ToDouble(strarr[7]);
                weldcon.WeavingHz = Convert.ToDouble(strarr[8]);
                weldcon.WeavingWidth = Convert.ToDouble(strarr[9]);
                weldcon.WeavingFloorStop = Convert.ToDouble(strarr[10]);
                weldcon.WeavingWallStop = Convert.ToDouble(strarr[11]);
                weldcon.ArcSen = Convert.ToInt32(strarr[12]);
                weldcon.BeadBias = Convert.ToDouble(strarr[13]);
            }
            catch
            {
                return 0;
            }

            return 1;
        }


        /// <summary>
        /// 용접정보에 용접DB, 용접설정, 오프셋 등을 반영하는 함수
        /// </summary>
        /// <param name="DefaultInfo">초기 용접정보</param>
        /// <param name="ResultInfo">데이터 반영 후 용접정보</param>
        /// <param name="Position">용접자세, 2F/3F/4F</param>
        /// <param name="Width">각장</param>
        /// <param name="Gap">갭</param>
        /// <param name="TotalPath">전체 패스수</param>
        /// <param name="NowPath">현재 패스</param>
        /// <param name="AdditionalAnglelInfo">컴마로 구분된 추가정보 문자열. 용접라인이 3개가 연결되어 용접선을 이룰 때 
        /// "B,P,F" 문자열을 넣는 경우 첫번째는 B조건, 두번째는 P, 세번째는 F 조건이 들어감
        /// 문자열 개수와 용접라인 개수가 맞지 않는경우 남는 문자는 무시, 부족한 문자는 P(수직)로 적용됨
        /// 종류는 B(후진각), P(수직), F(전진각), S1(스페셜1), S2(스페셜2), S3(스페셜3)</param>
        /// <param name="AdditionalArcSenInfo">컴마로 구분된 아크센싱 추가정보 문자열. "1,2,3"일때 해당하는 용접선에 1:DB대로 실행, 2:강제로 아크센싱 온, 3:강제로 아크센싱 오프 적용</param>
        /// <param name="StartOffset">시작쪽 오프셋 길이(mm)</param>
        /// <param name="EndOffset">종료쪽 오프셋 길이(mm)</param>
        /// <returns></returns>
        int ApplyWeldConAndOffset(WeldInformation DefaultInfo, out WeldInformation ResultInfo, string Position, double Width, double Gap, int TotalPath, int NowPath, string AdditionalAnglelInfo, string AdditionalArcSenInfo, double StartOffset, double EndOffset, double NVx, double NVy, double NVz)
        {
            string tempstr1;
            WeldingCondition WeldDB_B = new WeldingCondition();
            WeldingCondition WeldDB_P = new WeldingCondition();
            WeldingCondition WeldDB_F = new WeldingCondition();
            WeldingCondition WeldDB_S1 = new WeldingCondition();
            WeldingCondition WeldDB_S2 = new WeldingCondition();
            WeldingCondition WeldDB_InitPath = new WeldingCondition();
            ResultInfo = new WeldInformation();

            //DB에서 용접조건 가져옴
            tempstr1 = Position + "," + ((int)Width).ToString() + "," + ((int)Gap).ToString() + "," + TotalPath.ToString() + "," + (NowPath + 1).ToString() + ",B";
            if (WeldDBLoad(tempstr1, WeldDB_B) != 1) return 0;
            tempstr1 = Position + "," + ((int)Width).ToString() + "," + ((int)Gap).ToString() + "," + TotalPath.ToString() + "," + (NowPath + 1).ToString() + ",P";
            if (WeldDBLoad(tempstr1, WeldDB_P) != 1) return 0;
            tempstr1 = Position + "," + ((int)Width).ToString() + "," + ((int)Gap).ToString() + "," + TotalPath.ToString() + "," + (NowPath + 1).ToString() + ",F";
            if (WeldDBLoad(tempstr1, WeldDB_F) != 1) return 0;
            tempstr1 = Position + "," + ((int)Width).ToString() + "," + ((int)Gap).ToString() + "," + TotalPath.ToString() + "," + (NowPath + 1).ToString() + ",S1";
            if (WeldDBLoad(tempstr1, WeldDB_S1) != 1) return 0;
            tempstr1 = Position + "," + ((int)Width).ToString() + "," + ((int)Gap).ToString() + "," + TotalPath.ToString() + "," + (NowPath + 1).ToString() + ",S2";
            if (WeldDBLoad(tempstr1, WeldDB_S2) != 1) return 0;


            //설정에서 아크센싱조건 가져옴
            double HFactor = 0, VFactor = 0, HMaxdL = 0, VMaxdL = 0, HOncedL = 0, VOncedL = 0, TimeShift = 0;
            double HFactor1F, VFactor1F, HMaxdL1F, VMaxdL1F, HOncedL1F, VOncedL1F, TimeShift1F;
            double HFactor2F, VFactor2F, HMaxdL2F, VMaxdL2F, HOncedL2F, VOncedL2F, TimeShift2F;
            double HFactor3F, VFactor3F, HMaxdL3F, VMaxdL3F, HOncedL3F, VOncedL3F, TimeShift3F;
            double HFactor4F, VFactor4F, HMaxdL4F, VMaxdL4F, HOncedL4F, VOncedL4F, TimeShift4F;

            if (SettingLoadArcSen(1, out HFactor1F, out VFactor1F, out HMaxdL1F, out VMaxdL1F, out HOncedL1F, out VOncedL1F, out TimeShift1F) != 1) return 0;
            if (SettingLoadArcSen(2, out HFactor2F, out VFactor2F, out HMaxdL2F, out VMaxdL2F, out HOncedL2F, out VOncedL2F, out TimeShift2F) != 1) return 0;
            if (SettingLoadArcSen(3, out HFactor3F, out VFactor3F, out HMaxdL3F, out VMaxdL3F, out HOncedL3F, out VOncedL3F, out TimeShift3F) != 1) return 0;
            if (SettingLoadArcSen(4, out HFactor4F, out VFactor4F, out HMaxdL4F, out VMaxdL4F, out HOncedL4F, out VOncedL4F, out TimeShift4F) != 1) return 0;

            if (Position == "1F")
            {
                if (SettingLoadArcSen(1, out HFactor, out VFactor, out HMaxdL, out VMaxdL, out HOncedL, out VOncedL, out TimeShift) != 1) return 0;
            }else if(Position == "2F")
            {
                if (SettingLoadArcSen(2, out HFactor, out VFactor, out HMaxdL, out VMaxdL, out HOncedL, out VOncedL, out TimeShift) != 1) return 0;
            }
            else if (Position == "3F")
            {
                if (SettingLoadArcSen(3, out HFactor, out VFactor, out HMaxdL, out VMaxdL, out HOncedL, out VOncedL, out TimeShift) != 1) return 0;
            }
            else if (Position == "4F")
            {
                if (SettingLoadArcSen(4, out HFactor, out VFactor, out HMaxdL, out VMaxdL, out HOncedL, out VOncedL, out TimeShift) != 1) return 0;
            }

            //설정에서 시작, 종료조건 가져옴
            double SGasTime, SArcTime, SArcVol, SArcAmp, EGasTime, EArcTime, EArcVol, EArcAmp, EBackLength;
            if (SettingLoadStartEndData(out SGasTime, out SArcTime, out SArcVol, out SArcAmp, out EGasTime, out EArcTime, out EArcVol, out EArcAmp, out EBackLength) != 1) return 0;

            //결과반환 객체 만든 후 시작조건, 종료조건 입력
            ResultInfo.InitCondition = new WeldStartCondition(SGasTime, SArcTime, SArcVol, SArcAmp);
            ResultInfo.EndCondition = new WeldEndCondition(EGasTime, EArcTime, EArcVol, EArcAmp, EBackLength);

            //용접경로가 라인 몇개로 구성되있는지 체크
            int count = DefaultInfo.GetMainConditionCount();
                        
            //디폴트인포의 메인조건을 하나씩 리절트인포로 복사하면서 오프셋, 작업각, 용접조건을 반영함
            for (int i = 0; i < count; i++)
            {
                WeldMainCondition ResultCondition = DefaultInfo.GetMainCondition(i);

                //옵션 문자열에 대해 적용할 용접조건 선택
                WeldingCondition WeldDB_Apply;
                string[] tempstrarr1 = AdditionalAnglelInfo.Split(',');
                if (i < tempstrarr1.Length)
                {
                    if (tempstrarr1[i] == "B")
                    {
                        WeldDB_Apply = (WeldingCondition)WeldDB_B.Clone();
                    }
                    else if (tempstrarr1[i] == "F")
                    {
                        WeldDB_Apply = (WeldingCondition)WeldDB_F.Clone();
                    }
                    else if (tempstrarr1[i] == "S1")
                    {
                        WeldDB_Apply = (WeldingCondition)WeldDB_S1.Clone();
                    }
                    else if (tempstrarr1[i] == "S2")
                    {
                        WeldDB_Apply = (WeldingCondition)WeldDB_S2.Clone();
                    }
                    else
                    {
                        WeldDB_Apply = (WeldingCondition)WeldDB_P.Clone();
                    }

                }
                else
                {
                    WeldDB_Apply = (WeldingCondition)WeldDB_P.Clone();
                }

                //용접조건중 오프셋 반영
                ResultCondition.ApplyOffset(new double[] { WeldDB_Apply.Offset_X, WeldDB_Apply.Offset_Y, WeldDB_Apply.Offset_Z, WeldDB_Apply.Offset_WorkAngle, WeldDB_Apply.Offset_TravelAngle },
                                            new double[] { NVx, NVy, NVz });

                //아크센싱 후 다층용접에 사용하기 위해 초층대비 상대오프셋 저장해둠
                if (NowPath != 0)
                {
                    tempstr1 = Position + "," + ((int)Width).ToString() + "," + ((int)Gap).ToString() + "," + TotalPath.ToString() + "," + "1" + ",P";
                    if (WeldDBLoad(tempstr1, WeldDB_InitPath) != 1) return 0;

                    ResultInfo.MultipathFlag = true;
                    ResultInfo.MultipathNumber = NowPath + 1;
                    ResultCondition.SetOffset(WeldDB_Apply.Offset_X - WeldDB_InitPath.Offset_X, WeldDB_Apply.Offset_Y - WeldDB_InitPath.Offset_Y, WeldDB_Apply.Offset_Z - WeldDB_InitPath.Offset_Z,
                                              WeldDB_Apply.Offset_WorkAngle - WeldDB_InitPath.Offset_WorkAngle, WeldDB_Apply.Offset_TravelAngle - WeldDB_InitPath.Offset_TravelAngle);
                }
                else
                {
                    ResultInfo.MultipathFlag = false;
                    ResultInfo.MultipathNumber = 1;
                    ResultCondition.SetOffset(0, 0, 0, 0, 0);
                }

                //DB 용접조건 반영
                ResultCondition.ApplyWeldDB(WeldDB_Apply, new double[] { NVx, NVy, NVz });



                //컴마로 구분된 "1,2,3" 옵션문자열에 따라 아크센싱 설정. 2:DB와는 상관 없이 아크센싱 사용, 3:DB와는 상관 없이 아크센싱 사용안함, 1 또는 그외:DB조건대로 실행
                string[] tempstrarr2 = AdditionalArcSenInfo.Split(',');
                if (i < tempstrarr2.Length)
                {
                    if (tempstrarr2[i] == "2")
                    {
                        ResultCondition.ArcSen = 3;
                    }
                    else if (tempstrarr2[i] == "3")
                    {
                        ResultCondition.ArcSen = 0;
                    }
                    else
                    {
                        ResultCondition.ArcSen = WeldDB_Apply.ArcSen;
                    }
                }
                else
                {
                    ResultCondition.ArcSen = WeldDB_Apply.ArcSen;
                }


                if (i < tempstrarr1.Length)
                {
                    //아크센싱 설정값 조건 반영. 
                    if ((Position == "3F") && (tempstrarr1[i] == "S1"))
                    {
                        ResultCondition.ArcSenHFactor = HFactor2F;
                        ResultCondition.ArcSenVFactor = VFactor2F;
                        ResultCondition.ArcSenHMaxdL = VMaxdL2F;
                        ResultCondition.ArcSenVMaxdL = VMaxdL2F;
                        ResultCondition.ArcSenHOncedL = HOncedL2F;
                        ResultCondition.ArcSenVOncedL = VOncedL2F;
                        ResultCondition.ArcSenTimeShift = TimeShift2F;
                    }
                    else
                    {
                        ResultCondition.ArcSenHFactor = HFactor;
                        ResultCondition.ArcSenVFactor = VFactor;
                        ResultCondition.ArcSenHMaxdL = VMaxdL;
                        ResultCondition.ArcSenVMaxdL = VMaxdL;
                        ResultCondition.ArcSenHOncedL = HOncedL;
                        ResultCondition.ArcSenVOncedL = VOncedL;
                        ResultCondition.ArcSenTimeShift = TimeShift;
                    }
                }
                else
                {
                    ResultCondition.ArcSenHFactor = HFactor;
                    ResultCondition.ArcSenVFactor = VFactor;
                    ResultCondition.ArcSenHMaxdL = VMaxdL;
                    ResultCondition.ArcSenVMaxdL = VMaxdL;
                    ResultCondition.ArcSenHOncedL = HOncedL;
                    ResultCondition.ArcSenVOncedL = VOncedL;
                    ResultCondition.ArcSenTimeShift = TimeShift;
                }

                ResultInfo.AddMainCondition(ResultCondition);



            }

            ResultInfo.ApplyOffset(StartOffset, EndOffset);

            return 1;
        }


        public int FindCloseRDPIndex(double f1, double f2, double f3, double f4, double f5, double f6)
        {
            double[] initMatrix;
            double dirXx, dirXy, dirXz, rdpXx, rdpXy, rdpXz;
            double dirYx, dirYy, dirYz, rdpYx, rdpYy, rdpYz;
            double dirZx, dirZy, dirZz, rdpZx, rdpZy, rdpZz;
            RobotCommclass.MakeXYZAngleToRMatrix((float)f4, (float)f5, (float)f6, out initMatrix);
            dirXx = initMatrix[0];
            dirXy = initMatrix[3];
            dirXz = initMatrix[6];
            dirYx = initMatrix[1];
            dirYy = initMatrix[4];
            dirYz = initMatrix[7];
            dirZx = initMatrix[2];
            dirZy = initMatrix[5];
            dirZz = initMatrix[8];

            double MinAngle = 180;
            int MinAngleIndex = 0;
            double Range = 30;
            List<int> AllIndex = new List<int>();


            for (int i = 0; i < RDP_TCP.Length; i++)
            {
                RobotCommclass.MakeXYZAngleToRMatrix(RDP_TCP[i].f4, RDP_TCP[i].f5, RDP_TCP[i].f6, out initMatrix);
                rdpXx = initMatrix[0];
                rdpXy = initMatrix[3];
                rdpXz = initMatrix[6];
                rdpYx = initMatrix[1];
                rdpYy = initMatrix[4];
                rdpYz = initMatrix[7];
                rdpZx = initMatrix[2];
                rdpZy = initMatrix[5];
                rdpZz = initMatrix[8];

                //사이각 구함
                double AngleX = (Math.Acos((dirXx * rdpXx + dirXy * rdpXy + dirXz * rdpXz) / ((Math.Sqrt(dirXx * dirXx + dirXy * dirXy + dirXz * dirXz)) * ((Math.Sqrt(rdpXx * rdpXx + rdpXy * rdpXy + rdpXz * rdpXz)))))) * (180 / Math.PI);
                double AngleY = (Math.Acos((dirYx * rdpYx + dirYy * rdpYy + dirYz * rdpYz) / ((Math.Sqrt(dirYx * dirYx + dirYy * dirYy + dirYz * dirYz)) * ((Math.Sqrt(rdpYx * rdpYx + rdpYy * rdpYy + rdpYz * rdpYz)))))) * (180 / Math.PI);
                double AngleZ = (Math.Acos((dirZx * rdpZx + dirZy * rdpZy + dirZz * rdpZz) / ((Math.Sqrt(dirZx * dirZx + dirZy * dirZy + dirZz * dirZz)) * ((Math.Sqrt(rdpZx * rdpZx + rdpZy * rdpZy + rdpZz * rdpZz)))))) * (180 / Math.PI);
                double AngleSum = AngleX + AngleY + AngleZ;

                if (AngleSum < MinAngle)
                {
                    MinAngle = AngleSum;
                    MinAngleIndex = i;
                }
            }

            for (int i = 0; i < RDP_TCP.Length; i++)
            {
                RobotCommclass.MakeXYZAngleToRMatrix(RDP_TCP[i].f4, RDP_TCP[i].f5, RDP_TCP[i].f6, out initMatrix);
                rdpXx = initMatrix[0];
                rdpXy = initMatrix[3];
                rdpXz = initMatrix[6];
                rdpYx = initMatrix[1];
                rdpYy = initMatrix[4];
                rdpYz = initMatrix[7];
                rdpZx = initMatrix[2];
                rdpZy = initMatrix[5];
                rdpZz = initMatrix[8];

                //사이각 구함
                double AngleX = (Math.Acos((dirXx * rdpXx + dirXy * rdpXy + dirXz * rdpXz) / ((Math.Sqrt(dirXx * dirXx + dirXy * dirXy + dirXz * dirXz)) * ((Math.Sqrt(rdpXx * rdpXx + rdpXy * rdpXy + rdpXz * rdpXz)))))) * (180 / Math.PI);
                double AngleY = (Math.Acos((dirYx * rdpYx + dirYy * rdpYy + dirYz * rdpYz) / ((Math.Sqrt(dirYx * dirYx + dirYy * dirYy + dirYz * dirYz)) * ((Math.Sqrt(rdpYx * rdpYx + rdpYy * rdpYy + rdpYz * rdpYz)))))) * (180 / Math.PI);
                double AngleZ = (Math.Acos((dirZx * rdpZx + dirZy * rdpZy + dirZz * rdpZz) / ((Math.Sqrt(dirZx * dirZx + dirZy * dirZy + dirZz * dirZz)) * ((Math.Sqrt(rdpZx * rdpZx + rdpZy * rdpZy + rdpZz * rdpZz)))))) * (180 / Math.PI);
                double AngleSum = AngleX + AngleY + AngleZ;

                if ((AngleSum < (MinAngle + Range)) && (AngleSum > (MinAngle - Range)))
                {
                    AllIndex.Add(i);
                }
            }

            double MinLength = 10000;
            int MinLengthIndex = 0;
            for (int i = 0; i < AllIndex.Count; i++)
            {
                double tempd1 = RDP_TCP[AllIndex[i]].f1 - f1;
                double tempd2 = RDP_TCP[AllIndex[i]].f2 - f2;
                double tempd3 = RDP_TCP[AllIndex[i]].f3 - f3;
                double Length = Math.Sqrt((tempd1 * tempd1) + (tempd2 * tempd2) + (tempd3 * tempd3));

                if (Length < MinLength)
                {
                    MinLength = Length;
                    MinLengthIndex = AllIndex[i];
                }
            }
            return MinLengthIndex;
        }


        void DTDataSave()
        {
            List<string> tempstrlist = new List<string>();
            string tempstr = "";

            tempstr = Convert.ToString(DateTime.Now.Ticks);
            tempstrlist.Add(tempstr);

            for (int i = 0; i < 32; i++)
            {
                tempstr = AutoWeld_DTPoint_Left_JointPose[i].PoseType.ToString();
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].Speed.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].f1.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].f2.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].f3.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].f4.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].f5.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_JointPose[i].f6.ToString("0.00");
                tempstrlist.Add(tempstr);
            }

            for (int i = 0; i < 32; i++)
            {
                tempstr = AutoWeld_DTPoint_Left_TCPPose[i].PoseType.ToString();
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].Speed.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].f1.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].f2.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].f3.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].f4.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].f5.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Left_TCPPose[i].f6.ToString("0.00");
                tempstrlist.Add(tempstr);
            }

            for (int i = 0; i < 32; i++)
            {
                tempstr = AutoWeld_DTPoint_Right_JointPose[i].PoseType.ToString();
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].Speed.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].f1.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].f2.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].f3.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].f4.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].f5.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_JointPose[i].f6.ToString("0.00");
                tempstrlist.Add(tempstr);
            }

            for (int i = 0; i < 32; i++)
            {
                tempstr = AutoWeld_DTPoint_Right_TCPPose[i].PoseType.ToString();
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].Speed.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].f1.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].f2.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].f3.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].f4.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].f5.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_DTPoint_Right_TCPPose[i].f6.ToString("0.00");
                tempstrlist.Add(tempstr);
            }

            string[] tempstrarr = tempstrlist.ToArray();

            File.WriteAllLines(@"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Data\CellLastDTData.txt", tempstrarr);
            MainLog_Add("셀용접 직접교시점 저장 성공");
        }


        void DTDataLoad()
        {

            string[] tempstrarr = File.ReadAllLines(@"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Data\CellLastDTData.txt");

            try
            {
                DateTime SaveTime = new DateTime(Convert.ToInt64(tempstrarr[0]));

                for (int i = 1; i < 33; i++)
                {
                    string[] tempstrarr1 = tempstrarr[i].Split(',');

                    AutoWeld_DTPoint_Left_JointPose[i-1] = new RobotPoseData(Convert.ToInt32(tempstrarr1[0]), Convert.ToDouble(tempstrarr1[1]),
                                                                            Convert.ToDouble(tempstrarr1[2]), Convert.ToDouble(tempstrarr1[3]), Convert.ToDouble(tempstrarr1[4]),
                                                                            Convert.ToDouble(tempstrarr1[5]), Convert.ToDouble(tempstrarr1[6]), Convert.ToDouble(tempstrarr1[7]));
                }
                for (int i = 33; i < 65; i++)
                {
                    string[] tempstrarr1 = tempstrarr[i].Split(',');

                    AutoWeld_DTPoint_Left_TCPPose[i-33] = new RobotPoseData(Convert.ToInt32(tempstrarr1[0]), Convert.ToDouble(tempstrarr1[1]),
                                                                            Convert.ToDouble(tempstrarr1[2]), Convert.ToDouble(tempstrarr1[3]), Convert.ToDouble(tempstrarr1[4]),
                                                                            Convert.ToDouble(tempstrarr1[5]), Convert.ToDouble(tempstrarr1[6]), Convert.ToDouble(tempstrarr1[7]));
                }
                for (int i = 65; i < 97; i++)
                {
                    string[] tempstrarr1 = tempstrarr[i].Split(',');

                    AutoWeld_DTPoint_Right_JointPose[i-65] = new RobotPoseData(Convert.ToInt32(tempstrarr1[0]), Convert.ToDouble(tempstrarr1[1]),
                                                                            Convert.ToDouble(tempstrarr1[2]), Convert.ToDouble(tempstrarr1[3]), Convert.ToDouble(tempstrarr1[4]),
                                                                            Convert.ToDouble(tempstrarr1[5]), Convert.ToDouble(tempstrarr1[6]), Convert.ToDouble(tempstrarr1[7]));
                }
                for (int i = 97; i < 129; i++)
                {
                    string[] tempstrarr1 = tempstrarr[i].Split(',');

                    AutoWeld_DTPoint_Right_TCPPose[i-97] = new RobotPoseData(Convert.ToInt32(tempstrarr1[0]), Convert.ToDouble(tempstrarr1[1]),
                                                                            Convert.ToDouble(tempstrarr1[2]), Convert.ToDouble(tempstrarr1[3]), Convert.ToDouble(tempstrarr1[4]),
                                                                            Convert.ToDouble(tempstrarr1[5]), Convert.ToDouble(tempstrarr1[6]), Convert.ToDouble(tempstrarr1[7]));
                }

                MainLog_Add("셀용접 직접교시점 불러오기 성공");
            }
            catch
            {
                MainLog_Add("셀용접 직접교시점 불러오기 실패");
            }


        }


        void TouchDataSave()
        {
            List<string> tempstrlist = new List<string>();
            string tempstr = "";

            tempstr = Convert.ToString(DateTime.Now.Ticks);
            tempstrlist.Add(tempstr);

            for (int i = 0; i < 32; i++)
            {
                tempstr = AutoWeld_WedlPoint_Left[i].PoseType.ToString();
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].Speed.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].f1.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].f2.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].f3.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].f4.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].f5.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Left[i].f6.ToString("0.00");
                tempstrlist.Add(tempstr);
            }

            for (int i = 0; i < 32; i++)
            {
                tempstr = AutoWeld_WedlPoint_Right[i].PoseType.ToString();
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].Speed.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].f1.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].f2.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].f3.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].f4.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].f5.ToString("0.00");
                tempstr = tempstr + "," + AutoWeld_WedlPoint_Right[i].f6.ToString("0.00");
                tempstrlist.Add(tempstr);
            }


            string[] tempstrarr = tempstrlist.ToArray();

            File.WriteAllLines(@"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Data\CellLastTouchData.txt", tempstrarr);
            MainLog_Add("셀용접 터치센싱결과 저장 성공");

        }


        void TouchDataLoad()
        {

            string[] tempstrarr = File.ReadAllLines(@"C:\HHIAutomation\OpenBlockWeldingRobot_Server\Data\CellLastTouchData.txt");

            try
            {
                DateTime SaveTime = new DateTime(Convert.ToInt64(tempstrarr[0]));

                for (int i = 1; i < 33; i++)
                {
                    string[] tempstrarr1 = tempstrarr[i].Split(',');

                    AutoWeld_WedlPoint_Left[i-1] = new RobotPoseData(Convert.ToInt32(tempstrarr1[0]), Convert.ToDouble(tempstrarr1[1]),
                                                                            Convert.ToDouble(tempstrarr1[2]), Convert.ToDouble(tempstrarr1[3]), Convert.ToDouble(tempstrarr1[4]),
                                                                            Convert.ToDouble(tempstrarr1[5]), Convert.ToDouble(tempstrarr1[6]), Convert.ToDouble(tempstrarr1[7]));
                }
                for (int i = 33; i < 65; i++)
                {
                    string[] tempstrarr1 = tempstrarr[i].Split(',');

                    AutoWeld_WedlPoint_Right[i-33] = new RobotPoseData(Convert.ToInt32(tempstrarr1[0]), Convert.ToDouble(tempstrarr1[1]),
                                                                            Convert.ToDouble(tempstrarr1[2]), Convert.ToDouble(tempstrarr1[3]), Convert.ToDouble(tempstrarr1[4]),
                                                                            Convert.ToDouble(tempstrarr1[5]), Convert.ToDouble(tempstrarr1[6]), Convert.ToDouble(tempstrarr1[7]));
                }

                MainLog_Add("셀용접 터치결과 불러오기 성공");
            }
            catch
            {
                MainLog_Add("셀용접 터치결과 불러오기 실패");
            }


        }


        /// <summary>
        /// 자동용접리스트의 count번째 용접선이 다층용접(1패스 제외, 2패스 이상을 말함)이며 초층에 아크센싱을 사용했는지 판단하는 함수
        /// </summary>
        /// <param name="count">자동용접리스트 번호</param>
        /// <returns></returns>
        bool MultipathAndArcSensingCheck(List<WeldInformation> WInfoList, int count)
        {
            if (WInfoList[count].MultipathNumber > 1)
            {
                int initPathCount = count - (WInfoList[count].MultipathNumber - 1);
                if (initPathCount >= 0)
                {
                    int mainconcount = WInfoList[initPathCount].GetMainConditionCount();
                    bool arcsenflag = false;
                    for (int i = 0; i < mainconcount; i++) if (WInfoList[initPathCount].GetMainCondition(i).ArcSen > 0) arcsenflag = true;
                    if (arcsenflag == true)
                    {//메인 용접리스트중 하나라도 아크센싱 사용하면 true 리턴
                        return true;
                    }
                    else
                    {//전부 아크센싱 사용 안하면 false 리턴
                        return false;
                    }
                }
                else
                {//초층 카운트가 맞지 않으면 false 리턴
                    return false;
                }
            }
            else
            {//멀티패스가 아니면 false 리턴
                return false;
            }
        }


        WeldInformation MakeArcSensingMultiPath(List<WeldInformation> WInfoList, List<List<ActualWeldingPathRecord>> WRecord, int count)
        {
            WeldMainCondition tempmaincondition;
            WeldInformation welddata = (WeldInformation)WInfoList[count].Clone();
            welddata.ClearMainCondition();

            int initPathCount = count - (WInfoList[count].MultipathNumber - 1);
            double offsetStart = (WInfoList[count].MultipathNumber - 1) * 5;
            double offsetEnd = (WInfoList[count].MultipathNumber - 1) * 5;

            for (int i = 0; i < WInfoList[count].GetMainConditionCount(); i++)
            {
                //대략적인 용접거리 계산
                double dirX, dirY, dirZ, weldlength;
                RobotCommclass.RobotStartEndToDirCal(WInfoList[count].GetMainCondition(i).GetStartPose(),
                                                        WInfoList[count].GetMainCondition(i).GetEndPose(),
                                                        out dirX, out dirY, out dirZ, out weldlength);

                if (weldlength < 140)
                {//용접거리가 300mm 이내라면 중간경유점 만들지 않고 한번에 생성
                    tempmaincondition = WInfoList[count].GetMainCondition(i);

                    tempmaincondition.SetStartPose((RobotPoseData)WRecord[initPathCount][i].StartPose.Clone());
                    tempmaincondition.SetEndPose((RobotPoseData)WRecord[initPathCount][i].EndPose.Clone());
                    tempmaincondition.ApplyOffset(tempmaincondition.Offset, tempmaincondition.NormalV);

                    welddata.AddMainCondition(tempmaincondition);
                }
                else
                {//용접거리가 300mm 이상이라면 약 200mm씩 끊어서 이동함
                    int divcount = (int)(weldlength / 100);
                    int pathcount = WRecord[initPathCount][i].MidPath.Count / (divcount + 1);

                    tempmaincondition = WInfoList[count].GetMainCondition(i);
                    
                    tempmaincondition.SetStartPose((RobotPoseData)WRecord[initPathCount][i].StartPose.Clone());
                    tempmaincondition.SetEndPose((RobotPoseData)WRecord[initPathCount][i].MidPath[pathcount].WeavingMiddlePosition.Clone());
                    tempmaincondition.ApplyOffset(tempmaincondition.Offset, tempmaincondition.NormalV); // 주익찬 추가 - 오프셋 반영

                    welddata.AddMainCondition(tempmaincondition);

                    for (int j = 1; j < divcount; j++)
                    {
                        tempmaincondition.SetStartPose((RobotPoseData)WRecord[initPathCount][i].MidPath[pathcount * j].WeavingMiddlePosition.Clone());
                        tempmaincondition.SetEndPose((RobotPoseData)WRecord[initPathCount][i].MidPath[pathcount * (j + 1)].WeavingMiddlePosition.Clone());
                        tempmaincondition.ApplyOffset(tempmaincondition.Offset, tempmaincondition.NormalV); // 주익찬 추가 - 오프셋 반영
                        welddata.AddMainCondition(tempmaincondition);
                    }
                    
                    tempmaincondition.SetStartPose((RobotPoseData)WRecord[initPathCount][i].MidPath[pathcount * divcount].WeavingMiddlePosition.Clone()); // 주익찬 수정 - divcount -1 ==> divcount : 경로 중복 문제 해결
                    tempmaincondition.SetEndPose((RobotPoseData)WRecord[initPathCount][i].EndPose.Clone());
                    tempmaincondition.ApplyOffset(tempmaincondition.Offset, tempmaincondition.NormalV); // 주익찬 추가 - 오프셋 반영
                    welddata.AddMainCondition(tempmaincondition);
                }
            }

            return welddata;
        }



        void AutoWeldCalcInfo_Total()
        {
            double temp1 = 0, temp2 = 0;

            AutoWeldSub_TotalLineCount = AutoWeld_WeldInformationList.Count;

            foreach(WeldInformation wi in AutoWeld_WeldInformationList)
            {
                temp1 = temp1 + wi.CalcWeldLength();
                temp2 = temp2 + wi.CalcWeldTime();
            }

            AutoWeldSub_TotalLineLength = temp1;
            AutoWeldSub_TotalWeldTime = temp2;
        }


        void AutoWeldCalcInfo_Left()
        {
            if (AutoWeldCount - 1 >= 0)
            {
                AutoWeldSub_NowLineCount = AutoWeldCount;

                double temp1 = 0, temp2 = 0, temp3 = 0, temp4 = 0;

                for (int i = AutoWeldCount; i < AutoWeld_WeldInformationList.Count; i++)
                {
                    temp1 = temp1 + AutoWeld_WeldInformationList[i].CalcWeldLength();
                    temp2 = temp2 + AutoWeld_WeldInformationList[i].CalcWeldTime();
                }

                temp3 = AutoWeld_WeldInformationList[AutoWeldCount - 1].CalcWeldLength();
                temp4 = AutoWeld_WeldInformationList[AutoWeldCount - 1].CalcWeldTime();


                if (RobotCommclass.RobotControlThreadSeq < 112)
                {
                    AutoWeldSub_LeftNowLineLength = temp3;
                    AutoWeldSub_LeftNowWeldTime = temp4;
                    AutoWeldSub_LeftTotalLineLength = temp1 + temp3;
                    AutoWeldSub_LeftTotalWeldTime = temp2 + temp4;
                }
                else if (RobotCommclass.RobotControlThreadSeq < 115)
                {
                    int nowweldcount = AutoWeld_WeldInformationList[AutoWeldCount - 1].GetMainConditionCount();

                    double d1 = AutoWeld_WeldInformationList[AutoWeldCount - 1].GetMainCondition(nowweldcount - 1).GetEndPose().f1 - RobotDataEX.moni_RobotTCPActualPose[0];
                    double d2 = AutoWeld_WeldInformationList[AutoWeldCount - 1].GetMainCondition(nowweldcount - 1).GetEndPose().f2 - RobotDataEX.moni_RobotTCPActualPose[1];
                    double d3 = AutoWeld_WeldInformationList[AutoWeldCount - 1].GetMainCondition(nowweldcount - 1).GetEndPose().f3 - RobotDataEX.moni_RobotTCPActualPose[2];
                    double d4 = Math.Sqrt(d1 * d1 + d2 * d2 + d3 * d3);

                    temp4 = temp4 * (d4 / temp3);
                    temp3 = d4;

                    AutoWeldSub_LeftNowLineLength = temp3;
                    AutoWeldSub_LeftNowWeldTime = temp4;
                    AutoWeldSub_LeftTotalLineLength = temp1 + temp3;
                    AutoWeldSub_LeftTotalWeldTime = temp2 + temp4;
                }
                else
                {
                    AutoWeldSub_LeftNowLineLength = 0;
                    AutoWeldSub_LeftNowWeldTime = 0;
                    AutoWeldSub_LeftTotalLineLength = temp1;
                    AutoWeldSub_LeftTotalWeldTime = temp2;
                }
            }
            else
            {
                AutoWeldSub_NowLineCount = 0;
                AutoWeldSub_LeftNowLineLength = 0;
                AutoWeldSub_LeftNowWeldTime = 0;
                AutoWeldSub_LeftTotalLineLength = 0;
                AutoWeldSub_LeftTotalWeldTime = 0;
            }
            
        }

    }
}
