﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenBlockWeldingRobot
{
    class WeldStartCondition : ICloneable
    {
        public double GasPreTime = 0;
        public double WeldStartTime = 0;
        public double WeldStartVol = 0;
        public double WeldStartAmp = 0;
        List<RobotPoseData> StartPosition = new List<RobotPoseData>();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldStartCondition()
        {

        }
        /// <summary>
        /// 초기가스시간, 초기아크시간, 초기아크전압, 초기아크전류 설정해주는 생성자
        /// </summary>
        /// <param name="gas">초기가스시간</param>
        /// <param name="startt">초기아크시간</param>
        /// <param name="startv">초기아크전압</param>
        /// <param name="starta">초기아크전류</param>
        public WeldStartCondition(double gas, double startt, double startv, double starta)
        {
            GasPreTime = gas;
            WeldStartTime = startt;
            WeldStartVol = startv;
            WeldStartAmp = starta;
            StartPosition = new List<RobotPoseData>();
        }


        /// <summary>
        /// 시작경로 리스트에 경로 추가하는 함수
        /// </summary>
        /// <param name="RobotPose">추가할 로봇 포즈</param>
        public void AddStartPosition(RobotPoseData RobotPose)
        {
            StartPosition.Add((RobotPoseData)RobotPose.Clone());
        }

        /// <summary>
        /// 시작경로 리스트에서 index번째 객체 복사해오는 함수
        /// </summary>
        /// <param name="index">복사해올 객체 인덱스</param>
        /// <returns>인덱스가 유효하면 로봇포즈 복사본 리턴, 유효하지 않으면 NULL 리턴</returns>
        public RobotPoseData GetStartPosition(int index)
        {
            if ((index >= 0) && (index < StartPosition.Count))
            {
                return (RobotPoseData)(StartPosition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 시작경로 리스트 개수 반환
        /// </summary>
        /// <returns>시작경로 리스트 개수</returns>
        public int GetStartPositionCount()
        {
            return StartPosition.Count;
        }

        /// <summary>
        /// 시작경로 리스트 초기화하는 함수
        /// </summary>
        public void ClearStartPosition()
        {
            StartPosition = new List<RobotPoseData>();
        }

        public object Clone()
        {
            WeldStartCondition tempdata = new WeldStartCondition();

            tempdata.GasPreTime = this.GasPreTime;
            tempdata.WeldStartTime = this.WeldStartTime;
            tempdata.WeldStartVol = this.WeldStartVol;
            tempdata.WeldStartAmp = this.WeldStartAmp;

            for (int i = 0; i < this.StartPosition.Count; i++)
            {
                tempdata.StartPosition.Add(this.StartPosition[i]);
            }

            return tempdata;
        }
    }

    class WeldMainCondition : ICloneable
    {
        public int PathType = 1; //1:선형 2:원호
        RobotPoseData PathStartPosition = new RobotPoseData();
        RobotPoseData PathMidPosition = new RobotPoseData();
        RobotPoseData PathEndPosition = new RobotPoseData();

        public double WelVol = 0;
        public double WeldAmp = 0;
        public double WeldSpd = 0;

        public int Weaving = 0; //0:위빙안함 1:지그재그 2:사인파
        public double WeavHz = 0;
        public double WeavLength = 0;
        public double WeavLeftStopTime = 0;
        public double WeavRightStopTime = 0;

        public int ArcSen = 0; //0:아크센싱안함 1:좌우센싱만함 2:상하센싱만함 3:둘다함
        public double ArcSenTimeShift = 0;
        public double ArcSenHFactor = 0;
        public double ArcSenVFactor = 0;
        public double ArcSenHMaxdL = 0;
        public double ArcSenVMaxdL = 0;
        public double ArcSenHOncedL = 0;
        public double ArcSenVOncedL = 0;
        public double ArcSenWeightedFactorRight = 0;
        public double ArcSenWeightedFactorLeft = 0;

        //다층용접일때 초층대비 쉬프트량 저장. 초층 아크센싱후 초층대비 경로보정 위해
        //배열 순서는 x, y, z, 작업각, 진행각
        public double[] Offset = new double[] { 0, 0, 0, 0, 0 };
        //public double[] OffsetM = new double[] { 0, 0, 0, 0, 0 };
        //public double[] OffsetE = new double[] { 0, 0, 0, 0, 0 };
        public double[] NormalV = new double[] { 0, 0, 0 };


        /// <summary>
        /// 로봇 모션 시작점 지정하는 함수
        /// </summary>
        /// <param name="temppose">시작점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetStartPose(RobotPoseData temppose) { PathStartPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 중간점 지정하는 함수
        /// </summary>
        /// <param name="temppose">중간점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetMidPose(RobotPoseData temppose) { PathMidPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 종료점 지정하는 함수
        /// </summary>
        /// <param name="temppose">종료점 정보 담긴 로봇포즈객체(TCP데이터)(</param>
        public void SetEndPose(RobotPoseData temppose) { PathEndPosition = (RobotPoseData)(temppose.Clone()); }
        /// <summary>
        /// 로봇 모션 시작포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 시작포즈객체 복사본</returns>
        public RobotPoseData GetStartPose() { return (RobotPoseData)(this.PathStartPosition.Clone()); }
        /// <summary>
        /// 로봇 모션 중간포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 중간포즈객체 복사본</returns>
        public RobotPoseData GetMidPose() { return (RobotPoseData)(this.PathMidPosition.Clone()); }
        /// <summary>
        /// 로봇 모션 종료포즈객체 복사해오는 함수
        /// </summary>
        /// <returns>로봇 종료포즈객체 복사본</returns>
        public RobotPoseData GetEndPose() { return (RobotPoseData)(this.PathEndPosition.Clone()); }

        /// <summary>
        /// 보간방식, 시작, 중간, 종료점 동시에 설정하는 함수
        /// </summary>
        /// <param name="type">보간방식 1:선형, 2:원호</param>
        /// <param name="Start">시작점</param>
        /// <param name="Mid">중간점</param>
        /// <param name="End">종료점</param>
        public void SetPath(int type, RobotPoseData Start, RobotPoseData Mid, RobotPoseData End)
        {
            PathType = type;
            SetStartPose(Start);
            SetMidPose(Mid);
            SetEndPose(End);
        }


        //오프셋 한번에 입력하는 함수
        public void SetOffset(double x, double y, double z, double WAngle, double TAngle)
        {
            Offset[0] = x;
            Offset[1] = y;
            Offset[2] = z;
            Offset[3] = WAngle;
            Offset[4] = TAngle;
        }

        /*
        public void SetOffsetM(double x, double y, double z, double WAngle, double TAngle)
        {
            OffsetM[0] = x;
            OffsetM[1] = y;
            OffsetM[2] = z;
            OffsetM[3] = WAngle;
            OffsetM[4] = TAngle;
        }
        public void SetOffsetE(double x, double y, double z, double WAngle, double TAngle)
        {
            OffsetE[0] = x;
            OffsetE[1] = y;
            OffsetE[2] = z;
            OffsetE[3] = WAngle;
            OffsetE[4] = TAngle;
        }
         */

        /// <summary>
        /// 보간방식, 전압, 전류, 속도 동시에 설정하는 함수
        /// </summary>
        /// <param name="type">보간방식 1:선형, 2:원호</param>
        /// <param name="vol">용접전압</param>
        /// <param name="amp">용접전류</param>
        /// <param name="speed">속도</param>
        public void WeldSetting(int type, double vol, double amp, double speed)
        {
            PathType = type;
            WelVol = vol;
            WeldAmp = amp;
            WeldSpd = speed;
        }

        /// <summary>
        /// 위빙관련 데이터 동시에 설정하는 함수
        /// </summary>
        /// <param name="onoff">위빙여부, 0:위빙안함, 1:지그재그위빙, 2:사인파위빙</param>
        /// <param name="Hz">위빙 주파수</param>
        /// <param name="Length">위빙 폭</param>
        /// <param name="LeftStopTime">좌멈춤시간</param>
        /// <param name="RightStopTime">우멈춤시간</param>
        public void WeavingSetting(int onoff, double Hz, double Length, double LeftStopTime, double RightStopTime)
        {
            Weaving = onoff;
            WeavHz = Hz;
            WeavLength = Length;
            WeavLeftStopTime = LeftStopTime;
            WeavRightStopTime = RightStopTime;
        }

        /// <summary>
        /// 아크센싱 관련 데이터 동시에 설정하는 함수
        /// </summary>
        /// <param name="onoff">0:아크센싱안함 1:좌우센싱만함 2:상하센싱만함 3:좌우,상하 전부함</param>
        /// <param name="TimeShift">센서 지연시간</param>
        /// <param name="HFactor">좌우센싱계수</param>
        /// <param name="VFactor">상하센싱계수</param>
        /// <param name="HMaxdL">좌우 최대보정량 한계값</param>
        /// <param name="VMaxdL">상하 최대보정량 한계값</param>
        /// <param name="HOncedL">좌우 1회보정량 한계값</param>
        /// <param name="VOncedL">상하 1회보정량 한계값</param>
        /// <param name="WeightedFactorRight">우외빙 센서값 가중치</param>
        /// <param name="WeightedFactorLeft">좌위빙 센서값 가중치</param>
        public void ArcSenSetting(int onoff, double TimeShift, double HFactor, double VFactor, double HMaxdL, double VMaxdL, double HOncedL, double VOncedL, double WeightedFactorRight, double WeightedFactorLeft)
        {
            ArcSen = onoff;
            ArcSenTimeShift = TimeShift;
            ArcSenHFactor = HFactor;
            ArcSenVFactor = VFactor;
            ArcSenHMaxdL = HMaxdL;
            ArcSenVMaxdL = VMaxdL;
            ArcSenHOncedL = HOncedL;
            ArcSenVOncedL = VOncedL;
            ArcSenWeightedFactorRight = WeightedFactorRight;
            ArcSenWeightedFactorLeft = WeightedFactorLeft;
        }



        //x,y,z,작업각,진행각 오프셋 적용하는 함수
        public void ApplyOffset(double[] Offset, double[] Nor)
        {
            HCRRobotCommunication RobotCalc = new HCRRobotCommunication();

            if(PathType == 1)
            {
                //직선용접일때 다층용접 오프셋 적용
                //오프셋 방향 기준은 입력된 법선벡터 방향과 용접방향으로 계산됨
                //z축은 법선벡터 방향. x축은 용접방향과 법선벡터방향 외적한 방향
                //작업각은 용접 방향으로 회전, 진행각은 용접방향과 토치방향 외적해서 나오는 방향으로 회전


                //용접 방향벡터 계산. x y z (작업각 회전축)
                double[] WeldDir = new double[] { PathEndPosition.f1 - PathStartPosition.f1, PathEndPosition.f2 - PathStartPosition.f2, PathEndPosition.f3 - PathStartPosition.f3 };

                //시작, 중간, 종료점 각각의 로봇 툴방향 계산 (회전할 벡터)
                double[] initMatrix;
                RobotCalc.MakeXYZAngleToRMatrix(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, out initMatrix);
                double[] ToolDirS = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };
                RobotCalc.MakeXYZAngleToRMatrix(PathMidPosition.f4, PathMidPosition.f5, PathMidPosition.f6, out initMatrix);
                double[] ToolDirM = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };
                RobotCalc.MakeXYZAngleToRMatrix(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, out initMatrix);
                double[] ToolDirE = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };

                //용접방향과 각각 위치에서의 툴방향 외적 (진행각 회전축)
                double[] CrossS, CrossM, CrossE;
                RobotCalc.NormalVectorCalculation(WeldDir, ToolDirS, out CrossS);
                RobotCalc.NormalVectorCalculation(WeldDir, ToolDirM, out CrossM);
                RobotCalc.NormalVectorCalculation(WeldDir, ToolDirE, out CrossE);

                


                //작업각, 진행각, XYZ오프셋 적용
                //작업평면 노말백터와 툴방향벡터 내적해서 양수가 나오면 노말벡터*-1함. 이게 오프셋 z축이 됨
                //위에서 구한 노말벡터와 용접방향벡터 외적해서 나오는 벡터를 다시 툴방향벡터와 내적함. 이 값이 양수일때 *-1함. 이게 오프셋 x축
                //y축은 적용안함 무시
                double[] OffsetDirX, OffsetDirZ;
                if (ToolDirS[0] * Nor[0] + ToolDirS[1] * Nor[1] + ToolDirS[2] * Nor[2] > 0)
                {
                    RobotCalc.UnitVector(new double[] { -Nor[0], -Nor[1], -Nor[2] }, out OffsetDirZ);
                }
                else
                {
                    RobotCalc.UnitVector(new double[] { Nor[0], Nor[1], Nor[2] }, out OffsetDirZ);
                }

                RobotCalc.NormalVectorCalculation(OffsetDirZ, WeldDir, out OffsetDirX);
                if (ToolDirS[0] * OffsetDirX[0] + ToolDirS[1] * OffsetDirX[1] + ToolDirS[2] * OffsetDirX[2] > 0)
                {
                    OffsetDirX[0] = -OffsetDirX[0]; OffsetDirX[1] = -OffsetDirX[1]; OffsetDirX[2] = -OffsetDirX[2];
                }


                //x,y,z 오프셋 반영
                PathStartPosition.f1 = (float)(PathStartPosition.f1 + Offset[0] * OffsetDirX[0] + Offset[2] * OffsetDirZ[0]);
                PathStartPosition.f2 = (float)(PathStartPosition.f2 + Offset[0] * OffsetDirX[1] + Offset[2] * OffsetDirZ[1]);
                PathStartPosition.f3 = (float)(PathStartPosition.f3 + Offset[0] * OffsetDirX[2] + Offset[2] * OffsetDirZ[2]);

                PathMidPosition.f1 = (float)(PathMidPosition.f1 + Offset[0] * OffsetDirX[0] + Offset[2] * OffsetDirZ[0]);
                PathMidPosition.f2 = (float)(PathMidPosition.f2 + Offset[0] * OffsetDirX[1] + Offset[2] * OffsetDirZ[1]);
                PathMidPosition.f3 = (float)(PathMidPosition.f3 + Offset[0] * OffsetDirX[2] + Offset[2] * OffsetDirZ[2]);

                PathEndPosition.f1 = (float)(PathEndPosition.f1 + Offset[0] * OffsetDirX[0] + Offset[2] * OffsetDirZ[0]);
                PathEndPosition.f2 = (float)(PathEndPosition.f2 + Offset[0] * OffsetDirX[1] + Offset[2] * OffsetDirZ[1]);
                PathEndPosition.f3 = (float)(PathEndPosition.f3 + Offset[0] * OffsetDirX[2] + Offset[2] * OffsetDirZ[2]);



                //작업각 진행각 오프셋 계산

                //바닥방향(작업각 +일때 기울일 방향)이 왼쪽인지 오른쪽인지 판단해야 함
                //토치방향벡터X바닥평면 노말벡터 결과벡터가 용접방향과 예각이면 오른쪽이 바닥. 둔각이면 왼쪽이 바닥임
                double[] tempV1;
                RobotCalc.NormalVectorCalculation(ToolDirS, OffsetDirZ, out tempV1);
                float RRx, RRy, RRz;
                if((WeldDir[0]*tempV1[0]+WeldDir[1]*tempV1[1]+WeldDir[2]*tempV1[2])<0)
                {
                    //왼쪽이 바닥일 경우 작업각 부호 반대로 적용
                    RobotCalc.RobotBaseRotation(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, (float)WeldDir[0], (float)WeldDir[1], (float)WeldDir[2], -(float)Offset[3], out RRx, out RRy, out RRz);
                    PathStartPosition.f4 = RRx; PathStartPosition.f5 = RRy; PathStartPosition.f6 = RRz;

                    RobotCalc.RobotBaseRotation(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, (float)WeldDir[0], (float)WeldDir[1], (float)WeldDir[2], -(float)Offset[3], out RRx, out RRy, out RRz);
                    PathEndPosition.f4 = RRx; PathEndPosition.f5 = RRy; PathEndPosition.f6 = RRz;
                }
                else
                {
                    //오른쪽이 바닥일 경우 작업각 그대로 반영
                    RobotCalc.RobotBaseRotation(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, (float)WeldDir[0], (float)WeldDir[1], (float)WeldDir[2], (float)Offset[3], out RRx, out RRy, out RRz);
                    PathStartPosition.f4 = RRx; PathStartPosition.f5 = RRy; PathStartPosition.f6 = RRz;

                    RobotCalc.RobotBaseRotation(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, (float)WeldDir[0], (float)WeldDir[1], (float)WeldDir[2], (float)Offset[3], out RRx, out RRy, out RRz);
                    PathEndPosition.f4 = RRx; PathEndPosition.f5 = RRy; PathEndPosition.f6 = RRz;
                }

                //진행각 반영
                RobotCalc.RobotBaseRotation(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, (float)CrossS[0], (float)CrossS[1], (float)CrossS[2], (float)Offset[4], out RRx, out RRy, out RRz);
                PathStartPosition.f4 = RRx; PathStartPosition.f5 = RRy; PathStartPosition.f6 = RRz;

                RobotCalc.RobotBaseRotation(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, (float)CrossE[0], (float)CrossE[1], (float)CrossE[2], (float)Offset[4], out RRx, out RRy, out RRz);
                PathEndPosition.f4 = RRx; PathEndPosition.f5 = RRy; PathEndPosition.f6 = RRz;


            }
            else if (PathType == 2)
            {
                //원호 용접인 경우 원호 중심 계산해서 오프셋 반영함

                //세 점의 원호 중심 구함
                double[] midpoint;
                RobotCalc.CalcCircleCenter(new double[] { PathStartPosition.f1, PathStartPosition.f2, PathStartPosition.f3 },
                                           new double[] { PathMidPosition.f1, PathMidPosition.f2, PathMidPosition.f3 },
                                           new double[] { PathEndPosition.f1, PathEndPosition.f2, PathEndPosition.f3 }, out midpoint);

                //원의 반지름 구함
                double r = Math.Sqrt((PathStartPosition.f1 - midpoint[0]) * (PathStartPosition.f1 - midpoint[0]) +
                                     (PathStartPosition.f2 - midpoint[1]) * (PathStartPosition.f2 - midpoint[1]) +
                                     (PathStartPosition.f3 - midpoint[2]) * (PathStartPosition.f3 - midpoint[2]));

                //원호 중심에서 시작,중간,종료점까지의 벡터 구함
                double[] V_S, V_M, V_E;
                RobotCalc.UnitVector(new double[] { PathStartPosition.f1 - midpoint[0], PathStartPosition.f2 - midpoint[1], PathStartPosition.f3 - midpoint[2] }, out V_S);
                RobotCalc.UnitVector(new double[] { PathMidPosition.f1 - midpoint[0], PathMidPosition.f2 - midpoint[1], PathMidPosition.f3 - midpoint[2] }, out V_M);
                RobotCalc.UnitVector(new double[] { PathEndPosition.f1 - midpoint[0], PathEndPosition.f2 - midpoint[1], PathEndPosition.f3 - midpoint[2] }, out V_E);

                //중심에서 시작점 종료점벡터 외적해서 회전축 벡터 만듬
                double[] CircCenter;
                RobotCalc.NormalVectorCalculation(V_S, V_E, out CircCenter);

                //회전축 벡터와 각 경로벡터 외적해서 해당 위치에서의 용접방향(원호의 접선벡터)계산
                double[] WeldDirS, WeldDirM, WeldDirE;
                RobotCalc.NormalVectorCalculation(CircCenter, V_S, out WeldDirS);
                RobotCalc.NormalVectorCalculation(CircCenter, V_M, out WeldDirM);
                RobotCalc.NormalVectorCalculation(CircCenter, V_E, out WeldDirE);


                //x y z 이동오프셋 적용. y는 무시함. x는 V_S, V_M, V_E방향, z는 CircCenter방향
                PathStartPosition.f1 = (float)(PathStartPosition.f1 + Offset[0] * V_S[0] + Offset[2] * CircCenter[0]);
                PathStartPosition.f2 = (float)(PathStartPosition.f2 + Offset[0] * V_S[1] + Offset[2] * CircCenter[1]);
                PathStartPosition.f3 = (float)(PathStartPosition.f3 + Offset[0] * V_S[2] + Offset[2] * CircCenter[2]);

                PathMidPosition.f1 = (float)(PathMidPosition.f1 + Offset[0] * V_M[0] + Offset[2] * CircCenter[0]);
                PathMidPosition.f2 = (float)(PathMidPosition.f2 + Offset[1] * V_M[1] + Offset[2] * CircCenter[1]);
                PathMidPosition.f3 = (float)(PathMidPosition.f3 + Offset[2] * V_M[2] + Offset[2] * CircCenter[2]);

                PathEndPosition.f1 = (float)(PathEndPosition.f1 + Offset[0] * V_E[0] + Offset[2] * CircCenter[0]);
                PathEndPosition.f2 = (float)(PathEndPosition.f2 + Offset[1] * V_E[1] + Offset[2] * CircCenter[1]);
                PathEndPosition.f3 = (float)(PathEndPosition.f3 + Offset[2] * V_E[2] + Offset[2] * CircCenter[2]);


                //회전오프셋 적용. 원호의 경우 입력된 노말벡터 무시하고 원호 중심 회전축을 노말벡터로 사용함

                //시작, 중간, 종료점 각각의 로봇 툴방향 계산 (회전할 벡터)
                double[] initMatrix;
                RobotCalc.MakeXYZAngleToRMatrix(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, out initMatrix);
                double[] ToolDirS = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };
                RobotCalc.MakeXYZAngleToRMatrix(PathMidPosition.f4, PathMidPosition.f5, PathMidPosition.f6, out initMatrix);
                double[] ToolDirM = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };
                RobotCalc.MakeXYZAngleToRMatrix(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, out initMatrix);
                double[] ToolDirE = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };

                //용접방향과 각각 위치에서의 툴방향 외적 (진행각 회전축)
                double[] CrossS, CrossM, CrossE;
                RobotCalc.NormalVectorCalculation(WeldDirS, ToolDirS, out CrossS);
                RobotCalc.NormalVectorCalculation(WeldDirM, ToolDirM, out CrossM);
                RobotCalc.NormalVectorCalculation(WeldDirE, ToolDirE, out CrossE);


                //바닥방향(작업각 +일때 기울일 방향)이 왼쪽인지 오른쪽인지 판단해야 함
                //토치방향벡터X바닥평면 노말벡터 결과벡터가 용접방향과 예각이면 오른쪽이 바닥. 둔각이면 왼쪽이 바닥임
                double[] tempV1;
                RobotCalc.NormalVectorCalculation(ToolDirS, CircCenter, out tempV1);
                float RRx, RRy, RRz;
                if ((WeldDirS[0] * tempV1[0] + WeldDirS[1] * tempV1[1] + WeldDirS[2] * tempV1[2]) < 0)
                {
                    //왼쪽이 바닥일 경우 작업각 부호 반대로 적용
                    RobotCalc.RobotBaseRotation(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, (float)WeldDirS[0], (float)WeldDirS[1], (float)WeldDirS[2], -(float)Offset[3], out RRx, out RRy, out RRz);
                    PathStartPosition.f4 = RRx; PathStartPosition.f5 = RRy; PathStartPosition.f6 = RRz;

                    RobotCalc.RobotBaseRotation(PathMidPosition.f4, PathMidPosition.f5, PathMidPosition.f6, (float)WeldDirM[0], (float)WeldDirM[1], (float)WeldDirM[2], -(float)Offset[3], out RRx, out RRy, out RRz);
                    PathMidPosition.f4 = RRx; PathMidPosition.f5 = RRy; PathMidPosition.f6 = RRz;

                    RobotCalc.RobotBaseRotation(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, (float)WeldDirE[0], (float)WeldDirE[1], (float)WeldDirE[2], -(float)Offset[3], out RRx, out RRy, out RRz);
                    PathEndPosition.f4 = RRx; PathEndPosition.f5 = RRy; PathEndPosition.f6 = RRz;
                }
                else
                {
                    //오른쪽이 바닥일 경우 작업각 그대로 반영
                    RobotCalc.RobotBaseRotation(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, (float)WeldDirS[0], (float)WeldDirS[1], (float)WeldDirS[2], (float)Offset[3], out RRx, out RRy, out RRz);
                    PathStartPosition.f4 = RRx; PathStartPosition.f5 = RRy; PathStartPosition.f6 = RRz;

                    RobotCalc.RobotBaseRotation(PathMidPosition.f4, PathMidPosition.f5, PathMidPosition.f6, (float)WeldDirM[0], (float)WeldDirM[1], (float)WeldDirM[2], (float)Offset[3], out RRx, out RRy, out RRz);
                    PathMidPosition.f4 = RRx; PathMidPosition.f5 = RRy; PathMidPosition.f6 = RRz;

                    RobotCalc.RobotBaseRotation(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, (float)WeldDirE[0], (float)WeldDirE[1], (float)WeldDirE[2], (float)Offset[3], out RRx, out RRy, out RRz);
                    PathEndPosition.f4 = RRx; PathEndPosition.f5 = RRy; PathEndPosition.f6 = RRz;
                }

                //진행각 반영
                RobotCalc.RobotBaseRotation(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, (float)CrossS[0], (float)CrossS[1], (float)CrossS[2], (float)Offset[4], out RRx, out RRy, out RRz);
                PathStartPosition.f4 = RRx; PathStartPosition.f5 = RRy; PathStartPosition.f6 = RRz;

                RobotCalc.RobotBaseRotation(PathMidPosition.f4, PathMidPosition.f5, PathMidPosition.f6, (float)CrossM[0], (float)CrossM[1], (float)CrossM[2], (float)Offset[4], out RRx, out RRy, out RRz);
                PathMidPosition.f4 = RRx; PathMidPosition.f5 = RRy; PathMidPosition.f6 = RRz;

                RobotCalc.RobotBaseRotation(PathEndPosition.f4, PathEndPosition.f5, PathEndPosition.f6, (float)CrossE[0], (float)CrossE[1], (float)CrossE[2], (float)Offset[4], out RRx, out RRy, out RRz);
                PathEndPosition.f4 = RRx; PathEndPosition.f5 = RRy; PathEndPosition.f6 = RRz;

            }

        }


        public void ApplyWeldDB(WeldingCondition WDB, double[] Nor)
        {
            HCRRobotCommunication RobotCalc = new HCRRobotCommunication();

            this.WelVol = WDB.Vol;
            this.WeldAmp = WDB.Amp;
            this.WeldSpd = WDB.Spd;
            if (WDB.WeavingHz < 0.1)
            {
                this.Weaving = 0;
                this.WeavHz = WDB.WeavingHz;
            }
            else
            {
                this.Weaving = 1;
                this.WeavHz = WDB.WeavingHz;
            }
            this.WeavLength = WDB.WeavingWidth;


            //바닥이 왼쪽인지 오른쪽인지 판단하기위한 기준벡터 구함. 직선인 경우 입력벡터, 원호인 경우 원호회전축 벡터
            double[] NormalV = new double[] { 0, 0, 1 };
            double[] WeldDir = new double[] { 0, 0, 1 };
            double[] ToolDir = new double[] { 0, 0, 1 };

            if (PathType == 1)
            {
                RobotCalc.UnitVector(Nor, out NormalV);

                WeldDir = new double[] { PathEndPosition.f1 - PathStartPosition.f1, PathEndPosition.f2 - PathStartPosition.f2, PathEndPosition.f3 - PathStartPosition.f3 };

                //로봇 툴방향 계산
                double[] initMatrix;
                RobotCalc.MakeXYZAngleToRMatrix(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, out initMatrix);
                ToolDir = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };

            }else if(PathType == 2)
            {
                //세 점의 원호 중심 구함
                double[] midpoint;
                RobotCalc.CalcCircleCenter(new double[] { PathStartPosition.f1, PathStartPosition.f2, PathStartPosition.f3 },
                                           new double[] { PathMidPosition.f1, PathMidPosition.f2, PathMidPosition.f3 },
                                           new double[] { PathEndPosition.f1, PathEndPosition.f2, PathEndPosition.f3 }, out midpoint);

                //원호 중심에서 시작,중간,종료점까지의 벡터 구함
                double[] V_S, V_E;
                RobotCalc.UnitVector(new double[] { PathStartPosition.f1 - midpoint[0], PathStartPosition.f2 - midpoint[1], PathStartPosition.f3 - midpoint[2] }, out V_S);
                RobotCalc.UnitVector(new double[] { PathEndPosition.f1 - midpoint[0], PathEndPosition.f2 - midpoint[1], PathEndPosition.f3 - midpoint[2] }, out V_E);

                //중심에서 시작점 종료점벡터 외적해서 회전축 벡터 만듬
                RobotCalc.NormalVectorCalculation(V_S, V_E, out NormalV);

                //로봇 툴방향 계산
                double[] initMatrix;
                RobotCalc.MakeXYZAngleToRMatrix(PathStartPosition.f4, PathStartPosition.f5, PathStartPosition.f6, out initMatrix);
                ToolDir = new double[] { initMatrix[2], initMatrix[5], initMatrix[8] };

                RobotCalc.NormalVectorCalculation(NormalV, V_S, out WeldDir);
            }

            //바닥방향(작업각 +일때 기울일 방향)이 왼쪽인지 오른쪽인지 판단해야 함
            //토치방향벡터X바닥평면 노말벡터 결과벡터가 용접방향과 예각이면 오른쪽이 바닥. 둔각이면 왼쪽이 바닥임
            double[] tempV1;
            RobotCalc.NormalVectorCalculation(ToolDir, NormalV, out tempV1);
            if ((WeldDir[0] * tempV1[0] + WeldDir[1] * tempV1[1] + WeldDir[2] * tempV1[2]) < 0)
            {   //왼쪽이 바닥
                this.WeavLeftStopTime = WDB.WeavingFloorStop;
                this.WeavRightStopTime = WDB.WeavingWallStop;
                this.ArcSenWeightedFactorLeft = 1 - (WDB.BeadBias / 100);
                this.ArcSenWeightedFactorRight = 1 + (WDB.BeadBias / 100);
            }
            else
            {   //오른쪽이 바닥
                this.WeavRightStopTime = WDB.WeavingFloorStop;
                this.WeavLeftStopTime = WDB.WeavingWallStop;
                this.ArcSenWeightedFactorRight = 1 - (WDB.BeadBias / 100);
                this.ArcSenWeightedFactorLeft = 1 + (WDB.BeadBias / 100);
            }


        }
        
        
        
        public object Clone()
        {
            WeldMainCondition tempclone = new WeldMainCondition();

            tempclone.PathStartPosition = (RobotPoseData)(this.PathStartPosition.Clone());
            tempclone.PathMidPosition = (RobotPoseData)(this.PathMidPosition.Clone());
            tempclone.PathEndPosition = (RobotPoseData)(this.PathEndPosition.Clone());

            tempclone.PathType = this.PathType;
            tempclone.WelVol = this.WelVol;
            tempclone.WeldAmp = this.WeldAmp;
            tempclone.WeldSpd = this.WeldSpd;

            tempclone.Weaving = this.Weaving;
            tempclone.WeavHz = this.WeavHz;
            tempclone.WeavLength = this.WeavLength;
            tempclone.WeavLeftStopTime = this.WeavLeftStopTime;
            tempclone.WeavRightStopTime = this.WeavRightStopTime;

            tempclone.ArcSen = this.ArcSen;
            tempclone.ArcSenTimeShift = this.ArcSenTimeShift;
            tempclone.ArcSenHFactor = this.ArcSenHFactor;
            tempclone.ArcSenVFactor = this.ArcSenVFactor;
            tempclone.ArcSenHMaxdL = this.ArcSenHMaxdL;
            tempclone.ArcSenVMaxdL = this.ArcSenVMaxdL;
            tempclone.ArcSenHOncedL = this.ArcSenHOncedL;
            tempclone.ArcSenVOncedL = this.ArcSenVOncedL;
            tempclone.ArcSenWeightedFactorRight = this.ArcSenWeightedFactorRight;
            tempclone.ArcSenWeightedFactorLeft = this.ArcSenWeightedFactorLeft;

            for (int i = 0; i < 5; i++ )
            {
                tempclone.Offset[i] = this.Offset[i];
                //tempclone.OffsetM[i] = this.OffsetM[i];
                //tempclone.OffsetE[i] = this.OffsetE[i];
            }

            tempclone.NormalV[0] = this.NormalV[0];
            tempclone.NormalV[1] = this.NormalV[1];
            tempclone.NormalV[2] = this.NormalV[2];

            return tempclone;
        }
    }

    class WeldEndCondition : ICloneable
    {
        public double GasPostTime = 0;
        public double WeldEndTime = 0;
        public double WeldEndVol = 0;
        public double WeldEndAmp = 0;
        public double WeldEndLength = 0;
        List<RobotPoseData> EndPosition = new List<RobotPoseData>();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldEndCondition()
        {

        }

        /// <summary>
        /// 종료 아크조건 설정해주는 생성자
        /// </summary>
        /// <param name="gas">아크 종료후 후기가스시간</param>
        /// <param name="endt">크레이터 아크시간</param>
        /// <param name="endv">크레이터 아크전압</param>
        /// <param name="enda">크레이터 아크전류</param>
        /// <param name="endl">아크 종료후 후진거리</param>
        public WeldEndCondition(double gas, double endt, double endv, double enda, double endl)
        {
            GasPostTime = gas;
            WeldEndTime = endt;
            WeldEndVol = endv;
            WeldEndAmp = enda;
            WeldEndLength = endl;
            EndPosition = new List<RobotPoseData>();
        }



        /// <summary>
        /// 종료경로 리스트에 경로 추가하는 함수
        /// </summary>
        /// <param name="RobotPose">추가할 로봇 포즈</param>
        public void AddEndPosition(RobotPoseData RobotPose)
        {
            EndPosition.Add((RobotPoseData)RobotPose.Clone());
        }

        /// <summary>
        /// 종료경로 리스트에서 index번째 객체 복사해오는 함수
        /// </summary>
        /// <param name="index">복사해올 객체 인덱스</param>
        /// <returns>인덱스가 유효하면 로봇포즈 복사본 리턴, 유효하지 않으면 NULL 리턴</returns>
        public RobotPoseData GetEndPosition(int index)
        {
            if ((index >= 0) && (index < EndPosition.Count))
            {
                return (RobotPoseData)(EndPosition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 종료경로 리스트 개수 반환
        /// </summary>
        /// <returns>종료경로 리스트 개수</returns>
        public int GetEndPositionCount()
        {
            return EndPosition.Count;
        }

        /// <summary>
        /// 종료경로 리스트 초기화하는 함수
        /// </summary>
        public void ClearEndPosition()
        {
            EndPosition = new List<RobotPoseData>();
        }


        public object Clone()
        {
            WeldEndCondition tempdata = new WeldEndCondition();

            tempdata.GasPostTime = this.GasPostTime;
            tempdata.WeldEndTime = this.WeldEndTime;
            tempdata.WeldEndVol = this.WeldEndVol;
            tempdata.WeldEndAmp = this.WeldEndAmp;
            tempdata.WeldEndLength = this.WeldEndLength;

            for (int i = 0; i < this.EndPosition.Count; i++)
            {
                tempdata.EndPosition.Add(this.EndPosition[i]);
            }

            return tempdata;
        }

    }

    class WeldInformation : ICloneable
    {
        public bool ArcOnFlag; //용접을 할지 모션만 할지 선택
        public bool ContinueFlag = true; //용접 종료 후 멈추고자 할때 false 지정
        public bool MultipathFlag = false; // 해당 용접이 다층용접(초층제외)일경우 true 지정. 슬래그 털기 설정이 되어 있는 경우 이게 트루이면 용접 진행 안하고 대기함
        public int MultipathNumber = 1; // 다층용접인 경우 몇번째 용접인지 입력. 초층=1.

        public WeldStartCondition InitCondition = new WeldStartCondition();
        List<WeldMainCondition> MainCondition = new List<WeldMainCondition>();
        public WeldEndCondition EndCondition = new WeldEndCondition();

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public WeldInformation()
        {

        }

        /// <summary>
        /// 메인 용접정보 리스트에 객체 추가하는 함수
        /// </summary>
        /// <param name="tempWMC">메인컨디션 객체</param>
        public void AddMainCondition(WeldMainCondition tempWMC)
        {
            MainCondition.Add((WeldMainCondition)(tempWMC.Clone()));
        }

        /// <summary>
        /// 메인컨디션 리스트에서 index번째 객체 반환(복사본으로)
        /// </summary>
        /// <param name="index"></param>
        /// <returns>해당 인덱스번째 객체가 있으면 객체 복사본 반환. 그렇지 않으면 Null 반환</returns>
        public WeldMainCondition GetMainCondition(int index)
        {
            if ((index >= 0) && (index < MainCondition.Count))
            {
                return (WeldMainCondition)(MainCondition[index].Clone());
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 메인컨디션리스트의 객체 개수 반환
        /// </summary>
        /// <returns>리스트 객체 개수</returns>
        public int GetMainConditionCount()
        {
            return MainCondition.Count;
        }


        public void ClearMainCondition()
        {
            MainCondition = new List<WeldMainCondition>();
        }


        public object Clone()
        {
            WeldInformation tempclone = new WeldInformation();

            tempclone.ArcOnFlag = this.ArcOnFlag;
            tempclone.ContinueFlag = this.ContinueFlag;
            tempclone.MultipathFlag = this.MultipathFlag;
            tempclone.MultipathNumber = this.MultipathNumber;

            tempclone.InitCondition = (WeldStartCondition)this.InitCondition.Clone();
            tempclone.EndCondition = (WeldEndCondition)this.EndCondition.Clone();

            tempclone.MainCondition = new List<WeldMainCondition>();
            for (int i = 0; i < this.MainCondition.Count; i++)
            {
                tempclone.MainCondition.Add((WeldMainCondition)this.MainCondition[i].Clone());
            }

            return tempclone;
        }


        //용접 시작,종료오프셋 적용하는 함수
        public void ApplyOffset(double Offset_Start, double Offset_End)
        {
            //용접경로가 없으면 종료
            if (MainCondition.Count == 0) return;


            HCRRobotCommunication RobotCalc = new HCRRobotCommunication();


            if (Offset_Start>1)
            {
                if(MainCondition[0].PathType == 1)
                {//시작오프셋 - 직선경로 계산

                    //첫번째 용접선 용접 방향벡터 계산

                    //용접 방향벡터 계산. x y z (작업각 회전축)
                    double[] WeldDir;
                    RobotCalc.UnitVector(new double[] { MainCondition[0].GetEndPose().f1 - MainCondition[0].GetStartPose().f1, 
                                                        MainCondition[0].GetEndPose().f2 - MainCondition[0].GetStartPose().f2, 
                                                        MainCondition[0].GetEndPose().f3 - MainCondition[0].GetStartPose().f3 }, out WeldDir);

                    RobotPoseData temppose = MainCondition[0].GetStartPose();
                    temppose.f1 = (float)(temppose.f1 + WeldDir[0] * Offset_Start);
                    temppose.f2 = (float)(temppose.f2 + WeldDir[1] * Offset_Start);
                    temppose.f3 = (float)(temppose.f3 + WeldDir[2] * Offset_Start);
                    MainCondition[0].SetStartPose(temppose);

                }else if(MainCondition[0].PathType == 2)
                {//시작오프셋 원호경로 계산

                    //세 점의 원호 중심 구함
                    RobotPoseData temppose1 = MainCondition[0].GetStartPose();
                    RobotPoseData temppose2 = MainCondition[0].GetMidPose();
                    RobotPoseData temppose3 = MainCondition[0].GetEndPose();
                    double[] midpoint;
                    RobotCalc.CalcCircleCenter(new double[] { temppose1.f1, temppose1.f2, temppose1.f3 },
                                               new double[] { temppose2.f1, temppose2.f2, temppose2.f3 },
                                               new double[] { temppose3.f1, temppose3.f2, temppose3.f3 }, out midpoint);

                    //원의 반지름 구함
                    double r = Math.Sqrt((temppose1.f1 - midpoint[0]) * (temppose1.f1 - midpoint[0]) +
                                         (temppose1.f2 - midpoint[1]) * (temppose1.f2 - midpoint[1]) +
                                         (temppose1.f3 - midpoint[2]) * (temppose1.f3 - midpoint[2]));

                    //계산한 반지름에서 해당 오프셋 길이를 만들기위한 각도 구함
                    double th = (Offset_Start / r) * (180 / Math.PI);

                    //중심에서 시작점 종료점벡터 외적해서 회전축 벡터 만듬
                    double rox, roy, roz;
                    RobotCalc.VectorCrossProduct(temppose1.f1 - midpoint[0], temppose1.f2 - midpoint[1], temppose1.f3 - midpoint[2],
                                                 temppose3.f1 - midpoint[0], temppose3.f2 - midpoint[1], temppose3.f3 - midpoint[2], out rox, out roy, out roz);


                    //원호중심->시작점 벡터를 회전축벡터로 각도만큼 회전시킨 벡터 구함
                    double offsetVx, offsetVy, offsetVz;
                    RobotCalc.CalcVectorRotation(temppose1.f1 - midpoint[0], temppose1.f2 - midpoint[1], temppose1.f3 - midpoint[2],
                                                 rox, roy, roz, th, out offsetVx, out offsetVy, out offsetVz);

                    //회전된 벡터에 원호중심 더해서 실제 좌표 구하고 해당 위치를 용접시작 위치로 저장
                    temppose1.f1 = (float)(midpoint[0] + offsetVx);
                    temppose1.f2 = (float)(midpoint[1] + offsetVy);
                    temppose1.f3 = (float)(midpoint[2] + offsetVz);
                    MainCondition[0].SetStartPose(temppose1);

                }

            }


            if (Offset_End > 1)
            {
                int Lasti = MainCondition.Count - 1;

                if (MainCondition[Lasti].PathType == 1)
                {//종료오프셋 - 직선경로 계산

                    //마지막 용접선 용접 방향벡터 계산

                    //용접 방향벡터 계산. x y z (작업각 회전축)
                    
                    double[] WeldDir;
                    RobotCalc.UnitVector(new double[] { MainCondition[Lasti].GetEndPose().f1 - MainCondition[Lasti].GetStartPose().f1, 
                                                        MainCondition[Lasti].GetEndPose().f2 - MainCondition[Lasti].GetStartPose().f2, 
                                                        MainCondition[Lasti].GetEndPose().f3 - MainCondition[Lasti].GetStartPose().f3 }, out WeldDir);

                    RobotPoseData temppose = MainCondition[Lasti].GetEndPose();
                    temppose.f1 = (float)(temppose.f1 - WeldDir[0] * Offset_End);
                    temppose.f2 = (float)(temppose.f2 - WeldDir[1] * Offset_End);
                    temppose.f3 = (float)(temppose.f3 - WeldDir[2] * Offset_End);
                    MainCondition[Lasti].SetEndPose(temppose);

                }
                else if (MainCondition[Lasti].PathType == 2)
                {//종료오프셋 원호경로 계산

                    //세 점의 원호 중심 구함
                    RobotPoseData temppose1 = MainCondition[Lasti].GetStartPose();
                    RobotPoseData temppose2 = MainCondition[Lasti].GetMidPose();
                    RobotPoseData temppose3 = MainCondition[Lasti].GetEndPose();
                    double[] midpoint;
                    RobotCalc.CalcCircleCenter(new double[] { temppose1.f1, temppose1.f2, temppose1.f3 },
                                               new double[] { temppose2.f1, temppose2.f2, temppose2.f3 },
                                               new double[] { temppose3.f1, temppose3.f2, temppose3.f3 }, out midpoint);

                    //원의 반지름 구함
                    double r = Math.Sqrt((temppose1.f1 - midpoint[0]) * (temppose1.f1 - midpoint[0]) +
                                         (temppose1.f2 - midpoint[1]) * (temppose1.f2 - midpoint[1]) +
                                         (temppose1.f3 - midpoint[2]) * (temppose1.f3 - midpoint[2]));

                    //계산한 반지름에서 해당 오프셋 길이를 만들기위한 각도 구함
                    double th = (Offset_Start / r) * (180 / Math.PI);

                    //중심에서 시작점 종료점벡터 외적해서 회전축 벡터 만듬
                    double rox, roy, roz;
                    RobotCalc.VectorCrossProduct(temppose1.f1 - midpoint[0], temppose1.f2 - midpoint[1], temppose1.f3 - midpoint[2],
                                                 temppose3.f1 - midpoint[0], temppose3.f2 - midpoint[1], temppose3.f3 - midpoint[2], out rox, out roy, out roz);


                    //원호중심->종료점 벡터를 회전축벡터로 -각도만큼 회전시킨 벡터 구함
                    double offsetVx, offsetVy, offsetVz;
                    RobotCalc.CalcVectorRotation(temppose3.f1 - midpoint[0], temppose3.f2 - midpoint[1], temppose3.f3 - midpoint[2],
                                                 rox, roy, roz, -th, out offsetVx, out offsetVy, out offsetVz);

                    //회전된 벡터에 원호중심 더해서 실제 좌표 구하고 해당 위치를 용접시작 위치로 저장
                    temppose3.f1 = (float)(midpoint[0] + offsetVx);
                    temppose3.f2 = (float)(midpoint[1] + offsetVy);
                    temppose3.f3 = (float)(midpoint[2] + offsetVz);
                    MainCondition[Lasti].SetEndPose(temppose3);

                }

            }

        }



        public WeldInformation ReverseInfo()
        {
            WeldInformation ResultInfo = (WeldInformation)this.Clone();

            //시작경로,종료경로 뒤집어 넣기
            ResultInfo.InitCondition.ClearStartPosition();
            int endposecount = this.EndCondition.GetEndPositionCount();
            for (int i = endposecount - 1; i >= 0; i--)
            {
                RobotPoseData temppose = this.EndCondition.GetEndPosition(i);
                if ((temppose.PoseType == 3) || (temppose.PoseType == 4)) continue;
                ResultInfo.InitCondition.AddStartPosition(temppose);
            }

            ResultInfo.EndCondition.ClearEndPosition();
            ResultInfo.EndCondition.AddEndPosition(new RobotPoseData(3, 50, -1, 0, 0, 0, 0, 0));
            int initposecount = this.InitCondition.GetStartPositionCount();
            for (int i = initposecount - 1; i >= 0; i--)
            {
                RobotPoseData temppose = this.InitCondition.GetStartPosition(i);
                if ((temppose.PoseType == 3) || (temppose.PoseType == 4)) continue;
                ResultInfo.EndCondition.AddEndPosition(temppose);
            }

            //메인경로 시작점 종료점 뒤바꿈
            int mainweldcount = this.MainCondition.Count;
            for (int i = 0; i < mainweldcount; i++)
            {
                ResultInfo.MainCondition[i].SetStartPose(this.MainCondition[i].GetEndPose());
                ResultInfo.MainCondition[i].SetEndPose(this.MainCondition[i].GetStartPose());
            }
            ResultInfo.MainCondition.Reverse();

            return ResultInfo;
        }



        //용접선 길이 리턴하는 함수 단위 밀리미터
        public double CalcWeldLength()
        {
            double length = 0;

            HCRRobotCommunication calcRobotFuc = new HCRRobotCommunication();

            //용접경로가 라인 몇개로 구성되있는지 체크
            int count = this.GetMainConditionCount();

            for (int i = 0; i < count; i++)
            {
                double Vx, Vy, Vz, SingleL;
                calcRobotFuc.RobotStartEndToDirCal(MainCondition[i].GetStartPose(), MainCondition[i].GetEndPose(), out Vx, out Vy, out Vz, out SingleL);
                length = length + SingleL;
            }

                return length;
        }


        //추정 용접시간 리턴하는 함수. 단위 초
        public double CalcWeldTime()
        {
            double time = 0;

            HCRRobotCommunication calcRobotFuc = new HCRRobotCommunication();

            //용접경로가 라인 몇개로 구성되있는지 체크
            int count = this.GetMainConditionCount();

            for (int i = 0; i < count; i++)
            {
                double Vx, Vy, Vz, SingleL;
                calcRobotFuc.RobotStartEndToDirCal(MainCondition[i].GetStartPose(), MainCondition[i].GetEndPose(), out Vx, out Vy, out Vz, out SingleL);

                double Speed = (MainCondition[i].WeldSpd / ((MainCondition[i].WeavLeftStopTime + MainCondition[i].WeavRightStopTime) * MainCondition[i].WeavHz + 1))/6;

                time = time + SingleL / Speed;

            }

            return time;
        }


    }

    class TouchSensingData : ICloneable
    {
        //터치센싱 진입데이터
        public int In_coord; //방향벡터의 기준좌표계 1:베이스, 2:툴,
        public float In_X; //방향벡터 성분 중 x
        public float In_Y; //방향벡터 성분 중 y
        public float In_Z; //방향벡터 성분 중 z
        public float In_Length; //벡터 방향으로 진행하는 거리
        public float In_Speed; //진행 속도

        //터치센싱 완료 후 복귀데이터
        public int Out_coord; //방향벡터의 기준좌표계 1:베이스, 2:툴,
        public float Out_X; //방향벡터 성분 중 x
        public float Out_Y; //방향벡터 성분 중 y
        public float Out_Z; //방향벡터 성분 중 z
        public float Out_Length; //벡터 방향으로 진행하는 거리
        public float Out_Speed; //진행 속도

        /// <summary>
        /// 기본 생성자
        /// </summary>
        public TouchSensingData()
        {

        }

        /// <summary>
        /// 터치관련 인자 바로 넣는 생성자
        /// </summary>
        /// <param name="iLength">서칭거리(mm)</param>
        /// <param name="iSpeed">서칭속도(mm/s)</param>
        /// <param name="iCoord">방향벡터 좌표계, 1:베이스좌표계, 2:툴좌표계</param>
        /// <param name="iX">방향벡터 X성분</param>
        /// <param name="iY">방향벡터 Y성분</param>
        /// <param name="iZ">방향벡터 Z성분</param>
        /// <param name="oLength">복귀거리(mm)</param>
        /// <param name="oSpeed">복귀속도(mm/s)</param>
        /// <param name="oCoord">방향벡터 좌표계, 1:베이스좌표계, 2:툴좌표계</param>
        /// <param name="oX">방향벡터 X성분</param>
        /// <param name="oY">방향벡터 Y성분</param>
        /// <param name="oZ">방향벡터 Z성분</param>
        public TouchSensingData(double iLength, double iSpeed, int iCoord, double iX, double iY, double iZ, double oLength, double oSpeed, int oCoord, double oX, double oY, double oZ)
        {
            In_Length = (float)iLength;
            In_Speed = (float)iSpeed;
            In_coord = iCoord;
            In_X = (float)iX;
            In_Y = (float)iY;
            In_Z = (float)iZ;

            Out_Length = (float)oLength;
            Out_Speed = (float)oSpeed;
            Out_coord = oCoord;
            Out_X = (float)oX;
            Out_Y = (float)oY;
            Out_Z = (float)oZ;
        }

        public object Clone()
        {
            TouchSensingData temp = new TouchSensingData();

            temp.In_coord = this.In_coord;
            temp.In_X = this.In_X;
            temp.In_Y = this.In_Y;
            temp.In_Z = this.In_Z;
            temp.In_Length = this.In_Length;
            temp.In_Speed = this.In_Speed;

            temp.Out_coord = this.Out_coord;
            temp.Out_X = this.Out_X;
            temp.Out_Y = this.Out_Y;
            temp.Out_Z = this.Out_Z;
            temp.Out_Length = this.Out_Length;
            temp.Out_Speed = this.Out_Speed;

            return temp;
        }


    }

    class WeldingCondition : ICloneable
    {
        public double Vol;
        public double Amp;
        public double Spd;
        public double Offset_WorkAngle;
        public double Offset_TravelAngle;
        public double Offset_X;
        public double Offset_Y;
        public double Offset_Z;
        public double WeavingHz;
        public double WeavingWidth;
        public double WeavingFloorStop;
        public double WeavingWallStop;
        public int ArcSen;
        public double BeadBias;


        public object Clone()
        {
            WeldingCondition temp = new WeldingCondition();

            temp.Vol = this.Vol;
            temp.Amp = this.Amp;
            temp.Spd = this.Spd;
            temp.Offset_WorkAngle = this.Offset_WorkAngle;
            temp.Offset_TravelAngle = this.Offset_TravelAngle;
            temp.Offset_X = this.Offset_X;
            temp.Offset_Y = this.Offset_Y;
            temp.Offset_Z = this.Offset_Z;
            temp.WeavingHz = this.WeavingHz;
            temp.WeavingWidth = this.WeavingWidth;
            temp.WeavingFloorStop = this.WeavingFloorStop;
            temp.WeavingWallStop = this.WeavingWallStop;
            temp.ArcSen = this.ArcSen;
            temp.BeadBias = this.BeadBias;

            return temp;
        }

    }


}
